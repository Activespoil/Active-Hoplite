import hashlib
import json
import zipfile
from pathlib import Path

root = Path(__file__).resolve().parent
jar_path = root / "build" / "cosmetics" / "libs" / "lin-cosmetics-v1.0.0.jar"
art_dir = root / "artifacts"
art_dir.mkdir(parents=True, exist_ok=True)


def pack(src_zip: zipfile.ZipFile, dst_path: Path, extra=None):
    extra = extra or {}
    with zipfile.ZipFile(dst_path, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as zout:
        for name in sorted(set(src_zip.namelist()) | set(extra.keys())):
            if name.endswith("/"):
                continue
            info = zipfile.ZipInfo(name, (1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            zout.writestr(info, extra[name] if name in extra else src_zip.read(name))


with zipfile.ZipFile(jar_path) as z:
    assert z.testzip() is None, "Corrupt JAR!"
    names = set(z.namelist())
    print("Total entries:", len(names))
    jars = sorted(n for n in names if n.startswith("META-INF/jars/"))
    print("Embedded jars:", jars)

    forbidden = [
        n
        for n in names
        if any(
            k in n
            for k in [
                "ServerAuth",
                "yun/shan/musicplayer",
                "LegendWatch",
                "DynamicIsland",
                "NewSettingsScreen",
                "HudEditorScreen",
                "LinClientMainUI",
                "NickHider",
                "lyricpulse",
                "linclient-modules.jar",
                "LinHubScreen",
            ]
        )
    ]
    assert not forbidden, f"Forbidden entries found: {forbidden}"

    required = [
        "com/linclient/client/presence/LinPresence.class",
        "com/linclient/client/presence/CosmeticSyncClient.class",
        "com/linclient/client/presence/LinBadge.class",
        "com/linclient/client/presence/LinBadgeChat.class",
        "com/linclient/client/auth/VerifiedHttps.class",
        "com/linclient/client/auth/SpringAuthorization.class",
        "com/linclient/mixin/client/LinBadgeTabMixin.class",
        "com/linclient/mixin/client/LinBadgeNametagMixin.class",
        "com/linclient/mixin/client/ChatVipMessageMixin.class",
        "com/linclient/mixin/client/ChatVipSignedMixin.class",
        "com/linclient/mixin/client/GuiRenderPerformanceMixin.class",
        "com/linclient/mixin/client/MinecraftCosmeticsMixin.class",
        "dev/lin/client/cosmetics/LinClient.class",
        "dev/lin/client/cosmetics/ui/CosmeticLockerScreen.class",
        "dev/lin/client/cosmetics/ui/ClientShell.class",
        "dev/lin/client/features/LinFeatures.class",
        "assets/linclient/font/peer_badge.json",
        "assets/linclient/textures/font/peer_badge.png",
        "lin-server-auth.properties",
    ]
    missing = [r for r in required if r not in names]
    assert not missing, f"Missing required entries: {missing}"

    fmod = json.loads(z.read("fabric.mod.json"))
    for mfile in fmod["mixins"]:
        mcfg = json.loads(z.read(mfile))
        pkg = mcfg["package"].replace(".", "/")
        for cls in mcfg.get("client", []) + mcfg.get("mixins", []):
            cpath = f"{pkg}/{cls.replace('.', '/')}.class"
            assert cpath in names, f"Missing mixin class {cpath} from {mfile}"
    print("All fabric.mod.json mixins verified!")

    normal_path = art_dir / "lin-cosmetics-online.jar"
    lunar_path = art_dir / "lin-cosmetics-lunar.jar"
    pack(z, normal_path)
    pack(
        z,
        lunar_path,
        {
            "lin-native-menus.marker": b"Use native Lunar menus. Shared Lin cosmetics remain enabled.\n"
        },
    )


def sha(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


sums = "".join(f"{sha(p)}  {p.name}\n" for p in sorted(art_dir.glob("*.jar")))
(art_dir / "SHA256SUMS.txt").write_text(sums, encoding="utf-8")
for p in sorted(art_dir.glob("*.jar")):
    print(f"{p.name}: {p.stat().st_size / (1024 * 1024):.2f} MB  SHA256={sha(p)}")
