package dev.lin.client.features.render;

import java.util.Locale;
import net.minecraft.client.Minecraft;
import net.minecraft.world.scores.DisplaySlot;
import net.minecraft.world.scores.PlayerTeam;

/** Headwear-only gate. Scan at most twice per second; never changes saved selections. */
public final class KingmcHeadwearContext {
    private static Object level;
    private static long scannedAt = Long.MIN_VALUE;
    private static boolean active;
    public static boolean isActive(Minecraft client) {
        if (client.level == null || client.hasSingleplayerServer()) {
            level = null; active = false; return false;
        }
        long now = client.level.getGameTime();
        if (level == client.level && now >= scannedAt && now - scannedAt < 10) return active;
        level = client.level; scannedAt = now;
        var server = client.getCurrentServer();
        active = server != null && matches(server.ip);
        if (active) return true;
        var board = client.level.getScoreboard();
        var objective = board.getDisplayObjective(DisplaySlot.SIDEBAR);
        if (client.player != null) {
            var team = board.getPlayersTeam(client.player.getScoreboardName());
            var slot = team == null ? null : DisplaySlot.teamColorToSlot(team.getColor());
            var colored = slot == null ? null : board.getDisplayObjective(slot);
            if (colored != null) objective = colored;
        }
        if (objective == null) return false;
        active = matches(objective.getDisplayName().getString());
        if (!active) for (var entry : board.listPlayerScores(objective)) {
            if (entry.owner().startsWith("#")) continue;
            var name = entry.display() == null ? entry.ownerName() : entry.display();
            if (matches(PlayerTeam.formatNameForTeam(board.getPlayersTeam(entry.owner()), name).getString())) {
                active = true; break;
            }
        }
        return active;
    }
    static boolean matches(String text) {
        return text != null && java.text.Normalizer.normalize(text, java.text.Normalizer.Form.NFKC)
                .replaceAll("(?i)§[0-9a-fk-orx]", "").replaceAll("[\\p{Cf}\\s\\p{Zs}]", "")
                .toLowerCase(Locale.ROOT).contains("kingmc");
    }
}
