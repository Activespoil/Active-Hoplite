package dev.lin.client.features.mixin;
import dev.lin.client.features.render.AccessoryItemModels;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.item.ItemModelResolver;
import net.minecraft.client.renderer.item.ItemStackRenderState;
import net.minecraft.world.entity.ItemOwner;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
@Mixin(ItemModelResolver.class)
public abstract class BoundHeadwearModelMixin {
    @ModifyVariable(method = "updateForTopItem", at = @At("HEAD"), argsOnly = true, ordinal = 0)
    private ItemStack lin$boundHeadwear(ItemStack value, ItemStackRenderState state, ItemStack original,
            ItemDisplayContext context, Level level, ItemOwner owner, int seed) {
        if (context == ItemDisplayContext.GROUND || context == ItemDisplayContext.FIXED
                || (owner != null && owner != Minecraft.getInstance().player)) return value;
        return AccessoryItemModels.replaceDefaultHelmetIcon(value);
    }
}
