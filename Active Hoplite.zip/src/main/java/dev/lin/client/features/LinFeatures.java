package dev.lin.client.features;

import dev.lin.client.features.accessory.AccessoryRegistry;
import dev.lin.client.features.artifact.ArtifactSkinConfig;
import dev.lin.client.features.artifact.ArtifactSkins;
import dev.lin.client.features.cape.LunarCapeRegistry;
import dev.lin.client.features.cape.LunarCapeTextureManager;
import dev.lin.client.features.config.ClientAccessoryConfig;
import dev.lin.client.features.font.FontManager;
import dev.lin.client.features.pet.LunarPetRegistry;
import dev.lin.client.features.pet.LunarPetTextureManager;
import dev.lin.client.features.render.AccessoryItemModels;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.Minecraft;

public final class LinFeatures implements ClientModInitializer {
   public static final String MOD_ID = "lin_client";

   @Override
   public void onInitializeClient() {
      AccessoryRegistry.load();
      LunarCapeRegistry.load();
      LunarPetRegistry.load();
      ArtifactSkinConfig.load();
      ClientAccessoryConfig.load();
      dev.lin.client.cosmetics.emote.EmoteConfig.load();
      if (!dev.lin.client.cosmetics.emote.EmoteConfig.defaultCapeInitialized()) {
         if (!java.nio.file.Files.isRegularFile(net.fabricmc.loader.api.FabricLoader.getInstance()
               .getConfigDir().resolve("lin-client.properties"))) {
            LunarCapeRegistry.select(LunarCapeRegistry.DEFAULT_ID);
            ClientAccessoryConfig.save();
         }
         dev.lin.client.cosmetics.emote.EmoteConfig.markDefaultCapeInitialized();
      }
      ClientTickEvents.END_CLIENT_TICK.register(LinFeatures::tick);
   }

   private static void tick(Minecraft minecraft) {
      LunarCapeTextureManager.tick();
      dev.lin.client.features.artifact.HopliteServerContext.tick(minecraft);
      dev.lin.client.features.artifact.ArtifactProjectileRenderer.tick(minecraft);
   }

   public static void closeClientResources() {
      FontManager.close();
      AccessoryItemModels.clear();
      ArtifactSkins.clear();
      LunarCapeTextureManager.close();
      LunarPetTextureManager.close();
   }
}
