package dev.lin.client.features.render;

import dev.lin.client.features.accessory.AccessoryDefinition;
import dev.lin.client.features.accessory.AccessoryRegistry;
import dev.lin.client.features.accessory.AccessorySlot;
import dev.lin.client.features.accessory.HeadwearVariant;
import dev.lin.client.features.accessory.HeadwearScope;
import dev.lin.client.features.artifact.HopliteServerContext;
import dev.lin.client.features.trim.LinTrimManager;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.core.component.DataComponents;
import net.minecraft.resources.Identifier;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.CustomModelData;
import net.minecraft.tags.ItemTags;

public final class AccessoryItemModels {
   private static final ThreadLocal<Boolean> RENDERING_DROPPED_ICON = ThreadLocal.withInitial(() -> false);

   public static void setRenderingDroppedIcon(boolean value) {
      RENDERING_DROPPED_ICON.set(value);
   }

   public static boolean isRenderingDroppedIcon() {
      return RENDERING_DROPPED_ICON.get();
   }
   private static boolean renderingNametag;

   public static boolean setRenderingNametag(boolean value) {
      boolean previous = renderingNametag; renderingNametag = value; return previous;
   }

   public static ItemStack nametagHead(ItemStack original, boolean self) {
      return nametagHeadSource(original, self).copyWithCount(1);
   }

   public static boolean hasNametagHead(ItemStack original, boolean self) {
      return !nametagHeadSource(original, self).isEmpty();
   }

   /** Read the live source without a copy; snapshot caches copy only on a change. */
   public static ItemStack nametagHeadSource(ItemStack original, boolean self) {
      if (self) {
         var selected = AccessoryRegistry.selected(AccessorySlot.HEADWEAR);
         if (selected != null && shouldReplaceHeadwear(original, true) && BoundHeadwear.matches(original)) {
            return stack(selected);
         }
      }
      return original;
   }

   public static boolean shouldReplaceWorldHelmet(ItemStack original) {
      return shouldReplaceHeadwear(original, false) && BoundHeadwear.matches(original);
   }

   public static boolean isEligibleHeadwear(ItemStack original) {
      return !original.isEmpty() && shouldReplaceHeadwear(original, false);
   }

   private static boolean shouldReplaceHeadwear(ItemStack original, boolean nametag) {
      return shouldReplaceHeadwear(original,nametag,AccessoryRegistry.headwearScope());
   }
   public static boolean shouldReplaceRemoteHelmet(ItemStack original,HeadwearScope scope) {
      return shouldReplaceHeadwear(original,false,scope);
   }
   private static boolean shouldReplaceHeadwear(ItemStack original,boolean nametag,HeadwearScope scope) {
      boolean hoplite = HopliteServerContext.isActive();
      boolean kingmc = KingmcHeadwearContext.isActive(net.minecraft.client.Minecraft.getInstance());
      return switch (scope) {
         case HOPLITE -> hoplite && (nametag ? !original.isEmpty() : isServerDefaultHelmet(original));
         case KINGMC -> kingmc && (nametag || !original.is(ItemTags.HEAD_ARMOR));
         case GLOBAL -> original.is(ItemTags.HEAD_ARMOR)
            || (hoplite && (nametag ? !original.isEmpty() : isServerDefaultHelmet(original)))
            || (kingmc && (nametag || !original.is(ItemTags.HEAD_ARMOR)));
      };
   }

   private static final float DEFAULT_HELMET_MODEL_DATA = 26.0F;
   private static final Identifier HEADWEAR_ITEM_MODEL = itemModel(AccessorySlot.HEADWEAR);
   private static final Identifier SHINY_HEADWEAR_ITEM_MODEL = itemModel(AccessorySlot.HEADWEAR, HeadwearVariant.SHINY);
   private static final Map<ModelKey, ItemStack> STACKS = new ConcurrentHashMap<>();

   private AccessoryItemModels() {
   }

   public static ItemStack stack(AccessoryDefinition definition) {
      return stack(definition, AccessoryRegistry.headwearVariant(definition));
   }

   public static ItemStack stack(AccessoryDefinition definition, HeadwearVariant variant) {
      HeadwearVariant resolved = definition.slot() == AccessorySlot.HEADWEAR && variant != null ? variant : HeadwearVariant.NORMAL;
      return STACKS.computeIfAbsent(new ModelKey(definition, resolved), AccessoryItemModels::createStack);
   }

   public static ItemStack replaceDefaultHelmetIcon(ItemStack original) {
      var selected = AccessoryRegistry.selected(AccessorySlot.HEADWEAR);
      if (selected == null || isRenderingDroppedIcon() || !isEligibleHeadwear(original)
          || !BoundHeadwear.matches(original)) return original;
      return stack(selected);
   }

   public static boolean isServerDefaultHelmet(ItemStack stack) {
      if (stack.is(Items.COAL)
         && !HEADWEAR_ITEM_MODEL.equals(stack.get(DataComponents.ITEM_MODEL))
         && !SHINY_HEADWEAR_ITEM_MODEL.equals(stack.get(DataComponents.ITEM_MODEL))) {
         CustomModelData modelData = stack.get(DataComponents.CUSTOM_MODEL_DATA);
         Float value = modelData == null ? null : modelData.getFloat(0);
         return value != null && value >= 26.0F && value < 27.0F;
      } else {
         return false;
      }
   }

   public static void clear() {
      STACKS.clear();
   }

   private static ItemStack createStack(ModelKey key) {
      AccessoryDefinition definition = key.definition();
      ItemStack stack = new ItemStack(switch (definition.slot()) {
         case HEADWEAR -> Items.COAL;
         case WINGS -> Items.BLAZE_POWDER;
         case FLOATING -> Items.PRISMARINE_CRYSTALS;
      });
      stack.set(DataComponents.ITEM_MODEL, itemModel(definition.slot(), key.variant()));
      stack.set(DataComponents.CUSTOM_MODEL_DATA, new CustomModelData(List.of((float)definition.customModelData()), List.of(), List.of(), List.of()));
      if (definition.slot() == AccessorySlot.HEADWEAR && key.variant() == HeadwearVariant.SHINY) {
         stack.set(DataComponents.ENCHANTMENT_GLINT_OVERRIDE, true);
      }
      return stack;
   }

   private static Identifier itemModel(AccessorySlot slot) {
      return itemModel(slot, HeadwearVariant.NORMAL);
   }

   private static Identifier itemModel(AccessorySlot slot, HeadwearVariant variant) {
      if (slot == AccessorySlot.HEADWEAR && variant == HeadwearVariant.SHINY) {
         return Identifier.fromNamespaceAndPath("lin_client", "headwear_shiny");
      }

      String path = switch (slot) {
         case HEADWEAR -> "headwear";
         case WINGS -> "wings";
         case FLOATING -> "floating";
      };
      return Identifier.fromNamespaceAndPath("lin_client", path);
   }

   private record ModelKey(AccessoryDefinition definition, HeadwearVariant variant) {
   }
}
