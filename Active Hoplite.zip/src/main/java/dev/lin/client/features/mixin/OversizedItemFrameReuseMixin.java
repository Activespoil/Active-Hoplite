package dev.lin.client.features.mixin;

import com.mojang.blaze3d.vertex.PoseStack;
import dev.lin.client.features.render.GuiRasterFrame;
import net.minecraft.client.gui.render.pip.OversizedItemRenderer;
import net.minecraft.client.gui.render.state.pip.OversizedItemRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Mirror the normal vanilla item atlas: an animated identity is rasterized once per GUI pass. */
@Mixin(OversizedItemRenderer.class)
public abstract class OversizedItemFrameReuseMixin {
    @Shadow private Object modelOnTextureIdentity;
    @Unique private long lin$lastRasterFrame=Long.MIN_VALUE;

    @Inject(method="renderToTexture(Lnet/minecraft/client/gui/render/state/pip/OversizedItemRenderState;Lcom/mojang/blaze3d/vertex/PoseStack;)V",at=@At("RETURN"))
    private void lin$rememberRaster(OversizedItemRenderState state,PoseStack pose,CallbackInfo ci) {
        lin$lastRasterFrame=GuiRasterFrame.current();
    }

    @Inject(method="textureIsReadyToBlit(Lnet/minecraft/client/gui/render/state/pip/OversizedItemRenderState;)Z",at=@At("HEAD"),cancellable=true)
    private void lin$reuseSameFrame(OversizedItemRenderState state,CallbackInfoReturnable<Boolean> cir) {
        var item=state.guiItemRenderState().itemStackRenderState();
        // PictureInPictureRenderer has already checked that the raster dimensions match.
        // Retain vanilla model identity (including selection/tint/foil) and reload invalidation.
        if(item.isAnimated() && lin$lastRasterFrame==GuiRasterFrame.current()
                && modelOnTextureIdentity!=null && item.getModelIdentity().equals(modelOnTextureIdentity))
            cir.setReturnValue(true);
    }
}
