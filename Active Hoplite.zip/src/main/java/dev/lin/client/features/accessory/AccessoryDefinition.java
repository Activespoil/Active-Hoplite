package dev.lin.client.features.accessory;

import java.util.Objects;

public record AccessoryDefinition(AccessorySlot slot, String id, String displayName, String modelPath, int customModelData) {
   public AccessoryDefinition {
      Objects.requireNonNull(slot, "slot");
      if (id == null || id.isBlank()) {
         throw new IllegalArgumentException("id");
      }

      if (displayName == null || displayName.isBlank()) {
         throw new IllegalArgumentException("displayName");
      }

      if (modelPath == null || modelPath.isBlank()) {
         throw new IllegalArgumentException("modelPath");
      }

      if (customModelData < 1) {
         throw new IllegalArgumentException("customModelData");
      }
   }
}
