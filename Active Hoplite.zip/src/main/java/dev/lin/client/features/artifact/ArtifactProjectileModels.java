package dev.lin.client.features.artifact;

import net.minecraft.core.component.DataComponents;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.ItemOwner;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.item.ItemStack;

/** Flight models retain the pack's animated geometry instead of selecting a held/charged model. */
public final class ArtifactProjectileModels {
    private ArtifactProjectileModels() {}

    public static LivingEntity livingOwner(ItemOwner owner) {
        if (!(owner instanceof Entity entity)) return owner == null ? null : owner.asLivingEntity();
        // Server display/armor-stand projectiles can ride the actual projectile entity.
        for (int depth = 0; entity != null && depth < 8; depth++) {
            if (entity instanceof Projectile projectile) entity = projectile.getOwner();
            else if (entity.getVehicle() instanceof Projectile projectile) entity = projectile.getOwner();
            else if (entity instanceof LivingEntity living) return living;
            else entity = entity.getVehicle();
        }
        return null;
    }

    public static Identifier model(ArtifactSkins.Option selected, int sourceCmd) {
        if (selected == null || ArtifactSkins.isServerDefault(selected)) return null;
        if (selected.id().startsWith("custom:")) {
            // This imported trident has different held, charging and flight geometry.
            if (selected.id().equals("custom:lin_abyss_trident")) return id("abyss_trident");
            if (selected.id().equals("custom:legendary_poseidon_trident_normal_default_bow")) {
                return Identifier.parse("lin_artifacts:custom/legendary_poseidon_trident_normal_default_hand");
            }
            return selected.worldModel();
        }
        return switch (HopliteSkinCatalog.group(selected)) {
            case "aiglos:default" -> id("aiglos_normal");
            case "poseidon_trident:default" -> id("poseidon_normal");
            case "harpoon_launcher:default" -> id("harpoon_normal");
            case "ribbit_reel:default" -> id("ribbit_normal");
            case "sceptre_of_arachne:default" -> id(sourceCmd == 6 || sourceCmd == 13
                    || sourceCmd == 31 || sourceCmd == 35 ? "arachne_normal_on" : "arachne_normal_off");
            case "aiglos:serpentine" -> id("aiglos_serpentine");
            case "poseidon_trident:guardian" -> id("poseidon_guardian");
            case "harpoon_launcher:horn" -> id("harpoon_horn");
            case "harpoon_launcher:ender" -> id("harpoon_ender");
            case "ribbit_reel:valentine" -> id("ribbit_valentine");
            case "ribbit_reel:scarecrow" -> id("ribbit_scarecrow");
            case "sceptre_of_arachne:undead" -> id(sourceCmd == 6 || sourceCmd == 13
                    || sourceCmd == 31 || sourceCmd == 35 ? "arachne_undead_on" : "arachne_undead_off");
            // Unrelated weapons must never turn an ordinary arrow into a held model.
            default -> null;
        };
    }

    private static Identifier id(String name) {
        return Identifier.fromNamespaceAndPath("lin_client", "artifact_projectile/" + name);
    }

    /** A render-only copy; never change the network/inventory stack's item components. */
    public static ItemStack forEntity(ItemStack stack, Entity entity) {
        Identifier original = stack.get(DataComponents.ITEM_MODEL);
        Identifier selected = ArtifactSkinModelPolicy.selectModel(original, entity, stack);
        if (selected == null || selected.equals(original)) return stack;
        ItemStack copy = stack.copy();
        copy.set(DataComponents.ITEM_MODEL, selected);
        return copy;
    }
}
