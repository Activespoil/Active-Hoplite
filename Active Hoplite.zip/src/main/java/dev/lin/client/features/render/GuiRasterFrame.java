package dev.lin.client.features.render;

/** Render-thread-only boundary for the existing vanilla GUI item surfaces. */
public final class GuiRasterFrame {
    private static long frame;
    private GuiRasterFrame() {}
    public static void advance() {frame++;}
    public static long current() {return frame;}
}
