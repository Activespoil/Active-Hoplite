package dev.lin.client.features.artifact;

import com.google.gson.Gson;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import net.minecraft.resources.Identifier;

final class HopliteSkinCatalog {
    private static final Map<String,String> GROUPS = loadGroups();
    private static Map<String,String> loadGroups() {
        try (var stream = HopliteSkinCatalog.class.getResourceAsStream("/assets/lin_client/artifact_skin_groups.json")) {
            return new Gson().fromJson(new InputStreamReader(stream, StandardCharsets.UTF_8),
                new com.google.gson.reflect.TypeToken<Map<String,String>>() {}.getType());
        } catch (Exception e) { throw new IllegalStateException("Cannot load skin display groups",e); }
    }
    static String group(ArtifactSkins.Option option) {
        return GROUPS.getOrDefault(option.id(), option.artifact().id()+":"+option.id().replace("valentines","valentine"));
    }
    static Entry[] entries() {
        try (var stream = HopliteSkinCatalog.class.getResourceAsStream("/assets/lin_client/hoplite_skins.json")) {
            return new Gson().fromJson(new InputStreamReader(stream, StandardCharsets.UTF_8), Entry[].class);
        } catch (Exception e) { throw new IllegalStateException("Cannot load Hoplite skin catalog", e); }
    }
    static void appendTo(Map<ArtifactSkins.Artifact, List<ArtifactSkins.Option>> options) {
        try (var stream = HopliteSkinCatalog.class.getResourceAsStream("/assets/lin_client/hoplite_skins.json")) {
            if (stream == null) return;
            var entries = new Gson().fromJson(new InputStreamReader(stream, StandardCharsets.UTF_8), Entry[].class);
            var currentSkins = new java.util.HashMap<String, Entry>();
            for (var e : entries) currentSkins.putIfAbsent(GROUPS.get(e.id), e);
            for (var artifact : ArtifactSkins.Artifact.values()) {
                var list = new ArrayList<>(options.get(artifact));
                if (artifact.defaultSkinId().equals("hoplite_default")) list.clear();
                // Keep saved legacy IDs while refreshing their model and neutral preview.
                // Otherwise these earlier entries hide the newly imported skin in the menu.
                for (int i = 0; i < list.size(); i++) {
                    var previous = list.get(i);
                    var current = currentSkins.get(group(previous));
                    if (current != null) list.set(i, new ArtifactSkins.Option(artifact, previous.id(),
                        previous.displayName(), Identifier.parse(current.preview),
                        Identifier.parse(current.world), previous.seed()));
                }
                for (var e : entries) if (e.artifact.equals(artifact.id())) {
                    String key = GROUPS.get(e.id);
                    String name = key.endsWith(":default") ? "默认" : e.name;
                    list.add(new ArtifactSkins.Option(artifact,e.id,name,
                        Identifier.parse(e.preview),Identifier.parse(e.world),2000+list.size()));
                }
                options.put(artifact,List.copyOf(list));
            }
        } catch (Exception e) { throw new IllegalStateException("Cannot load Hoplite skin catalog", e); }
    }
    record Entry(String artifact,String id,String name,String preview,String world,String item,int cmd) {}
}
