package dev.lin.client.features.artifact;

import java.text.Normalizer;
import java.util.Locale;
import net.minecraft.client.Minecraft;
import net.minecraft.world.scores.DisplaySlot;
import net.minecraft.world.scores.PlayerTeam;

/** Server-scoped runtime gate; never modifies the user's saved skin preferences. */
public final class HopliteServerContext {
    private static Object level;
    private static boolean active;
    private static boolean competition;
    private static int nextScan;
    private HopliteServerContext() {}

    public static void tick(Minecraft client) {
        if (client.level == null || client.player == null || client.hasSingleplayerServer()) {
            level = null; active = false; competition = false; nextScan = 0; return;
        }
        if (level != client.level) {
            level = client.level; active = false; competition = false; nextScan = 0;
        }
        if (nextScan-- > 0) return;
        nextScan = 9;
        var server = client.getCurrentServer();
        boolean hopliteServer = server != null && matches(server.ip);
        var board = client.level.getScoreboard();
        var objective = board.getDisplayObjective(DisplaySlot.SIDEBAR);
        var team = board.getPlayersTeam(client.player.getScoreboardName());
        if (team != null) {
            var slot = DisplaySlot.teamColorToSlot(team.getColor());
            var colored = slot == null ? null : board.getDisplayObjective(slot);
            if (colored != null) objective = colored;
        }
        active = hopliteServer;
        competition = objective != null && objective.getDisplayName().getString()
                .toLowerCase(Locale.ROOT).contains("comp");
        if (objective == null) return;
        if (active || matches(objective.getDisplayName().getString())) { active = true; return; }
        for (var entry : board.listPlayerScores(objective)) {
            if (entry.owner().startsWith("#")) continue;
            var lineTeam = board.getPlayersTeam(entry.owner());
            var visibleName = entry.display() == null ? entry.ownerName() : entry.display();
            String line = PlayerTeam.formatNameForTeam(lineTeam,visibleName).getString();
            if (matches(line)) { active = true; return; }
        }
    }

    public static boolean isActive() {
        var client = Minecraft.getInstance();
        return active && client.level != null && client.level == level
                && client.player != null && !client.hasSingleplayerServer();
    }

    public static boolean canRenderArtifactSkins() {
        var client = Minecraft.getInstance();
        return isActive() && client.level != null
                && client.level.getScoreboard().getDisplayObjective(DisplaySlot.LIST) != null;
    }

    public static boolean isInCompetition() {
        var client = Minecraft.getInstance();
        return isActive() && client.level != null
                && client.level.getScoreboard().getDisplayObjective(DisplaySlot.LIST) != null;
    }

    /** Lobby mode follows the same TAB health objective used by teammate glow. */
    public static boolean isLobbyWithoutTabHealth() {
        var client = Minecraft.getInstance();
        return isActive() && client.level != null
                && client.level.getScoreboard().getDisplayObjective(DisplaySlot.LIST) == null;
    }

    public static boolean matches(String text) {
        if (text == null) return false;
        String normalized = Normalizer.normalize(text,Normalizer.Form.NFKC)
                .replaceAll("(?i)§[0-9A-FK-ORX]", "")
                .replaceAll("[\\p{Cf}\\s\\p{Zs}]", "")
                .toLowerCase(Locale.ROOT);
        return normalized.contains("hoplite");
    }
}
