package dev.lin.client.features.mixin;

import dev.lin.client.features.trim.LinTrimPreview;
import dev.lin.client.features.ui.AccessorySelectorScreen;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.entity.player.AvatarRenderer;
import net.minecraft.client.renderer.entity.state.AvatarRenderState;
import net.minecraft.world.entity.Avatar;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(AvatarRenderer.class)
public abstract class LinTrimPreviewMixin {
   @Inject(method = "extractRenderState", at = @At("TAIL"))
   private void linClient$applyTrimPreviewArmor(Avatar entity, AvatarRenderState state, float partialTick, CallbackInfo callback) {
      Minecraft minecraft = Minecraft.getInstance();
      if (entity == minecraft.player && minecraft.screen instanceof AccessorySelectorScreen screen && screen.isTrimPage()) {
         LinTrimPreview preview = LinTrimPreview.selected();
         state.headEquipment = preview.helmet();
         state.chestEquipment = preview.chestplate();
         state.legsEquipment = preview.leggings();
         state.feetEquipment = preview.boots();
      }
   }
}
