package dev.lin.client.features.mixin;

import com.mojang.blaze3d.vertex.PoseStack;
import dev.lin.client.features.artifact.ArtifactProjectileRenderer;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.entity.ArrowRenderer;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.state.ArrowRenderState;
import net.minecraft.client.renderer.state.CameraRenderState;
import net.minecraft.world.entity.projectile.arrow.AbstractArrow;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ArrowRenderer.class)
public abstract class ArtifactArrowRendererMixin extends EntityRenderer<AbstractArrow, ArrowRenderState> {
    protected ArtifactArrowRendererMixin(EntityRendererProvider.Context context) { super(context); }

    @Inject(method = "method_62377(Lnet/minecraft/class_1665;Lnet/minecraft/class_9999;F)V", at = @At("TAIL"))
    private void linClient$extractFlightModel(AbstractArrow entity, ArrowRenderState state, float delta, CallbackInfo ci) {
        ArtifactProjectileRenderer.extract(entity, state);
    }

    @Inject(method = "method_3875(Lnet/minecraft/class_9999;Lnet/minecraft/class_4587;Lnet/minecraft/class_11659;Lnet/minecraft/class_12075;)V", at = @At("HEAD"), cancellable = true)
    private void linClient$submitFlightModel(ArrowRenderState state, PoseStack poses,
                                            SubmitNodeCollector collector, CameraRenderState camera, CallbackInfo ci) {
        if (ArtifactProjectileRenderer.submit(state, state.yRot, state.xRot, poses, collector)) {
            super.submit(state, poses, collector, camera);
            ci.cancel();
        }
    }
}
