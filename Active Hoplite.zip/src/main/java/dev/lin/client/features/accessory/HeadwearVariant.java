package dev.lin.client.features.accessory;

import java.util.Locale;

public enum HeadwearVariant {
   NORMAL("normal", "普通"),
   SHINY("shiny", "神话");

   private final String id;
   private final String displayName;

   HeadwearVariant(String id, String displayName) {
      this.id = id;
      this.displayName = displayName;
   }

   public String id() {
      return this.id;
   }

   public String displayName() {
      return this.displayName;
   }

   public static HeadwearVariant byId(String id) {
      if (id != null) {
         String normalized = id.trim().toLowerCase(Locale.ROOT);
         for (HeadwearVariant variant : values()) {
            if (variant.id.equals(normalized)) {
               return variant;
            }
         }
      }

      return NORMAL;
   }
}
