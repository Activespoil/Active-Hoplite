package dev.lin.client.features.cape;

import dev.lin.client.cosmetics.render.CosmeticWorldRenderer;
import net.minecraft.client.renderer.entity.state.AvatarRenderState;

public final class LunarCapeWorldRenderer {
   private LunarCapeWorldRenderer() {
   }

   public static void apply(AvatarRenderState state) {
      CosmeticWorldRenderer.applyCape(state);
   }

   public static boolean isSelectedCapeApplied(AvatarRenderState state) {
      return CosmeticWorldRenderer.isCapeApplied(state);
   }
}
