package dev.lin.client.features.mixin;

import dev.lin.client.features.render.AccessoryItemModels;
import dev.lin.client.features.render.HudStaticItems;
import dev.lin.client.features.trim.LinTrimManager;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.item.ItemModelResolver;
import net.minecraft.client.renderer.item.ItemStackRenderState;
import net.minecraft.world.entity.ItemOwner;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(GuiGraphics.class)
public abstract class GuiGraphicsMixin {
   @Redirect(
      method = "renderItem(Lnet/minecraft/world/entity/LivingEntity;Lnet/minecraft/world/level/Level;Lnet/minecraft/world/item/ItemStack;III)V",
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/renderer/item/ItemModelResolver;updateForTopItem(Lnet/minecraft/client/renderer/item/ItemStackRenderState;Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/item/ItemDisplayContext;Lnet/minecraft/world/level/Level;Lnet/minecraft/world/entity/ItemOwner;I)V"
      )
   )
   private void linClient$resolveLocalEquippedItem(
      ItemModelResolver resolver,
      ItemStackRenderState renderState,
      ItemStack stack,
      ItemDisplayContext displayContext,
      Level level,
      ItemOwner owner,
      int seed
   ) {
      if (renderState instanceof HudStaticItems.FrozenItem frozen && frozen.isResolved()) return;

      boolean previous = LinTrimManager.isLocalArmorRendering();
      var previousTrim = LinTrimManager.worldArmorTrim();
      boolean dropped = AccessoryItemModels.isRenderingDroppedIcon();
      boolean equipped = !dropped
         && LinTrimManager.isEquippedArmorStack(stack, owner);
      var trim = dropped ? null : equipped ? LinTrimManager.fakeTrim() : LinTrimManager.remoteEquippedTrim(stack, owner);
      LinTrimManager.setLocalArmorRendering(equipped);
      LinTrimManager.setWorldArmorTrim(trim);

      try {
         ItemStack display = equipped ? AccessoryItemModels.replaceDefaultHelmetIcon(stack) : stack;
         resolver.updateForTopItem(
            renderState,
            display,
            displayContext,
            level,
            owner,
            seed
         );
         if (renderState instanceof HudStaticItems.FrozenItem frozen) frozen.markResolved();
      } finally {
         LinTrimManager.setWorldArmorTrim(previousTrim);
         LinTrimManager.setLocalArmorRendering(previous);
      }
   }

}
