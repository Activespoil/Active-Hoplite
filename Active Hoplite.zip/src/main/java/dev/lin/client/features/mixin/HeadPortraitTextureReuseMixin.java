package dev.lin.client.features.mixin;

import dev.lin.client.cosmetics.ui.HeadPortraitRenderState;
import dev.lin.client.cosmetics.ui.StaticPortraitModels;
import net.minecraft.client.gui.render.pip.PictureInPictureRenderer;
import net.minecraft.client.gui.render.state.GuiRenderState;
import net.minecraft.client.gui.render.state.pip.GuiEntityRenderState;
import net.minecraft.client.gui.render.state.pip.PictureInPictureRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Reuse the native surface; its parent still checks physical texture dimensions. */
@Mixin(PictureInPictureRenderer.class)
public abstract class HeadPortraitTextureReuseMixin {
    @Unique private GuiEntityRenderState lin$lastPortrait;
    @Unique private long lin$portraitGeneration;

    @Inject(method="textureIsReadyToBlit", at=@At("HEAD"), cancellable=true)
    private void lin$staticPortrait(PictureInPictureRenderState current, CallbackInfoReturnable<Boolean> cir) {
        if (!(current instanceof GuiEntityRenderState next)
                || !(next.renderState() instanceof HeadPortraitRenderState avatar) || !avatar.staticHead
                || lin$lastPortrait == null || lin$portraitGeneration != StaticPortraitModels.generation()) return;
        var previous = (HeadPortraitRenderState) lin$lastPortrait.renderState();
        // CachedHead creates a new immutable preview whenever owner/skin/components/resources change.
        if (avatar == previous
                && Float.compare(next.scale(), lin$lastPortrait.scale()) == 0
                && next.translation().equals(lin$lastPortrait.translation())
                && next.rotation().equals(lin$lastPortrait.rotation())
                && java.util.Objects.equals(next.overrideCameraAngle(), lin$lastPortrait.overrideCameraAngle()))
            cir.setReturnValue(true);
    }

    @Inject(method="prepare", at=@At("RETURN"))
    private void lin$rememberPortrait(PictureInPictureRenderState current, GuiRenderState gui, int guiScale, CallbackInfo ci) {
        // Any other image overwrites this renderer's single native surface.
        lin$lastPortrait = current instanceof GuiEntityRenderState entity
                && entity.renderState() instanceof HeadPortraitRenderState avatar && avatar.staticHead ? entity : null;
        lin$portraitGeneration = StaticPortraitModels.generation();
    }

    @Inject(method="close", at=@At("HEAD"))
    private void lin$forgetPortrait(CallbackInfo ci) { lin$lastPortrait = null; }
}
