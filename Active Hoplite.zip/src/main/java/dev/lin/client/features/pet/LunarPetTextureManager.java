package dev.lin.client.features.pet;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mojang.blaze3d.platform.NativeImage;
import dev.lin.client.features.LinFeatures;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import javax.imageio.ImageIO;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.resources.Identifier;

public final class LunarPetTextureManager {
   private static final String BUNDLED_ASSET_PREFIX = "/assets/lin_client/lunar_pet_assets/";
   private static final int UI_RENDER_LIMIT = 80;
   private static final Path LOCAL_JIT = Path.of(System.getProperty("user.home"), ".lunarclient", "jit", "assets", "lunar-jit");
   private static final Path LAUNCHER_ASSETS = launcherAssets();
   private static final Path CACHE = FabricLoader.getInstance().getConfigDir().resolve("lin-client/lunar-pet-cache");
   private static final ExecutorService EXECUTOR = Executors.newSingleThreadExecutor(task -> {
      Thread thread = new Thread(task, "Lin Client Lunar Shoulder Pet Loader");
      thread.setDaemon(true);
      return thread;
   });
   private static final ExecutorService UI_EXECUTOR = Executors.newFixedThreadPool(4, task -> {
      Thread thread = new Thread(task, "Lin Client Lunar Shoulder Pet UI Loader");
      thread.setDaemon(true);
      return thread;
   });
   private static final Object WEBP_DECODE_LOCK = new Object();
   private static final Map<String, Object> ASSET_LOCKS = new ConcurrentHashMap<>();
   private static final Map<String, PreviewTexture> PREVIEWS = Collections.synchronizedMap(new LinkedHashMap<>(64, 0.75F, true));
   private static final Set<String> LOADING_UI = ConcurrentHashMap.newKeySet();
   private static final Set<String> FAILED_UI = ConcurrentHashMap.newKeySet();
   private static final Map<String, ActivePet> UI_PETS = Collections.synchronizedMap(new LinkedHashMap<>(64, 0.75F, true));
   private static volatile ActivePet active;
   private static volatile String loadingId;
   private static volatile String failedId;

   private static final Map<String,ActivePet> REMOTE = new LinkedHashMap<>();
   private static final Map<String,Long> REMOTE_BYTES = new LinkedHashMap<>();
   private static Set<String> remoteWanted=Set.of();
   private static long remoteBytes;
   private static final Set<String> remoteOverBudget=new java.util.HashSet<>();
   public static RenderData remoteRenderData(String id) {
      ActivePet pet=REMOTE.get(id);return pet==null?null:new RenderData(pet.texture,pet.mesh);
   }
   public static void remoteTick(Set<String> ids) {
      if(!remoteWanted.equals(ids))remoteOverBudget.clear();
      remoteWanted=Set.copyOf(ids);
      var iterator=REMOTE.entrySet().iterator();
      while(iterator.hasNext()){
         var e=iterator.next();if(ids.contains(e.getKey()))continue;
         Minecraft.getInstance().getTextureManager().release(e.getValue().texture);
         remoteBytes-=REMOTE_BYTES.remove(e.getKey());iterator.remove();
      }
      for(String id:ids){
         LunarPet pet=dev.lin.client.cosmetics.sync.RemoteCosmetics.pet(id);
         if(pet==null || REMOTE.containsKey(id) || remoteOverBudget.contains(id) || remoteBytes>=16L*1024*1024)continue;
         dev.lin.client.cosmetics.sync.RemoteAssetLoader.request("pet:"+id,
            ()->remoteWanted.contains(id) && !REMOTE.containsKey(id),()->loadAssets(pet),loaded->{
               long cost=(long)loaded.image.getWidth()*loaded.image.getHeight()*8+(long)loaded.mesh.vertices().length*64;
               if(remoteBytes+cost>16L*1024*1024){remoteOverBudget.add(id);return;}
               NativeImage pixels=toNativeImage(loaded.image);
               Identifier texture=Identifier.fromNamespaceAndPath(LinFeatures.MOD_ID,"lunar_pet/remote_"+id);
               DynamicTexture dynamic=new DynamicTexture(()->"Remote pet "+id,pixels);
               Minecraft.getInstance().getTextureManager().register(texture,dynamic);
               REMOTE.put(id,new ActivePet(id,texture,dynamic,loaded.mesh));REMOTE_BYTES.put(id,cost);remoteBytes+=cost;
            });
      }
   }

   private LunarPetTextureManager() {
   }

   public static PreviewTexture preview(LunarPet pet) {
      PreviewTexture cached = PREVIEWS.get(pet.id());
      if (cached != null) {
         return cached;
      }
      String path = "/assets/lin_client/textures/pet_previews/" + pet.id() + ".png";
      try (InputStream input = LunarPetTextureManager.class.getResourceAsStream(path)) {
         if (input == null) {
            return null;
         }
         BufferedImage image = ImageIO.read(input);
         if (image == null) {
            return null;
         }
         NativeImage pixels = toNativeImage(image);
         Identifier texture = Identifier.fromNamespaceAndPath(LinFeatures.MOD_ID, "lunar_pet/preview_" + pet.id());
         DynamicTexture dynamicTexture = new DynamicTexture(() -> "Lunar shoulder pet preview " + pet.id(), pixels);
         Minecraft.getInstance().getTextureManager().register(texture, dynamicTexture);
         PreviewTexture preview = new PreviewTexture(texture, image.getWidth(), image.getHeight());
         PREVIEWS.put(pet.id(), preview);
         trimPreviews();
         return preview;
      } catch (IOException ignored) {
         return null;
      }
   }

   private static void trimPreviews() {
      synchronized (PREVIEWS) {
         Iterator<Map.Entry<String, PreviewTexture>> iterator = PREVIEWS.entrySet().iterator();
         while (PREVIEWS.size() > 160 && iterator.hasNext()) {
            PreviewTexture removed = iterator.next().getValue();
            iterator.remove();
            Minecraft.getInstance().getTextureManager().release(removed.texture());
         }
      }
   }

   public static void tick() {
      selectedRenderData();
   }

   public static RenderData uiRenderData(LunarPet pet) {
      ActivePet current = UI_PETS.get(pet.id());
      if (current != null) {
         return new RenderData(current.texture, current.mesh);
      }
      ActivePet selected = active;
      if (selected != null && selected.petId.equals(pet.id())) {
         return new RenderData(selected.texture, selected.mesh);
      }
      if (!FAILED_UI.contains(pet.id()) && LOADING_UI.add(pet.id())) {
         UI_EXECUTOR.execute(() -> loadForUi(pet));
      }
      return null;
   }

   public static RenderData selectedRenderData() {
      LunarPet selected = LunarPetRegistry.selected();
      if (selected == null) {
         if (active != null) {
            releaseActive();
         }
         return null;
      }
      ActivePet current = active;
      if (current != null && current.petId.equals(selected.id())) {
         return new RenderData(current.texture, current.mesh);
      }
      if (!selected.id().equals(loadingId) && !selected.id().equals(failedId)) {
         loadingId = selected.id();
         EXECUTOR.execute(() -> load(selected));
      }
      return null;
   }

   public static void selectionChanged() {
      loadingId = null;
      failedId = null;
      Minecraft.getInstance().execute(() -> {
         releaseActive();
         selectedRenderData();
      });
   }

   private static void load(LunarPet pet) {
      try {
         LoadedPet loaded = loadAssets(pet);
         Minecraft.getInstance().execute(() -> register(pet, loaded.mesh, loaded.image));
      } catch (Exception exception) {
         failedId = pet.id();
         loadingId = null;
         System.err.println("[Lin Client] Unable to load Lunar shoulder pet " + pet.displayName() + ": " + exception.getMessage());
      }
   }

   private static void loadForUi(LunarPet pet) {
      try {
         LoadedPet loaded = loadAssets(pet);
         Minecraft.getInstance().execute(() -> registerForUi(pet, loaded.mesh, loaded.image));
      } catch (Exception exception) {
         LOADING_UI.remove(pet.id());
         FAILED_UI.add(pet.id());
         System.err.println("[Lin Client] Unable to load Lunar shoulder pet UI model " + pet.displayName() + ": " + exception.getMessage());
      }
   }

   private static LoadedPet loadAssets(LunarPet pet) throws IOException {
      Path definitionPath = obtain(pet.definitionPath(), pet.definitionAsset());
      JsonObject definition = JsonParser.parseString(Files.readString(definitionPath, StandardCharsets.UTF_8)).getAsJsonObject();
      String geometryPath = LunarPetRegistry.normalize(definition.get("model").getAsString());
      String texturePath = LunarPetRegistry.normalize(definition.get("texture").getAsString());
      LunarPet.Asset geometryAsset = LunarPetRegistry.asset(geometryPath);
      LunarPet.Asset textureAsset = LunarPetRegistry.asset(texturePath);
      if (geometryAsset == null || textureAsset == null) {
         throw new IOException("Lunar pet asset index is incomplete");
      }
      Path geometryFile = obtain(geometryPath, geometryAsset);
      Path textureFile = obtain(texturePath, textureAsset);
      JsonObject animation = null;
      if (definition.has("animation")) {
         String animationPath = LunarPetRegistry.normalize(definition.get("animation").getAsString());
         LunarPet.Asset animationAsset = LunarPetRegistry.asset(animationPath);
         if (animationAsset != null) {
            Path animationFile = obtain(animationPath, animationAsset);
            animation = JsonParser.parseString(Files.readString(animationFile, StandardCharsets.UTF_8)).getAsJsonObject();
         }
      }
      LunarPetModelLoader.PetMesh mesh = LunarPetModelLoader.load(
         JsonParser.parseString(Files.readString(geometryFile, StandardCharsets.UTF_8)).getAsJsonObject(), animation, definition
      );
      BufferedImage image;
      synchronized (WEBP_DECODE_LOCK) {
         image = ImageIO.read(textureFile.toFile());
      }
      if (image == null) {
         throw new IOException("Unable to decode Lunar pet texture");
      }
      image = firstTextureFrame(image, mesh.textureWidth(), mesh.textureHeight());
      return new LoadedPet(mesh, image);
   }

   private static BufferedImage firstTextureFrame(BufferedImage image, int declaredWidth, int declaredHeight) {
      if (declaredWidth <= 0 || declaredHeight <= 0 || image.getWidth() <= 0) {
         return image;
      }
      float pixelScale = (float)image.getWidth() / declaredWidth;
      int frameHeight = Math.max(1, Math.round(declaredHeight * pixelScale));
      return image.getHeight() > frameHeight ? image.getSubimage(0, 0, image.getWidth(), frameHeight) : image;
   }

   private static void register(LunarPet pet, LunarPetModelLoader.PetMesh mesh, BufferedImage image) {
      loadingId = null;
      LunarPet selected = LunarPetRegistry.selected();
      if (selected == null || !selected.id().equals(pet.id())) {
         return;
      }
      releaseActive();
      NativeImage pixels = toNativeImage(image);
      Identifier texture = Identifier.fromNamespaceAndPath(LinFeatures.MOD_ID, "lunar_pet/selected_" + pet.id());
      DynamicTexture dynamicTexture = new DynamicTexture(() -> "Selected Lunar shoulder pet " + pet.id(), pixels);
      Minecraft.getInstance().getTextureManager().register(texture, dynamicTexture);
      active = new ActivePet(pet.id(), texture, dynamicTexture, mesh);
      failedId = null;
   }

   private static void registerForUi(LunarPet pet, LunarPetModelLoader.PetMesh mesh, BufferedImage image) {
      LOADING_UI.remove(pet.id());
      if (UI_PETS.containsKey(pet.id())) {
         return;
      }
      NativeImage pixels = toNativeImage(image);
      Identifier texture = Identifier.fromNamespaceAndPath(LinFeatures.MOD_ID, "lunar_pet/ui_" + pet.id());
      DynamicTexture dynamicTexture = new DynamicTexture(() -> "Lunar shoulder pet UI model " + pet.id(), pixels);
      Minecraft.getInstance().getTextureManager().register(texture, dynamicTexture);
      UI_PETS.put(pet.id(), new ActivePet(pet.id(), texture, dynamicTexture, mesh));
      FAILED_UI.remove(pet.id());
      trimUiPets();
   }

   private static void trimUiPets() {
      synchronized (UI_PETS) {
         Iterator<Map.Entry<String, ActivePet>> iterator = UI_PETS.entrySet().iterator();
         while (UI_PETS.size() > UI_RENDER_LIMIT && iterator.hasNext()) {
            ActivePet removed = iterator.next().getValue();
            iterator.remove();
            Minecraft.getInstance().getTextureManager().release(removed.texture);
         }
      }
   }

   private static Path obtain(String relativePath, LunarPet.Asset asset) throws IOException {
      String normalizedPath = LunarPetRegistry.normalize(relativePath);
      Path local = LOCAL_JIT.resolve(normalizedPath).normalize();
      if (!local.startsWith(LOCAL_JIT)) {
         throw new IOException("Unsafe Lunar pet asset path");
      }
      if (asset!=null && valid(local,asset)) {
         return local;
      }
      if (asset == null || !asset.hash().matches("[0-9a-f]{40}")) {
         throw new IOException("No Lunar pet asset entry for " + normalizedPath);
      }
      if (LAUNCHER_ASSETS != null) {
         Path shared = LAUNCHER_ASSETS.resolve("objects").resolve(asset.hash()).normalize();
         if (shared.startsWith(LAUNCHER_ASSETS) && valid(shared, asset)) {
            return shared;
         }
      }
      Files.createDirectories(CACHE);
      Path cached = CACHE.resolve(asset.hash());
      if (valid(cached, asset)) {
         return cached;
      }
      Object lock = ASSET_LOCKS.computeIfAbsent(asset.hash(), ignored -> new Object());
      synchronized (lock) {
         if (!valid(cached, asset)) {
            if (!extractBundled(asset, cached)) {
               throw new IOException("Bundled Lunar pet asset is missing: " + asset.hash());
            }
         }
      }
      return cached;
   }

   private static Path launcherAssets() {
      String configured = System.getProperty("lin.client.assetsDir", "").trim();
      if (configured.isEmpty()) {
         return null;
      }
      try {
         return Path.of(configured).toAbsolutePath().normalize();
      } catch (Exception ignored) {
         return null;
      }
   }

   private static boolean extractBundled(LunarPet.Asset asset, Path target) throws IOException {
      try (InputStream input = LunarPetTextureManager.class.getResourceAsStream(BUNDLED_ASSET_PREFIX + asset.hash())) {
         if (input == null) {
            return false;
         }
         byte[] body = input.readAllBytes();
         if (asset.size() > 0L && body.length != asset.size()) {
            throw new IOException("Bundled Lunar pet asset size mismatch");
         }
         if (!sha1(body).equals(asset.hash())) {
            throw new IOException("Bundled Lunar pet asset SHA-1 mismatch");
         }
         writeAtomically(target, body);
         return true;
      }
   }

   private static boolean valid(Path path, LunarPet.Asset asset) {
      return dev.lin.client.cosmetics.assets.LunarAssetStore.validPinned(path,asset.hash(),asset.size());
   }

   private static void writeAtomically(Path target, byte[] body) throws IOException {
      Path staging = Files.createTempFile(CACHE, "pet-", ".tmp");
      try {
         Files.write(staging, body);
         try {
            Files.move(staging, target, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
         } catch (AtomicMoveNotSupportedException ignored) {
            Files.move(staging, target, StandardCopyOption.REPLACE_EXISTING);
         }
      } finally {
         Files.deleteIfExists(staging);
      }
   }

   private static String sha1(byte[] value) throws IOException {
      try {
         byte[] hash = MessageDigest.getInstance("SHA-1").digest(value);
         StringBuilder result = new StringBuilder(hash.length * 2);
         for (byte part : hash) {
            result.append(Character.forDigit(part >>> 4 & 15, 16));
            result.append(Character.forDigit(part & 15, 16));
         }
         return result.toString();
      } catch (NoSuchAlgorithmException exception) {
         throw new IOException(exception);
      }
   }

   private static NativeImage toNativeImage(BufferedImage image) {
      NativeImage result = new NativeImage(image.getWidth(), image.getHeight(), true);
      for (int y = 0; y < image.getHeight(); y++) {
         for (int x = 0; x < image.getWidth(); x++) {
            int argb = image.getRGB(x, y);
            int abgr = argb & 0xFF00FF00 | (argb & 0xFF0000) >>> 16 | (argb & 0xFF) << 16;
            result.setPixelABGR(x, y, abgr);
         }
      }
      return result;
   }

   private static void releaseActive() {
      ActivePet current = active;
      if (current != null) {
         Minecraft.getInstance().getTextureManager().release(current.texture);
         active = null;
      }
   }

   public static void close() {
      remoteTick(Set.of());
      releaseActive();
      synchronized (PREVIEWS) {
         for (PreviewTexture preview : PREVIEWS.values()) {
            Minecraft.getInstance().getTextureManager().release(preview.texture());
         }
         PREVIEWS.clear();
      }
      synchronized (UI_PETS) {
         for (ActivePet pet : UI_PETS.values()) {
            Minecraft.getInstance().getTextureManager().release(pet.texture);
         }
         UI_PETS.clear();
      }
      LOADING_UI.clear();
      FAILED_UI.clear();
      loadingId = null;
      failedId = null;
   }

   public record PreviewTexture(Identifier texture, int width, int height) {
   }

   public record RenderData(Identifier texture, LunarPetModelLoader.PetMesh mesh) {
   }

   private record LoadedPet(LunarPetModelLoader.PetMesh mesh, BufferedImage image) {
   }

   private record ActivePet(String petId, Identifier texture, DynamicTexture dynamicTexture, LunarPetModelLoader.PetMesh mesh) {
   }
}
