package dev.lin.client.features.mixin;

import dev.lin.client.features.trim.LinTrimManager;
import net.minecraft.core.component.DataComponentType;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.component.PatchedDataComponentMap;
import net.minecraft.world.item.equipment.trim.ArmorTrim;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(PatchedDataComponentMap.class)
public abstract class PatchedDataComponentMapMixin {
   @Inject(method = "method_58694", at = @At("RETURN"), cancellable = true, remap = false)
   @SuppressWarnings("unchecked")
   private <T> void linClient$provideSelectedTrim(DataComponentType<? extends T> type, CallbackInfoReturnable<T> callback) {
      if (type == DataComponents.TRIM) {
         ArmorTrim trim = LinTrimManager.renderTrim();
         if (trim == null) return;
         PatchedDataComponentMap components = (PatchedDataComponentMap)(Object)this;
         if (components.keySet().contains(DataComponents.EQUIPPABLE)) {
            callback.setReturnValue((T)trim);
         }
      }
   }
}
