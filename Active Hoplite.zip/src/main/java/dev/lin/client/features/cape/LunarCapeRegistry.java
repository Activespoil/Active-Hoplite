package dev.lin.client.features.cape;

import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;
import javax.imageio.ImageIO;
import net.fabricmc.loader.api.FabricLoader;

public final class LunarCapeRegistry {
   public static final String DEFAULT_ID = "lin_default_lunar";
   private static final String ASSET_PREFIX = "assets/lunar/";
   private static final String BUNDLED_CATALOG = "/assets/lin_client/lunar_capes.tsv";
   private static final String OFFICIAL_CATALOG = "/assets/lin_client/official_capes.tsv";
   private static final String DUNGEON_CATALOG = "/assets/lin_client/dungeon_capes.tsv";
   private static final Path LUNAR_ROOT = Path.of(System.getProperty("user.home"), ".lunarclient");
   private static final Path CATALOG = LUNAR_ROOT.resolve("textures/assets/lunar/cosmetics/index");
   private static final Path JIT_INDEX = LUNAR_ROOT.resolve("textures/assets/lunar/jit_index");
   private static final Path CUSTOM_DIR = FabricLoader.getInstance().getConfigDir().resolve("lin-client/custom-capes");
   private static volatile List<LunarCape> capes = List.of();
   private static volatile List<LunarCape> officialCapes = List.of();
   private static volatile List<LunarCape> dungeonCapes = List.of();
   private static volatile LunarCape selected;

   private LunarCapeRegistry() {
   }

   public static synchronized void load() {
      Map<String, LunarCape.Asset> assets = loadAssetIndex();
      List<LunarCape> loaded = new ArrayList<>();
      loaded.add(new LunarCape(DEFAULT_ID, "默认 Lunar 披风",
         "default_lunar/cape.webp", null, null, null));
      loadCustomCapes(loaded);
      Map<String, LunarCape> official = new LinkedHashMap<>();
      List<LunarCape> bundled = new ArrayList<>();
      loadBundledCapes(bundled);
      bundled.forEach(cape -> official.put(cape.id(), cape));
      loadLocalCapes(official, assets);
      loaded.addAll(official.values());

      capes = List.copyOf(loaded);
      officialCapes = List.copyOf(loadOfficialCapes());
      dungeonCapes = List.copyOf(loadPackagedCapes(DUNGEON_CATALOG,
         "dungeon_", "dungeon_capes/", "dungeon"));
      if (selected != null) {
         select(selected.id());
      }
      System.out.println("[Lin Client] Loaded " + capes.size() + " Lunar capes and "
         + officialCapes.size() + " official capes and "
         + dungeonCapes.size() + " dungeon capes");
   }

   private static List<LunarCape> loadOfficialCapes() {
      return loadPackagedCapes(OFFICIAL_CATALOG, "official_",
         "official_capes/", "official");
   }

   private static List<LunarCape> loadPackagedCapes(String catalog,
                                                    String idPrefix,
                                                    String pathPrefix,
                                                    String label) {
      List<LunarCape> result = new ArrayList<>();
      try (InputStream stream = LunarCapeRegistry.class.getResourceAsStream(catalog)) {
         if (stream == null) {
            return result;
         }
         try (BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
               String[] columns = line.split("\\t", -1);
               if (columns.length < 3) {
                  continue;
               }
               String id = columns[0].trim();
               String name = columns[1].trim();
               String relativePath = normalize(columns[2]);
               if (!id.startsWith(idPrefix) || name.isEmpty()
                  || !relativePath.startsWith(pathPrefix) || relativePath.contains("..")) {
                  continue;
               }
               result.add(new LunarCape(id, name, relativePath, null, null, null));
            }
         }
      } catch (IOException exception) {
         System.err.println("[Lin Client] Unable to read " + label
            + " cape catalog: " + exception.getMessage());
      }
      return result;
   }

   private static void loadLocalCapes(Map<String, LunarCape> target, Map<String, LunarCape.Asset> assets) {
      if (!Files.isRegularFile(CATALOG)) {
         return;
      }

      try {
         for (String line : Files.readAllLines(CATALOG, StandardCharsets.UTF_8)) {
            String[] columns = line.split(",", -1);
            if (columns.length < 12 || !columns[6].equals("cloak")) {
               continue;
            }

            String id = columns[0].trim();
            String name = columns[3].trim();
            String relativePath = resolveCapePath(columns[8], assets);
            if (id.isEmpty() || name.isEmpty() || relativePath == null) {
               continue;
            }

            String logicalPath = ASSET_PREFIX + relativePath;
            LunarCape fallback = target.get(id);
            LunarCape.Asset texture = assets.get(logicalPath);
            LunarCape.Asset metadata = assets.get(logicalPath + ".mcmeta");
            if (fallback != null && fallback.relativePath().equals(relativePath)) {
               if (texture == null) {
                  texture = fallback.textureAsset();
               }
               if (metadata == null) {
                  metadata = fallback.metadataAsset();
               }
            }
            target.put(id, new LunarCape(id, name, relativePath, texture, metadata, null));
         }
      } catch (IOException exception) {
         System.err.println("[Lin Client] Unable to read Lunar cape catalog: " + exception.getMessage());
      }
   }

   private static String resolveCapePath(String value, Map<String, LunarCape.Asset> assets) {
      String relativePath = normalize(value);
      if (relativePath.isEmpty() || relativePath.contains("..")) {
         return null;
      }

      if (!relativePath.startsWith("cosmetics/cloaks/")) {
         int separator = relativePath.lastIndexOf('/');
         String fileName = separator >= 0 ? relativePath.substring(separator + 1) : relativePath;
         String capePath = "cosmetics/cloaks/" + fileName;
         if (assets.containsKey(ASSET_PREFIX + capePath)) {
            relativePath = capePath;
         } else {
            return null;
         }
      }

      String logicalPath = ASSET_PREFIX + relativePath;
      if (!assets.containsKey(logicalPath)) {
         int extension = relativePath.lastIndexOf('.');
         if (extension > 0) {
            String alias = relativePath.substring(0, extension) + "_cloak" + relativePath.substring(extension);
            if (assets.containsKey(ASSET_PREFIX + alias)) {
               relativePath = alias;
            }
         }
      }
      return relativePath;
   }

   private static boolean loadBundledCapes(List<LunarCape> target) {
      try (InputStream stream = LunarCapeRegistry.class.getResourceAsStream(BUNDLED_CATALOG)) {
         if (stream == null) {
            return false;
         }
         try (BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
               String[] columns = line.split("\\t", -1);
               if (columns.length < 7) {
                  continue;
               }
               String id = columns[0].trim();
               String name = columns[1].trim();
               String relativePath = normalize(columns[2]);
               String logicalPath = ASSET_PREFIX + relativePath;
               if (id.isEmpty() || name.isEmpty() || !relativePath.startsWith("cosmetics/cloaks/") || relativePath.contains("..")) {
                  continue;
               }
               try {
                  LunarCape.Asset texture = new LunarCape.Asset(logicalPath, columns[3], Long.parseLong(columns[4]));
                  LunarCape.Asset metadata = columns[5].isEmpty()
                     ? null
                     : new LunarCape.Asset(logicalPath + ".mcmeta", columns[5], Long.parseLong(columns[6]));
                  target.add(new LunarCape(id, name, relativePath, texture, metadata, null));
               } catch (NumberFormatException ignored) {
               }
            }
         }
         return true;
      } catch (IOException exception) {
         System.err.println("[Lin Client] Unable to read bundled Lunar cape catalog: " + exception.getMessage());
         return false;
      }
   }

   private static void loadCustomCapes(List<LunarCape> target) {
      try {
         Files.createDirectories(CUSTOM_DIR);
         try (Stream<Path> files = Files.list(CUSTOM_DIR)) {
            files.filter(Files::isRegularFile)
               .filter(LunarCapeRegistry::isCapeImage)
               .sorted(Comparator.comparingLong(LunarCapeRegistry::lastModified).reversed())
               .forEach(path -> {
                  String fileName = path.getFileName().toString();
                  int extension = fileName.lastIndexOf('.');
                  String displayName = extension > 0 ? fileName.substring(0, extension) : fileName;
                  String id = customId(fileName);
                  target.add(new LunarCape(id, displayName, "custom/" + fileName, null, null, path));
               });
         }
      } catch (IOException exception) {
         System.err.println("[Lin Client] Unable to read custom capes: " + exception.getMessage());
      }
   }

   public static LunarCape importCustomCape(Path source) throws IOException {
      Path normalizedSource = source.toAbsolutePath().normalize();
      if (!Files.isRegularFile(normalizedSource) || !isCapeImage(normalizedSource)) {
         throw new IOException("请选择 PNG 或 WebP 披风文件");
      }
      if (Files.size(normalizedSource) > 64L * 1024L * 1024L) {
         throw new IOException("披风文件不能超过 64 MB");
      }
      BufferedImage decoded = ImageIO.read(normalizedSource.toFile());
      if (decoded == null) {
         throw new IOException("无法读取该披风图片");
      }
      int width = decoded.getWidth();
      int height = decoded.getHeight();
      boolean compactLayout = width % 22 == 0 && height >= width / 22 * 17;
      boolean atlasLayout = width % 64 == 0 && height >= width / 64 * 32;
      if (!compactLayout && !atlasLayout) {
         throw new IOException("披风尺寸应为 22×17 或 64×32 的整数倍");
      }

      Files.createDirectories(CUSTOM_DIR);
      Path target = uniqueTarget(normalizedSource.getFileName().toString());
      Files.copy(normalizedSource, target, StandardCopyOption.COPY_ATTRIBUTES);
      Path sourceMetadata = Path.of(normalizedSource.toString() + ".mcmeta");
      if (Files.isRegularFile(sourceMetadata) && Files.size(sourceMetadata) <= 1024L * 1024L) {
         Files.copy(sourceMetadata, Path.of(target.toString() + ".mcmeta"), StandardCopyOption.REPLACE_EXISTING);
      }

      load();
      Path normalizedTarget = target.toAbsolutePath().normalize();
      for (LunarCape cape : capes) {
         if (cape.customPath() != null && cape.customPath().toAbsolutePath().normalize().equals(normalizedTarget)) {
            return cape;
         }
      }
      throw new IOException("自定义披风保存后无法读取");
   }

   public static Path customDirectory() {
      return CUSTOM_DIR;
   }

   private static String legacyCustomId(String fileName) {
      return "custom_" + fileName.toLowerCase(java.util.Locale.ROOT).replaceAll("[^a-z0-9._-]", "_");
   }

   private static String customId(String fileName) {
      String normalized = fileName.toLowerCase(java.util.Locale.ROOT);
      String legacy = legacyCustomId(fileName);
      // Chinese names must not collapse to the same sequence of underscores.
      if (normalized.matches("[a-z0-9._-]+")) return legacy;
      return legacy + "_" + java.util.UUID.nameUUIDFromBytes(
         normalized.getBytes(StandardCharsets.UTF_8)).toString().replace("-", "");
   }

   private static Path uniqueTarget(String fileName) throws IOException {
      Path candidate = CUSTOM_DIR.resolve(fileName).normalize();
      if (!candidate.startsWith(CUSTOM_DIR) || candidate.getParent() == null || !candidate.getParent().equals(CUSTOM_DIR)) {
         throw new IOException("无效的披风文件名");
      }
      if (!Files.exists(candidate)) {
         return candidate;
      }

      int extension = fileName.lastIndexOf('.');
      String stem = extension > 0 ? fileName.substring(0, extension) : fileName;
      String suffix = extension > 0 ? fileName.substring(extension) : "";
      for (int index = 2; index < 10000; index++) {
         candidate = CUSTOM_DIR.resolve(stem + "-" + index + suffix).normalize();
         if (candidate.startsWith(CUSTOM_DIR) && !Files.exists(candidate)) {
            return candidate;
         }
      }
      throw new IOException("同名自定义披风过多");
   }

   private static boolean isCapeImage(Path path) {
      String name = path.getFileName().toString().toLowerCase();
      return name.endsWith(".png") || name.endsWith(".webp");
   }

   private static long lastModified(Path path) {
      try {
         return Files.getLastModifiedTime(path).toMillis();
      } catch (IOException ignored) {
         return 0L;
      }
   }

   private static Map<String, LunarCape.Asset> loadAssetIndex() {
      Map<String, LunarCape.Asset> assets = new HashMap<>();
      if (!Files.isRegularFile(JIT_INDEX)) {
         return assets;
      }

      try {
         for (String line : Files.readAllLines(JIT_INDEX, StandardCharsets.UTF_8)) {
            String[] columns = line.trim().split("\\s+", 4);
            if (columns.length < 3) {
               continue;
            }

            String logicalPath = normalize(columns[0]);
            String hash = columns[1].trim().toLowerCase();
            if (!logicalPath.startsWith(ASSET_PREFIX + "cosmetics/cloaks/") || !hash.matches("[0-9a-f]{40}")) {
               continue;
            }

            try {
               assets.put(logicalPath, new LunarCape.Asset(logicalPath, hash, Long.parseLong(columns[2])));
            } catch (NumberFormatException ignored) {
            }
         }
      } catch (IOException exception) {
         System.err.println("[Lin Client] Unable to read Lunar JIT index: " + exception.getMessage());
      }
      return assets;
   }

   private static String normalize(String value) {
      return value.replace('\\', '/').replaceFirst("^/+", "").trim();
   }

   public static List<LunarCape> values() {
      ensureLoaded();
      return capes;
   }

   public static List<LunarCape> officialValues() {
      ensureLoaded();
      return officialCapes;
   }

   public static List<LunarCape> dungeonValues() {
      ensureLoaded();
      return dungeonCapes;
   }

   public static boolean isOfficial(LunarCape cape) {
      return cape != null && cape.id().startsWith("official_");
   }

   public static boolean isDungeon(LunarCape cape) {
      return cape != null && cape.id().startsWith("dungeon_");
   }

   public static LunarCape selected() {
      return selected;
   }

   public static String selectedId() {
      return selected == null ? "" : selected.id();
   }

   public static synchronized void select(String id) {
      ensureLoaded();
      selected = null;
      if (id == null || id.isBlank()) {
         return;
      }

      for (LunarCape cape : capes) {
         if (cape.id().equals(id)) {
            selected = cape;
            return;
         }
      }
      for (LunarCape cape : officialCapes) {
         if (cape.id().equals(id)) {
            selected = cape;
            return;
         }
      }
      for (LunarCape cape : dungeonCapes) {
         if (cape.id().equals(id)) {
            selected = cape;
            return;
         }
      }
      // Keep old saved non-ASCII selections readable after introducing stable IDs.
      for (LunarCape cape : capes) {
         if (cape.custom() && id.equals(legacyCustomId(cape.customPath().getFileName().toString()))) {
            selected = cape;
            return;
         }
      }
   }

   private static void ensureLoaded() {
      if (capes.isEmpty() && officialCapes.isEmpty() && dungeonCapes.isEmpty()) {
         load();
      }
   }

   public static synchronized void clearSelection() {
      selected = null;
   }
}
