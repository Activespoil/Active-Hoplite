package dev.lin.client.features.artifact;

import java.util.Set;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.core.component.DataComponents;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.ItemOwner;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Display;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.CustomModelData;

public final class ArtifactSkinModelPolicy {
   private static final Identifier ENDER_HARPOON_BOW =
      Identifier.fromNamespaceAndPath("lin_hoplite", "harpoon_launcher/ender_bow");
   private static final Set<String> OVERRIDDEN_ITEM_MODELS = Set.of(
      "arrow", "blaze_rod", "bow", "crossbow", "diamond_pickaxe",
      "diamond_sword", "elytra", "fishing_rod", "iron_sword",
      "netherite_axe", "netherite_sword", "stone_axe", "stone_hoe",
      "stone_sword", "wooden_shovel", "writable_book", "goat_horn", "enchanted_book", "totem_of_undying", "sniffer_spawn_egg"
   );

   private ArtifactSkinModelPolicy() {
   }

   /** Server menu stacks may have the local player as their render owner. */
   public static boolean allowGuiSkin(ItemStack stack) {
      Minecraft client = Minecraft.getInstance();
      if (!HopliteServerContext.canRenderArtifactSkins()) return false;
      if (!(client.screen instanceof AbstractContainerScreen<?>) || client.screen instanceof InventoryScreen) return true;
      if (client.player == null) return false;
      var inventory = client.player.getInventory();
      for (int slot = 0; slot < inventory.getContainerSize(); slot++) {
         // Identity distinguishes our real inventory from a recipe/crate copy of it.
         if (inventory.getItem(slot) == stack) return true;
      }
      return false;
   }

   public static boolean shouldAdjustHand(ItemStack stack, ItemOwner owner) {
      return handTransformKey(stack, owner) != null;
   }

   public static String handTransformKey(ItemStack stack, ItemOwner owner) {
      if (stack == null) return null;
      Identifier original = stack.get(DataComponents.ITEM_MODEL);
      if (original == null || original.equals(selectModel(original, owner, stack))) return null;
      CustomModelData data = stack.get(DataComponents.CUSTOM_MODEL_DATA);
      Float value = data == null ? null : data.getFloat(0);
      ArtifactSkins.Artifact artifact = value == null ? null
         : ArtifactSkins.artifactFor(itemModelPath(original), Math.round(value));
      return artifact == null ? null : ArtifactSkins.handTransformKey(artifact);
   }

   public static Identifier selectModel(Identifier original, ItemOwner owner, ItemStack stack) {
      if (original == null || stack == null || !ArtifactSkinConfig.enabled || !HopliteServerContext.canRenderArtifactSkins()
         || !OVERRIDDEN_ITEM_MODELS.contains(itemModelPath(original))) {
         return original;
      }
      CustomModelData data = stack.get(DataComponents.CUSTOM_MODEL_DATA);
      Float value = data == null ? null : data.getFloat(0);
      ArtifactSkins.Artifact artifact = value == null ? null
         : ArtifactSkins.artifactFor(itemModelPath(original), Math.round(value));
      if (artifact == null) {
         return original;
      }
      LivingEntity livingOwner = ArtifactProjectileModels.livingOwner(owner);
      Minecraft minecraft = Minecraft.getInstance();
      // Verified remote choices take precedence over this observer's local onlySelf setting.
      if(livingOwner instanceof net.minecraft.client.player.AbstractClientPlayer remote && remote!=minecraft.player){
         var peer=dev.lin.client.cosmetics.sync.CosmeticSyncBridge.remote(remote.getUUID());
         if(peer!=null){
            var chosen=ArtifactSkins.sharedOption(artifact,peer.outfit().appearance().skins().get(artifact.id()));
            return chosen==null?original:modelFor(original,artifact,chosen,Math.round(value));
         }
      }
      if(!ArtifactSkinConfig.isArtifactEnabled(artifact.id()))return original;
      // The server can replace a thrown artifact with a display or a
      // projectile that has no owner packet. It is still the unique artifact
      // stack, so retain its selected skin while it is in flight.
      boolean ownerlessFlight = owner instanceof Entity entity
         && (livingOwner == null && (entity instanceof Projectile || entity instanceof Display.ItemDisplay
            || entity instanceof ItemEntity item && !item.onGround())
            || entity instanceof ArmorStand && (livingOwner == null || livingOwner == entity));
      if (ArtifactSkinConfig.onlySelf
         && (minecraft == null || livingOwner != minecraft.player && !ownerlessFlight)) {
         return original;
      }
      var selected = ArtifactSkins.selected(artifact);
      return modelFor(original,artifact,selected,Math.round(value));
   }

   private static Identifier modelFor(Identifier original,ArtifactSkins.Artifact artifact,ArtifactSkins.Option selected,int cmd) {
      if (ArtifactSkins.isServerDefault(selected)) return original;
      String itemPath = itemModelPath(original);
      if ("arrow".equals(itemPath)) {
         Identifier projectile = ArtifactProjectileModels.model(selected, cmd);
         return projectile == null ? original : projectile;
      }
      boolean bundledSkin = "lin_hoplite".equals(selected.worldModel().getNamespace());
      if (selected.id().startsWith("custom:") || bundledSkin) {
         if (bundledSkin) {
            if ("bow".equals(itemPath) && "harpoon_launcher:ender".equals(HopliteSkinCatalog.group(selected))) {
               return ENDER_HARPOON_BOW;
            }
            String base = artifact.baseItem();
            return (itemPath.equals("bow") || itemPath.equals("crossbow")) && !itemPath.equals(base)
                ? original : selected.worldModel();
         }
         return selected.worldModel();
      }
      // Keep the actual stack and owner so the resource pack can evaluate
      // using_item, use_duration and charge_type against the active hand.
      // Static catalog/default models discard all draw and loaded stages.
      // The pack provides Fishflop for bows only. Keep the server's complete
      // crossbow model when no compatible skin state tree is bundled.
      if ("crossbow".equals(itemPath) && artifact == ArtifactSkins.Artifact.PUFFERFISH_CANNON) {
         return original;
      }
      if ("bow".equals(itemPath) || "crossbow".equals(itemPath)) {
         return Identifier.fromNamespaceAndPath("lin_client",
            "artifact_world/" + itemPath + "_states");
      }
      return selected.worldModel();
   }

   /** Hoplite's modern item components use clap:server/<item>, with the same CMD table. */
   static String itemModelPath(Identifier model) {
      if (model == null) return "";
      if ("minecraft".equals(model.getNamespace())) return model.getPath();
      if ("clap".equals(model.getNamespace()) && model.getPath().startsWith("server/")) {
         return model.getPath().substring("server/".length());
      }
      return "";
   }

}
