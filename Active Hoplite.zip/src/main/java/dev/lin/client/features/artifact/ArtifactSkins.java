package dev.lin.client.features.artifact;

import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.core.component.DataComponents;
import net.minecraft.resources.Identifier;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.CustomModelData;

public final class ArtifactSkins {
   private static final Identifier CATALOG_PREVIEW = Identifier.fromNamespaceAndPath("lin_client", "artifact_preview");
   private static final Map<Artifact, List<Option>> OPTIONS = buildOptions();
   private static final Map<ModelKey, Artifact> MODEL_ARTIFACTS = buildModelArtifacts();
   private static final Map<Artifact, SelectedOption> SELECTED_OPTIONS = new EnumMap<>(Artifact.class);
   private record SelectedOption(String custom, String standard, Object legacy, Option option) {}
   private static final Map<Option, ItemStack> PREVIEW_STACKS = new ConcurrentHashMap<>();
   private static final Map<Option, ItemStack> WORN_PREVIEW_STACKS = new ConcurrentHashMap<>();
   private static long sharedRevision=Long.MIN_VALUE;
   private static Map<String,String> shared=Map.of();

   private ArtifactSkins() {
   }

   public static List<Option> options(Artifact artifact) {
      Map<String,Option> visible = new java.util.LinkedHashMap<>();
      for (Option option : OPTIONS.getOrDefault(artifact, List.of())) {
         if (!option.id().startsWith("custom:")) visible.putIfAbsent(HopliteSkinCatalog.group(option),option);
      }
      return List.copyOf(visible.values());
   }

   /** Artifact availability is independent of how many alternate skins it has. */
   public static List<Artifact> visibleArtifacts() {
      return java.util.Arrays.stream(Artifact.values()).filter(ArtifactSkins::isArtifact).toList();
   }

   public static boolean isArtifact(Artifact artifact) {
      // Only explicit exclusions affect the roster. Default-only artifacts stay
      // selectable, independently of alternate skins or custom-model availability.
      return switch (artifact) {
         case TOME_OF_UNDINE, VOID_BLOSSOM, MACE, GRIMOIRE, HELLFIRE_HALBERD, CLOUD_TOTEM -> false;
         default -> true;
      };
   }

   public static boolean sameSkin(Option first, Option second) {
      return HopliteSkinCatalog.group(first).equals(HopliteSkinCatalog.group(second));
   }

   /** Default is a pass-through selection, not a bundled replacement model. */
   public static boolean isServerDefault(Option option) {
      return option != null && !option.id().startsWith("custom:")
         && HopliteSkinCatalog.group(option).equals(option.artifact().id() + ":default");
   }

   public static Option catalogIcon(Artifact artifact) {
      return options(artifact).stream().filter(o -> HopliteSkinCatalog.group(o).equals(artifact.id()+":default"))
         .findFirst().orElse(options(artifact).getFirst());
   }

   public static List<Option> customOptions(Artifact artifact) {
      return CustomArtifactCatalog.optionsFor(artifact);
   }

   /** Only bundled catalog IDs cross the network, never models, paths or user files. */
   public static Map<String,String> sharedSelections() {
      if(!ArtifactSkinConfig.enabled)return Map.of();
      if(sharedRevision==ArtifactSkinConfig.revision)return shared;
      Map<String,String> out=new java.util.LinkedHashMap<>();
      for(var artifact:visibleArtifacts())if(ArtifactSkinConfig.isArtifactEnabled(artifact.id())){
         var selected=selected(artifact);
         if(!isServerDefault(selected) && dev.lin.client.cosmetics.sync.CosmeticSyncBridge.knownSkin(artifact.id(),selected.id()))out.put(artifact.id(),selected.id());
      }
      shared=Map.copyOf(out);sharedRevision=ArtifactSkinConfig.revision;return shared;
   }

   public static Option sharedOption(Artifact artifact,String id) {
      if(!dev.lin.client.cosmetics.sync.CosmeticSyncBridge.knownSkin(artifact.id(),id))return null;
      return SharedOptions.VALUES.getOrDefault(artifact,Map.of()).get(id);
   }
   private static final class SharedOptions {
      static final Map<Artifact,Map<String,Option>> VALUES=index();
      static Map<Artifact,Map<String,Option>> index(){
         Map<Artifact,Map<String,Option>> result=new EnumMap<>(Artifact.class);
         for(var artifact:visibleArtifacts()){
            Map<String,Option> group=new HashMap<>();
            for(var option:OPTIONS.getOrDefault(artifact,List.of()))group.put(option.id(),option);
            for(var option:customOptions(artifact))group.put(option.id(),option);
            result.put(artifact,Map.copyOf(group));
         }
         return Map.copyOf(result);
      }
   }

   public static void toggleCustom(Option option) {
      if (!customOptions(option.artifact()).contains(option)) return;
      String key = option.artifact().id();
      if (option.id().equals(ArtifactSkinConfig.customSkins.get(key))) ArtifactSkinConfig.customSkins.remove(key);
      else ArtifactSkinConfig.customSkins.put(key, option.id());
      ArtifactPackManager.selectionChanged();
   }

   public static Option selected(Artifact artifact) {
      String custom = ArtifactSkinConfig.customSkins.get(artifact.id());
      String standard = ArtifactSkinConfig.selectedSkins.get(artifact.id());
      Object legacy = switch (artifact) {
         case CHRONO_SWORD -> ArtifactSkinConfig.chronoSword;
         case DEATH_NOTE -> ArtifactSkinConfig.deathNote;
         case DRAGON_KATANA -> ArtifactSkinConfig.dragonKatana;
         case MJOLNIR -> ArtifactSkinConfig.mjolnir;
         case SOUL_GAUNTLET -> ArtifactSkinConfig.soulGauntlet;
         case WAR_PICKAXE -> ArtifactSkinConfig.warPickaxe;
         default -> artifact.defaultSkinId();
      };
      SelectedOption cached = SELECTED_OPTIONS.get(artifact);
      if (cached != null && java.util.Objects.equals(cached.custom(), custom)
         && java.util.Objects.equals(cached.standard(), standard) && java.util.Objects.equals(cached.legacy(), legacy))
         return cached.option();
      Option selected = null;
      if (custom != null) {
         for (Option option : customOptions(artifact)) if (option.id().equals(custom)) { selected = option; break; }
      }
      if (selected == null) selected = standardSelected(artifact);
      SELECTED_OPTIONS.put(artifact, new SelectedOption(custom, standard, legacy, selected));
      return selected;
   }

   public static String handTransformKey(Artifact artifact) {
      return artifact.id() + "|" + selected(artifact).worldModel();
   }

   public static Option standardSelected(Artifact artifact) {
      String selectedId = switch (artifact) {
         case CHRONO_SWORD -> ArtifactSkinConfig.chronoSword.name();
         case DEATH_NOTE -> ArtifactSkinConfig.deathNote.name();
         case DRAGON_KATANA -> ArtifactSkinConfig.dragonKatana.name();
         case MJOLNIR -> ArtifactSkinConfig.mjolnir.name();
         case SOUL_GAUNTLET -> ArtifactSkinConfig.soulGauntlet.name();
         case WAR_PICKAXE -> ArtifactSkinConfig.warPickaxe.name();
         default -> artifact.defaultSkinId();
      };
      return option(artifact, ArtifactSkinConfig.selectedSkins.getOrDefault(artifact.id(), selectedId.toLowerCase(Locale.ROOT)));
   }

   public static void select(Option option) {
      if (option == null) {
         return;
      }

      if (!options(option.artifact()).contains(option)) return;
      ArtifactSkinConfig.customSkins.remove(option.artifact().id());
      ArtifactSkinConfig.selectedSkins.put(option.artifact().id(), option.id());

      ArtifactPackManager.selectionChanged();
   }

   public static Artifact artifactFor(String itemModelPath, int customModelData) {
      Artifact artifact = MODEL_ARTIFACTS.get(new ModelKey(itemModelPath, customModelData));
      return artifact != null && isArtifact(artifact) ? artifact : null;
   }

   /** Only the HUD icon is replaced; gameplay continues to use the server's stack. */
   public static ItemStack hudIcon(ItemStack stack) {
      if (stack == null || stack.isEmpty() || !ArtifactSkinConfig.enabled
              || !HopliteServerContext.canRenderArtifactSkins()) return stack;
      Identifier model = stack.get(DataComponents.ITEM_MODEL);
      CustomModelData data = stack.get(DataComponents.CUSTOM_MODEL_DATA);
      if (model == null || data == null || data.floats().isEmpty()) return stack;
      String path = model.getPath();
      if ("clap".equals(model.getNamespace()) && path.startsWith("server/")) path = path.substring(7);
      else if (!"minecraft".equals(model.getNamespace())) return stack;
      Artifact artifact = artifactFor(path, Math.round(data.floats().getFirst()));
      if (artifact == null || !ArtifactSkinConfig.isArtifactEnabled(artifact.id())) return stack;
      Option selected = selected(artifact);
      return isServerDefault(selected) ? stack : previewStack(selected);
   }

   public static ItemStack previewStack(Artifact artifact) {
      return previewStack(selected(artifact));
   }

   public static ItemStack previewStack(Option option) {
      return PREVIEW_STACKS.computeIfAbsent(option, ArtifactSkins::createPreviewStack);
   }

   public static ItemStack wornPreviewStack(Artifact artifact) {
      Option option = selected(artifact);
      return WORN_PREVIEW_STACKS.computeIfAbsent(option,
         value -> createPreviewStack(value, Items.ELYTRA));
   }

   public static void clear() {
      SELECTED_OPTIONS.clear();
      PREVIEW_STACKS.clear();
      WORN_PREVIEW_STACKS.clear();
   }

   private static Option option(Artifact artifact, String id) {
      // A default expression passed to orElse is evaluated even when the lookup succeeds.
      for (Option option : OPTIONS.getOrDefault(artifact, List.of())) {
         if (option.id().equals(id)) return option;
      }
      return options(artifact).getFirst();
   }

   private static Option option(Artifact artifact, String id, String displayName, String previewModel, int seed) {
      Identifier model = Identifier.fromNamespaceAndPath("lin_client", previewModel);
      return new Option(artifact, id, displayName, model, model, seed);
   }

   private static Map<Artifact, List<Option>> buildOptions() {
      Map<Artifact, List<Option>> values = new EnumMap<>(Artifact.class);
      for (Artifact artifact : Artifact.values()) {
         values.put(
            artifact,
            switch (artifact) {
               case HEADHUNTERS_CHESTPIECE -> List.of(
                  option(artifact, "default", "默认", "artifact/headhunters_might", 221)
               );
               case DEATH_NOTE -> List.of(
                  option(artifact, "green", "绿色", "artifact/death_note_green", 201),
                  option(artifact, "red", "红色", "artifact/death_note_red", 202)
               );
               case CHRONO_SWORD -> List.of(
                  option(artifact, "engineers", "工程师", "artifact/chrono_sword_engineers", 211),
                  option(artifact, "steaming", "蒸汽", "artifact/chrono_sword_steaming", 212)
               );
               case DRAGON_KATANA -> List.of(
                  option(artifact, "dragonbreath", "龙息", "artifact/dragon_katana_dragonbreath", 203),
                  option(artifact, "cthulhu", "克苏鲁", "artifact/dragon_katana_cthulhu", 204)
               );
               case MJOLNIR -> List.of(
                  option(artifact, "valentine", "情人节", "artifact/mjolnir_valentine", 205),
                  option(artifact, "shattered", "破碎", "artifact/mjolnir_shattered", 206)
               );
               case SOUL_GAUNTLET -> List.of(
                  option(artifact, "alien", "异星", "artifact/soul_gauntlet_alien", 207),
                  option(artifact, "infinity", "无限", "artifact/soul_gauntlet_infinity", 208)
               );
               case WAR_PICKAXE -> List.of(
                  option(artifact, "talarian", "塔拉里安", "artifact/war_pickaxe_talarian", 209),
                  option(artifact, "victorian", "维多利亚", "artifact/war_pickaxe_victorian", 210)
               );
               default -> List.of(new Option(artifact, artifact.defaultSkinId(), artifact.defaultSkinName(), CATALOG_PREVIEW,
                  Identifier.fromNamespaceAndPath("lin_client", "artifact_world/" + artifact.id()), artifact.previewIndex()));
            }
         );
      }
      HopliteSkinCatalog.appendTo(values);
      return Map.copyOf(values);
   }

   private static ItemStack createPreviewStack(Option option) {
      return createPreviewStack(option, Items.STICK);
   }

   private static ItemStack createPreviewStack(Option option, net.minecraft.world.item.Item item) {
      ItemStack stack = new ItemStack(item);
      stack.set(DataComponents.ITEM_MODEL, option.previewModel());
      if (CATALOG_PREVIEW.equals(option.previewModel())) {
         stack.set(
            DataComponents.CUSTOM_MODEL_DATA,
            new CustomModelData(List.of((float)option.artifact().previewIndex()), List.of(), List.of(), List.of())
         );
      }
      return stack;
   }

   private static Map<ModelKey, Artifact> buildModelArtifacts() {
      Map<ModelKey, Artifact> values = new HashMap<>();
      link(values, Artifact.AIGLOS, "arrow", 2, 8);
      link(values, Artifact.AIGLOS, "bow", 7, 13);
      link(values, Artifact.ARMADILLO_DETONATOR, "crossbow", 5, 8);
      link(values, Artifact.BEEHIVE_BLASTER, "bow", 9, 21);
      link(values, Artifact.CHRONO_SWORD, "iron_sword", 10, 11, 13);
      link(values, Artifact.CLOUD_SWORD, "diamond_sword", 7, 12);
      link(values, Artifact.CORRUPTED_CROSSBOW, "crossbow", 4, 12);
      link(values, Artifact.CRIMSON_CHAINSWORD, "diamond_sword", 8, 9, 15, 16);
      link(values, Artifact.DEATH_NOTE, "writable_book", 1, 2);
      link(values, Artifact.DRAGON_KATANA, "diamond_sword", 2);
      link(values, Artifact.DRAGON_KATANA, "netherite_sword", 1, 4, 6);
      link(values, Artifact.DRAGONIGHT_STAFF, "stone_sword", 14, 15, 18);
      link(values, Artifact.EAGLE_EYE_BOW, "bow", 28, 29);
      link(values, Artifact.EMERALD_BLADE, "diamond_sword", 3, 17);
      link(values, Artifact.ENDER_BOW, "bow", 1, 2, 32, 33);
      link(values, Artifact.EVOKER_WAND, "stone_sword", 7, 8);
      link(values, Artifact.EXCALIBUR_SWORD, "netherite_sword", 3, 5);
      link(values, Artifact.FREEZING_CHAKRAM, "diamond_sword", 13, 18);
      link(values, Artifact.GOLEM_HAMMER, "stone_axe", 3, 4);
      link(values, Artifact.GUARDIAN_CANNON, "blaze_rod", 7, 20);
      link(values, Artifact.GUARDIAN_CANNON, "bow", 10, 23);
      link(values, Artifact.HARPOON_LAUNCHER, "arrow", 4, 17, 26);
      link(values, Artifact.HARPOON_LAUNCHER, "blaze_rod", 8, 21, 39);
      link(values, Artifact.HARPOON_LAUNCHER, "bow", 11, 24, 39, 42);
      link(values, Artifact.HARPOON_LAUNCHER, "crossbow", 7, 20);
      link(values, Artifact.HYPNOSIS_STAFF, "stone_sword", 6, 10);
      link(values, Artifact.LICH_STAFF, "stone_sword", 2, 16);
      link(values, Artifact.MAGMA_CANNON, "blaze_rod", 24, 25, 26, 28, 29, 30);
      link(values, Artifact.MAGMA_CLUB, "diamond_sword", 5, 10);
      link(values, Artifact.MAGMA_CLUB, "iron_sword", 3);
      link(values, Artifact.MIDAS_SWORD, "diamond_sword", 1, 14);
      link(values, Artifact.MJOLNIR, "stone_axe", 1, 5, 8);
      link(values, Artifact.MJOLNIR, "netherite_axe", 5, 6, 7);
      link(values, Artifact.POSEIDON_TRIDENT, "arrow", 3, 9);
      link(values, Artifact.POSEIDON_TRIDENT, "bow", 8, 14);
      link(values, Artifact.PUFFERFISH_CANNON, "bow", 15, 16);
      link(values, Artifact.PUFFERFISH_CANNON, "crossbow", 23);
      link(values, Artifact.PUFFERFISH_CANNON, "wooden_shovel", 1, 2, 3, 4, 5, 6, 7, 8, 10);
      link(values, Artifact.REAPER_SCYTHE, "stone_hoe", 2, 8);
      link(values, Artifact.REINFORCED_ELYTRA, "elytra", 1, 2);
      link(values, Artifact.RIBBIT_REEL, "arrow", 11, 22, 25);
      link(values, Artifact.RIBBIT_REEL, "blaze_rod", 16, 27, 38);
      link(values, Artifact.RIBBIT_REEL, "crossbow", 6, 17);
      link(values, Artifact.SCEPTRE_OF_ARACHNE, "arrow", 5, 6, 12, 13);
      link(values, Artifact.SCEPTRE_OF_ARACHNE, "bow", 30, 31, 34, 35);
      link(values, Artifact.SCULKWEAVER_LANTERN, "fishing_rod", 5, 6, 7, 8);
      link(values, Artifact.SHADOW_BLADE, "diamond_sword", 4, 11);
      link(values, Artifact.SHRINK_RAY, "blaze_rod", 10, 15);
      link(values, Artifact.SHRINK_RAY, "bow", 12, 17);
      link(values, Artifact.SONIC_CROSSBOW, "crossbow", 1, 22);
      link(values, Artifact.SOUL_GAUNTLET, "blaze_rod", 17, 34, 35);
      link(values, Artifact.VILLAGER_WAND, "stone_sword", 11, 13);
      link(values, Artifact.WAR_PICKAXE, "diamond_pickaxe", 1, 3, 7);
      link(values, Artifact.WITHER_SICKLE, "stone_hoe", 3, 7);
      for (var entry : HopliteSkinCatalog.entries()) {
         try { values.put(new ModelKey(entry.item(), entry.cmd()), Artifact.valueOf(entry.artifact().toUpperCase(Locale.ROOT))); }
         catch (IllegalArgumentException ignored) {}
      }
      return Map.copyOf(values);
   }

   private static void link(Map<ModelKey, Artifact> values, Artifact artifact, String itemModelPath, int... customModelData) {
      for (int value : customModelData) {
         values.put(new ModelKey(itemModelPath, value), artifact);
      }
   }

   public enum Artifact {
      AIGLOS("aiglos", "埃格洛斯", "bow", 7, "serpentine", "蛇纹", "civilization:item/tools/aiglos/serpentine/pulling/3"),
      ARMADILLO_DETONATOR("armadillo_detonator", "犰狳引爆器", "crossbow", 5, "infernal", "炼狱", "civilization:item/tools/armadillo_detonator/infernal/default"),
      BEEHIVE_BLASTER("beehive_blaster", "蜂巢爆能枪", "bow", 9, "flower_power", "花之力", "civilization:item/tools/beehive_blaster/flower_power/default"),
      CHRONO_SWORD("chrono_sword", "时序之剑", "iron_sword", 10, "engineers", "工程师", "civilization:item/tools/chrono_sword/engineers"),
      CLOUD_SWORD("cloud_sword", "轻云之剑", "diamond_sword", 7, "air_king", "天空之王", "civilization:item/tools/cloud_sword/air_king"),
      CORRUPTED_CROSSBOW("corrupted_crossbow", "腐败之弩", "crossbow", 4, "trap_dismantling", "陷阱拆解", "civilization:item/tools/corrupted_crossbow/trap_dismantling/default"),
      CRIMSON_CHAINSWORD("crimson_chainsword", "猩红链锯剑", "diamond_sword", 8, "zombie", "丧尸", "civilization:item/tools/crimson_chainsword/zombie_off"),
      DEATH_NOTE("death_note", "死亡笔记", "writable_book", 1, "red", "红色", "civilization:item/tools/death_note_red"),
      DRAGON_KATANA("dragon_katana", "龙刃", "netherite_sword", 1, "cthulhu", "克苏鲁", "civilization:item/tools/dragon_katana/cthulhu"),
      DRAGONIGHT_STAFF("dragonight_staff", "龙骑士法杖", "stone_sword", 14, "tricksters_dragon_sceptre", "诡术龙权杖", "civilization:item/tools/dragonight_staff/tricksters_dragon_sceptre"),
      EAGLE_EYE_BOW("eagle_eye_bow", "鹰眼弓", "bow", 28, "frosted", "霜冻", "civilization:item/tools/eagle_eye_bow/frosted/default"),
      EMERALD_BLADE("emerald_blade", "绿宝石之剑", "diamond_sword", 3, "valentine", "情人节", "civilization:item/tools/emerald_blade/valentine"),
      ENDER_BOW("ender_bow", "末影之弓", "bow", 1, "pirates_helm", "海盗头盔", "civilization:item/tools/ender_bow/pirates_helm/arrow/default"),
      EVOKER_WAND("evoker_wand", "唤魔者法杖", "stone_sword", 7, "frostbite", "霜寒", "civilization:item/tools/evoker_wand/frostbite"),
      EXCALIBUR_SWORD("excalibur_sword", "王者之剑", "netherite_sword", 3, "radiant", "辉耀", "civilization:item/tools/excalibur_sword/radiant"),
      FREEZING_CHAKRAM("freezing_chakram", "冰霜环刃", "diamond_sword", 13, "starfall", "星落", "civilization:item/tools/freezing_chakram/starfall"),
      GOLEM_HAMMER("golem_hammer", "傀儡战锤", "stone_axe", 3, "resonant", "共鸣", "civilization:item/tools/golem_hammer/resonant"),
      GUARDIAN_CANNON("guardian_cannon", "守卫者炮", "bow", 10, "light_up", "点亮", "civilization:item/tools/guardian_cannon/light_up/default"),
      HARPOON_LAUNCHER("harpoon_launcher", "钩爪发射器", "crossbow", 7, "horn", "号角", "civilization:item/tools/harpoon_launcher/horn/default"),
      HYPNOSIS_STAFF("hypnosis_staff", "催眠法杖", "stone_sword", 6, "eggstatic", "彩蛋", "civilization:item/tools/hypnosis_staff/eggstatic"),
      LICH_STAFF("lich_staff", "巫妖法杖", "stone_sword", 2, "timeloss", "时间迷失", "civilization:item/tools/lich_staff/timeloss"),
      MAGMA_CANNON("magma_cannon", "岩浆炮", "blaze_rod", 24, "gilded", "鎏金", "civilization:item/tools/magma_cannon/gilded/default"),
      MAGMA_CLUB("magma_club", "岩浆棍", "diamond_sword", 5, "inferno", "烈焰", "civilization:item/tools/magma_club/inferno"),
      MIDAS_SWORD("midas_sword", "米达斯之剑", "diamond_sword", 1, "ominous", "不祥", "civilization:item/tools/midas_sword/ominous"),
      MJOLNIR("mjolnir", "雷神之锤", "stone_axe", 1, "valentine", "情人节", "civilization:item/tools/mjolnir/valentine"),
      POSEIDON_TRIDENT("poseidon_trident", "波塞冬三叉戟", "bow", 8, "guardian", "守护者", "civilization:item/tools/poseidon_trident/guardian/default"),
      PUFFERFISH_CANNON("pufferfish_cannon", "河豚炮", "bow", 15, "fishflop", "鱼跃", "civilization:item/tools/pufferfish_cannon/fishflop/default"),
      REAPER_SCYTHE("reaper_scythe", "死神镰刀", "stone_hoe", 2, "necromancer", "亡灵法师", "civilization:item/tools/reaper_scythe/necromancer"),
      REINFORCED_ELYTRA("reinforced_elytra", "强化鞘翅", "elytra", 1, "valentines", "情人节", "civilization:item/tools/reinforced_elytra/valentines"),
      RIBBIT_REEL("ribbit_reel", "蛙鸣鱼竿", "crossbow", 6, "valentine", "情人节", "civilization:item/tools/ribbit_reel/valentine/default"),
      SCEPTRE_OF_ARACHNE("sceptre_of_arachne", "阿拉克涅权杖", "bow", 30, "undead", "亡灵", "civilization:item/tools/sceptre_of_arachne/undead/off/default"),
      SCULKWEAVER_LANTERN("sculkweaver_lantern", "幽匿编织者灯笼", "fishing_rod", 5, "jolly", "欢庆", "civilization:item/tools/sculkweaver_lantern/jolly/default"),
      SHADOW_BLADE("shadow_blade", "暗影之刃", "diamond_sword", 4, "sculkripper", "幽匿撕裂者", "civilization:item/tools/shadow_blade/sculkripper"),
      SHRINK_RAY("shrink_ray", "缩小射线", "bow", 12, "void_singularity", "虚空奇点", "civilization:item/tools/shrink_ray/void_singularity/default"),
      SONIC_CROSSBOW("sonic_crossbow", "音速强弩", "crossbow", 1, "breezy", "轻风", "civilization:item/tools/sonic_crossbow/breezy/default"),
      SOUL_GAUNTLET("soul_gauntlet", "灵魂手套", "blaze_rod", 17, "infinity", "无限", "civilization:item/tools/soul_gauntlet/infinity"),
      VILLAGER_WAND("villager_wand", "村民法杖", "stone_sword", 11, "bifrost", "彩虹桥", "civilization:item/tools/villager_wand/bifrost"),
      WAR_PICKAXE("war_pickaxe", "战争镐", "diamond_pickaxe", 1, "talarian", "塔拉里安", "civilization:item/tools/war_pickaxe/talarian"),
      WITHER_SICKLE("wither_sickle", "凋零镰刀", "stone_hoe", 3, "gravedigger", "掘墓者", "civilization:item/tools/wither_sickle/gravedigger"),
      ARTEMIS_BOW("artemis_bow", "阿尔忒弥斯之弓", "bow", 0, "hoplite_default", "Hoplite", "minecraft:item/bow"),
      MACE("mace", "重锤", "diamond_sword", 0, "hoplite_default", "Hoplite", "minecraft:item/diamond_sword"),
      SAKURA_TESSEN("sakura_tessen", "樱花铁扇", "diamond_sword", 0, "hoplite_default", "Hoplite", "minecraft:item/diamond_sword"),
      VAMPIRE_SABRE("vampire_sabre", "吸血鬼军刀", "diamond_sword", 0, "hoplite_default", "Hoplite", "minecraft:item/diamond_sword"),
      HELLFIRE_HALBERD("hellfire_halberd", "地狱火战戟", "netherite_axe", 0, "hoplite_default", "Hoplite", "minecraft:item/netherite_axe"),
      VOID_BLOSSOM("void_blossom", "虚空之花", "stone_axe", 0, "hoplite_default", "Hoplite", "minecraft:item/stone_axe"),
      RAVAGER_HORN("ravager_horn", "劫掠兽号角", "goat_horn", 0, "hoplite_default", "Hoplite", "minecraft:item/goat_horn"),
      HORN_OF_WINTER("horn_of_winter", "寒冬号角", "blaze_rod", 0, "hoplite_default", "Hoplite", "minecraft:item/blaze_rod"),
      GHASTLY_WHISTLE("ghastly_whistle", "恶魂哨笛", "blaze_rod", 0, "hoplite_default", "Hoplite", "minecraft:item/blaze_rod"),
      GRIMOIRE("grimoire", "魔法典籍", "enchanted_book", 0, "hoplite_default", "Hoplite", "minecraft:item/enchanted_book"),
      TOME_OF_UNDINE("tome_of_undine", "水精灵之书", "enchanted_book", 0, "hoplite_default", "Hoplite", "minecraft:item/enchanted_book"),
      CLOUD_TOTEM("cloud_totem", "云之图腾", "totem_of_undying", 0, "hoplite_default", "Hoplite", "minecraft:item/totem_of_undying"),
      LEGENDARY_SNIFFER("legendary_sniffer", "传奇嗅探兽", "sniffer_spawn_egg", 0, "hoplite_default", "Hoplite", "minecraft:item/sniffer_spawn_egg"),
      HEADHUNTERS_CHESTPIECE("headhunters_chestpiece", "猎颅者盔甲", "diamond_chestplate", 1, "default", "默认", "civilization:item/armor/headhunters_might/chestplate"),
      PHANTOM_BOW("phantom_bow", "幻翼弓 / Phantom Bow", "bow", 22, "hoplite_default", "Hoplite", "minecraft:item/bow");

      private final String id;
      private final String displayName;
      private final String baseItem;
      private final int customModelData;
      private final String defaultSkinId;
      private final String defaultSkinName;
      private final Identifier previewModel;

      Artifact(
         String id,
         String displayName,
         String baseItem,
         int customModelData,
         String defaultSkinId,
         String defaultSkinName,
         String previewModel
      ) {
         this.id = id;
         this.displayName = displayName;
         this.baseItem = baseItem;
         this.customModelData = customModelData;
         this.defaultSkinId = defaultSkinId;
         this.defaultSkinName = defaultSkinName;
         this.previewModel = Identifier.parse(previewModel);
      }

      public String id() {
         return this.id;
      }

      public String displayName() {
         return this.displayName;
      }

      public String baseItem() {
         return this.baseItem;
      }

      public int customModelData() {
         return this.customModelData;
      }

      public String defaultSkinId() {
         return this.defaultSkinId;
      }

      public String defaultSkinName() {
         return this.defaultSkinName;
      }

      public Identifier previewModel() {
         return this.previewModel;
      }

      public int previewIndex() {
         return this.ordinal() + 1;
      }

      public PreviewMode previewMode() {
         return switch (this) {
            case AIGLOS, BEEHIVE_BLASTER, EAGLE_EYE_BOW, ENDER_BOW,
               GUARDIAN_CANNON, PUFFERFISH_CANNON, SCEPTRE_OF_ARACHNE,
               SHRINK_RAY -> PreviewMode.TWO_HAND_BOW;
            case ARMADILLO_DETONATOR, CORRUPTED_CROSSBOW,
               HARPOON_LAUNCHER, MAGMA_CANNON, RIBBIT_REEL,
               SONIC_CROSSBOW -> PreviewMode.TWO_HAND_CROSSBOW;
            case DEATH_NOTE -> PreviewMode.TWO_HAND_ITEM;
            case CRIMSON_CHAINSWORD, DRAGON_KATANA, DRAGONIGHT_STAFF,
               GOLEM_HAMMER, HYPNOSIS_STAFF, LICH_STAFF, MAGMA_CLUB,
               REAPER_SCYTHE, VILLAGER_WAND, WAR_PICKAXE, WITHER_SICKLE ->
               PreviewMode.TWO_HAND_ITEM;
            case POSEIDON_TRIDENT -> PreviewMode.TRIDENT;
            case REINFORCED_ELYTRA -> PreviewMode.ELYTRA;
            default -> PreviewMode.MAIN_HAND;
         };
      }
   }

   public enum PreviewMode {
      MAIN_HAND,
      TWO_HAND_ITEM,
      TWO_HAND_BOW,
      TWO_HAND_CROSSBOW,
      TRIDENT,
      HEAD,
      ELYTRA
   }

   public record Option(Artifact artifact, String id, String displayName, Identifier previewModel,
                        Identifier worldModel, int seed) {
   }

   private record ModelKey(String itemModelPath, int customModelData) {
   }
}
