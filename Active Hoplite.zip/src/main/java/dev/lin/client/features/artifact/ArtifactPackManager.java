package dev.lin.client.features.artifact;

public final class ArtifactPackManager {
   private ArtifactPackManager() {
   }

   public static void setEnabled(boolean enabled) {
      ArtifactSkinConfig.enabled = enabled;
      ArtifactSkinConfig.save();
   }

   public static void setOnlySelf(boolean onlySelf) {
      ArtifactSkinConfig.onlySelf = onlySelf;
      ArtifactSkinConfig.save();
   }

   public static void setArtifactEnabled(ArtifactSkins.Artifact artifact, boolean enabled) {
      if (artifact == null) {
         return;
      }

      ArtifactSkinConfig.setArtifactEnabled(artifact.id(), enabled);
      ArtifactSkinConfig.save();
   }

   public static void selectionChanged() {
      ArtifactSkinConfig.save();
   }
}
