package dev.lin.client.features.render;

import com.mojang.blaze3d.vertex.PoseStack;
import dev.lin.client.cosmetics.sync.RemoteCosmetics;
import dev.lin.client.features.accessory.AccessoryDefinition;
import dev.lin.client.features.accessory.AccessoryRegistry;
import dev.lin.client.features.accessory.AccessorySlot;
import dev.lin.client.features.config.ClientAccessoryConfig;
import dev.lin.client.features.artifact.HopliteServerContext;
import dev.lin.client.cosmetics.catalog.CosmeticCategory;
import dev.lin.client.cosmetics.config.CosmeticConfig;
import dev.lin.client.features.pet.LunarPetWorldRenderer;
import dev.lin.client.features.ui.AccessorySelectorScreen;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.player.PlayerModel;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.state.CameraRenderState;
import net.minecraft.client.renderer.entity.layers.CustomHeadLayer;
import net.minecraft.client.renderer.entity.layers.CustomHeadLayer.Transforms;
import net.minecraft.client.renderer.entity.state.AvatarRenderState;
import net.minecraft.client.renderer.item.ItemStackRenderState;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import net.minecraft.ChatFormatting;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.HashMap;
import java.util.Map;

public final class AccessoryWorldRenderer {
   private static final float HOPLITE_WING_BASE_OFFSET_Y = 0.12F;
   private static final float HOPLITE_MEDALLION_BASE_SCALE = 0.30F;
   private static final double BADGE_FLOW_PERIOD = 1.1;
   private static final double RANK_FLOW_PERIOD = 1.3;
   private static final float[] IDLE_BADGE_X = {-0.70F, -0.27F, 0.32F, 0.70F, -0.50F, 0.50F};
   private static final float[] IDLE_BADGE_Z = {0.18F, -0.35F, 0.40F, -0.15F, 0.52F, -0.48F};
   private static final float[] IDLE_RANK_X = {0.10F, 0.68F, -0.62F, 0.35F, -0.20F, -0.72F};
   private static final float[] IDLE_RANK_Z = {-0.52F, 0.26F, -0.10F, -0.42F, 0.48F, 0.32F};
   private static long channelEpoch=-1;
   private static final Map<java.util.UUID,FloatingChannel> CHANNELS = new java.util.LinkedHashMap<>(64,.75f,true);
   private static final Map<Integer, AccessoryDefinition> PREVIEW_WINGS = new HashMap<>();
   private static final Map<Integer, AccessoryDefinition> PREVIEW_FLOATING = new HashMap<>();
   private static final Map<String, float[]> PREVIEW_WING_OFFSETS = Map.ofEntries(
      Map.entry("abomination", new float[]{-0.35F, -0.16F}),
      Map.entry("autumn", new float[]{0.07F, -0.35F}),
      Map.entry("doc_oc", new float[]{-0.04F, 0.00F}),
      Map.entry("ender_dragon", new float[]{-0.02F, 0.03F}),
      Map.entry("engineer", new float[]{0.35F, 0.04F}),
      Map.entry("fallen", new float[]{-0.35F, 0.04F}),
      Map.entry("flowery", new float[]{0.10F, -0.12F}),
      Map.entry("ghost", new float[]{-0.35F, -0.35F}),
      Map.entry("golden", new float[]{-0.10F, 0.03F}),
      Map.entry("graphite_lattice", new float[]{0.27F, -0.05F}),
      Map.entry("holographic", new float[]{0.01F, -0.07F}),
      Map.entry("mechanical", new float[]{0.07F, 0.04F}),
      Map.entry("nether", new float[]{-0.35F, 0.05F}),
      Map.entry("parrot", new float[]{0.35F, 0.02F}),
      Map.entry("pastel", new float[]{0.12F, 0.02F}),
      Map.entry("runekeeper", new float[]{-0.35F, -0.18F}),
      Map.entry("spiderweb", new float[]{0.09F, 0.09F}),
      Map.entry("steampunk", new float[]{-0.35F, 0.01F}),
      Map.entry("winter", new float[]{0.09F, -0.14F})
   );

   private AccessoryWorldRenderer() {
   }
   public static void clearChannels() { CHANNELS.clear(); }

   public static void submit(PlayerModel model, AvatarRenderState state, PoseStack matrices, SubmitNodeCollector collector) {
      AccessoryDefinition wings = PREVIEW_WINGS.get(state.id);
      Minecraft minecraft = Minecraft.getInstance();
      if (!PREVIEW_WINGS.containsKey(state.id) && minecraft.player != null && state.id == minecraft.player.getId()) {
         wings = CosmeticConfig.equipped(CosmeticCategory.DRAGON_WINGS) == null
            ? AccessoryRegistry.selected(AccessorySlot.WINGS)
            : null;
      }
      if(state.isInvisible)return;
      var remote=RemoteCosmetics.outfit(state);
      if(remote!=null && !PREVIEW_WINGS.containsKey(state.id))
         wings=remote.slots().containsKey("dragon_wings")?null:RemoteCosmetics.accessory(remote,AccessorySlot.WINGS);
      submitWings(model, wings, state, matrices, collector);
      if(remote!=null ? !remote.slots().containsKey("pet") : CosmeticConfig.equipped(CosmeticCategory.PET)==null)
         LunarPetWorldRenderer.submit(state,matrices,collector);
   }

   public static void submitFloating(AvatarRenderState state, PoseStack matrices,
                                     SubmitNodeCollector collector,
                                     CameraRenderState camera) {
      Minecraft minecraft = Minecraft.getInstance();
      AccessoryDefinition floating = PREVIEW_FLOATING.get(state.id);
      boolean preview = PREVIEW_FLOATING.containsKey(state.id);
      if (!preview && minecraft.player != null && state.id == minecraft.player.getId()
         && minecraft.options.getCameraType().isFirstPerson()) return;
      if (!preview && minecraft.player != null && state.id == minecraft.player.getId()
         && (ClientAccessoryConfig.floatingGlobal
            || HopliteServerContext.isLobbyWithoutTabHealth())) {
         floating = AccessoryRegistry.selected(AccessorySlot.FLOATING);
      }
      var remote=RemoteCosmetics.outfit(state);
      var view=RemoteCosmetics.view(state);
      if(!preview && remote!=null && view.animated()
         && (remote.flag("floatingGlobal",false) || HopliteServerContext.isLobbyWithoutTabHealth()))
         floating=RemoteCosmetics.accessory(remote,AccessorySlot.FLOATING);
      renderFloating(floating, state, matrices, collector, camera, preview, false);
   }

   public static void renderFirstPerson(
      net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext context
   ) {
      Minecraft minecraft = Minecraft.getInstance();
      if (minecraft.player == null || minecraft.level == null
         || !minecraft.options.getCameraType().isFirstPerson()
         || minecraft.gameRenderer.getMainCamera().entity() != minecraft.player
         || minecraft.player.isSpectator() || context.matrices() == null) return;
      if (!(ClientAccessoryConfig.floatingGlobal
         || HopliteServerContext.isLobbyWithoutTabHealth())) return;
      AccessoryDefinition definition = AccessoryRegistry.selected(AccessorySlot.FLOATING);
      if (definition == null) return;
      AvatarRenderState state = new AvatarRenderState();
      state.id = minecraft.player.getId();
      state.ageInTicks = minecraft.player.tickCount
         + minecraft.gameRenderer.getMainCamera().getPartialTickTime();
      state.boundingBoxHeight = minecraft.player.getBbHeight();
      state.distanceToCameraSq = 4.5 * 4.5;
      PoseStack matrices = context.matrices();
      matrices.pushPose();
      try {
         renderFloating(definition, state, matrices, context.commandQueue(),
            minecraft.gameRenderer.getLevelRenderState().cameraRenderState, false, true);
      } finally {
         matrices.popPose();
      }
   }

   public static void beginPreviewFrame() {
      PREVIEW_WINGS.clear();
      PREVIEW_FLOATING.clear();
   }

   public static void registerPreviewWing(int stateId, AccessoryDefinition definition) {
      if (definition != null && definition.slot() == AccessorySlot.FLOATING) {
         PREVIEW_FLOATING.put(stateId, definition);
      } else {
         PREVIEW_WINGS.put(stateId, definition);
      }
   }

   public static void registerPreviewFloating(int stateId, AccessoryDefinition definition) {
      PREVIEW_FLOATING.put(stateId, definition);
   }

   private static void renderFloating(AccessoryDefinition definition,AvatarRenderState state,PoseStack matrices,
         SubmitNodeCollector collector,CameraRenderState camera,boolean preview,boolean firstPerson) {
      if(definition==null || state.isInvisible)return;
      if(channelEpoch!=RemoteCosmetics.epoch){CHANNELS.clear();channelEpoch=RemoteCosmetics.epoch;}
      var owner=RemoteCosmetics.player(state);
      java.util.UUID key=preview || owner==null?new java.util.UUID(0,state.id):owner.getUUID();
      FloatingChannel channel=CHANNELS.computeIfAbsent(key,id->new FloatingChannel());
      while(CHANNELS.size()>64)CHANNELS.remove(CHANNELS.keySet().iterator().next());
      channel.renderFloating(definition,state,matrices,collector,camera,preview,firstPerson);
   }
   private static final class FloatingChannel {
   private int channelOwner = Integer.MIN_VALUE;
   private String channelDefinition = "";
   private long channelTime;
   private double movementBlend;
   private double pathDistance;
   private double flowSeconds;
   private boolean moving;
   private double stoppedSeconds;
   private boolean restartFromTop;
   private float idleTicks;
   private float lastTicks;
   private float frozenTop;
   private final Deque<MovementPoint> movementPath = new ArrayDeque<>();
   private void renderFloating(AccessoryDefinition definition,
                                      AvatarRenderState state, PoseStack matrices,
                                      SubmitNodeCollector collector,
                                      CameraRenderState camera,
                                      boolean preview, boolean firstPerson) {
      if (definition == null) return;
      Minecraft minecraft = Minecraft.getInstance();
      var owner=preview?minecraft.player:RemoteCosmetics.player(state);
      var remote=preview?null:RemoteCosmetics.outfit(state);
      ItemStackRenderState itemState = new ItemStackRenderState();
      if (owner != null) {
         minecraft.getItemModelResolver().updateForLiving(itemState,
            AccessoryItemModels.stack(definition), ItemDisplayContext.GUI,
            owner);
      }
      if (itemState.isEmpty()) return;
      boolean animateMovement = !preview && owner != null;
      Vec3 playerPosition = Vec3.ZERO;
      double currentPath = 0.0;
      if (animateMovement) {
         long now = System.nanoTime();
         boolean reset = channelOwner != state.id
            || !channelDefinition.equals(definition.id())
            || now < channelTime || now - channelTime > 500_000_000L;
         double dt = reset ? 0.0 : Math.min(0.1, (now - channelTime) * 1.0E-9);
         float partial = Mth.clamp(state.ageInTicks - owner.tickCount, 0.0F, 1.0F);
         playerPosition = new Vec3(
            Mth.lerp(partial, owner.xOld, owner.getX()),
            Mth.lerp(partial, owner.yOld, owner.getY()),
            Mth.lerp(partial, owner.zOld, owner.getZ()));
         if (reset || !movementPath.isEmpty()
            && movementPath.peekLast().position().distanceToSqr(playerPosition) > 9.0) {
            movementBlend = pathDistance = flowSeconds = 0.0;
            moving = false;
            stoppedSeconds = 0.0;
            restartFromTop = false;
            idleTicks = lastTicks = state.ageInTicks;
            frozenTop = state.boundingBoxHeight + 0.65F;
            movementPath.clear();
         }
         channelOwner = state.id;
         channelDefinition = definition.id();
         channelTime = now;
         double dx = owner.getX() - owner.xOld;
         double dz = owner.getZ() - owner.zOld;
         double speed = Math.sqrt(dx * dx + dz * dz) * 20.0;
         // Hysteresis prevents repeated switches near the movement threshold.
         boolean wasMoving = moving;
         stoppedSeconds = moving && speed <= 0.3 ? stoppedSeconds + dt : 0.0;
         moving = moving ? stoppedSeconds < 0.06 : speed > 0.8;
         if (wasMoving && !moving) {
            // Retire the moving cycle, never pull its symbols back to their origins.
            movementBlend = pathDistance = flowSeconds = 0.0;
            idleTicks = 0.0F;
            lastTicks = state.ageInTicks;
            restartFromTop = true;
            frozenTop = state.boundingBoxHeight + 0.65F;
            movementPath.clear();
            return;
         }
         movementBlend = transition(movementBlend, moving, dt);
         // Time drives flow; running faster cannot emit more symbols.
         if (moving) flowSeconds += dt;
         if (moving && movementBlend < 1.0) {
            // Ease out the existing fall while horizontal motion eases in.
            idleTicks += Mth.clamp(state.ageInTicks - lastTicks, 0.0F, 2.0F)
               * (float)(1.0 - smooth(movementBlend));
         }
         if (movementBlend == 0.0) {
            idleTicks += Mth.clamp(state.ageInTicks - lastTicks, 0.0F, 2.0F);
            frozenTop = state.boundingBoxHeight + 0.65F;
         }
         lastTicks = state.ageInTicks;
         if (movementPath.isEmpty()) {
            movementPath.addLast(new MovementPoint(playerPosition, pathDistance));
         }
         Vec3 lastSample = movementPath.peekLast().position();
         double distance = Math.hypot(playerPosition.x - lastSample.x, playerPosition.z - lastSample.z);
         if (distance >= 0.025) {
            pathDistance += distance;
            movementPath.addLast(new MovementPoint(playerPosition, pathDistance));
            distance = 0.0;
         }
         currentPath = pathDistance + distance;
         while (movementPath.size() > 256 || movementPath.size() > 2
            && currentPath - movementPath.peekFirst().distance() > 5.0) {
            movementPath.removeFirst();
         }
      }
      double blend = animateMovement ? smooth(movementBlend) : 0.0;
      if (animateMovement && movementBlend == 0.0) {
         movementPath.clear();
         movementPath.addLast(new MovementPoint(playerPosition, 0.0));
         pathDistance = currentPath = 0.0;
         flowSeconds = 0.0;
      }
      float ticks = animateMovement ? idleTicks : state.ageInTicks;
      float top = animateMovement ? frozenTop : state.boundingBoxHeight + 0.65F;
      float span = top + 0.05F;
      float entityPhase = Math.floorMod(state.id * 31, 1000) / 1000.0F;
      double available = movementPath.isEmpty() ? 0.0
         : Math.max(0.0, currentPath - movementPath.peekFirst().distance());
      // All original slots retain their position, phase, size and identity.
      // Movement adds horizontal displacement only; there is no alternate layout.
      for (int index = 0; index < IDLE_BADGE_X.length; index++) {
         if (firstPerson && index != 0 && index != 3) continue;
         float progress = ticks * 0.0125F + entityPhase
            + index / (float)IDLE_BADGE_X.length;
         if (animateMovement && restartFromTop) {
            progress = ticks * 0.01625F - index / (float)IDLE_BADGE_X.length;
            if (progress < 0.0F) continue;
         }
         progress -= (float)Math.floor(progress);
         float bob = (float)Math.sin(ticks * 0.10F + index * 0.83F) * 0.025F;
         Vec3 idle = new Vec3(IDLE_BADGE_X[index], top - progress * span + bob,
            IDLE_BADGE_Z[index]);
         if (firstPerson) idle = firstPersonAnchor(idle, top, index < 3, camera);
         Vec3 position = idle;
         if (animateMovement) {
            position = horizontalFollow(idle, playerPosition,
               currentPath, flowDistance(flowSeconds, index, BADGE_FLOW_PERIOD, 3.0), available, blend);
         }
         if (animateMovement && hideUnspread(moving, position.x - idle.x, position.z - idle.z)) continue;
         if (firstPerson) position = firstPersonPeripheral(position, index < 3, camera);
         matrices.pushPose();
         matrices.translate(position.x, position.y, position.z);
         matrices.mulPose(camera.orientation);
         float scale = HOPLITE_MEDALLION_BASE_SCALE;
         matrices.scale(scale, scale, scale);
         itemState.submit(matrices, collector, LightTexture.FULL_BRIGHT,
            OverlayTexture.NO_OVERLAY, state.outlineColor);
         matrices.popPose();
      }
      if (!"medallion_champion".equals(definition.id())) return;
      Component rank = Component.literal("[").withStyle(ChatFormatting.GRAY)
         .append(Component.literal("#" + (remote==null?ClientAccessoryConfig.floatingNumber:remote.floatingCount()))
            .withStyle(ChatFormatting.RED))
         .append(Component.literal("]").withStyle(ChatFormatting.GRAY));
      for (int index = 0; index < IDLE_RANK_X.length; index++) {
         if (firstPerson && index != 1 && index != 4) continue;
         float progress = ticks * 0.0125F + entityPhase
            + (index + 0.5F) / IDLE_RANK_X.length;
         if (animateMovement && restartFromTop) {
            progress = ticks * 0.01625F - (index + 0.5F) / IDLE_RANK_X.length;
            if (progress < 0.0F) continue;
         }
         progress -= (float)Math.floor(progress);
         Vec3 idle = new Vec3(IDLE_RANK_X[index], top - progress * span, IDLE_RANK_Z[index]);
         if (firstPerson) idle = firstPersonAnchor(idle, top, index < 3, camera);
         Vec3 position = idle;
         if (animateMovement) {
            position = horizontalFollow(idle, playerPosition,
               currentPath, flowDistance(flowSeconds, index, RANK_FLOW_PERIOD, 2.7), available, blend);
         }
         if (animateMovement && hideUnspread(moving, position.x - idle.x, position.z - idle.z)) continue;
         if (firstPerson) position = firstPersonPeripheral(position, index < 3, camera);
         matrices.pushPose();
         matrices.translate(position.x, position.y, position.z);
         // Match the name-tag pose, without its automatic options-based background.
         matrices.translate(0.0, 0.5, 0.0);
         matrices.mulPose(camera.orientation);
         matrices.scale(0.025F, -0.025F, 0.025F);
         float textX = -minecraft.font.width(rank) / 2.0F;
         collector.submitText(matrices, textX, 0.0F, rank.getVisualOrderText(), false,
            net.minecraft.client.gui.Font.DisplayMode.SEE_THROUGH,
            LightTexture.FULL_BRIGHT, 0x80FFFFFF, 0, 0);
         collector.submitText(matrices, textX, 0.0F, rank.getVisualOrderText(), false,
            net.minecraft.client.gui.Font.DisplayMode.NORMAL,
            LightTexture.FULL_BRIGHT, 0xFFFFFFFF, 0, 0);
         matrices.popPose();
      }
   }

   private boolean hideUnspread(boolean running, double dx, double dz) {
      return running && dx * dx + dz * dz < 0.25;
   }

   private Vec3 firstPersonAnchor(Vec3 offset, float top, boolean left, CameraRenderState camera) {
      org.joml.Matrix4f projection = Minecraft.getInstance().gameRenderer.getProjectionMatrix(
         Minecraft.getInstance().options.fov().get().floatValue());
      org.joml.Vector3f anchor = new org.joml.Vector3f(
         (left ? -0.76F : 0.76F) * 4.5F / projection.m00(),
         (float)(offset.y / (top + 0.05F) - 0.5) * 1.1F * 4.5F / projection.m11(), -4.5F);
      anchor.rotate(camera.orientation);
      return new Vec3(anchor.x(), anchor.y(), anchor.z());
   }

   private Vec3 firstPersonPeripheral(Vec3 position, boolean left, CameraRenderState camera) {
      // Keep world-trajectory motion, but reserve the aiming area and HUD margins.
      org.joml.Matrix4f projection = Minecraft.getInstance().gameRenderer.getProjectionMatrix(
         Minecraft.getInstance().options.fov().get().floatValue());
      org.joml.Vector3f local = new org.joml.Vector3f((float)position.x, (float)position.y, (float)position.z);
      local.rotate(new org.joml.Quaternionf(camera.orientation).conjugate());
      float depth = Math.max(1.5F, -local.z());
      float side = left ? -1F : 1F;
      float x = Mth.clamp(side * local.x() * projection.m00() / depth, 0.64F, 0.86F);
      float y = Mth.clamp(local.y() * projection.m11() / depth, -0.60F, 0.60F);
      local.set(side * x * 4.5F / projection.m00(), y * 4.5F / projection.m11(), -4.5F);
      local.rotate(camera.orientation);
      return new Vec3(local.x(), local.y(), local.z());
   }

   private double transition(double value, boolean moving, double seconds) {
      return moving ? Math.min(1.0, value + seconds / 0.22)
         : Math.max(0.0, value - seconds / 0.36);
   }

   private double smooth(double value) {
      return value * value * (3.0 - 2.0 * value);
   }

   private Vec3 horizontalFollow(Vec3 frozen, Vec3 player,
      double currentDistance, double behind, double available, double blend) {
      if (behind <= 1.0E-8) return frozen;
      double readiness = smooth(Math.min(1.0, available / behind));
      Vec3 historical = movementPosition(player, currentDistance, Math.min(behind, available));
      if (historical == null) return frozen;
      double weight = blend * readiness;
      return frozen.add((historical.x - player.x) * weight, 0.0,
         (historical.z - player.z) * weight);
   }

   private double flowDistance(double seconds, int index, double period, double length) {
      // Every slot starts immediately; slightly different speeds stagger later recycling.
      double phase = Math.max(0.0, seconds) * (1.0 + index * 0.035) / period;
      return (phase - Math.floor(phase)) * length;
   }

   private Vec3 movementPosition(Vec3 current, double currentDistance, double behind) {
      if (behind == 0.0) return current;
      Vec3 newerPosition = current;
      double newerDistance = currentDistance;
      double target = currentDistance - behind;
      for (var it = movementPath.descendingIterator(); it.hasNext();) {
         MovementPoint older = it.next();
         if (older.distance() <= target) {
            double span = newerDistance - older.distance();
            if (span < 1.0E-8) return older.position();
            return older.position().lerp(newerPosition,
               (target - older.distance()) / span);
         }
         newerPosition = older.position();
         newerDistance = older.distance();
      }
      // Insufficient real history: omit the slot instead of inventing a direction.
      return null;
   }

   private record MovementPoint(Vec3 position, double distance) {}

   }

   public static void replaceDefaultHelmet(AvatarRenderState state) {
      Minecraft minecraft = Minecraft.getInstance();
      var remote=RemoteCosmetics.outfit(state);var owner=RemoteCosmetics.player(state);
      if(remote!=null && owner!=null && remote.flag("headwearActive",false)) {
         var selected=RemoteCosmetics.accessory(remote,AccessorySlot.HEADWEAR);
         var scope=dev.lin.client.features.accessory.HeadwearScope.byId(remote.options().get("headwearScope"));
         if(selected!=null && AccessoryItemModels.shouldReplaceRemoteHelmet(owner.getItemBySlot(EquipmentSlot.HEAD),scope)) {
            state.headEquipment=ItemStack.EMPTY;
            minecraft.getItemModelResolver().updateForLiving(state.headItem,
               AccessoryItemModels.stack(selected,dev.lin.client.features.accessory.HeadwearVariant.byId(remote.options().get("headwearVariant"))),
               ItemDisplayContext.HEAD,owner);
         }
         return;
      }
      if (minecraft.player != null && state.id == minecraft.player.getId()) {
         if (minecraft.screen instanceof AccessorySelectorScreen screen && screen.isHeadwearPage()) {
            AccessoryDefinition selected = AccessoryRegistry.selected(AccessorySlot.HEADWEAR);
            if (selected != null) {
               state.headEquipment = ItemStack.EMPTY;
               minecraft.getItemModelResolver().updateForLiving(state.headItem, AccessoryItemModels.stack(selected), ItemDisplayContext.HEAD, minecraft.player);
            }
            return;
         }

         if(CosmeticConfig.equipped(CosmeticCategory.HAT)!=null)return;
         ItemStack equipped = minecraft.player.getItemBySlot(EquipmentSlot.HEAD);
         if (AccessoryItemModels.shouldReplaceWorldHelmet(equipped)) {
            AccessoryDefinition selected = AccessoryRegistry.selected(AccessorySlot.HEADWEAR);
            if (selected != null) {
               state.headEquipment = ItemStack.EMPTY;
               minecraft.getItemModelResolver().updateForLiving(state.headItem, AccessoryItemModels.stack(selected), ItemDisplayContext.HEAD, minecraft.player);
            }
         }
      }
   }

   private static void submitWings(
      PlayerModel playerModel, AccessoryDefinition definition, AvatarRenderState state, PoseStack matrices, SubmitNodeCollector collector
   ) {
      if (definition != null) {
         Minecraft minecraft = Minecraft.getInstance();
         var owner=RemoteCosmetics.player(state);if(owner==null)owner=minecraft.player;
         var remote=RemoteCosmetics.outfit(state);
         ItemStackRenderState itemState = new ItemStackRenderState();
         if (owner != null) {
            minecraft.getItemModelResolver().updateForLiving(itemState,
               AccessoryItemModels.stack(definition), ItemDisplayContext.HEAD,
               owner);
         } else {
            minecraft.getItemModelResolver().updateForTopItem(itemState,
               AccessoryItemModels.stack(definition), ItemDisplayContext.HEAD,
               null, null, state.id);
         }
         if (!itemState.isEmpty()) {
            matrices.pushPose();
            float horizontalScale = Transforms.DEFAULT.horizontalScale();
            float movement = Math.min(1.0F, Math.max(0.0F,
               state.walkAnimationSpeed * 1.6F));
            float wave = (float)Math.sin(state.ageInTicks * (0.35F + movement * 0.55F));
            float spread = 1.0F + movement * 0.018F * wave;
            matrices.scale(horizontalScale * spread, 1.0F,
               horizontalScale * (1.0F - movement * 0.018F * Math.abs(wave)));
            playerModel.root().translateAndRotate(matrices);
            playerModel.body.translateAndRotate(matrices);
            matrices.translate(0.0F,
               -1.5F - HOPLITE_WING_BASE_OFFSET_Y - (remote==null?ClientAccessoryConfig.wingOffsetY:remote.number("wingOffsetY",0)),
               0.0F);
            CustomHeadLayer.translateToHead(matrices, Transforms.DEFAULT);
            if (state.id < 0) {
               float[] correction = PREVIEW_WING_OFFSETS.get(definition.id());
               if (correction != null) {
                  matrices.translate(0.0F, correction[0], correction[1]);
               }
            }
            itemState.submit(matrices, collector, state.lightCoords, OverlayTexture.NO_OVERLAY, state.outlineColor);
            matrices.popPose();
         }
      }
   }
}
