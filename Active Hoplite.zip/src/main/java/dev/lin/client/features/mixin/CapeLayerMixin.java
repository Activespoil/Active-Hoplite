package dev.lin.client.features.mixin;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.mojang.blaze3d.vertex.PoseStack;
import dev.lin.client.features.cape.LunarCapeWorldRenderer;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.entity.layers.CapeLayer;
import net.minecraft.client.renderer.entity.state.AvatarRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(CapeLayer.class)
public abstract class CapeLayerMixin {
   @ModifyExpressionValue(
      method = "submit(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/SubmitNodeCollector;ILnet/minecraft/client/renderer/entity/state/AvatarRenderState;FF)V",
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/renderer/entity/layers/CapeLayer;hasLayer(Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/client/resources/model/EquipmentClientInfo$LayerType;)Z",
         ordinal = 0
      )
   )
   private boolean linClient$allowSelectedCapeWithWings(
      boolean hasWingsLayer,
      PoseStack matrices,
      SubmitNodeCollector collector,
      int light,
      AvatarRenderState state,
      float bodyYaw,
      float partialTick
   ) {
      return hasWingsLayer && !LunarCapeWorldRenderer.isSelectedCapeApplied(state);
   }
}
