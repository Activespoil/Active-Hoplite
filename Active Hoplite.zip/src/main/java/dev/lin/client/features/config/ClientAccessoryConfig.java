package dev.lin.client.features.config;

import dev.lin.client.features.accessory.AccessoryRegistry;
import dev.lin.client.features.accessory.AccessorySlot;
import dev.lin.client.features.accessory.HeadwearVariant;
import dev.lin.client.features.accessory.HeadwearScope;
import dev.lin.client.features.cape.LunarCapeRegistry;
import dev.lin.client.features.pet.LunarPetRegistry;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import net.fabricmc.loader.api.FabricLoader;

public final class ClientAccessoryConfig {
   private static final Path PATH = FabricLoader.getInstance().getConfigDir().resolve("lin-client.properties");
   public static final float PET_OFFSET_STEP = 0.05F;
   public static final float PET_OFFSET_LIMIT = 0.8F;
   public static final float WING_OFFSET_STEP = 0.05F;
   public static final float WING_OFFSET_LIMIT = 0.8F;
   public static final int BACKGROUND_BLUR_MIN = 0;
   public static final int BACKGROUND_BLUR_MAX = 10;
   public static final float BACKGROUND_OPACITY_MIN = 0.0F;
   public static final float BACKGROUND_OPACITY_MAX = 1.0F;
   public static boolean capePreviewAngled = true;
   public static float petOffsetX;
   public static float petOffsetY;
   public static float wingOffsetY;
   public static int backgroundBlur = 10;
   public static float backgroundOpacity = 0.08F;
   public static int menuBlur = 10;
   public static float menuOpacity = 0.90F;
   public static int floatingNumber = 5;
   public static boolean floatingGlobal = true;

   private ClientAccessoryConfig() {
   }

   public static void load() {
      if (Files.isRegularFile(PATH)) {
         try {
            for (String line : Files.readAllLines(PATH, StandardCharsets.UTF_8)) {
               int split = line.indexOf(61);
               if (split >= 1) {
                  String slot = line.substring(0, split).trim();
                  String id = line.substring(split + 1).trim();
                  if (slot.equals("headwear")) {
                     AccessoryRegistry.select(AccessorySlot.HEADWEAR, id);
                  }
                  if (slot.equals("headwear_source")) {
                     AccessoryRegistry.setKingmcHeadwear(id.equals("kingmc"));
                  }

                  if (slot.equals("headwear_scope")) {
                     AccessoryRegistry.setHeadwearScope(HeadwearScope.byId(id));
                  }

                  if (slot.equals("wings")) {
                     AccessoryRegistry.select(AccessorySlot.WINGS, id);
                  }

                  if (slot.equals("floating")) {
                     AccessoryRegistry.select(AccessorySlot.FLOATING, id);
                  }

                  if (slot.equals("floating_number")) {
                     floatingNumber = parseFloatingNumber(id);
                  }

                  if (slot.equals("floating_scope")) {
                     floatingGlobal = !id.equalsIgnoreCase("hoplite");
                  }

                  if (slot.startsWith("headwear_variant.")) {
                     AccessoryRegistry.selectHeadwearVariant(slot.substring("headwear_variant.".length()), HeadwearVariant.byId(id));
                  }

                  if (slot.equals("cape")) {
                     LunarCapeRegistry.select(id);
                  }

                  if (slot.equals("pet")) {
                     LunarPetRegistry.select(id);
                  }

                  if (slot.equals("pet_offset_x")) {
                     petOffsetX = parsePetOffset(id);
                  }

                  if (slot.equals("pet_offset_y")) {
                     petOffsetY = parsePetOffset(id);
                  }

                  if (slot.equals("wing_offset_y")) {
                     wingOffsetY = parseWingOffset(id);
                  }

                  if (slot.equals("cape_preview_angled")) {
                     capePreviewAngled = Boolean.parseBoolean(id);
                  }

                  if (slot.equals("background_blur")) {
                     backgroundBlur = parseBackgroundBlur(id);
                  }

                  if (slot.equals("background_opacity")) {
                     backgroundOpacity = parseBackgroundOpacity(id);
                  }

                  if (slot.equals("menu_blur")) {
                     menuBlur = parseBackgroundBlur(id);
                  }

                  if (slot.equals("menu_opacity")) {
                     menuOpacity = parseBackgroundOpacity(id);
                  }
               }
            }
         } catch (IOException ignored) {
         }
      }
   }

   public static void save() {
      List<String> lines = new ArrayList<>(List.of(
         "headwear=" + AccessoryRegistry.selectedId(AccessorySlot.HEADWEAR),
         "headwear_source=" + (AccessoryRegistry.kingmcHeadwear() ? "kingmc" : "hoplite"),
         "headwear_scope=" + AccessoryRegistry.headwearScope().id(),
         "wings=" + AccessoryRegistry.selectedId(AccessorySlot.WINGS),
         "floating=" + AccessoryRegistry.selectedId(AccessorySlot.FLOATING),
         "floating_number=" + floatingNumber,
         "floating_scope=" + (floatingGlobal ? "global" : "hoplite"),
         "cape=" + LunarCapeRegistry.selectedId(),
         "pet=" + LunarPetRegistry.selectedId(),
         "pet_offset_x=" + Float.toString(petOffsetX),
         "pet_offset_y=" + Float.toString(petOffsetY),
         "wing_offset_y=" + Float.toString(wingOffsetY),
         "cape_preview_angled=" + capePreviewAngled,
         "background_blur=" + backgroundBlur,
         "background_opacity=" + Float.toString(backgroundOpacity),
         "menu_blur=" + menuBlur,
         "menu_opacity=" + Float.toString(menuOpacity)
      ));
      AccessoryRegistry.headwearVariants().entrySet().stream()
         .sorted(Map.Entry.comparingByKey())
         .forEach(entry -> lines.add("headwear_variant." + entry.getKey() + "=" + entry.getValue().id()));

      try {
         Files.createDirectories(PATH.getParent());
         Files.write(PATH, lines, StandardCharsets.UTF_8);
      } catch (IOException ignored) {
      }
   }

   public static void movePet(float horizontal, float vertical) {
      petOffsetX = clampPetOffset(petOffsetX + horizontal);
      petOffsetY = clampPetOffset(petOffsetY + vertical);
      save();
   }

   public static void resetPetPosition() {
      petOffsetX = 0.0F;
      petOffsetY = 0.0F;
      save();
   }

   public static void moveWings(float vertical) {
      wingOffsetY = clampWingOffset(wingOffsetY + vertical);
      save();
   }

   public static void resetWingPosition() {
      wingOffsetY = 0.0F;
      save();
   }

   public static void setBackgroundBlur(int value) {
      backgroundBlur = Math.max(BACKGROUND_BLUR_MIN,
         Math.min(BACKGROUND_BLUR_MAX, value));
      save();
   }

   public static void setBackgroundOpacity(float value) {
      backgroundOpacity = Math.max(BACKGROUND_OPACITY_MIN,
         Math.min(BACKGROUND_OPACITY_MAX, value));
      save();
   }

   public static void setMenuBlur(int value) {
      menuBlur = Math.max(BACKGROUND_BLUR_MIN,
         Math.min(BACKGROUND_BLUR_MAX, value));
      save();
   }

   public static void setMenuOpacity(float value) {
      menuOpacity = Math.max(BACKGROUND_OPACITY_MIN,
         Math.min(BACKGROUND_OPACITY_MAX, value));
      save();
   }

   public static void setFloatingNumber(int value) {
      floatingNumber = Math.max(0, Math.min(9999, value));
      save();
   }

   public static void setFloatingGlobal(boolean value) {
      floatingGlobal = value;
      save();
   }

   private static float parsePetOffset(String value) {
      try {
         return clampPetOffset(Float.parseFloat(value));
      } catch (NumberFormatException ignored) {
         return 0.0F;
      }
   }

   private static float clampPetOffset(float value) {
      return Math.max(-PET_OFFSET_LIMIT, Math.min(PET_OFFSET_LIMIT, value));
   }

   private static float parseWingOffset(String value) {
      try {
         return clampWingOffset(Float.parseFloat(value));
      } catch (NumberFormatException ignored) {
         return 0.0F;
      }
   }

   private static float clampWingOffset(float value) {
      return Math.max(-WING_OFFSET_LIMIT, Math.min(WING_OFFSET_LIMIT, value));
   }

   private static int parseBackgroundBlur(String value) {
      try {
         return Math.max(BACKGROUND_BLUR_MIN,
            Math.min(BACKGROUND_BLUR_MAX, Integer.parseInt(value)));
      } catch (NumberFormatException ignored) {
         return 12;
      }
   }

   private static float parseBackgroundOpacity(String value) {
      try {
         return Math.max(BACKGROUND_OPACITY_MIN,
            Math.min(BACKGROUND_OPACITY_MAX, Float.parseFloat(value)));
      } catch (NumberFormatException ignored) {
         return 0.88F;
      }
   }

   private static int parseFloatingNumber(String value) {
      try {
         return Math.max(0, Math.min(9999, Integer.parseInt(value)));
      } catch (NumberFormatException ignored) {
         return 5;
      }
   }

}
