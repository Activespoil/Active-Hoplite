package dev.lin.client.features.accessory;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

public final class AccessoryRegistry {
   private static final Map<AccessorySlot, List<AccessoryDefinition>> ACCESSORIES = new EnumMap<>(AccessorySlot.class);
   private static final Map<AccessorySlot, AccessoryDefinition> SELECTED = new EnumMap<>(AccessorySlot.class);
   private static final Map<String, HeadwearVariant> HEADWEAR_VARIANTS = new java.util.HashMap<>();
   private static boolean kingmcHeadwear;
   private static HeadwearScope headwearScope = HeadwearScope.GLOBAL;

   public static boolean isKingmc(AccessoryDefinition definition) {
      return definition != null && definition.id().startsWith("kingmc_");
   }

   public static boolean kingmcHeadwear() { return kingmcHeadwear; }

   public static synchronized void setKingmcHeadwear(boolean value) {
      kingmcHeadwear = value;
   }

   public static HeadwearScope headwearScope() { return headwearScope; }

   public static synchronized void setHeadwearScope(HeadwearScope value) {
      headwearScope = value == null ? HeadwearScope.GLOBAL : value;
   }

   public static List<AccessoryDefinition> visibleHeadwear() {
      return values(AccessorySlot.HEADWEAR).stream().filter(d -> isKingmc(d) == kingmcHeadwear).toList();
   }

   private AccessoryRegistry() {
   }

   public static synchronized void load() {
      ACCESSORIES.clear();
      SELECTED.clear();

      for (AccessorySlot slot : AccessorySlot.values()) {
         ACCESSORIES.put(slot, new ArrayList<>());
      }

      try (InputStream stream = AccessoryRegistry.class.getResourceAsStream("/assets/lin_client/accessories.json")) {
         if (stream == null) {
            throw new IllegalStateException("accessories.json is missing");
         }

         JsonObject root = JsonParser.parseReader(new InputStreamReader(stream, StandardCharsets.UTF_8)).getAsJsonObject();
         loadSlot(root.getAsJsonArray("headwear"), AccessorySlot.HEADWEAR);
         loadSlot(root.getAsJsonArray("wings"), AccessorySlot.WINGS);
         ACCESSORIES.get(AccessorySlot.FLOATING).addAll(List.of(
            new AccessoryDefinition(AccessorySlot.FLOATING, "medallion_champion", "冠军漂浮", "civilization/models/item/ui/medallions/medallion_champion.json", 1),
            new AccessoryDefinition(AccessorySlot.FLOATING, "medallion_copper", "青铜漂浮", "civilization/models/item/ui/medallions/medallion_copper.json", 2),
            new AccessoryDefinition(AccessorySlot.FLOATING, "medallion_diamond", "钻石漂浮", "civilization/models/item/ui/medallions/medallion_diamond.json", 3),
            new AccessoryDefinition(AccessorySlot.FLOATING, "medallion_gold", "黄金漂浮", "civilization/models/item/ui/medallions/medallion_gold.json", 4),
            new AccessoryDefinition(AccessorySlot.FLOATING, "medallion_iron", "钢铁漂浮", "civilization/models/item/ui/medallions/medallion_iron.json", 5),
            new AccessoryDefinition(AccessorySlot.FLOATING, "medallion_master", "大师漂浮", "civilization/models/item/ui/medallions/medallion_master.json", 6)
         ));
      } catch (Exception exception) {
         throw new IllegalStateException("Unable to load accessory registry", exception);
      }

      for (AccessorySlot slot : AccessorySlot.values()) {
         List<AccessoryDefinition> values = ACCESSORIES.get(slot);
         ACCESSORIES.put(slot, List.copyOf(values));
      }
   }

   private static void loadSlot(JsonArray values, AccessorySlot slot) {
      if (values != null) {
         int customModelData = 1;

         for (JsonElement value : values) {
            JsonObject item = value.getAsJsonObject();
            ACCESSORIES.get(slot)
               .add(
                  new AccessoryDefinition(
                     slot, item.get("id").getAsString(), item.has("name") ? item.get("name").getAsString() : displayName(item.get("id").getAsString()), item.get("model").getAsString(), customModelData++
                  )
               );
         }
      }
   }

   private static String displayName(String id) {
      StringBuilder value = new StringBuilder(id.length());
      boolean uppercase = true;

      for (int index = 0; index < id.length(); index++) {
         char character = id.charAt(index);
         if (character == '_') {
            value.append(' ');
            uppercase = true;
         } else {
            value.append(uppercase ? Character.toUpperCase(character) : character);
            uppercase = false;
         }
      }

      return value.toString();
   }

   public static List<AccessoryDefinition> values(AccessorySlot slot) {
      return ACCESSORIES.getOrDefault(slot, List.of());
   }

   public static AccessoryDefinition selected(AccessorySlot slot) {
      return SELECTED.get(slot);
   }

   public static synchronized void select(AccessorySlot slot, String id) {
      if (id != null && !id.isBlank()) {
         for (AccessoryDefinition definition : values(slot)) {
            if (definition.id().equals(id)) {
               SELECTED.put(slot, definition);
               if (slot == AccessorySlot.HEADWEAR) kingmcHeadwear = isKingmc(definition);
               return;
            }
         }
      } else {
         clearSelection(slot);
      }
   }

   public static synchronized void clearSelection(AccessorySlot slot) {
      SELECTED.remove(slot);
   }

   public static String selectedId(AccessorySlot slot) {
      AccessoryDefinition definition = selected(slot);
      return definition == null ? "" : definition.id();
   }

   public static synchronized void selectHeadwearVariant(String headwearId, HeadwearVariant variant) {
      if (headwearId == null || headwearId.isBlank()) {
         return;
      }

      if (variant == null || variant == HeadwearVariant.NORMAL) {
         HEADWEAR_VARIANTS.remove(headwearId);
      } else {
         HEADWEAR_VARIANTS.put(headwearId, variant);
      }
   }

   public static HeadwearVariant headwearVariant(String headwearId) {
      return HEADWEAR_VARIANTS.getOrDefault(headwearId, HeadwearVariant.NORMAL);
   }

   public static HeadwearVariant headwearVariant(AccessoryDefinition definition) {
      return definition == null || definition.slot() != AccessorySlot.HEADWEAR
         ? HeadwearVariant.NORMAL
         : headwearVariant(definition.id());
   }

   public static Map<String, HeadwearVariant> headwearVariants() {
      return Map.copyOf(HEADWEAR_VARIANTS);
   }
}
