package dev.lin.client.features.mixin;

import net.minecraft.client.gui.render.GuiRenderer;
import dev.lin.client.features.render.GuiRasterFrame;
import dev.lin.client.cosmetics.ui.SelfInfoHeadPortrait;
import dev.lin.client.cosmetics.ui.HeadPortraitRenderState;
import dev.lin.client.features.render.HudStaticItems;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.render.pip.GuiEntityRenderer;
import net.minecraft.client.gui.render.state.GuiRenderState;
import net.minecraft.client.gui.render.state.pip.GuiEntityRenderState;
import net.minecraft.client.gui.render.state.pip.PictureInPictureRenderState;
import net.minecraft.client.renderer.MultiBufferSource;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Each vanilla GUI prepare pass is an independent animation/caching boundary. */
@Mixin(GuiRenderer.class)
public abstract class GuiOversizedItemReuseMixin {
    @Shadow @Final private MultiBufferSource.BufferSource bufferSource;
    @Shadow @Final private GuiRenderState renderState;
    @Unique private GuiEntityRenderer lin$selfPortrait, lin$targetPortrait;
    @Unique private Object lin$portraitWorld;
    @Unique private final java.util.List<GuiEntityRenderer> lin$lockerSurfaces = new java.util.ArrayList<>();
    @Unique private int lin$lockerCursor;
    @Unique private void lin$closeLockerSurfaces() {
        for (var renderer : lin$lockerSurfaces) renderer.close();
        lin$lockerSurfaces.clear(); lin$lockerCursor = 0;
    }

    @Inject(method="prepare",at=@At("HEAD"))
    private void lin$beginRasterFrame(CallbackInfo ci) {
        GuiRasterFrame.advance();
        lin$lockerCursor = 0;
        if (!(dev.lin.client.cosmetics.ui.SystemNavigation.activeScreen() instanceof dev.lin.client.cosmetics.ui.CosmeticLockerScreen)) lin$closeLockerSurfaces();
        Object world = Minecraft.getInstance().level;
        if (lin$portraitWorld != world) {
            lin$closePortraits(); lin$closeLockerSurfaces(); lin$portraitWorld = world;
            SelfInfoHeadPortrait.clear(); HudStaticItems.clear();
        }
    }

    // Atlas allocation is not a resource reload. Vanilla repopulates its cleared
    // atlas from the existing render states. Keep model identities and independent
    // portrait surfaces stable; StaticPortraitModels tracks actual model reloads.

    @Inject(method="preparePictureInPictureState", at=@At("HEAD"), cancellable=true)
    private void lin$separatePortraits(PictureInPictureRenderState current, int guiScale, CallbackInfo ci) {
        if (!(current instanceof GuiEntityRenderState entity)) return;
        // Each queued preview must retain its own texture until the GUI draw pass.
        // Vanilla has one GuiEntityRenderer surface: another preview overwrites it
        // (and changing dimensions closes a texture already referenced by a blit).
        if (dev.lin.client.cosmetics.ui.SystemNavigation.activeScreen() instanceof dev.lin.client.cosmetics.ui.CosmeticLockerScreen
                && !(entity.renderState() instanceof HeadPortraitRenderState)) {
            if (lin$lockerCursor == lin$lockerSurfaces.size())
                lin$lockerSurfaces.add(new GuiEntityRenderer(bufferSource, Minecraft.getInstance().getEntityRenderDispatcher()));
            lin$lockerSurfaces.get(lin$lockerCursor++).prepare(entity, renderState, guiScale);
            ci.cancel(); return;
        }
        if (!(entity.renderState() instanceof HeadPortraitRenderState avatar) || !avatar.staticHead) return;
        GuiEntityRenderer renderer;
        if (avatar.selfCard) {
            if (lin$selfPortrait == null) lin$selfPortrait = new GuiEntityRenderer(bufferSource,
                    Minecraft.getInstance().getEntityRenderDispatcher());
            renderer = lin$selfPortrait;
        } else {
            if (lin$targetPortrait == null) lin$targetPortrait = new GuiEntityRenderer(bufferSource,
                    Minecraft.getInstance().getEntityRenderDispatcher());
            renderer = lin$targetPortrait;
        }
        renderer.prepare(entity, renderState, guiScale);
        ci.cancel();
    }

    @Unique private void lin$closePortraits() {
        if (lin$selfPortrait != null) { lin$selfPortrait.close(); lin$selfPortrait = null; }
        if (lin$targetPortrait != null) { lin$targetPortrait.close(); lin$targetPortrait = null; }
    }

    @Inject(method="close", at=@At("HEAD"))
    private void lin$releasePortraits(CallbackInfo ci) {
        lin$closePortraits(); lin$closeLockerSurfaces(); lin$portraitWorld = null;
        SelfInfoHeadPortrait.clear(); HudStaticItems.clear();
    }

}
