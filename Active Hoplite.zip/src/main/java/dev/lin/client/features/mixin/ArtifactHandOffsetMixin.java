package dev.lin.client.features.mixin;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import dev.lin.client.features.artifact.ArtifactSkinConfig;
import dev.lin.client.features.artifact.ArtifactSkinModelPolicy;
import net.minecraft.client.renderer.ItemInHandRenderer;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ItemInHandRenderer.class)
public abstract class ArtifactHandOffsetMixin {
   @Inject(method = "renderItem", at = @At("HEAD"))
   private void linClient$offsetArtifactHand(
      LivingEntity owner,
      ItemStack stack,
      ItemDisplayContext displayContext,
      PoseStack matrices,
      SubmitNodeCollector collector,
      int light,
      CallbackInfo callback
   ) {
      if (!displayContext.firstPerson() || owner == null) return;
      String modelId = ArtifactSkinModelPolicy.handTransformKey(stack, owner);
      if (modelId == null) return;

      boolean right = displayContext == ItemDisplayContext.FIRST_PERSON_RIGHT_HAND;
      boolean mainHand = right == (owner.getMainArm() == HumanoidArm.RIGHT);
      ArtifactSkinConfig.HandTransform transform = ArtifactSkinConfig.handTransform(modelId);
      float x = mainHand ? transform.mainX() : transform.offX();
      float y = mainHand ? transform.mainY() : transform.offY();
      float z = mainHand ? transform.mainZ() : transform.offZ();
      float rotX = mainHand ? transform.mainRotX() : transform.offRotX();
      float rotY = mainHand ? transform.mainRotY() : transform.offRotY();
      matrices.translate(x, y, z);
      matrices.mulPose(Axis.XP.rotationDegrees(rotX));
      matrices.mulPose(Axis.YP.rotationDegrees(rotY));
   }
}
