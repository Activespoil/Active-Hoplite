package dev.lin.client.features.ui;

import it.unimi.dsi.fastutil.ints.Int2IntOpenHashMap;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.scores.DisplaySlot;
import net.minecraft.world.scores.ReadOnlyScoreInfo;
import net.minecraft.world.scores.Scoreboard;
import net.minecraft.world.scores.criteria.ObjectiveCriteria;

/** Curse-compatible scoreboard health lookup shared by NameTags and HUD cards. */
public final class ScoreboardHealthResolver {
    private static Object cachedWorld;
    private static long cachedTick = Long.MIN_VALUE;
    private static final Int2IntOpenHashMap SCORE_CACHE = new Int2IntOpenHashMap();

    static {
        SCORE_CACHE.defaultReturnValue(Integer.MIN_VALUE);
    }

    private ScoreboardHealthResolver() {}

    /** Base health for target/self HUD; absorption is returned separately. */
    public static float total(Object value) {
        if (!(value instanceof LivingEntity entity)) return 0.0F;
        Minecraft client = Minecraft.getInstance();
        if (!(entity instanceof Player) || entity == client.player) {
            return Math.max(0.0F, entity.getHealth());
        }
        int score = scoreboardHealth(entity);
        return score >= 0 ? score : 20.0F;
    }

    /** Absorption remains a separate HUD channel for local and remote players. */
    public static float absorption(Object value) {
        if (!(value instanceof LivingEntity entity)) return 0.0F;
        Minecraft client = Minecraft.getInstance();
        if (entity instanceof Player && entity != client.player && scoreboardHealth(entity) < 0) return 0.0F;
        return Math.max(0.0F, entity.getAbsorptionAmount());
    }

    /** Final value displayed by NameTags. */
    public static float displayHealth(Object value) {
        if (!(value instanceof LivingEntity entity)) return Float.NaN;
        if (entity instanceof Player) {
            int score = scoreboardHealth(entity);
            return score >= 0 ? score : 20.0F;
        }
        return Math.max(0f, entity.getHealth()) + Math.max(0f, entity.getAbsorptionAmount());
    }

    /** Remote Tab LIST value. A missing value is handled as 20 HP by total(). */
    public static int scoreboardHealth(Object value) {
        if (!(value instanceof Player player)) return -1;
        refreshCache();
        int cached = SCORE_CACHE.get(player.getId());
        if (cached != Integer.MIN_VALUE) return cached;
        int result = score(player);
        SCORE_CACHE.put(player.getId(), result);
        return result;
    }

    private static void refreshCache() {
        Minecraft client = Minecraft.getInstance();
        Object world = client.level;
        long tick = client.level == null ? Long.MIN_VALUE : client.level.getGameTime();
        if (cachedWorld == world && cachedTick == tick) return;
        cachedWorld = world;
        cachedTick = tick;
        SCORE_CACHE.clear();
    }

    private static int score(Player player) {
        Minecraft client = Minecraft.getInstance();
        if (client.level == null) return -1;
        Scoreboard scoreboard = client.level.getScoreboard();
        var objective = scoreboard.getDisplayObjective(DisplaySlot.LIST);
        if (objective == null) return -1;
        ReadOnlyScoreInfo info = scoreboard.getPlayerScoreInfo(player, objective);
        return info == null ? -1 : info.value();
    }
}
