package dev.lin.client.features.mixin;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import net.minecraft.server.packs.FilePackResources;
import java.util.Enumeration;import java.util.zip.ZipFile;import java.util.zip.ZipEntry;
@Mixin(FilePackResources.class)
public abstract class PackZipEnumerationMixin {
 @Redirect(method={"listResources","getNamespaces"},at=@At(value="INVOKE",target="Ljava/util/zip/ZipFile;entries()Ljava/util/Enumeration;"))
 private Enumeration<? extends ZipEntry> lin$entrySnapshot(ZipFile zip){
  return dev.lin.client.shared.ZipEntrySnapshot.entries(zip);
 }
}
