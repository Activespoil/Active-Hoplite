package dev.lin.client.features.font;

import com.mojang.blaze3d.platform.NativeImage;
import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.resources.Identifier;
import org.joml.Matrix3x2fStack;

public final class FontManager {
   private static final int PADDING = 2;
   private static final int MAX_RASTER_SCALE = 8;
   private static final Map<FontManager.GlyphKey, FontManager.Glyph> GLYPHS = new HashMap<>();
   private static Font latinFace;
   private static Font latinRegularFace;
   private static Font cjkFace;
   private static Font cjkRegularFace;

   private FontManager() {
   }

   public static float draw(GuiGraphics graphics, String text, float x, float y, float size, int color) {
      return draw(graphics, text, x, y, size, color, true);
   }

   public static float drawRegular(GuiGraphics graphics, String text, float x, float y, float size, int color) {
      return draw(graphics, text, x, y, size, color, false);
   }

   private static float draw(GuiGraphics graphics, String text, float x, float y, float size, int color, boolean bold) {
      if (text != null && !text.isEmpty()) {
         int rasterScale = rasterScale();
         int cursor = 0;
         Matrix3x2fStack pose = graphics.pose();
         pose.pushMatrix();

         try {
            pose.translate(Math.round(x), Math.round(y));
            pose.scale(1.0F / rasterScale, 1.0F / rasterScale);
            int offset = 0;

            while (offset < text.length()) {
               int codePoint = text.codePointAt(offset);
               FontManager.Glyph glyph = glyph(codePoint, size, color, rasterScale, bold);
               if (glyph.visible()) {
                  graphics.blit(
                     RenderPipelines.GUI_TEXTURED, glyph.texture(), cursor, 0, 0.0F, 0.0F, glyph.width(), glyph.height(), glyph.width(), glyph.height()
                  );
               }

               cursor = (int)(cursor + glyph.advance());
               offset += Character.charCount(codePoint);
            }
         } finally {
            pose.popMatrix();
         }

         return (float)cursor / rasterScale;
      } else {
         return 0.0F;
      }
   }

   public static float width(String text, float size) {
      return width(text, size, true);
   }

   public static float widthRegular(String text, float size) {
      return width(text, size, false);
   }

   private static float width(String text, float size, boolean bold) {
      if (text != null && !text.isEmpty()) {
         int rasterScale = rasterScale();
         int width = 0;
         int offset = 0;

         while (offset < text.length()) {
            int codePoint = text.codePointAt(offset);
            width = (int)(width + glyph(codePoint, size, -1, rasterScale, bold).advance());
            offset += Character.charCount(codePoint);
         }

         return (float)width / rasterScale;
      } else {
         return 0.0F;
      }
   }

   private static FontManager.Glyph glyph(int codePoint, float size, int color, int rasterScale, boolean bold) {
      int logicalSize = Math.max(7, Math.min(56, Math.round(size)));
      int pixelSize = logicalSize * rasterScale;
      FontManager.GlyphKey key = new FontManager.GlyphKey(codePoint, logicalSize, rasterScale, color, bold);
      FontManager.Glyph cached = GLYPHS.get(key);
      if (cached != null) {
         return cached;
      }

      Font font = font(codePoint, bold).deriveFont((float)pixelSize);
      int padding = 2 * rasterScale;
      BufferedImage image = new BufferedImage(1, 1, 2);
      Graphics2D metricsGraphics = image.createGraphics();
      metricsGraphics.setFont(font);
      applyRenderingHints(metricsGraphics);
      FontMetrics metrics = metricsGraphics.getFontMetrics();
      int advance = Math.max(1, metrics.stringWidth(new String(Character.toChars(codePoint))));
      int width = Math.max(1, advance + padding * 2);
      int height = Math.max(1, metrics.getAscent() + metrics.getDescent() + padding * 2);
      metricsGraphics.dispose();
      BufferedImage glyphImage = new BufferedImage(width, height, 2);
      Graphics2D draw = glyphImage.createGraphics();
      draw.setFont(font);
      draw.setColor(new Color(color, true));
      applyRenderingHints(draw);
      draw.drawString(new String(Character.toChars(codePoint)), padding, padding + metrics.getAscent());
      draw.dispose();
      NativeImage nativeImage = new NativeImage(width, height, true);

      for (int py = 0; py < height; py++) {
         for (int px = 0; px < width; px++) {
            int argb = glyphImage.getRGB(px, py);
            int abgr = argb & -16711936 | (argb & 0xFF0000) >>> 16 | (argb & 0xFF) << 16;
            nativeImage.setPixelABGR(px, py, abgr);
         }
      }

      Identifier texture = Identifier.fromNamespaceAndPath(
         "lin_client",
         "dynamic_font/" + Integer.toUnsignedString(codePoint, 36) + "_" + logicalSize + "x" + rasterScale + "_" + Integer.toUnsignedString(color, 36)
      );
      DynamicTexture dynamicTexture = new DynamicTexture(() -> "lin_client_font", nativeImage);
      Minecraft.getInstance().getTextureManager().register(texture, dynamicTexture);
      FontManager.Glyph glyph = new FontManager.Glyph(texture, width, height, advance, codePoint != 32);
      GLYPHS.put(key, glyph);
      return glyph;
   }

   private static int rasterScale() {
      return Math.max(1, Math.min(8, Minecraft.getInstance().getWindow().getGuiScale()));
   }

   private static void applyRenderingHints(Graphics2D graphics) {
      graphics.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
      graphics.setRenderingHint(RenderingHints.KEY_FRACTIONALMETRICS, RenderingHints.VALUE_FRACTIONALMETRICS_ON);
      graphics.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
      graphics.setRenderingHint(RenderingHints.KEY_ALPHA_INTERPOLATION, RenderingHints.VALUE_ALPHA_INTERPOLATION_QUALITY);
   }

   private static Font font(int codePoint, boolean bold) {
      if (codePoint <= 0x024F) {
         if (bold) {
            if (latinFace == null) {
               latinFace = loadFont("roboto-bold.ttf");
            }
            return latinFace;
         }
         if (latinRegularFace == null) {
            latinRegularFace = loadFont("roboto-regular.ttf");
         }
         return latinRegularFace;
      }
      if (bold) {
         if (cjkFace == null) {
            cjkFace = loadFont("harmony.ttf").deriveFont(Font.BOLD);
         }
         return cjkFace;
      }
      if (cjkRegularFace == null) {
         cjkRegularFace = loadFont("harmony.ttf");
      }
      return cjkRegularFace;
   }

   private static Font loadFont(String name) {
      try (InputStream stream = FontManager.class.getResourceAsStream("/assets/lin_client/font/" + name)) {
         if (stream == null) {
            throw new IllegalStateException(name + " is missing");
         }
         return Font.createFont(Font.TRUETYPE_FONT, stream);
      } catch (Exception exception) {
         throw new IllegalStateException("Unable to load " + name, exception);
      }
   }

   public static void close() {
      GLYPHS.clear();
      latinFace = null;
      latinRegularFace = null;
      cjkFace = null;
      cjkRegularFace = null;
   }

   private record Glyph(Identifier texture, int width, int height, float advance, boolean visible) {
   }

   private record GlyphKey(int codePoint, int size, int rasterScale, int color, boolean bold) {
   }
}
