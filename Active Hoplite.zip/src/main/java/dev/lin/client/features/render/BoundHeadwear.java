package dev.lin.client.features.render;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;

/** Tracks one owned stack, never all items with the same model or name. */
public final class BoundHeadwear {
    private static Object player;
    private static ItemStack bound = ItemStack.EMPTY;
    private static List<ItemStack> previous = List.of();
    private static List<ItemStack> previousReferences = List.of();
    private static int slot = -1;
    private static boolean waitForUnequip; // retained for compatibility with older packages
    private static int missingSince = -1;
    private BoundHeadwear() {}

    public static boolean matches(ItemStack item) {
        var local = Minecraft.getInstance().player;
        if (local == null) { reset(); return false; }
        if (player != local) { reset(); player = local; }
        List<ItemStack> current = new ArrayList<>();
        for (int i = 0; i < local.getInventory().getContainerSize(); i++)
            current.add(local.getInventory().getItem(i));
        current.add(local.containerMenu.getCarried());
        ItemStack head = local.getItemBySlot(EquipmentSlot.HEAD);

        if (slot >= 0) {
            int found = -1;
            boolean ambiguous = false;
            for (int i = 0; i < current.size(); i++)
                if (current.get(i) == bound && !bound.isEmpty()) { found = i; break; }
            if (found < 0 && slot < previous.size()) {
                ItemStack signature = previous.get(slot);
                // Only a changed destination may inherit a moved stack. Existing twins are excluded.
                for (int i = 0; i < current.size(); i++) {
                    ItemStack candidate = current.get(i);
                    if (candidate.isEmpty() || !same(signature, candidate)) continue;
                    // A known other stack moving at the same time is not the original bound item.
                    if (candidate != bound && previousReferences.stream().anyMatch(old -> old == candidate)) continue;
                    boolean unchangedTwin = i != slot && i < previous.size() && same(previous.get(i), candidate);
                    if (unchangedTwin) continue;
                    if (found >= 0) { found = -1; ambiguous = true; break; }
                    found = i;
                }
            }
            // Prefer an exact moved stack above. Slot packets also replace the object on
            // damage updates: accept only a damage-only update in its own slot, not a twin.
            if (found < 0 && !ambiguous && slot < previous.size() && slot < current.size()) {
                ItemStack candidate = current.get(slot);
                if (previousReferences.stream().noneMatch(old -> old == candidate)
                        && sameExceptDamage(previous.get(slot), candidate)) found = slot;
            }
            if (found >= 0) { slot = found; bound = current.get(found); missingSince = -1; }
            else {
                // Leave two ticks for cursor/slot packets to complete before choosing a replacement.
                if (missingSince < 0) missingSince = local.tickCount;
                if (local.tickCount - missingSince < 2) return false;
                slot = -1; bound = ItemStack.EMPTY; missingSince = -1;
            }
        }
        if (slot < 0) {
            // Head first, then hotbar 0..8, then main inventory 9..35. Never choose a chest slot.
            if (!head.isEmpty() && AccessoryItemModels.isEligibleHeadwear(head)) {
                for (int i = 0; i < current.size(); i++) if (current.get(i) == head) {
                    slot = i; bound = head; break;
                }
            }
            if (slot < 0) for (int i = 0; i < Math.min(36, local.getInventory().getContainerSize()); i++) {
                ItemStack candidate = current.get(i);
                if (!candidate.isEmpty() && AccessoryItemModels.isServerDefaultHelmet(candidate)
                        && AccessoryItemModels.isEligibleHeadwear(candidate)) {
                    slot = i; bound = candidate; break;
                }
            }
        }
        boolean changed = current.size() != previous.size();
        for (int i = 0; !changed && i < current.size(); i++) {
            ItemStack a = current.get(i), b = previous.get(i);
            changed = !(a.isEmpty() && b.isEmpty()) && !same(a, b);
        }
        if (changed) previous = current.stream().map(ItemStack::copy).toList();
        previousReferences = List.copyOf(current);
        return slot >= 0 && item == bound && !item.isEmpty();
    }

    private static boolean same(ItemStack a, ItemStack b) {
        return !a.isEmpty() && !b.isEmpty() && a.getCount() == b.getCount()
                && ItemStack.isSameItemSameComponents(a, b);
    }

    private static boolean sameExceptDamage(ItemStack a, ItemStack b) {
        if (a.isEmpty() || b.isEmpty() || a.getItem() != b.getItem()
                || a.getCount() != b.getCount() || !a.isDamageableItem() || !b.isDamageableItem()
                || a.getDamageValue() == b.getDamageValue()) return false;
        ItemStack before = a.copy();
        ItemStack after = b.copy();
        before.remove(DataComponents.DAMAGE);
        after.remove(DataComponents.DAMAGE);
        return ItemStack.isSameItemSameComponents(before, after);
    }
    public static void reset() {
        player = null; bound = ItemStack.EMPTY; previous = List.of(); previousReferences = List.of(); slot = -1; waitForUnequip = false; missingSince = -1;
    }
}
