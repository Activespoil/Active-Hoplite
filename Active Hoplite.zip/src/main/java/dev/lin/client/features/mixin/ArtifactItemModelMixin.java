package dev.lin.client.features.mixin;

import dev.lin.client.features.artifact.ArtifactSkinModelPolicy;
import dev.lin.client.features.artifact.ArtifactProjectileModels;
import net.minecraft.client.renderer.item.ItemModelResolver;
import net.minecraft.client.renderer.item.ItemStackRenderState;
import net.minecraft.core.component.DataComponentType;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.ItemOwner;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(ItemModelResolver.class)
public abstract class ArtifactItemModelMixin {
   @Redirect(
      method = "method_65595",
      at = @At(value = "INVOKE", target = "Lnet/minecraft/class_10442;method_65598(Lnet/minecraft/class_10444;Lnet/minecraft/class_1799;Lnet/minecraft/class_811;Lnet/minecraft/class_1937;Lnet/minecraft/class_11566;I)V")
   )
   private void linClient$preserveProjectileOwner(ItemModelResolver resolver, ItemStackRenderState state,
      ItemStack stack, ItemDisplayContext context, Level level, ItemOwner ignoredOwner, int seed,
      ItemStackRenderState originalState, ItemStack originalStack, ItemDisplayContext originalContext, Entity entity) {
      // Keep the projectile as ItemOwner so onlySelf and model conditions can
      // resolve its shooter after the item leaves the player's hand.
      resolver.updateForTopItem(state, ArtifactProjectileModels.forEntity(stack, entity), context, level, entity, seed);
   }

   @Redirect(
      method = "method_65596",
      at = @At(value = "INVOKE", target = "Lnet/minecraft/class_1799;method_58694(Lnet/minecraft/class_9331;)Ljava/lang/Object;")
   )
   private Object linClient$selectArtifactItemModel(
      ItemStack renderedStack,
      DataComponentType<?> component,
      ItemStackRenderState renderState,
      ItemStack stack,
      ItemDisplayContext displayContext,
      Level level,
      ItemOwner owner,
      int seed
   ) {
      @SuppressWarnings({"rawtypes", "unchecked"})
      Object selected = renderedStack.get((DataComponentType)component);
      if (displayContext == ItemDisplayContext.GUI && !ArtifactSkinModelPolicy.allowGuiSkin(stack)) return selected;
      return selected instanceof Identifier model ? ArtifactSkinModelPolicy.selectModel(model, owner, renderedStack) : selected;
   }
}
