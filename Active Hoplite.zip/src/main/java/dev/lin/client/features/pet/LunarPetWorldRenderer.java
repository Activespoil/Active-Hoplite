package dev.lin.client.features.pet;

import com.mojang.blaze3d.vertex.PoseStack;
import dev.lin.client.cosmetics.sync.RemoteCosmetics;
import com.mojang.blaze3d.vertex.VertexConsumer;
import dev.lin.client.features.config.ClientAccessoryConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.entity.state.AvatarRenderState;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.client.renderer.texture.OverlayTexture;

public final class LunarPetWorldRenderer {
   private static final java.util.Set<Integer> PREVIEW_IDS =
      java.util.concurrent.ConcurrentHashMap.newKeySet();
   private static final float SHOULDER_X = -0.58F;
   private static final float STANDING_SHOULDER_Y = -1.08F;
   private static final float CROUCHING_SHOULDER_Y = -0.87F;
   private static final float SHOULDER_Z = 0.02F;

   private LunarPetWorldRenderer() {
   }

   public static void setPreview(int stateId, boolean preview) {
      if (preview) PREVIEW_IDS.add(stateId); else PREVIEW_IDS.remove(stateId);
   }

   public static void submit(AvatarRenderState state, PoseStack matrices, SubmitNodeCollector collector) {
      Minecraft minecraft = Minecraft.getInstance();
      boolean preview = PREVIEW_IDS.contains(state.id);
      var remote=preview?null:RemoteCosmetics.outfit(state);
      if ((!preview && remote==null && (minecraft.player == null || state.id != minecraft.player.getId())) || state.isInvisible) {
         return;
      }
      LunarPetTextureManager.RenderData data = remote==null?LunarPetTextureManager.selectedRenderData()
         :LunarPetTextureManager.remoteRenderData(remote.accessories().get("pet"));
      if (data == null) {
         return;
      }
      matrices.pushPose();
      float bob = (float)Math.sin(state.ageInTicks * 0.08F) * 0.025F;
      float shoulderY = state.isCrouching ? CROUCHING_SHOULDER_Y : STANDING_SHOULDER_Y;
      matrices.translate(
         SHOULDER_X + (remote==null?ClientAccessoryConfig.petOffsetX:remote.number("petOffsetX",0)),
         shoulderY - (remote==null?ClientAccessoryConfig.petOffsetY:remote.number("petOffsetY",0)) + bob,
         SHOULDER_Z
      );
      matrices.mulPose(new org.joml.Quaternionf().rotateY((float)Math.toRadians(-18.0F)));
      collector.submitCustomGeometry(
         matrices,
         RenderTypes.entityCutoutNoCull(data.texture()),
         (pose, consumer) -> render(data.mesh(), pose, consumer, state.lightCoords)
      );
      matrices.popPose();
   }

   private static void render(
      LunarPetModelLoader.PetMesh mesh, PoseStack.Pose pose, VertexConsumer consumer, int light
   ) {
      for (LunarPetModelLoader.Vertex vertex : mesh.vertices()) {
         consumer.addVertex(pose, vertex.x(), vertex.y(), vertex.z())
            .setColor(-1)
            .setUv(vertex.u(), vertex.v())
            .setOverlay(OverlayTexture.NO_OVERLAY)
            .setLight(light)
            .setNormal(pose, vertex.nx(), vertex.ny(), vertex.nz());
      }
   }
}
