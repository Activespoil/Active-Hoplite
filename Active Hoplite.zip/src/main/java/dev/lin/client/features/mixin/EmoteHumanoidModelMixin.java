package dev.lin.client.features.mixin;

import dev.lin.client.cosmetics.emote.EmotePose;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.renderer.entity.state.AvatarRenderState;
import net.minecraft.client.renderer.entity.state.HumanoidRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(HumanoidModel.class)
public abstract class EmoteHumanoidModelMixin {
    @Inject(method = "setupAnim(Lnet/minecraft/client/renderer/entity/state/HumanoidRenderState;)V", at = @At("TAIL"))
    private void linClient$emote(HumanoidRenderState state, CallbackInfo ci) {
        if (state instanceof AvatarRenderState avatar)
            EmotePose.apply((HumanoidModel<?>)(Object)this, avatar);
    }
}
