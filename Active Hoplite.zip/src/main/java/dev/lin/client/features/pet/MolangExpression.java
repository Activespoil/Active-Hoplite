package dev.lin.client.features.pet;

import com.google.gson.JsonElement;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.Locale;

final class MolangExpression {
   private final String value;
   private final Map<String, Double> variables;
   private int cursor;

   private MolangExpression(String value, Map<String, Double> variables) {
      this.value = value == null ? "" : value.trim().toLowerCase(Locale.ROOT);
      this.variables = variables;
   }

   static float evaluate(JsonElement value) {
      return evaluate(value, new HashMap<>());
   }

   static float evaluate(JsonElement value, Map<String, Double> variables) {
      if (value == null || value.isJsonNull()) {
         return 0.0F;
      }
      if (value.isJsonPrimitive() && value.getAsJsonPrimitive().isNumber()) {
         return value.getAsFloat();
      }
      try {
         double result = evaluateScript(value.getAsString(), variables);
         return Double.isFinite(result) ? (float)result : 0.0F;
      } catch (RuntimeException ignored) {
         return 0.0F;
      }
   }

   private static double evaluateScript(String source, Map<String, Double> variables) {
      List<String> statements = splitStatements(source == null ? "" : source.toLowerCase(Locale.ROOT));
      double result = 0.0;
      for (String raw : statements) {
         String statement = raw.trim();
         if (statement.isEmpty()) {
            continue;
         }
         if (statement.startsWith("return ")) {
            return new MolangExpression(statement.substring(7), variables).parseConditional();
         }
         int assignment = assignmentIndex(statement);
         if (assignment > 0) {
            String name = statement.substring(0, assignment).trim();
            double assigned = new MolangExpression(statement.substring(assignment + 1), variables).parseConditional();
            variables.put(name, assigned);
            result = assigned;
         } else {
            result = new MolangExpression(statement, variables).parseConditional();
         }
      }
      return result;
   }

   private static List<String> splitStatements(String source) {
      List<String> result = new ArrayList<>();
      int start = 0;
      int parentheses = 0;
      int braces = 0;
      for (int index = 0; index < source.length(); index++) {
         char current = source.charAt(index);
         if (current == '(') {
            parentheses++;
         } else if (current == ')') {
            parentheses = Math.max(0, parentheses - 1);
         } else if (current == '{') {
            braces++;
         } else if (current == '}') {
            braces = Math.max(0, braces - 1);
         } else if (current == ';' && parentheses == 0 && braces == 0) {
            result.add(source.substring(start, index));
            start = index + 1;
         }
      }
      if (start < source.length()) {
         result.add(source.substring(start));
      }
      return result;
   }

   private static int assignmentIndex(String statement) {
      int parentheses = 0;
      for (int index = 0; index < statement.length(); index++) {
         char current = statement.charAt(index);
         if (current == '(') {
            parentheses++;
         } else if (current == ')') {
            parentheses = Math.max(0, parentheses - 1);
         } else if (current == '=' && parentheses == 0) {
            char before = index > 0 ? statement.charAt(index - 1) : 0;
            char after = index + 1 < statement.length() ? statement.charAt(index + 1) : 0;
            if (before != '=' && before != '<' && before != '>' && before != '!' && after != '=') {
               return index;
            }
         }
      }
      return -1;
   }

   private double parseConditional() {
      double condition = parseNullCoalescing();
      skipWhitespace();
      if (take('?')) {
         double whenTrue = parseConditional();
         require(':');
         double whenFalse = parseConditional();
         return truthy(condition) ? whenTrue : whenFalse;
      }
      return condition;
   }

   private double parseNullCoalescing() {
      double result = parseOr();
      while (take("??")) {
         double fallback = parseOr();
         if (!truthy(result)) {
            result = fallback;
         }
      }
      return result;
   }

   private double parseOr() {
      double result = parseAnd();
      while (take("||")) {
         double right = parseAnd();
         result = truthy(result) || truthy(right) ? 1.0 : 0.0;
      }
      return result;
   }

   private double parseAnd() {
      double result = parseEquality();
      while (take("&&")) {
         double right = parseEquality();
         result = truthy(result) && truthy(right) ? 1.0 : 0.0;
      }
      return result;
   }

   private double parseEquality() {
      double result = parseComparison();
      while (true) {
         if (take("==")) {
            result = result == parseComparison() ? 1.0 : 0.0;
         } else if (take("!=")) {
            result = result != parseComparison() ? 1.0 : 0.0;
         } else {
            return result;
         }
      }
   }

   private double parseComparison() {
      double result = parseAdditive();
      while (true) {
         if (take("<=")) {
            result = result <= parseAdditive() ? 1.0 : 0.0;
         } else if (take(">=")) {
            result = result >= parseAdditive() ? 1.0 : 0.0;
         } else if (take('<')) {
            result = result < parseAdditive() ? 1.0 : 0.0;
         } else if (take('>')) {
            result = result > parseAdditive() ? 1.0 : 0.0;
         } else {
            return result;
         }
      }
   }

   private double parseAdditive() {
      double result = parseMultiplicative();
      while (true) {
         if (take('+')) {
            result += parseMultiplicative();
         } else if (take('-')) {
            result -= parseMultiplicative();
         } else {
            return result;
         }
      }
   }

   private double parseMultiplicative() {
      double result = parseUnary();
      while (true) {
         if (take('*')) {
            result *= parseUnary();
         } else if (take('/')) {
            double divisor = parseUnary();
            result = divisor == 0.0 ? 0.0 : result / divisor;
         } else if (take('%')) {
            double divisor = parseUnary();
            result = divisor == 0.0 ? 0.0 : result % divisor;
         } else {
            return result;
         }
      }
   }

   private double parseUnary() {
      if (take('+')) {
         return parseUnary();
      }
      if (take('-')) {
         return -parseUnary();
      }
      if (take('!')) {
         return truthy(parseUnary()) ? 0.0 : 1.0;
      }
      return parsePrimary();
   }

   private double parsePrimary() {
      skipWhitespace();
      if (take('(')) {
         double result = parseConditional();
         require(')');
         return result;
      }
      if (cursor < value.length() && (Character.isDigit(value.charAt(cursor)) || value.charAt(cursor) == '.')) {
         return parseNumber();
      }
      String identifier = parseIdentifier();
      if (identifier.isEmpty()) {
         return 0.0;
      }
      if (take('(')) {
         List<Double> arguments = new ArrayList<>();
         if (!peek(')')) {
            do {
               arguments.add(parseConditional());
            } while (take(','));
         }
         require(')');
         return function(identifier, arguments);
      }
      return switch (identifier) {
         case "math.pi" -> Math.PI;
         case "true" -> 1.0;
         default -> this.variables.getOrDefault(identifier, 0.0);
      };
   }

   private double parseNumber() {
      int start = cursor;
      while (cursor < value.length()) {
         char current = value.charAt(cursor);
         if (!Character.isDigit(current) && current != '.' && current != 'e' && current != 'f'
            && current != '+' && current != '-') {
            break;
         }
         if ((current == '+' || current == '-') && cursor > start && value.charAt(cursor - 1) != 'e') {
            break;
         }
         cursor++;
      }
      String number = value.substring(start, cursor).replace("f", "");
      return Double.parseDouble(number);
   }

   private String parseIdentifier() {
      skipWhitespace();
      int start = cursor;
      while (cursor < value.length()) {
         char current = value.charAt(cursor);
         if (!Character.isLetterOrDigit(current) && current != '_' && current != '.') {
            break;
         }
         cursor++;
      }
      return value.substring(start, cursor);
   }

   private static double function(String name, List<Double> values) {
      double first = argument(values, 0);
      return switch (name) {
         case "math.cos" -> Math.cos(Math.toRadians(first));
         case "math.sin" -> Math.sin(Math.toRadians(first));
         case "math.asin" -> Math.toDegrees(Math.asin(first));
         case "math.abs" -> Math.abs(first);
         case "math.floor" -> Math.floor(first);
         case "math.round" -> Math.round(first);
         case "math.sqrt" -> Math.sqrt(Math.max(0.0, first));
         case "math.pow" -> Math.pow(first, argument(values, 1));
         case "math.mod" -> argument(values, 1) == 0.0 ? 0.0 : first % argument(values, 1);
         case "math.min" -> Math.min(first, argument(values, 1));
         case "math.max" -> Math.max(first, argument(values, 1));
         case "math.clamp" -> Math.max(argument(values, 1), Math.min(argument(values, 2), first));
         case "math.lerp", "math.lerprotate" -> first + (argument(values, 1) - first) * argument(values, 2);
         case "math.random" -> values.size() >= 2 ? (first + argument(values, 1)) * 0.5 : first * 0.5;
         case "lunar.sigmoid", "lunar.sigmoid_swing" -> argument(values, 1) * Math.tanh(
            first * Math.max(0.001, argument(values, 2)) / Math.max(0.001, argument(values, 1))
         );
         case "lunar.lopsided_wave", "lunar.movewave_sin", "lunar.speed_vibration", "lunar.linear_wave" -> Math.sin(Math.toRadians(first));
         case "lunar.movewave_cos" -> Math.cos(Math.toRadians(first));
         case "lunar.interval" -> 0.0;
         case "lunar.smoothclamp" -> Math.max(argument(values, 1), Math.min(argument(values, 2), first));
         case "lunar.smoothmin" -> Math.min(first, argument(values, 1));
         case "lunar.easeinback" -> first * first * (2.70158 * first - 1.70158);
         case "lunar.random_integer" -> Math.round(values.size() >= 2 ? (first + argument(values, 1)) * 0.5 : first * 0.5);
         default -> first;
      };
   }

   private static double argument(List<Double> values, int index) {
      return index < values.size() ? values.get(index) : 0.0;
   }

   private void require(char expected) {
      if (!take(expected)) {
         throw new IllegalArgumentException("Expected " + expected);
      }
   }

   private boolean peek(char expected) {
      skipWhitespace();
      return cursor < value.length() && value.charAt(cursor) == expected;
   }

   private boolean take(char expected) {
      skipWhitespace();
      if (cursor < value.length() && value.charAt(cursor) == expected) {
         cursor++;
         return true;
      }
      return false;
   }

   private boolean take(String expected) {
      skipWhitespace();
      if (value.startsWith(expected, cursor)) {
         cursor += expected.length();
         return true;
      }
      return false;
   }

   private void skipWhitespace() {
      while (cursor < value.length() && Character.isWhitespace(value.charAt(cursor))) {
         cursor++;
      }
   }

   private static boolean truthy(double value) {
      return Math.abs(value) > 1.0E-8;
   }
}
