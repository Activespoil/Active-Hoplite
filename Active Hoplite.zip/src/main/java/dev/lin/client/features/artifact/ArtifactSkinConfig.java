package dev.lin.client.features.artifact;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashSet;
import java.util.HashMap;
import java.util.Map;
import java.util.Locale;
import java.util.Set;
import net.fabricmc.loader.api.FabricLoader;

public final class ArtifactSkinConfig {
   private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
   private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("artifact-skin-switcher.json");

   public static boolean enabled = true;
   public static boolean onlySelf = true;
   public static long revision;
   public static final float HAND_POSITION_MIN = -1.0F;
   public static final float HAND_POSITION_MAX = 1.0F;
   public static final float HAND_ROTATION_MIN = -180.0F;
   public static final float HAND_ROTATION_MAX = 180.0F;
   private static final Map<String, HandTransform> HAND_TRANSFORMS = new HashMap<>();
   public static ChronoSwordSkin chronoSword = ChronoSwordSkin.ENGINEERS;
   public static DeathNoteSkin deathNote = DeathNoteSkin.RED;
   public static DragonKatanaSkin dragonKatana = DragonKatanaSkin.CTHULHU;
   public static MjolnirSkin mjolnir = MjolnirSkin.VALENTINE;
   public static SoulGauntletSkin soulGauntlet = SoulGauntletSkin.INFINITY;
   public static WarPickaxeSkin warPickaxe = WarPickaxeSkin.TALARIAN;
   public static final Map<String, String> customSkins = new HashMap<>();
   public static final Map<String, String> selectedSkins = new HashMap<>();
   private static final Set<String> DISABLED_ARTIFACTS = new HashSet<>();

   private ArtifactSkinConfig() {
   }

   public static synchronized void load() {
      revision++;
      if (!Files.isRegularFile(FILE)) {
         return;
      }

      try (Reader reader = Files.newBufferedReader(FILE, StandardCharsets.UTF_8)) {
         Values values = GSON.fromJson(reader, Values.class);
         if (values == null) {
            return;
         }

         if (values.enabled != null) {
            enabled = values.enabled;
         }
         if (values.onlySelf != null) {
            onlySelf = values.onlySelf;
         }
         HAND_TRANSFORMS.clear();
         if (values.handTransforms != null) values.handTransforms.forEach((key, value) -> {
            if (key != null && value != null) HAND_TRANSFORMS.put(key, value.clamped());
         });
         if (values.chronoSword != null) {
            chronoSword = values.chronoSword;
         }
         if (values.deathNote != null) {
            deathNote = values.deathNote;
         }
         if (values.dragonKatana != null) {
            dragonKatana = values.dragonKatana;
         }
         if (values.mjolnir != null) {
            mjolnir = values.mjolnir;
         }
         if (values.soulGauntlet != null) {
            soulGauntlet = values.soulGauntlet;
         }
         if (values.warPickaxe != null) {
            warPickaxe = values.warPickaxe;
         }
         customSkins.clear();
         if (values.customSkins != null) values.customSkins.forEach((key, value) -> {
            if (key != null && value != null) customSkins.put(key, value);
         });
         selectedSkins.clear();
         if (values.selectedSkins != null) values.selectedSkins.forEach((key, value) -> {
            if (key != null && value != null) selectedSkins.put(key, value);
         });
         selectedSkins.entrySet().removeIf(entry -> {
            if (!entry.getValue().startsWith("custom:")) return false;
            customSkins.putIfAbsent(entry.getKey(), entry.getValue());
            return true;
         });
         DISABLED_ARTIFACTS.clear();
         if (values.disabledArtifacts != null) {
            values.disabledArtifacts.stream().map(ArtifactSkinConfig::normalizeArtifactId).filter(id -> !id.isEmpty()).forEach(DISABLED_ARTIFACTS::add);
         }
      } catch (Exception exception) {
         System.err.println("[Lin Client] Failed to load artifact skins: " + exception.getMessage());
      }
   }

   public static synchronized void save() {
      revision++;
      try {
         Files.createDirectories(FILE.getParent());
         try (Writer writer = Files.newBufferedWriter(FILE, StandardCharsets.UTF_8)) {
            GSON.toJson(new Values(enabled, onlySelf, null, Map.copyOf(HAND_TRANSFORMS),
               chronoSword, deathNote, dragonKatana, mjolnir,
               soulGauntlet, warPickaxe, Set.copyOf(DISABLED_ARTIFACTS), Map.copyOf(selectedSkins), Map.copyOf(customSkins)), writer);
         }
      } catch (Exception exception) {
         System.err.println("[Lin Client] Failed to save artifact skins: " + exception.getMessage());
      }
   }

   public static synchronized boolean isArtifactEnabled(String artifactId) {
      return !DISABLED_ARTIFACTS.contains(normalizeArtifactId(artifactId));
   }

   public static synchronized void setArtifactEnabled(String artifactId, boolean enabled) {
      String normalized = normalizeArtifactId(artifactId);
      if (normalized.isEmpty()) {
         return;
      }

      if (enabled) {
         DISABLED_ARTIFACTS.remove(normalized);
      } else {
         DISABLED_ARTIFACTS.add(normalized);
      }
   }

   private static String normalizeArtifactId(String value) {
      return value == null ? "" : value.trim().toLowerCase(Locale.ROOT).replace('-', '_');
   }

   private static float clamp(Float value, float min, float max, float fallback) {
      return value == null ? fallback : Math.max(min, Math.min(max, value));
   }

   public static synchronized HandTransform handTransform(String modelId) {
      HandTransform value = modelId == null ? null : HAND_TRANSFORMS.get(modelId);
      return value != null ? value : HandTransform.ZERO;
   }

   public static synchronized void setHandTransform(String modelId, boolean mainHand,
                                                     int index, float value) {
      if (modelId == null || modelId.isBlank()) return;
      HAND_TRANSFORMS.put(modelId, handTransform(modelId).with(mainHand, index, value).clamped());
   }

   public static synchronized void resetHandTransform(String modelId, boolean mainHand) {
      if (modelId == null || modelId.isBlank()) return;
      HandTransform value = handTransform(modelId).reset(mainHand);
      HAND_TRANSFORMS.put(modelId, value);
   }

   public record HandTransform(float mainX, float mainY, float mainZ, float mainRotX, float mainRotY,
                               float offX, float offY, float offZ, float offRotX, float offRotY) {
      private static final HandTransform ZERO = new HandTransform(0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

      private HandTransform clamped() {
         return new HandTransform(
            clamp(mainX, HAND_POSITION_MIN, HAND_POSITION_MAX, 0),
            clamp(mainY, HAND_POSITION_MIN, HAND_POSITION_MAX, 0),
            clamp(mainZ, HAND_POSITION_MIN, HAND_POSITION_MAX, 0),
            clamp(mainRotX, HAND_ROTATION_MIN, HAND_ROTATION_MAX, 0),
            clamp(mainRotY, HAND_ROTATION_MIN, HAND_ROTATION_MAX, 0),
            clamp(offX, HAND_POSITION_MIN, HAND_POSITION_MAX, 0),
            clamp(offY, HAND_POSITION_MIN, HAND_POSITION_MAX, 0),
            clamp(offZ, HAND_POSITION_MIN, HAND_POSITION_MAX, 0),
            clamp(offRotX, HAND_ROTATION_MIN, HAND_ROTATION_MAX, 0),
            clamp(offRotY, HAND_ROTATION_MIN, HAND_ROTATION_MAX, 0));
      }

      private HandTransform with(boolean mainHand, int index, float value) {
         float[] values = {mainX, mainY, mainZ, mainRotX, mainRotY,
            offX, offY, offZ, offRotX, offRotY};
         values[(mainHand ? 0 : 5) + Math.max(0, Math.min(4, index))] = value;
         return new HandTransform(values[0], values[1], values[2], values[3], values[4],
            values[5], values[6], values[7], values[8], values[9]);
      }

      private HandTransform reset(boolean mainHand) {
         return mainHand
            ? new HandTransform(0, 0, 0, 0, 0, offX, offY, offZ, offRotX, offRotY)
            : new HandTransform(mainX, mainY, mainZ, mainRotX, mainRotY, 0, 0, 0, 0, 0);
      }
   }

   public enum ChronoSwordSkin {
      ENGINEERS,
      STEAMING
   }

   public enum DeathNoteSkin {
      GREEN,
      RED
   }

   public enum DragonKatanaSkin {
      DRAGONBREATH,
      CTHULHU
   }

   public enum MjolnirSkin {
      VALENTINE,
      SHATTERED
   }

   public enum SoulGauntletSkin {
      ALIEN,
      INFINITY
   }

   public enum WarPickaxeSkin {
      TALARIAN,
      VICTORIAN
   }

   private record Values(
      Boolean enabled,
      Boolean onlySelf,
      Float handOffsetY,
      Map<String, HandTransform> handTransforms,
      ChronoSwordSkin chronoSword,
      DeathNoteSkin deathNote,
      DragonKatanaSkin dragonKatana,
      MjolnirSkin mjolnir,
      SoulGauntletSkin soulGauntlet,
      WarPickaxeSkin warPickaxe,
      Set<String> disabledArtifacts,
      Map<String, String> selectedSkins,
      Map<String, String> customSkins
   ) {
   }
}
