package dev.lin.client.features.artifact;

import com.google.gson.Gson;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.resources.Identifier;

/** Bundled, data-driven model catalog; item state trees live in assets. */
final class CustomArtifactCatalog {
    private static final List<Entry> ENTRIES = load();
    private static final ConcurrentHashMap<ArtifactSkins.Artifact, List<ArtifactSkins.Option>> OPTIONS = new ConcurrentHashMap<>();

    static List<ArtifactSkins.Option> optionsFor(ArtifactSkins.Artifact artifact) {
        return OPTIONS.computeIfAbsent(artifact, CustomArtifactCatalog::createOptions);
    }

    private static List<Entry> load() {
        try (var stream = CustomArtifactCatalog.class.getResourceAsStream("/assets/lin_client/artifact_skins.json")) {
            if (stream == null) return List.of();
            Entry[] entries = new Gson().fromJson(new InputStreamReader(stream, StandardCharsets.UTF_8), Entry[].class);
            var unique = new LinkedHashMap<String, Entry>();
            if (entries != null) for (Entry entry : entries) unique.putIfAbsent(entry.id, entry);
            return List.copyOf(unique.values());
        } catch (Exception error) {
            System.err.println("[Lin Client] Cannot load custom artifact catalog: " + error.getMessage());
            return List.of();
        }
    }

    private static List<ArtifactSkins.Option> createOptions(ArtifactSkins.Artifact artifact) {
        var options = new ArrayList<ArtifactSkins.Option>(ENTRIES.size());
        for (int index = 0; index < ENTRIES.size(); index++) {
            Entry entry = ENTRIES.get(index);
            boolean base = entry.source.contains("/" + artifact.id() + "/")
                || entry.source.endsWith("/" + artifact.id());
            options.add(new ArtifactSkins.Option(artifact, "custom:" + entry.id,
                base ? "基础模型 · " + artifact.displayName() : "自定义 · " + entry.name,
                Identifier.parse(entry.preview), Identifier.parse(entry.world), 1000 + index));
        }
        return List.copyOf(options);
    }

    private record Entry(String id, String name, String kind, String preview, String world, String source) {}
}
