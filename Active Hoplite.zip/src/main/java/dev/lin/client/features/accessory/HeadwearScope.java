package dev.lin.client.features.accessory;

public enum HeadwearScope {
   HOPLITE("hoplite", "Hoplite"),
   KINGMC("kingmc", "KingMC"),
   GLOBAL("global", "全局运用");

   private final String id;
   private final String label;

   HeadwearScope(String id, String label) {
      this.id = id;
      this.label = label;
   }

   public String id() {
      return id;
   }

   public String label() {
      return label;
   }

   public HeadwearScope next() {
      HeadwearScope[] values = values();
      return values[(ordinal() + 1) % values.length];
   }

   public static HeadwearScope byId(String id) {
      for (HeadwearScope value : values()) {
         if (value.id.equalsIgnoreCase(id)) return value;
      }
      return GLOBAL;
   }
}
