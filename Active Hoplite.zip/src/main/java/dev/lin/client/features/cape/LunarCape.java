package dev.lin.client.features.cape;

import java.nio.file.Path;

public record LunarCape(
   String id,
   String displayName,
   String relativePath,
   LunarCape.Asset textureAsset,
   LunarCape.Asset metadataAsset,
   Path customPath
) {
   public boolean custom() {
      return this.customPath != null;
   }

   public record Asset(String logicalPath, String hash, long size) {
   }
}
