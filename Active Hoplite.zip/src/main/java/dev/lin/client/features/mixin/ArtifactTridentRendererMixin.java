package dev.lin.client.features.mixin;

import com.mojang.blaze3d.vertex.PoseStack;
import dev.lin.client.features.artifact.ArtifactProjectileRenderer;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.ThrownTridentRenderer;
import net.minecraft.client.renderer.entity.state.ThrownTridentRenderState;
import net.minecraft.client.renderer.state.CameraRenderState;
import net.minecraft.world.entity.projectile.arrow.ThrownTrident;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ThrownTridentRenderer.class)
public abstract class ArtifactTridentRendererMixin extends EntityRenderer<ThrownTrident, ThrownTridentRenderState> {
    protected ArtifactTridentRendererMixin(EntityRendererProvider.Context context) { super(context); }

    @Inject(method = "method_62552(Lnet/minecraft/class_1685;Lnet/minecraft/class_10073;F)V", at = @At("TAIL"))
    private void linClient$extractFlightModel(ThrownTrident entity, ThrownTridentRenderState state, float delta, CallbackInfo ci) {
        ArtifactProjectileRenderer.extract(entity, state);
    }

    @Inject(method = "method_4133(Lnet/minecraft/class_10073;Lnet/minecraft/class_4587;Lnet/minecraft/class_11659;Lnet/minecraft/class_12075;)V", at = @At("HEAD"), cancellable = true)
    private void linClient$submitFlightModel(ThrownTridentRenderState state, PoseStack poses,
                                            SubmitNodeCollector collector, CameraRenderState camera, CallbackInfo ci) {
        if (ArtifactProjectileRenderer.submit(state, state.yRot, state.xRot, poses, collector)) {
            super.submit(state, poses, collector, camera);
            ci.cancel();
        }
    }
}
