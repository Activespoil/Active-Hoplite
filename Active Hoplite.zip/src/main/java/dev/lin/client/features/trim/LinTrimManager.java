package dev.lin.client.features.trim;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Locale;
import java.util.Properties;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.world.entity.LivingEntity;
import dev.lin.client.cosmetics.sync.RemoteCosmetics;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.ItemOwner;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.equipment.trim.ArmorTrim;

public final class LinTrimManager {
   public static final List<String> PATTERNS = List.of(
      "civilization:dragon",
      "civilization:flame",
      "civilization:frost",
      "civilization:runic",
      "civilization:spiral",
      "civilization:warden",
      "civilization:ominous",
      "civilization:heart",
      "civilization:nether_heart",
      "civilization:aquatic",
      "civilization:ocean",
      "civilization:graphite",
      "civilization:wither",
      "civilization:zombie",
      "civilization:lightning",
      "civilization:necrotic",
      "civilization:infected",
      "civilization:radioactive",
      "civilization:redstone",
      "civilization:mummy",
      "civilization:pumpkin",
      "civilization:easter",
      "civilization:end",
      "civilization:ironclad",
      "civilization:gear",
      "civilization:vampire"
   );
   public static final List<String> MATERIALS = List.of(
      "gold", "iron", "diamond", "netherite", "redstone", "copper", "emerald", "lapis", "quartz", "amethyst", "resin"
   );
   private static final String DEFAULT_PATTERN = "civilization:dragon";
   private static final String DEFAULT_MATERIAL = "gold";
   private static final Path CONFIG_FILE = FabricLoader.getInstance().getConfigDir().resolve("lin-client-trim.properties");
   private static final EquipmentSlot[] ARMOR_SLOTS = {
      EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET
   };
   private static final ThreadLocal<Boolean> LOCAL_ARMOR_RENDER = ThreadLocal.withInitial(() -> false);
   private static final ThreadLocal<ArmorTrim> WORLD_ARMOR_TRIM = new ThreadLocal<>();
   private static final TrimAppearanceCache TRIMS = new TrimAppearanceCache();
   private static volatile String pattern = "civilization:dragon";
   private static volatile String material = "gold";
   private static volatile long lastModified = Long.MIN_VALUE;
   private static volatile long lastCheck;

   private LinTrimManager() {
   }

   public static String pattern() {
      reloadIfChanged();
      return pattern;
   }

   public static String material() {
      reloadIfChanged();
      return material;
   }

   public static boolean isEnabled() {
      return !"none".equals(pattern()) && !pattern().isBlank();
   }

   public static void setPattern(String value) {
      pattern = normalizePattern(value);
      save();
   }

   public static void setMaterial(String value) {
      material = normalizeMaterial(value);
      save();
   }

   public static void setLocalArmorRendering(boolean value) {
      LOCAL_ARMOR_RENDER.set(value);
   }

   public static boolean isLocalArmorRendering() {
      return Boolean.TRUE.equals(LOCAL_ARMOR_RENDER.get());
   }

   public static ArmorTrim worldArmorTrim() {
      return WORLD_ARMOR_TRIM.get();
   }

   public static void setWorldArmorTrim(ArmorTrim trim) {
      // Reuse the render thread's entry instead of reallocating it for every player submission.
      WORLD_ARMOR_TRIM.set(trim);
   }

   public static ArmorTrim renderTrim() {
      ArmorTrim world = WORLD_ARMOR_TRIM.get();
      return world != null ? world : isLocalArmorRendering() ? fakeTrim() : null;
   }

   public static boolean isEquippedArmorStack(ItemStack stack) {
      return isEquippedArmorStack(stack, null);
   }

   public static boolean isEquippedArmorStack(ItemStack stack, ItemOwner owner) {
      Minecraft minecraft = Minecraft.getInstance();
      if (stack == null || stack.isEmpty() || minecraft.player == null) {
         return false;
      }
      // Equipment HUD copies may compare equal; an explicitly different owner still isn't us.
      if (owner != null && owner.asLivingEntity() != null && owner.asLivingEntity() != minecraft.player) {
         return false;
      }

      return isEquippedBy(stack, minecraft.player);
   }

   private static boolean isEquippedBy(ItemStack stack, LivingEntity owner) {
      if (stack == null || stack.isEmpty() || owner == null) return false;
      for (EquipmentSlot slot : ARMOR_SLOTS) {
         ItemStack equipped = owner.getItemBySlot(slot);
         if (stack == equipped || !equipped.isEmpty()
            && stack.getCount() == equipped.getCount()
            && ItemStack.isSameItemSameComponents(stack, equipped)) {
            return true;
         }
      }
      return false;
   }

   /** Explicit remote owners never inherit our selection, including equal HUD stack copies. */
   public static ArmorTrim remoteEquippedTrim(ItemStack stack, ItemOwner owner) {
      var living = owner == null ? null : owner.asLivingEntity();
      if (living != null && living != Minecraft.getInstance().player) {
         if (!(living instanceof AbstractClientPlayer player) || !isEquippedBy(stack, player)) return null;
         var outfit = RemoteCosmetics.outfit(player);
         var selection = outfit == null ? null : outfit.trim();
         return selection == null ? null : appearanceTrim(selection.pattern(), selection.material());
      }
      return null;
   }

   public static ArmorTrim fakeTrim() {
      reloadIfChanged();
      return appearanceTrim(pattern, material);
   }

   /** Render-only shared cache, bounded by the 26 supported patterns and 11 materials. */
   public static ArmorTrim appearanceTrim(String selectedPattern, String selectedMaterial) {
      ClientPacketListener connection = Minecraft.getInstance().getConnection();
      if (connection == null) {
         TRIMS.clear();
         return null;
      }
      if (selectedPattern == null || selectedMaterial == null
         || !PATTERNS.contains(selectedPattern) || !MATERIALS.contains(selectedMaterial)) return null;
      try {
         return TRIMS.get(connection.registryAccess().lookupOrThrow(Registries.TRIM_MATERIAL), selectedPattern, selectedMaterial);
      } catch (RuntimeException ignored) {
         return null;
      }
   }

   public static String displayName(String id) {
      if (id != null && !id.isBlank() && !"none".equals(id)) {
         int split = id.indexOf(58);
         String path = split >= 0 ? id.substring(split + 1) : id;
         String[] words = path.split("_");
         StringBuilder result = new StringBuilder();

         for (String word : words) {
            if (!word.isEmpty()) {
               if (!result.isEmpty()) {
                  result.append(' ');
               }

               result.append(Character.toUpperCase(word.charAt(0))).append(word.substring(1));
            }
         }

         return result.toString();
      } else {
         return "None";
      }
   }

   private static String normalizePattern(String value) {
      if (value != null && !"none".equalsIgnoreCase(value.trim())) {
         String normalized = value.trim().toLowerCase(Locale.ROOT);
         return PATTERNS.contains(normalized) ? normalized : "civilization:dragon";
      } else {
         return "none";
      }
   }

   private static String normalizeMaterial(String value) {
      if (value == null) {
         return "gold";
      }

      String normalized = value.trim().toLowerCase(Locale.ROOT);
      return MATERIALS.contains(normalized) ? normalized : "gold";
   }

   private static void reloadIfChanged() {
      long now = System.currentTimeMillis();
      if (now - lastCheck >= 500L) {
         lastCheck = now;

         try {
            long modified = Files.exists(CONFIG_FILE) ? Files.getLastModifiedTime(CONFIG_FILE).toMillis() : Long.MIN_VALUE;
            if (modified != lastModified) {
               reload();
            }
         } catch (IOException ignored) {
         }
      }
   }

   private static void reload() {
      Properties properties = new Properties();

      try {
         if (Files.isRegularFile(CONFIG_FILE)) {
            try (BufferedReader reader = Files.newBufferedReader(CONFIG_FILE, StandardCharsets.UTF_8)) {
               properties.load(reader);
            }
         }

         pattern = normalizePattern(properties.getProperty("pattern", pattern));
         material = normalizeMaterial(properties.getProperty("material", material));
         lastModified = Files.exists(CONFIG_FILE) ? Files.getLastModifiedTime(CONFIG_FILE).toMillis() : Long.MIN_VALUE;
      } catch (IOException ignored) {
      }
   }

   private static void save() {
      try {
         Files.createDirectories(CONFIG_FILE.getParent());
         Properties properties = new Properties();
         properties.setProperty("pattern", pattern);
         properties.setProperty("material", material);

         try (BufferedWriter writer = Files.newBufferedWriter(CONFIG_FILE, StandardCharsets.UTF_8)) {
            properties.store(writer, "lin_client trim appearance");
         }

         lastModified = Files.getLastModifiedTime(CONFIG_FILE).toMillis();
      } catch (IOException ignored) {
      }
   }

   static {
      reload();
   }
}
