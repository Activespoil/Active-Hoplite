package dev.lin.client.features.render;

import dev.lin.client.cosmetics.ui.StaticPortraitModels;
import dev.lin.client.features.trim.LinTrimManager;
import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.item.TrackingItemStackRenderState;
import net.minecraft.core.component.DataComponentPatch;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.equipment.trim.ArmorTrim;
import net.minecraft.world.level.Level;

/** Only explicitly selected HUD calls freeze an image in the vanilla GUI atlas. */
public final class HudStaticItems {
    private static final int LIMIT = 128;
    private static final Map<Key, FrozenItem> ICONS = new LinkedHashMap<>(16, .75f, true);
    private static boolean active;
    private static Object world, player;
    private static long generation = Long.MIN_VALUE;
    private HudStaticItems() {}

    public static void renderItem(GuiGraphics graphics, ItemStack stack, int x, int y) {
        render(graphics, stack, x, y, false);
    }

    public static void renderFakeItem(GuiGraphics graphics, ItemStack stack, int x, int y) {
        render(graphics, stack, x, y, true);
    }

    public static void renderItem(GuiGraphics graphics, LivingEntity owner, ItemStack stack, int x, int y, int seed) {
        boolean previous = active;
        active = true;
        try { graphics.renderItem(owner, stack, x, y, seed); }
        finally { active = previous; }
    }

    private static void render(GuiGraphics graphics, ItemStack stack, int x, int y, boolean fake) {
        boolean previous = active;
        active = true;
        try {
            if (fake) graphics.renderFakeItem(stack, x, y);
            else graphics.renderItem(stack, x, y);
        } finally { active = previous; }
    }

    public static boolean active() { return active; }

    public static void clear() {
        ICONS.clear(); world = null; player = null; generation = Long.MIN_VALUE;
    }

    public static TrackingItemStackRenderState prepare(ItemStack original, LivingEntity owner, Level level, int seed) {
        Minecraft mc = Minecraft.getInstance();
        long nextGeneration = StaticPortraitModels.generation();
        if (world != mc.level || player != mc.player || generation != nextGeneration) {
            clear(); world = mc.level; player = mc.player; generation = nextGeneration;
        }
        // Match GuiGraphicsMixin's effective stack and trim context when looking up an image.
        boolean dropped = AccessoryItemModels.isRenderingDroppedIcon();
        boolean equipped = !dropped
                && LinTrimManager.isEquippedArmorStack(original, owner);
        ItemStack stack = equipped ? AccessoryItemModels.replaceDefaultHelmetIcon(original) : original;
        ArmorTrim trim = dropped ? null : equipped ? LinTrimManager.fakeTrim() : LinTrimManager.remoteEquippedTrim(original, owner);
        var remote=owner instanceof net.minecraft.client.player.AbstractClientPlayer avatar && owner!=mc.player
            ? dev.lin.client.cosmetics.sync.RemoteCosmetics.outfit(avatar):null;
        Key key = new Key(stack.getItem(), stack.getCount(), stack.getComponentsPatch(), owner, seed,
                trim,remote==null?null:remote.appearance(),dev.lin.client.features.artifact.ArtifactSkinConfig.revision);
        FrozenItem state = ICONS.get(key);
        if (state == null) {
            state = new FrozenItem();
            // The existing GuiGraphicsMixin owns the sole resolver redirect, including first resolution.
            ICONS.put(key, state);
            if (ICONS.size() > LIMIT) ICONS.remove(ICONS.keySet().iterator().next());
        }
        return state;
    }

    private record Key(Item item, int count, DataComponentPatch components, LivingEntity owner, int seed,
                       ArmorTrim trim,Object appearance,long localSkinRevision) {}

    public static final class FrozenItem extends TrackingItemStackRenderState {
        // A private identity prevents an animated inventory/world icon from overwriting this image.
        private final Object identity = new Object();
        private boolean resolved;
        public boolean isResolved() { return resolved; }
        public void markResolved() { resolved = true; }
        @Override public Object getModelIdentity() { return identity; }
        @Override public boolean isAnimated() { return false; }
    }
}
