package dev.lin.client.features.artifact;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import java.util.Map;
import java.util.WeakHashMap;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.entity.state.EntityRenderState;
import net.minecraft.client.renderer.entity.state.ThrownTridentRenderState;
import net.minecraft.client.renderer.item.ItemStackRenderState;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.core.component.DataComponents;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.arrow.AbstractArrow;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;

/** Native arrow/trident renderers bypass ItemModelResolver, so extract a separate flight item state. */
public final class ArtifactProjectileRenderer {
    private static final Map<EntityRenderState, ItemStackRenderState> STATES = new WeakHashMap<>();
    private static final Map<AbstractArrow, ItemStack> LAUNCH_STACKS = new WeakHashMap<>();
    private static final Map<LivingEntity, UsedWeapon> RECENT_WEAPONS = new WeakHashMap<>();
    private static Object trackedLevel;

    private record UsedWeapon(ItemStack stack, long tick) {}

    private ArtifactProjectileRenderer() {}

    public static void tick(Minecraft client) {
        if (trackedLevel != client.level) {
            trackedLevel = client.level;
            LAUNCH_STACKS.clear();
            RECENT_WEAPONS.clear();
            STATES.clear();
        }
        if (client.level == null || !ArtifactSkinConfig.enabled || !HopliteServerContext.canRenderArtifactSkins()) return;
        long now = client.level.getGameTime();
        RECENT_WEAPONS.values().removeIf(weapon -> now - weapon.tick() > 6);
        for (var player : client.level.players()) {
            if (ArtifactSkinConfig.onlySelf && player != client.player
                    && dev.lin.client.cosmetics.sync.CosmeticSyncBridge.remote(player.getUUID())==null || !player.isUsingItem()) continue;
            ItemStack used = player.getUseItem();
            var data = used.get(DataComponents.CUSTOM_MODEL_DATA);
            Float cmd = data == null ? null : data.getFloat(0);
            if (cmd != null && ArtifactSkins.artifactFor(
                    ArtifactSkinModelPolicy.itemModelPath(used.get(DataComponents.ITEM_MODEL)), Math.round(cmd)) != null) {
                RECENT_WEAPONS.put(player, new UsedWeapon(used.copy(), now));
            }
        }
    }

    public static void extract(AbstractArrow entity, EntityRenderState state) {
        ItemStack stack = entity.getPickupItemStackOrigin();
        Identifier model = selectedModel(stack, entity);
        if (model == null) {
            stack = entity.getWeaponItem();
            model = selectedModel(stack, entity);
        }
        if (model == null) {
            stack = LAUNCH_STACKS.get(entity);
            model = selectedModel(stack, entity);
        }
        if (model == null && !LAUNCH_STACKS.containsKey(entity) && entity.tickCount <= 10) {
            // The spawn packet can identify the shooter without synchronizing the
            // arrow's pickup/weapon stack. Capture the weapon once for this flight.
            var shooter = ArtifactProjectileModels.livingOwner(entity);
            if (shooter != null) {
                UsedWeapon recent = RECENT_WEAPONS.get(shooter);
                ItemStack released = recent != null && entity.level().getGameTime() - recent.tick() <= 6
                        ? recent.stack() : ItemStack.EMPTY;
                for (ItemStack candidate : new ItemStack[] {
                        released, shooter.getUseItem(), shooter.getMainHandItem(), shooter.getOffhandItem()}) {
                    Identifier candidateModel = selectedModel(candidate, entity);
                    if (candidateModel == null) continue;
                    stack = candidate.copy();
                    model = candidateModel;
                    LAUNCH_STACKS.put(entity, stack);
                    break;
                }
            }
        }
        if (model == null) {
            STATES.remove(state);
            return;
        }
        ItemStack rendered = stack.copy();
        rendered.set(DataComponents.ITEM_MODEL, model);
        if (state instanceof ThrownTridentRenderState trident && trident.isFoil) {
            rendered.set(DataComponents.ENCHANTMENT_GLINT_OVERRIDE, true);
        }
        ItemStackRenderState item = STATES.computeIfAbsent(state, ignored -> new ItemStackRenderState());
        // NONE avoids held/GUI transforms; the submit pass applies the entity's flight rotation.
        Minecraft.getInstance().getItemModelResolver().updateForTopItem(item, rendered,
                ItemDisplayContext.NONE, entity.level(), entity, entity.getId());
    }

    private static Identifier selectedModel(ItemStack stack, AbstractArrow entity) {
        if (stack == null || stack.isEmpty()) return null;
        Identifier original = stack.get(DataComponents.ITEM_MODEL);
        if (original == null || original.equals(ArtifactSkinModelPolicy.selectModel(original, entity, stack))) return null;
        var data = stack.get(DataComponents.CUSTOM_MODEL_DATA);
        Float cmd = data == null ? null : data.getFloat(0);
        var artifact = cmd == null ? null : ArtifactSkins.artifactFor(ArtifactSkinModelPolicy.itemModelPath(original), Math.round(cmd));
        if (artifact == null) return null;
        // Do not turn ordinary arrows from unrelated artifact bows into their weapon model.
        ArtifactSkins.Option chosen = ArtifactSkins.selected(artifact);
        LivingEntity shooter = ArtifactProjectileModels.livingOwner(entity);
        Minecraft mc = Minecraft.getInstance();
        if (shooter instanceof net.minecraft.client.player.AbstractClientPlayer remote && remote != mc.player) {
            var peer = dev.lin.client.cosmetics.sync.CosmeticSyncBridge.remote(remote.getUUID());
            if (peer != null) {
                var remoteChosen = ArtifactSkins.sharedOption(artifact, peer.outfit().appearance().skins().get(artifact.id()));
                if (remoteChosen == null) return null;
                chosen = remoteChosen;
            }
        }
        return switch (artifact) {
            case AIGLOS, POSEIDON_TRIDENT, HARPOON_LAUNCHER, RIBBIT_REEL, SCEPTRE_OF_ARACHNE ->
                    ArtifactProjectileModels.model(chosen, Math.round(cmd));
            default -> null;
        };
    }

    public static boolean submit(EntityRenderState state, float yaw, float pitch,
                                 PoseStack poses, SubmitNodeCollector collector) {
        ItemStackRenderState item = STATES.get(state);
        if (item == null || item.isEmpty()) return false;
        poses.pushPose();
        try {
            poses.mulPose(Axis.YP.rotationDegrees(yaw - 90f));
            // Bundled projectile models point up (+Y), unlike vanilla arrow geometry (+X).
            poses.mulPose(Axis.ZP.rotationDegrees(pitch - 90f));
            item.submit(poses, collector, state.lightCoords, OverlayTexture.NO_OVERLAY, state.outlineColor);
        } finally {
            poses.popPose();
        }
        return true;
    }
}
