package dev.lin.client.features.accessory;

public enum AccessorySlot {
   HEADWEAR,
   WINGS,
   FLOATING;
}
