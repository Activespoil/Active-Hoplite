package dev.lin.client.features.mixin;

import com.mojang.blaze3d.vertex.PoseStack;
import dev.lin.client.features.trim.LinTrimManager;
import dev.lin.client.cosmetics.sync.RemoteCosmetics;
import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.entity.layers.HumanoidArmorLayer;
import net.minecraft.client.renderer.entity.state.AvatarRenderState;
import net.minecraft.client.renderer.entity.state.HumanoidRenderState;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(HumanoidArmorLayer.class)
public abstract class HumanoidArmorLayerMixin {
   @WrapMethod(method = "submit")
   private void linClient$renderPlayerTrim(
      PoseStack matrices, SubmitNodeCollector collector, int light, HumanoidRenderState state, float limbAngle, float limbDistance, Operation<Void> original
   ) {
      Minecraft minecraft = Minecraft.getInstance();
      boolean local = minecraft.player != null && state instanceof AvatarRenderState avatar && avatar.id == minecraft.player.getId();
      var outfit = !local && state instanceof AvatarRenderState avatar ? RemoteCosmetics.outfit(avatar) : null;
      var selection = outfit == null ? null : outfit.trim();
      var trim = local ? LinTrimManager.fakeTrim() : selection == null ? null
         : LinTrimManager.appearanceTrim(selection.pattern(), selection.material());
      boolean previousLocal = LinTrimManager.isLocalArmorRendering();
      var previousTrim = LinTrimManager.worldArmorTrim();
      LinTrimManager.setLocalArmorRendering(local);
      LinTrimManager.setWorldArmorTrim(trim);
      try {
         original.call(matrices, collector, light, state, limbAngle, limbDistance);
      } finally {
         // Nested renders and failed submissions must not leak one player's trim into the next.
         LinTrimManager.setWorldArmorTrim(previousTrim);
         LinTrimManager.setLocalArmorRendering(previousLocal);
      }
   }
}
