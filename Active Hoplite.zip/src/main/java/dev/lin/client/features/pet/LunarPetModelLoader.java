package dev.lin.client.features.pet;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.joml.Vector4f;

public final class LunarPetModelLoader {
   private LunarPetModelLoader() {
   }

   static PetMesh load(JsonObject root) {
      return load(root, null, null);
   }

   static PetMesh load(JsonObject root, JsonObject animationRoot) {
      return load(root, animationRoot, null);
   }

   static PetMesh load(JsonObject root, JsonObject animationRoot, JsonObject definitionRoot) {
      JsonArray geometries = root.getAsJsonArray("minecraft:geometry");
      if (geometries == null || geometries.isEmpty()) {
         throw new IllegalArgumentException("pet geometry is empty");
      }
      JsonObject geometry = geometries.get(0).getAsJsonObject();
      JsonObject description = geometry.getAsJsonObject("description");
      float textureWidth = number(description, "texture_width", 64.0F);
      float textureHeight = number(description, "texture_height", 64.0F);
      JsonArray bones = geometry.getAsJsonArray("bones");
      if (bones == null) {
         throw new IllegalArgumentException("pet geometry has no bones");
      }

      Map<String, JsonObject> byName = new HashMap<>();
      for (JsonElement value : bones) {
         JsonObject bone = value.getAsJsonObject();
         if (bone.has("name")) {
            byName.put(bone.get("name").getAsString(), bone);
         }
      }
      Map<String, Matrix4f> transforms = new HashMap<>();
      Map<String, AnimationTransform> animation = animationTransforms(animationRoot, definitionRoot);
      List<Vertex> vertices = new ArrayList<>();
      for (JsonElement value : bones) {
         JsonObject bone = value.getAsJsonObject();
         Matrix4f transform = boneTransform(bone, byName, transforms, animation, new ArrayList<>());
         JsonArray cubes = bone.getAsJsonArray("cubes");
         if (cubes != null) {
            float boneInflate = number(bone, "inflate", 0.0F);
            boolean boneMirror = booleanValue(bone, "mirror", false);
            for (JsonElement cube : cubes) {
               addCube(vertices, cube.getAsJsonObject(), transform, textureWidth, textureHeight, boneInflate, boneMirror);
            }
         }
      }
      if (vertices.isEmpty()) {
         throw new IllegalArgumentException("pet geometry has no visible cubes");
      }
      return normalize(vertices, Math.max(1, Math.round(textureWidth)), Math.max(1, Math.round(textureHeight)));
   }

   private static Matrix4f boneTransform(
      JsonObject bone,
      Map<String, JsonObject> bones,
      Map<String, Matrix4f> cache,
      Map<String, AnimationTransform> animation,
      List<String> visiting
   ) {
      String name = bone.has("name") ? bone.get("name").getAsString() : "";
      Matrix4f cached = cache.get(name);
      if (cached != null) {
         return new Matrix4f(cached);
      }
      if (visiting.contains(name)) {
         return new Matrix4f();
      }
      visiting.add(name);
      Matrix4f transform = new Matrix4f();
      if (bone.has("parent")) {
         JsonObject parent = bones.get(bone.get("parent").getAsString());
         if (parent != null) {
            transform.set(boneTransform(parent, bones, cache, animation, visiting));
         }
      }
      Vector3f pivot = lunarPosition(vector(bone.getAsJsonArray("pivot")));
      Vector3f rotation = lunarRotation(vector(bone.getAsJsonArray("rotation")));
      AnimationTransform animated = animation.getOrDefault(name, AnimationTransform.IDENTITY);
      transform.translate(-animated.position.x, animated.position.y, animated.position.z);
      transform.translate(pivot.x, pivot.y, pivot.z)
         .rotateZ((float)Math.toRadians(rotation.z + animated.rotation.z))
         .rotateY((float)Math.toRadians(rotation.y - animated.rotation.y))
         .rotateX((float)Math.toRadians(rotation.x - animated.rotation.x))
         .scale(animated.scale)
         .translate(-pivot.x, -pivot.y, -pivot.z);
      visiting.remove(name);
      cache.put(name, new Matrix4f(transform));
      return transform;
   }

   private static void addCube(
      List<Vertex> target,
      JsonObject cube,
      Matrix4f boneTransform,
      float textureWidth,
      float textureHeight,
      float inheritedInflate,
      boolean inheritedMirror
   ) {
      Vector3f origin = vector(cube.getAsJsonArray("origin"));
      Vector3f size = vector(cube.getAsJsonArray("size"));
      float inflate = number(cube, "inflate", inheritedInflate);
      float x0 = -(origin.x + size.x) - inflate;
      float y0 = origin.y - inflate;
      float z0 = origin.z - inflate;
      float x1 = -origin.x + inflate;
      float y1 = origin.y + size.y + inflate;
      float z1 = origin.z + size.z + inflate;
      // Opposite faces of zero-thickness cubes otherwise compete at exactly
      // the same depth in the no-cull entity pass (visible as flashing feathers).
      // 0.01 authored pixel is subpixel at preview size and preserves both UV sides.
      if (Math.abs(x1 - x0) < 1.0E-6F) { x0 -= 0.005F; x1 += 0.005F; }
      if (Math.abs(y1 - y0) < 1.0E-6F) { y0 -= 0.005F; y1 += 0.005F; }
      if (Math.abs(z1 - z0) < 1.0E-6F) { z0 -= 0.005F; z1 += 0.005F; }
      Matrix4f transform = new Matrix4f(boneTransform);
      if (cube.has("rotation")) {
         rotateAround(transform, vector(cube.getAsJsonArray("pivot")), vector(cube.getAsJsonArray("rotation")));
      }
      boolean mirror = booleanValue(cube, "mirror", inheritedMirror);
      JsonElement uv = cube.get("uv");
      if (uv != null && uv.isJsonObject()) {
         JsonObject faces = uv.getAsJsonObject();
         addFace(target, faces, "west", transform, textureWidth, textureHeight, mirror, size.z, size.y,
            x0, y1, z1, x0, y1, z0, x0, y0, z0, x0, y0, z1);
         addFace(target, faces, "east", transform, textureWidth, textureHeight, mirror, size.z, size.y,
            x1, y1, z0, x1, y1, z1, x1, y0, z1, x1, y0, z0);
         addFace(target, faces, "north", transform, textureWidth, textureHeight, mirror, size.x, size.y,
            x0, y1, z0, x1, y1, z0, x1, y0, z0, x0, y0, z0);
         addFace(target, faces, "south", transform, textureWidth, textureHeight, mirror, size.x, size.y,
            x1, y1, z1, x0, y1, z1, x0, y0, z1, x1, y0, z1);
         addFace(target, faces, "up", transform, textureWidth, textureHeight, mirror, size.x, size.z,
            x0, y1, z1, x1, y1, z1, x1, y1, z0, x0, y1, z0);
         addFace(target, faces, "down", transform, textureWidth, textureHeight, mirror, size.x, size.z,
            x0, y0, z0, x1, y0, z0, x1, y0, z1, x0, y0, z1);
      } else {
         Vector3f baseUv = uv != null && uv.isJsonArray() ? vector2(uv.getAsJsonArray()) : new Vector3f();
         float u = baseUv.x;
         float v = baseUv.y;
         addBoxUvFace(target, transform, textureWidth, textureHeight, mirror, u + size.z + size.x, v + size.z, size.z, size.y,
            x0, y1, z1, x0, y1, z0, x0, y0, z0, x0, y0, z1);
         addBoxUvFace(target, transform, textureWidth, textureHeight, mirror, u, v + size.z, size.z, size.y,
            x1, y1, z0, x1, y1, z1, x1, y0, z1, x1, y0, z0);
         addBoxUvFace(target, transform, textureWidth, textureHeight, mirror, u + size.z, v + size.z, size.x, size.y,
            x0, y1, z0, x1, y1, z0, x1, y0, z0, x0, y0, z0);
         addBoxUvFace(target, transform, textureWidth, textureHeight, mirror, u + size.z * 2 + size.x, v + size.z, size.x, size.y,
            x1, y1, z1, x0, y1, z1, x0, y0, z1, x1, y0, z1);
         addBoxUvFace(target, transform, textureWidth, textureHeight, mirror, u + size.z, v, size.x, size.z,
            x0, y1, z1, x1, y1, z1, x1, y1, z0, x0, y1, z0);
         addBoxUvFace(target, transform, textureWidth, textureHeight, mirror, u + size.z + size.x, v + size.z, size.x, -size.z,
            x0, y0, z0, x1, y0, z0, x1, y0, z1, x0, y0, z1);
      }
   }

   private static void addFace(
      List<Vertex> target, JsonObject faces, String name, Matrix4f transform, float textureWidth, float textureHeight, boolean mirror,
      float defaultWidth, float defaultHeight, float... positions
   ) {
      JsonObject face = faces.getAsJsonObject(name);
      if (face == null || !face.has("uv")) {
         return;
      }
      Vector3f uv = vector2(face.getAsJsonArray("uv"));
      Vector3f uvSize = face.has("uv_size") ? vector2(face.getAsJsonArray("uv_size")) : new Vector3f(defaultWidth, defaultHeight, 0.0F);
      addBoxUvFace(target, transform, textureWidth, textureHeight, mirror, uv.x, uv.y, uvSize.x, uvSize.y, positions);
   }

   private static void addBoxUvFace(
      List<Vertex> target, Matrix4f transform, float textureWidth, float textureHeight, boolean mirror,
      float u, float v, float width, float height, float... positions
   ) {
      Vector3f[] points = new Vector3f[4];
      for (int index = 0; index < 4; index++) {
         Vector4f transformed = transform.transform(new Vector4f(positions[index * 3], positions[index * 3 + 1], positions[index * 3 + 2], 1.0F));
         points[index] = new Vector3f(transformed.x, transformed.y, transformed.z);
      }
      Vector3f normal = new Vector3f(points[1]).sub(points[0]).cross(new Vector3f(points[2]).sub(points[0]));
      if (normal.lengthSquared() < 1.0E-8F) {
         return;
      }
      normal.normalize();
      float u0 = u / textureWidth;
      float u1 = (u + width) / textureWidth;
      float v0 = v / textureHeight;
      float v1 = (v + height) / textureHeight;
      if (mirror) {
         float swap = u0;
         u0 = u1;
         u1 = swap;
      }
      float[] us = mirror ? new float[]{u0, u1, u1, u0} : new float[]{u1, u0, u0, u1};
      float[] vs = {v0, v0, v1, v1};
      // Minecraft's entity cutout pipeline consumes QUADS. Supplying the old
      // triangle list made every four adjacent triangle vertices form an
      // unrelated quad, stretching both the pet bones and their texture.
      for (int index : new int[]{0, 1, 2, 3}) {
         Vector3f point = points[index];
         target.add(new Vertex(point.x, point.y, point.z, us[index], vs[index], normal.x, normal.y, normal.z));
      }
   }

   private static PetMesh normalize(List<Vertex> source, int textureWidth, int textureHeight) {
      float minX = Float.POSITIVE_INFINITY;
      float minY = Float.POSITIVE_INFINITY;
      float minZ = Float.POSITIVE_INFINITY;
      float maxX = Float.NEGATIVE_INFINITY;
      float maxY = Float.NEGATIVE_INFINITY;
      float maxZ = Float.NEGATIVE_INFINITY;
      for (Vertex vertex : source) {
         minX = Math.min(minX, vertex.x);
         minY = Math.min(minY, vertex.y);
         minZ = Math.min(minZ, vertex.z);
         maxX = Math.max(maxX, vertex.x);
         maxY = Math.max(maxY, vertex.y);
         maxZ = Math.max(maxZ, vertex.z);
      }
      float extent = Math.max(0.001F, Math.max(maxX - minX, Math.max(maxY - minY, maxZ - minZ)));
      float scale = 0.68F / extent;
      float centerX = (minX + maxX) * 0.5F;
      float centerY = (minY + maxY) * 0.5F;
      float centerZ = (minZ + maxZ) * 0.5F;
      Vertex[] normalized = new Vertex[source.size()];
      for (int index = 0; index < source.size(); index++) {
         Vertex vertex = source.get(index);
         normalized[index] = new Vertex(
            (vertex.x - centerX) * scale,
            -(vertex.y - centerY) * scale,
            (vertex.z - centerZ) * scale,
            vertex.u,
            vertex.v,
            vertex.nx,
            -vertex.ny,
            vertex.nz
         );
      }
      return new PetMesh(normalized, textureWidth, textureHeight);
   }

   private static Map<String, AnimationTransform> animationTransforms(JsonObject root, JsonObject definitionRoot) {
      if (root == null) {
         return Map.of();
      }
      JsonObject animations = root.getAsJsonObject("animations");
      if (animations == null || animations.isEmpty()) {
         return Map.of();
      }
      Map<String, Double> variables = previewVariables();
      List<String> selectedNames = selectedAnimations(definitionRoot, animations, variables);
      Map<String, AnimationTransformBuilder> merged = new HashMap<>();
      for (String selectedName : selectedNames) {
         JsonObject selected = animations.getAsJsonObject(selectedName);
         if (selected == null) {
            continue;
         }
         JsonObject animatedBones = selected.getAsJsonObject("bones");
         if (animatedBones == null) {
            continue;
         }
         for (Map.Entry<String, JsonElement> entry : animatedBones.entrySet()) {
            if (!entry.getValue().isJsonObject()) {
               continue;
            }
            JsonObject channels = entry.getValue().getAsJsonObject();
            AnimationTransformBuilder transform = merged.computeIfAbsent(entry.getKey(), ignored -> new AnimationTransformBuilder());
            if (channels.has("position")) {
               transform.position = animationVector(channels.get("position"), new Vector3f(), variables);
            }
            if (channels.has("rotation")) {
               transform.rotation = animationVector(channels.get("rotation"), new Vector3f(), variables);
            }
            if (channels.has("scale")) {
               transform.scale = animationVector(channels.get("scale"), new Vector3f(1.0F, 1.0F, 1.0F), variables);
            }
         }
      }
      Map<String, AnimationTransform> result = new HashMap<>();
      for (Map.Entry<String, AnimationTransformBuilder> entry : merged.entrySet()) {
         result.put(entry.getKey(), entry.getValue().build());
      }
      return result;
   }

   static List<String> previewAnimationNames(JsonObject animationRoot, JsonObject definitionRoot) {
      if (animationRoot == null) {
         return List.of();
      }
      JsonObject animations = animationRoot.getAsJsonObject("animations");
      if (animations == null || animations.isEmpty()) {
         return List.of();
      }
      return List.copyOf(selectedAnimations(definitionRoot, animations, previewVariables()));
   }

   private static List<String> selectedAnimations(
      JsonObject definitionRoot, JsonObject animations, Map<String, Double> variables
   ) {
      List<String> selected = new ArrayList<>();
      JsonObject stateMachine = definitionRoot == null ? null : definitionRoot.getAsJsonObject("state_machine");
      JsonArray controllers = stateMachine == null ? null : stateMachine.getAsJsonArray("controllers");
      if (controllers != null) {
         for (JsonElement controllerValue : controllers) {
            if (!controllerValue.isJsonObject()) {
               continue;
            }
            JsonArray states = controllerValue.getAsJsonObject().getAsJsonArray("states");
            if (states == null) {
               continue;
            }
            for (JsonElement stateValue : states) {
               if (!stateValue.isJsonObject()) {
                  continue;
               }
               JsonObject state = stateValue.getAsJsonObject();
               JsonElement animationName = state.get("anim");
               JsonElement condition = state.get("plays_when");
               if (animationName == null || !animationName.isJsonPrimitive() || condition == null) {
                  continue;
               }
               if (MolangExpression.evaluate(condition, new HashMap<>(variables)) != 0.0F) {
                  String name = animationName.getAsString();
                  if (animations.has(name)) {
                     selected.add(name);
                  }
                  break;
               }
            }
         }
      }
      if (!selected.isEmpty()) {
         return selected;
      }
      if (animations.has("main")) {
         return List.of("main");
      }
      for (Map.Entry<String, JsonElement> entry : animations.entrySet()) {
         if (entry.getKey().endsWith(".main") && entry.getValue().isJsonObject()) {
            return List.of(entry.getKey());
         }
      }
      if (definitionRoot == null) {
         for (Map.Entry<String, JsonElement> entry : animations.entrySet()) {
            if (entry.getValue().isJsonObject()) {
               return List.of(entry.getKey());
            }
         }
      }
      return List.of();
   }

   private static Map<String, Double> previewVariables() {
      Map<String, Double> variables = new HashMap<>();
      queryVariable(variables, "is_in_gui", 1.0);
      queryVariable(variables, "is_in_preview_model", 1.0);
      queryVariable(variables, "is_on_ground", 1.0);
      queryVariable(variables, "life_time", 0.0);
      variables.put("c.afk_timer", 0.0);
      return variables;
   }

   private static void queryVariable(Map<String, Double> variables, String name, double value) {
      variables.put("q." + name, value);
      variables.put("query." + name, value);
   }

   private static Vector3f animationVector(JsonElement value, Vector3f fallback, Map<String, Double> variables) {
      if (value == null || value.isJsonNull()) {
         return new Vector3f(fallback);
      }
      if (value.isJsonArray()) {
         JsonArray values = value.getAsJsonArray();
         return new Vector3f(
            animationComponent(values, 0, fallback.x, variables),
            animationComponent(values, 1, fallback.y, variables),
            animationComponent(values, 2, fallback.z, variables)
         );
      }
      if (value.isJsonPrimitive()) {
         float uniform = MolangExpression.evaluate(value, variables);
         return new Vector3f(uniform, uniform, uniform);
      }
      JsonObject object = value.getAsJsonObject();
      if (object.has("vector")) {
         return animationVector(object.get("vector"), fallback, variables);
      }
      if (object.has("post")) {
         return animationVector(object.get("post"), fallback, variables);
      }
      if (object.has("pre")) {
         return animationVector(object.get("pre"), fallback, variables);
      }
      JsonElement earliest = null;
      double earliestTime = Double.POSITIVE_INFINITY;
      for (Map.Entry<String, JsonElement> entry : object.entrySet()) {
         try {
            double time = Double.parseDouble(entry.getKey());
            if (time < earliestTime) {
               earliestTime = time;
               earliest = entry.getValue();
            }
         } catch (NumberFormatException ignored) {
         }
      }
      return earliest == null ? new Vector3f(fallback) : animationVector(earliest, fallback, variables);
   }

   private static float animationComponent(JsonArray values, int index, float fallback, Map<String, Double> variables) {
      return index < values.size() ? MolangExpression.evaluate(values.get(index), variables) : fallback;
   }

   private static void rotateAround(Matrix4f matrix, Vector3f pivot, Vector3f rotation) {
      if (rotation.lengthSquared() == 0.0F) {
         return;
      }
      pivot = lunarPosition(pivot);
      rotation = lunarRotation(rotation);
      matrix.translate(pivot.x, pivot.y, pivot.z)
         .rotateZ((float)Math.toRadians(rotation.z))
         .rotateY((float)Math.toRadians(rotation.y))
         .rotateX((float)Math.toRadians(rotation.x))
         .translate(-pivot.x, -pivot.y, -pivot.z);
   }

   private static Vector3f lunarPosition(Vector3f value) {
      return new Vector3f(-value.x, value.y, value.z);
   }

   private static Vector3f lunarRotation(Vector3f value) {
      return new Vector3f(-value.x, -value.y, value.z);
   }

   private static Vector3f vector(JsonArray values) {
      if (values == null) {
         return new Vector3f();
      }
      return new Vector3f(component(values, 0), component(values, 1), component(values, 2));
   }

   private static Vector3f vector2(JsonArray values) {
      return values == null ? new Vector3f() : new Vector3f(component(values, 0), component(values, 1), 0.0F);
   }

   private static float component(JsonArray values, int index) {
      return index < values.size() ? values.get(index).getAsFloat() : 0.0F;
   }

   private static float number(JsonObject object, String name, float fallback) {
      return object != null && object.has(name) ? object.get(name).getAsFloat() : fallback;
   }

   private static boolean booleanValue(JsonObject object, String name, boolean fallback) {
      return object != null && object.has(name) && !object.get(name).isJsonNull() ? object.get(name).getAsBoolean() : fallback;
   }

   public record PetMesh(Vertex[] vertices, int textureWidth, int textureHeight) {
   }

   public record Vertex(float x, float y, float z, float u, float v, float nx, float ny, float nz) {
   }

   private record AnimationTransform(Vector3f position, Vector3f rotation, Vector3f scale) {
      private static final AnimationTransform IDENTITY = new AnimationTransform(
         new Vector3f(), new Vector3f(), new Vector3f(1.0F, 1.0F, 1.0F)
      );
   }

   private static final class AnimationTransformBuilder {
      private Vector3f position = new Vector3f();
      private Vector3f rotation = new Vector3f();
      private Vector3f scale = new Vector3f(1.0F, 1.0F, 1.0F);

      private AnimationTransform build() {
         return new AnimationTransform(position, rotation, scale);
      }
   }
}
