package dev.lin.client.features.trim;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

public enum LinTrimPreview {
   NETHERITE("下界合金", Items.NETHERITE_HELMET, Items.NETHERITE_CHESTPLATE, Items.NETHERITE_LEGGINGS, Items.NETHERITE_BOOTS),
   DIAMOND("钻石", Items.DIAMOND_HELMET, Items.DIAMOND_CHESTPLATE, Items.DIAMOND_LEGGINGS, Items.DIAMOND_BOOTS),
   GOLD("金", Items.GOLDEN_HELMET, Items.GOLDEN_CHESTPLATE, Items.GOLDEN_LEGGINGS, Items.GOLDEN_BOOTS),
   IRON("铁", Items.IRON_HELMET, Items.IRON_CHESTPLATE, Items.IRON_LEGGINGS, Items.IRON_BOOTS);

   private static volatile LinTrimPreview selected = NETHERITE;
   private final String displayName;
   private final Item helmet;
   private final Item chestplate;
   private final Item leggings;
   private final Item boots;

   LinTrimPreview(String displayName, Item helmet, Item chestplate, Item leggings, Item boots) {
      this.displayName = displayName;
      this.helmet = helmet;
      this.chestplate = chestplate;
      this.leggings = leggings;
      this.boots = boots;
   }

   public String displayName() {
      return this.displayName;
   }

   public ItemStack helmet() {
      return new ItemStack(this.helmet);
   }

   public ItemStack chestplate() {
      return new ItemStack(this.chestplate);
   }

   public ItemStack leggings() {
      return new ItemStack(this.leggings);
   }

   public ItemStack boots() {
      return new ItemStack(this.boots);
   }

   public static LinTrimPreview selected() {
      return selected;
   }

   public static void select(LinTrimPreview preview) {
      if (preview != null) {
         selected = preview;
      }
   }
}
