package dev.lin.client.features.mixin;

import dev.lin.client.features.render.HudStaticItems;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.item.TrackingItemStackRenderState;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

/** Keep native pose, scissor, oversize handling and error reporting at the submission site. */
@Mixin(GuiGraphics.class)
public abstract class HudStaticItemMixin {
    @Redirect(method="renderItem(Lnet/minecraft/world/entity/LivingEntity;Lnet/minecraft/world/level/Level;Lnet/minecraft/world/item/ItemStack;III)V",
            at=@At(value="NEW", target="net/minecraft/client/renderer/item/TrackingItemStackRenderState"))
    private TrackingItemStackRenderState lin$hudImage(LivingEntity owner, Level level, ItemStack stack,
                                                     int x, int y, int seed) {
        return HudStaticItems.active() ? HudStaticItems.prepare(stack, owner, level, seed)
                : new TrackingItemStackRenderState();
    }
}
