package dev.lin.client.features.mixin;

import com.mojang.blaze3d.vertex.PoseStack;
import dev.lin.client.features.render.AccessoryWorldRenderer;
import dev.lin.client.features.cape.LunarCapeWorldRenderer;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.player.AvatarRenderer;
import net.minecraft.client.renderer.entity.state.AvatarRenderState;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.client.renderer.state.CameraRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(LivingEntityRenderer.class)
public abstract class AvatarRendererMixin {
   @Inject(method = "submit", at = @At("HEAD"))
   private void linClient$replaceDefaultHelmet(
      LivingEntityRenderState state, PoseStack matrices, SubmitNodeCollector collector, CameraRenderState camera, CallbackInfo callback
   ) {
      if (state instanceof AvatarRenderState avatarState && (Object)this instanceof AvatarRenderer<?>) {
         AccessoryWorldRenderer.replaceDefaultHelmet(avatarState);
      }
   }

   @Inject(method = "submit", at = @At(value = "INVOKE", target = "Lcom/mojang/blaze3d/vertex/PoseStack;popPose()V", shift = Shift.BEFORE))
   private void linClient$submit(
      LivingEntityRenderState state, PoseStack matrices, SubmitNodeCollector collector, CameraRenderState camera, CallbackInfo callback
   ) {
      if (state instanceof AvatarRenderState avatarState && (Object)this instanceof AvatarRenderer<?> renderer) {
         AccessoryWorldRenderer.submit(renderer.getModel(), avatarState, matrices, collector);
      }
   }

   @Inject(method = "submit", at = @At(value = "INVOKE", target = "Lcom/mojang/blaze3d/vertex/PoseStack;popPose()V", shift = Shift.AFTER))
   private void linClient$submitFloating(
      LivingEntityRenderState state, PoseStack matrices, SubmitNodeCollector collector, CameraRenderState camera, CallbackInfo callback
   ) {
      if (state instanceof AvatarRenderState avatarState && (Object)this instanceof AvatarRenderer<?>) {
         AccessoryWorldRenderer.submitFloating(avatarState, matrices, collector, camera);
      }
   }
}
