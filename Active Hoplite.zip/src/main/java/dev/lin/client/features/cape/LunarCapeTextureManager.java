package dev.lin.client.features.cape;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mojang.blaze3d.platform.NativeImage;
import dev.lin.client.features.LinFeatures;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.Duration;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import javax.imageio.ImageIO;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.resources.Identifier;

public final class LunarCapeTextureManager {
   private static final String CDN = "https://textures.lunarclientcdn.com/file/";
   private static final int PREVIEW_WIDTH = 28;
   private static final int PREVIEW_HEIGHT = 44;
   private static final int PREVIEW_LIMIT = 160;
   private static final Path LOCAL_JIT = Path.of(System.getProperty("user.home"), ".lunarclient", "jit", "assets", "lunar-jit");
   private static final Path CACHE = FabricLoader.getInstance().getConfigDir().resolve("lin-client/lunar-cape-cache");
   private static final Path PREVIEW_CACHE = FabricLoader.getInstance().getConfigDir().resolve("lin-client/lunar-cape-previews");
   private static final ExecutorService PREVIEW_EXECUTOR = Executors.newFixedThreadPool(8, task -> {
      Thread thread = new Thread(task, "Lin Client Lunar Cape Preview");
      thread.setDaemon(true);
      return thread;
   });
   private static final ExecutorService ACTIVE_EXECUTOR = Executors.newSingleThreadExecutor(task -> {
      Thread thread = new Thread(task, "Lin Client Selected Cape Loader");
      thread.setDaemon(true);
      return thread;
   });
   private static final HttpClient HTTP = HttpClient.newBuilder()
      .connectTimeout(Duration.ofSeconds(10))
      .followRedirects(HttpClient.Redirect.NORMAL)
      .build();
   private static final Map<String, Object> ASSET_LOCKS = new ConcurrentHashMap<>();
   private static final Object WEBP_DECODE_LOCK = new Object();
   private static final Set<String> LOADING_PREVIEWS = ConcurrentHashMap.newKeySet();
   private static final Set<String> FAILED_PREVIEWS = ConcurrentHashMap.newKeySet();
   private static final Map<String, Integer> PREVIEW_FAILURE_COUNTS = new ConcurrentHashMap<>();
   private static final Map<String, PreviewTexture> PREVIEWS = Collections.synchronizedMap(new LinkedHashMap<>(64, 0.75F, true));
   private static volatile ActiveTexture active;
   private static volatile String loadingActiveId;
   private static volatile String failedActiveId;

   private static final Map<String,ActiveTexture> REMOTE = new LinkedHashMap<>();
   private static Set<String> remoteWanted = Set.of();
   private static final long REMOTE_BYTE_LIMIT=32L*1024*1024;
   private static long remoteBytes;
   private static final Set<String> remoteOverBudget=new java.util.HashSet<>();
   private static long remoteCost(ActiveTexture t) {
      return (long)t.sheet.getWidth()*t.sheet.getHeight()*4+(long)t.pixels.getWidth()*t.pixels.getHeight()*8;
   }
   public static Identifier remoteTexture(String id) {
      ActiveTexture texture=REMOTE.get(id);return texture==null?null:texture.texture;
   }
   public static void remoteTick(Set<String> ids,Set<String> animated) {
      if(!remoteWanted.equals(ids))remoteOverBudget.clear();
      remoteWanted=Set.copyOf(ids);
      var iterator=REMOTE.entrySet().iterator();
      while(iterator.hasNext()) {
         var e=iterator.next();var t=e.getValue();
         if(!ids.contains(e.getKey())){remoteBytes-=remoteCost(t);Minecraft.getInstance().getTextureManager().release(t.texture);iterator.remove();continue;}
         if(animated.contains(e.getKey()) && t.spec.frameCount>1 && ++t.ticks>=t.spec.frameTime) {
            t.ticks=0;t.frame=(t.frame+1)%t.spec.frameCount;
            writeFrame(t.pixels,t.sheet,t.spec,t.frame);t.dynamicTexture.upload();
         }
      }
      for(String id:ids) {
         LunarCape cape=dev.lin.client.cosmetics.sync.RemoteCosmetics.cape(id);
         if(cape==null || REMOTE.containsKey(id) || remoteOverBudget.contains(id) || remoteBytes>=REMOTE_BYTE_LIMIT)continue;
         dev.lin.client.cosmetics.sync.RemoteAssetLoader.request("cape:"+id,
            ()->remoteWanted.contains(id) && !REMOTE.containsKey(id),
            ()->{BufferedImage sheet=readImage(cape);return new RemoteSheet(sheet,frameSpec(sheet,readMetadata(cape)));},
            loaded->{
               int scale=frameScale(loaded.spec);int w=Math.max(64,scale*64),h=Math.max(32,scale*32);
               long cost=(long)loaded.sheet.getWidth()*loaded.sheet.getHeight()*4+(long)w*h*8;
               if(remoteBytes+cost>REMOTE_BYTE_LIMIT){remoteOverBudget.add(id);return;}
               NativeImage pixels=new NativeImage(w,h,true);writeFrame(pixels,loaded.sheet,loaded.spec,0);
               Identifier texture=Identifier.fromNamespaceAndPath(LinFeatures.MOD_ID,"lunar_cape/remote_"+id);
               DynamicTexture dynamic=new DynamicTexture(()->"Remote cape "+id,pixels);
               Minecraft.getInstance().getTextureManager().register(texture,dynamic);
               REMOTE.put(id,new ActiveTexture(id,texture,dynamic,pixels,loaded.sheet,loaded.spec));remoteBytes+=cost;
            });
      }
   }
   private record RemoteSheet(BufferedImage sheet,FrameSpec spec) {}

   private LunarCapeTextureManager() {
   }

   public static PreviewTexture preview(LunarCape cape) {
      PreviewTexture cached = PREVIEWS.get(cape.id());
      if (cached != null) {
         return cached;
      }
      BufferedImage bundled = readBundledPreview(cape);
      if (bundled != null) {
         registerPreview(cape, bundled);
         return PREVIEWS.get(cape.id());
      }
      if (!FAILED_PREVIEWS.contains(cape.id()) && LOADING_PREVIEWS.add(cape.id())) {
         PREVIEW_EXECUTOR.execute(() -> loadPreview(cape));
      }
      return null;
   }

   private static BufferedImage readBundledPreview(LunarCape cape) {
      if (cape.custom()) {
         return null;
      }
      String path = "/assets/lin_client/textures/cape_previews/" + cape.id() + ".png";
      try (InputStream input = LunarCapeTextureManager.class.getResourceAsStream(path)) {
         if (input == null) {
            return null;
         }
         BufferedImage image = ImageIO.read(input);
         return image != null && image.getWidth() == PREVIEW_WIDTH && image.getHeight() == PREVIEW_HEIGHT ? image : null;
      } catch (IOException ignored) {
         return null;
      }
   }

   private static void loadPreview(LunarCape cape) {
      try {
         BufferedImage sheet = readImage(cape);
         FrameSpec spec = frameSpec(sheet, readMetadata(cape));
         BufferedImage preview = readCachedPreview(cape);
         if (preview == null) {
            preview = new BufferedImage(PREVIEW_WIDTH, PREVIEW_HEIGHT, BufferedImage.TYPE_INT_ARGB);
            Graphics2D graphics = preview.createGraphics();
            try {
               graphics.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
               graphics.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
               graphics.drawImage(previewFrame(sheet, spec, 0), 0, 0, PREVIEW_WIDTH, PREVIEW_HEIGHT, null);
            } finally {
               graphics.dispose();
            }
            writeCachedPreview(cape, preview);
         }

         BufferedImage readyPreview = preview;
         BufferedImage readySheet = sheet;
         FrameSpec readySpec = spec;
         Minecraft.getInstance().execute(() -> {
            try {
               registerPreview(cape, readyPreview, readySheet, readySpec);
            } catch (Exception exception) {
               previewFailed(cape, exception);
            } finally {
               LOADING_PREVIEWS.remove(cape.id());
            }
         });
      } catch (Exception exception) {
         previewFailed(cape, exception);
         LOADING_PREVIEWS.remove(cape.id());
      }
   }

   private static void previewFailed(LunarCape cape, Exception exception) {
      int failures = PREVIEW_FAILURE_COUNTS.merge(cape.id(), 1, Integer::sum);
      if (failures >= 3) {
         FAILED_PREVIEWS.add(cape.id());
         System.err.println(
            "[Lin Client] Unable to load Lunar cape preview " + cape.displayName() + " after " + failures + " attempts: " + exception.getMessage()
         );
      }
   }

   private static void registerPreview(LunarCape cape, BufferedImage image) {
      registerPreview(cape, image, null, null);
   }

   private static void registerPreview(LunarCape cape, BufferedImage image,
                                       BufferedImage sheet, FrameSpec spec) {
      if (PREVIEWS.containsKey(cape.id())) {
         return;
      }
      NativeImage pixels = toNativeImage(image);
      Identifier texture = Identifier.fromNamespaceAndPath(LinFeatures.MOD_ID, "lunar_cape/preview_" + cape.id());
      DynamicTexture dynamicTexture = new DynamicTexture(() -> "Lunar cape preview " + cape.id(), pixels);
      Minecraft.getInstance().getTextureManager().register(texture, dynamicTexture);
      NativeImage capePixels = sheet == null || spec == null
         ? toCapeAtlas(image) : toCapeAtlas(sheet, spec);
      Identifier capeTexture = Identifier.fromNamespaceAndPath(LinFeatures.MOD_ID, "lunar_cape/mannequin_" + cape.id());
      DynamicTexture capeDynamicTexture = new DynamicTexture(() -> "Lunar cape mannequin " + cape.id(), capePixels);
      Minecraft.getInstance().getTextureManager().register(capeTexture, capeDynamicTexture);
      PREVIEWS.put(cape.id(), new PreviewTexture(texture, PREVIEW_WIDTH, PREVIEW_HEIGHT, capeTexture));
      PREVIEW_FAILURE_COUNTS.remove(cape.id());
      FAILED_PREVIEWS.remove(cape.id());
      trimPreviews();
   }

   private static void trimPreviews() {
      Minecraft minecraft = Minecraft.getInstance();
      synchronized (PREVIEWS) {
         Iterator<Map.Entry<String, PreviewTexture>> iterator = PREVIEWS.entrySet().iterator();
         while (PREVIEWS.size() > PREVIEW_LIMIT && iterator.hasNext()) {
            PreviewTexture removed = iterator.next().getValue();
            iterator.remove();
            minecraft.getTextureManager().release(removed.texture());
            minecraft.getTextureManager().release(removed.capeTexture());
         }
      }
   }

   public static Identifier selectedTexture() {
      LunarCape selected = LunarCapeRegistry.selected();
      if (selected == null) {
         return null;
      }
      if (active != null && active.capeId.equals(selected.id())) {
         return active.texture;
      }
      if (!selected.id().equals(loadingActiveId) && !selected.id().equals(failedActiveId)) {
         loadingActiveId = selected.id();
         ACTIVE_EXECUTOR.execute(() -> loadActive(selected));
      }
      return null;
   }

   private static void loadActive(LunarCape cape) {
      try {
         BufferedImage sheet = readImage(cape);
         FrameSpec spec = frameSpec(sheet, readMetadata(cape));
         Minecraft.getInstance().execute(() -> registerActive(cape, sheet, spec));
      } catch (Exception exception) {
         failedActiveId = cape.id();
         loadingActiveId = null;
         System.err.println("[Lin Client] Unable to load Lunar cape " + cape.displayName() + ": " + exception.getMessage());
      }
   }

   private static void registerActive(LunarCape cape, BufferedImage sheet, FrameSpec spec) {
      loadingActiveId = null;
      if (LunarCapeRegistry.selected() == null || !LunarCapeRegistry.selected().id().equals(cape.id())) {
         return;
      }
      releaseActive();
      int scale = frameScale(spec);
      int atlasWidth = Math.max(64, scale * 64);
      int atlasHeight = Math.max(32, scale * 32);
      NativeImage pixels = new NativeImage(atlasWidth, atlasHeight, true);
      writeFrame(pixels, sheet, spec, 0);
      Identifier texture = Identifier.fromNamespaceAndPath(LinFeatures.MOD_ID, "lunar_cape/selected_" + cape.id());
      DynamicTexture dynamicTexture = new DynamicTexture(() -> "Selected Lunar cape " + cape.id(), pixels);
      Minecraft.getInstance().getTextureManager().register(texture, dynamicTexture);
      active = new ActiveTexture(cape.id(), texture, dynamicTexture, pixels, sheet, spec);
   }

   public static void selectionChanged() {
      failedActiveId = null;
      loadingActiveId = null;
      Minecraft minecraft = Minecraft.getInstance();
      minecraft.execute(() -> {
         releaseActive();
         selectedTexture();
      });
   }

   public static void tick() {
      ActiveTexture current = active;
      LunarCape selected = LunarCapeRegistry.selected();
      if (current == null) {
         if (selected != null) {
            selectedTexture();
         }
         return;
      }
      if (selected == null || !current.capeId.equals(selected.id())) {
         releaseActive();
         return;
      }
      if (current.spec.frameCount <= 1) {
         return;
      }

      current.ticks++;
      if (current.ticks >= current.spec.frameTime) {
         current.ticks = 0;
         current.frame = (current.frame + 1) % current.spec.frameCount;
         writeFrame(current.pixels, current.sheet, current.spec, current.frame);
         current.dynamicTexture.upload();
      }
   }

   private static void releaseActive() {
      if (active != null) {
         Minecraft.getInstance().getTextureManager().release(active.texture);
         active = null;
      }
   }

   public static void close() {
      remoteTick(Set.of(),Set.of());
      Minecraft minecraft = Minecraft.getInstance();
      releaseActive();
      synchronized (PREVIEWS) {
         for (PreviewTexture preview : PREVIEWS.values()) {
            minecraft.getTextureManager().release(preview.texture());
            minecraft.getTextureManager().release(preview.capeTexture());
         }
         PREVIEWS.clear();
      }
      LOADING_PREVIEWS.clear();
      FAILED_PREVIEWS.clear();
      PREVIEW_FAILURE_COUNTS.clear();
   }

   private static BufferedImage readImage(LunarCape cape) throws IOException {
      BufferedImage image;
      if (cape.id().equals(LunarCapeRegistry.DEFAULT_ID)
         || LunarCapeRegistry.isOfficial(cape) || LunarCapeRegistry.isDungeon(cape)) {
         String resource = "/assets/lin_client/textures/" + cape.relativePath();
         try (InputStream input = LunarCapeTextureManager.class.getResourceAsStream(resource)) {
            if (input == null) {
               throw new IOException("Missing bundled cape " + resource);
            }
            image = ImageIO.read(input);
         }
      } else {
         Path texture = cape.custom() ? cape.customPath() : obtain(cape.relativePath(), cape.textureAsset());
         synchronized (WEBP_DECODE_LOCK) {
            image = ImageIO.read(texture.toFile());
         }
      }
      if (image == null) {
         throw new IOException("Image decoder rejected " + cape.relativePath());
      }
      return image;
   }

   private static CapeMetadata readMetadata(LunarCape cape) {
      try {
         JsonObject animation;
         if (cape.id().equals(LunarCapeRegistry.DEFAULT_ID)) {
            try (InputStream input = LunarCapeTextureManager.class.getResourceAsStream(
                  "/assets/lin_client/textures/" + cape.relativePath() + ".mcmeta")) {
               if (input == null) return CapeMetadata.DEFAULT;
               animation = JsonParser.parseReader(new java.io.InputStreamReader(input, StandardCharsets.UTF_8))
                  .getAsJsonObject().getAsJsonObject("animation");
            }
         } else {
            Path metadata = cape.custom()
               ? Path.of(cape.customPath().toString() + ".mcmeta")
               : obtain(cape.relativePath() + ".mcmeta", cape.metadataAsset());
            animation = JsonParser.parseString(Files.readString(metadata, StandardCharsets.UTF_8))
               .getAsJsonObject().getAsJsonObject("animation");
         }
         if (animation == null) {
            return CapeMetadata.DEFAULT;
         }
         int width = animation.has("width") ? animation.get("width").getAsInt() : 0;
         int height = animation.has("height") ? animation.get("height").getAsInt() : 0;
         int frameTime = animation.has("frametime") ? animation.get("frametime").getAsInt() : 2;
         return new CapeMetadata(width, height, Math.max(1, frameTime), true);
      } catch (Exception ignored) {
         return CapeMetadata.DEFAULT;
      }
   }

   private static BufferedImage readCachedPreview(LunarCape cape) {
      try {
         Path cached = previewCachePath(cape);
         if (!Files.isRegularFile(cached)) {
            return null;
         }
         BufferedImage image = ImageIO.read(cached.toFile());
         return image != null && image.getWidth() == PREVIEW_WIDTH && image.getHeight() == PREVIEW_HEIGHT ? image : null;
      } catch (Exception ignored) {
         return null;
      }
   }

   private static void writeCachedPreview(LunarCape cape, BufferedImage image) {
      try {
         Files.createDirectories(PREVIEW_CACHE);
         Path cached = previewCachePath(cape);
         Path staging = Files.createTempFile(PREVIEW_CACHE, "preview-", ".tmp");
         try {
            if (!ImageIO.write(image, "png", staging.toFile())) {
               throw new IOException("PNG encoder unavailable");
            }
            try {
               Files.move(staging, cached, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException ignored) {
               Files.move(staging, cached, StandardCopyOption.REPLACE_EXISTING);
            }
         } finally {
            Files.deleteIfExists(staging);
         }
      } catch (Exception ignored) {
      }
   }

   private static Path previewCachePath(LunarCape cape) throws IOException {
      String fingerprint;
      if (cape.textureAsset() != null) {
         fingerprint = cape.textureAsset().hash().substring(0, 16);
      } else if (LunarCapeRegistry.isOfficial(cape) || LunarCapeRegistry.isDungeon(cape)) {
         fingerprint = "bundled";
      } else if (cape.customPath() != null && Files.isRegularFile(cape.customPath())) {
         String state = cape.customPath().toAbsolutePath().normalize()
            + ":"
            + Files.size(cape.customPath())
            + ":"
            + Files.getLastModifiedTime(cape.customPath()).toMillis();
         fingerprint = sha1(state.getBytes(StandardCharsets.UTF_8)).substring(0, 16);
      } else {
         fingerprint = "unknown";
      }
      return PREVIEW_CACHE.resolve(cape.id() + "-" + fingerprint + ".png");
   }

   private static Path obtain(String relativePath, LunarCape.Asset asset) throws IOException {
      Path local = LOCAL_JIT.resolve(relativePath).normalize();
      if (asset!=null && local.startsWith(LOCAL_JIT) && dev.lin.client.cosmetics.assets.LunarAssetStore.validPinned(local,asset.hash(),asset.size())) {
         return local;
      }
      if (asset == null) {
         throw new IOException("Lunar JIT index has no entry for " + relativePath);
      }

      try {
         Files.createDirectories(CACHE);
      } catch (IOException exception) {
         throw new IOException("Unable to create cape cache", exception);
      }
      Path cached = CACHE.resolve(asset.hash());
      if (dev.lin.client.cosmetics.assets.LunarAssetStore.validPinned(cached,asset.hash(),asset.size())) {
         return cached;
      }

      Object lock = ASSET_LOCKS.computeIfAbsent(asset.hash(), ignored -> new Object());
      synchronized (lock) {
         if (dev.lin.client.cosmetics.assets.LunarAssetStore.validPinned(cached,asset.hash(),asset.size())) {
            return cached;
         }
         download(asset, cached);
         return cached;
      }
   }

   private static void download(LunarCape.Asset asset, Path target) throws IOException {
      HttpRequest request = HttpRequest.newBuilder(URI.create(CDN + asset.hash()))
         .timeout(Duration.ofSeconds(150))
         .header("User-Agent", "LinClient/1.0.0")
         .GET()
         .build();
      byte[] body;
      try {
         body=dev.lin.client.cosmetics.sync.CosmeticHttp.download(HTTP,request,asset.size());
      } catch (InterruptedException exception) {
         Thread.currentThread().interrupt();
         throw new IOException("Lunar cape download interrupted", exception);
      }
      if (asset.size() > 0L && body.length != asset.size()) {
         throw new IOException("Lunar cape size mismatch");
      }
      if (!sha1(body).equals(asset.hash())) {
         throw new IOException("Lunar cape SHA-1 mismatch");
      }

      Path staging = Files.createTempFile(CACHE, "cape-", ".tmp");
      try {
         Files.write(staging, body);
         try {
            Files.move(staging, target, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
         } catch (AtomicMoveNotSupportedException ignored) {
            Files.move(staging, target, StandardCopyOption.REPLACE_EXISTING);
         }
      } finally {
         Files.deleteIfExists(staging);
      }
   }

   private static String sha1(byte[] value) throws IOException {
      try {
         byte[] hash = MessageDigest.getInstance("SHA-1").digest(value);
         StringBuilder result = new StringBuilder(hash.length * 2);
         for (byte part : hash) {
            result.append(Character.forDigit(part >>> 4 & 15, 16));
            result.append(Character.forDigit(part & 15, 16));
         }
         return result.toString();
      } catch (NoSuchAlgorithmException exception) {
         throw new IOException("SHA-1 is unavailable", exception);
      }
   }

   private static FrameSpec frameSpec(BufferedImage image, CapeMetadata metadata) {
      int width = metadata.width > 0 ? Math.min(metadata.width, image.getWidth()) : image.getWidth();
      boolean fullAtlas = width % 64 == 0
         && (metadata.height > 0 ? metadata.height * 2 == width : image.getHeight() >= width / 2 && image.getHeight() % (width / 2) == 0);
      int inferredHeight = fullAtlas ? width / 2 : Math.max(1, Math.round(width * 17.0F / 22.0F));
      int height = metadata.height > 0 ? Math.min(metadata.height, image.getHeight()) : Math.min(inferredHeight, image.getHeight());
      int columns = Math.max(1, image.getWidth() / width);
      int rows = Math.max(1, image.getHeight() / height);
      int frameCount = metadata.animated ? columns * rows : 1;
      return new FrameSpec(width, height, columns, frameCount, metadata.frameTime, fullAtlas);
   }

   private static BufferedImage previewFrame(BufferedImage sheet, FrameSpec spec, int frame) {
      int column = frame % spec.columns;
      int row = frame / spec.columns;
      int scale = frameScale(spec);
      int x = column * spec.width + scale;
      int y = row * spec.height + scale;
      int width = Math.min(scale * 10, sheet.getWidth() - x);
      int height = Math.min(scale * 16, sheet.getHeight() - y);
      return sheet.getSubimage(x, y, width, height);
   }

   private static int frameScale(FrameSpec spec) {
      return spec.fullAtlas ? Math.max(1, spec.width / 64) : Math.max(1, Math.round(spec.width / 22.0F));
   }

   private static void writeFrame(NativeImage target, BufferedImage sheet, FrameSpec spec, int frame) {
      int column = frame % spec.columns;
      int row = frame / spec.columns;
      BufferedImage source = sheet.getSubimage(column * spec.width, row * spec.height, spec.width, spec.height);
      int width = Math.min(source.getWidth(), target.getWidth());
      int height = Math.min(source.getHeight(), target.getHeight());
      for (int y = 0; y < height; y++) {
         for (int x = 0; x < width; x++) {
            target.setPixelABGR(x, y, argbToAbgr(source.getRGB(x, y)));
         }
      }
   }

   private static NativeImage toNativeImage(BufferedImage image) {
      NativeImage result = new NativeImage(image.getWidth(), image.getHeight(), true);
      for (int y = 0; y < image.getHeight(); y++) {
         for (int x = 0; x < image.getWidth(); x++) {
            result.setPixelABGR(x, y, argbToAbgr(image.getRGB(x, y)));
         }
      }
      return result;
   }

   private static NativeImage toCapeAtlas(BufferedImage preview) {
      NativeImage atlas = new NativeImage(64, 32, true);
      for (int y = 0; y < 16; y++) {
         int sourceY = Math.min(preview.getHeight() - 1, Math.round((float)y * (preview.getHeight() - 1) / 15.0F));
         for (int x = 0; x < 10; x++) {
            int sourceX = Math.min(preview.getWidth() - 1, Math.round((float)x * (preview.getWidth() - 1) / 9.0F));
            int color = argbToAbgr(preview.getRGB(sourceX, sourceY));
            atlas.setPixelABGR(1 + x, 1 + y, color);
            atlas.setPixelABGR(12 + x, 1 + y, color);
         }
      }
      return atlas;
   }

   private static NativeImage toCapeAtlas(BufferedImage sheet, FrameSpec spec) {
      int scale = frameScale(spec);
      NativeImage atlas = new NativeImage(Math.max(64, scale * 64),
         Math.max(32, scale * 32), true);
      writeFrame(atlas, sheet, spec, 0);
      return atlas;
   }

   private static int argbToAbgr(int argb) {
      return argb & 0xFF00FF00 | (argb & 0xFF0000) >>> 16 | (argb & 0xFF) << 16;
   }

   public record PreviewTexture(Identifier texture, int width, int height, Identifier capeTexture) {
   }

   private record CapeMetadata(int width, int height, int frameTime, boolean animated) {
      private static final CapeMetadata DEFAULT = new CapeMetadata(0, 0, 2, false);
   }

   private record FrameSpec(int width, int height, int columns, int frameCount, int frameTime, boolean fullAtlas) {
   }

   private static final class ActiveTexture {
      private final String capeId;
      private final Identifier texture;
      private final DynamicTexture dynamicTexture;
      private final NativeImage pixels;
      private final BufferedImage sheet;
      private final FrameSpec spec;
      private int frame;
      private int ticks;

      private ActiveTexture(
         String capeId, Identifier texture, DynamicTexture dynamicTexture, NativeImage pixels, BufferedImage sheet, FrameSpec spec
      ) {
         this.capeId = capeId;
         this.texture = texture;
         this.dynamicTexture = dynamicTexture;
         this.pixels = pixels;
         this.sheet = sheet;
         this.spec = spec;
      }
   }
}
