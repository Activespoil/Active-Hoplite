package dev.lin.client.features.pet;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class LunarPetRegistry {
   private static final String CATALOG = "/assets/lin_client/lunar_pets.tsv";
   private static final String ASSET_CATALOG = "/assets/lin_client/lunar_pet_assets.tsv";
   private static volatile List<LunarPet> pets = List.of();
   private static volatile Map<String, LunarPet.Asset> assets = Map.of();
   private static volatile LunarPet selected;

   private LunarPetRegistry() {
   }

   public static synchronized void load() {
      Map<String, LunarPet.Asset> loadedAssets = loadAssets();
      List<LunarPet> loadedPets = new ArrayList<>();
      try (InputStream stream = LunarPetRegistry.class.getResourceAsStream(CATALOG)) {
         if (stream == null) {
            throw new IOException("lunar_pets.tsv is missing");
         }
         try (BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
               String[] columns = line.split("\\t", -1);
               if (columns.length < 5) {
                  continue;
               }
               String id = columns[0].trim();
               String name = columns[1].trim();
               String definitionPath = normalize(columns[2]);
               if (id.isEmpty() || name.isEmpty() || !safePetPath(definitionPath)) {
                  continue;
               }
               try {
                  LunarPet.Asset definition = new LunarPet.Asset(definitionPath, columns[3], Long.parseLong(columns[4]));
                  loadedPets.add(new LunarPet(id, name, definitionPath, definition));
                  loadedAssets.putIfAbsent(definitionPath, definition);
               } catch (NumberFormatException ignored) {
               }
            }
         }
      } catch (IOException exception) {
         System.err.println("[Lin Client] Unable to load Lunar pets: " + exception.getMessage());
      }
      pets = List.copyOf(loadedPets);
      assets = Map.copyOf(loadedAssets);
      if (selected != null) {
         select(selected.id());
      }
      System.out.println("[Lin Client] Loaded " + pets.size() + " Lunar shoulder pets");
   }

   private static Map<String, LunarPet.Asset> loadAssets() {
      Map<String, LunarPet.Asset> result = new HashMap<>();
      try (InputStream stream = LunarPetRegistry.class.getResourceAsStream(ASSET_CATALOG)) {
         if (stream == null) {
            return result;
         }
         try (BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
               String[] columns = line.split("\\t", -1);
               if (columns.length < 3) {
                  continue;
               }
               String path = normalize(columns[0]);
               if (!safePetPath(path)) {
                  continue;
               }
               try {
                  result.put(path, new LunarPet.Asset(path, columns[1], Long.parseLong(columns[2])));
               } catch (NumberFormatException ignored) {
               }
            }
         }
      } catch (IOException exception) {
         System.err.println("[Lin Client] Unable to load Lunar pet asset catalog: " + exception.getMessage());
      }
      return result;
   }

   public static List<LunarPet> values() {
      return pets;
   }

   public static LunarPet selected() {
      return selected;
   }

   public static String selectedId() {
      return selected == null ? "" : selected.id();
   }

   public static LunarPet.Asset asset(String relativePath) {
      return assets.get(normalize(relativePath));
   }

   public static synchronized void select(String id) {
      selected = null;
      if (id == null || id.isBlank()) {
         return;
      }
      for (LunarPet pet : pets) {
         if (pet.id().equals(id)) {
            selected = pet;
            return;
         }
      }
   }

   public static synchronized void clearSelection() {
      selected = null;
   }

   private static boolean safePetPath(String path) {
      return path.startsWith("cosmetics/models/gek/pets/") && !path.contains("..");
   }

   static String normalize(String value) {
      String normalized = value.replace('\\', '/').trim();
      if (normalized.startsWith("lunar-jit:")) {
         normalized = normalized.substring("lunar-jit:".length());
      } else if (normalized.startsWith("lunar:")) {
         normalized = normalized.substring("lunar:".length());
      }
      return normalized.replaceFirst("^/+", "");
   }
}
