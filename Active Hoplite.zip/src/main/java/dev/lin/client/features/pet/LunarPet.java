package dev.lin.client.features.pet;

public record LunarPet(String id, String displayName, String definitionPath, LunarPet.Asset definitionAsset) {
   public record Asset(String relativePath, String hash, long size) {
   }
}
