package dev.lin.client.features.mixin;

import dev.lin.client.cosmetics.emote.*;
import net.minecraft.client.renderer.entity.state.AvatarRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

@Mixin(AvatarRenderState.class)
public abstract class EmoteAvatarStateMixin implements EmoteRenderState {
    @Unique private EmoteRuntime.Sample linClient$emote;
    @Override public EmoteRuntime.Sample linEmoteSample() { return linClient$emote; }
    @Override public void linEmoteSample(EmoteRuntime.Sample sample) { linClient$emote = sample; }
}
