package dev.lin.client.features.ui;

import dev.lin.client.features.accessory.AccessoryDefinition;
import dev.lin.client.features.accessory.AccessoryRegistry;
import dev.lin.client.features.accessory.AccessorySlot;
import dev.lin.client.features.accessory.HeadwearVariant;
import dev.lin.client.features.artifact.ArtifactPackManager;
import dev.lin.client.features.artifact.ArtifactSkinConfig;
import dev.lin.client.features.artifact.ArtifactSkins;
import dev.lin.client.features.cape.LunarCape;
import dev.lin.client.features.cape.LunarCapeRegistry;
import dev.lin.client.features.cape.LunarCapeTextureManager;
import dev.lin.client.features.config.ClientAccessoryConfig;
import dev.lin.client.features.font.FontManager;
import dev.lin.client.features.pet.LunarPet;
import dev.lin.client.features.pet.LunarPetRegistry;
import dev.lin.client.features.pet.LunarPetTextureManager;
import dev.lin.client.features.render.AccessoryItemModels;
import dev.lin.client.features.render.AccessoryWorldRenderer;
import dev.lin.client.features.render.OpenGlUiRenderer;
import dev.lin.client.features.trim.LinTrimManager;
import dev.lin.client.features.trim.LinTrimPreview;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.renderer.entity.EntityRenderDispatcher;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.state.AvatarRenderState;
import net.minecraft.client.renderer.entity.state.EntityRenderState;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.core.ClientAsset;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.PlayerSkin;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ItemDisplayContext;
import org.joml.Matrix3x2fStack;
import org.joml.Quaternionf;
import org.joml.Vector3f;
import org.lwjgl.PointerBuffer;
import org.lwjgl.system.MemoryStack;
import org.lwjgl.util.tinyfd.TinyFileDialogs;

public final class AccessorySelectorScreen extends Screen {
   private static final int WIDTH = 960;
   private static final int HEIGHT = 540;
   private static final float MAX_UI_SCALE = 0.82F;
   private static final int PANEL_X = 5;
   private static final int PANEL_Y = 7;
   private static final int PANEL_W = 950;
   private static final int PANEL_H = 526;
   private static final int SIDEBAR_W = 188;
   private static final int CONTENT_X = 210;
   private static final int CONTENT_W = 493;
   private static final int PREVIEW_X = 716;
   private static final int PREVIEW_W = 239;
   private static final int SEARCH_X = 338;
   private static final int SEARCH_Y = 24;
   private static final int SEARCH_W = 246;
   private static final int SEARCH_H = 29;
   private static final int SEARCH_TEXT_X = 365;
   private static final int SEARCH_TEXT_W = 184;
   private static final int ACCESSORY_CARD_TOP = 68;
   private static final int ACCESSORY_CARD_W = 153;
   private static final int ACCESSORY_CARD_H = 140;
   private static final int ACCESSORY_CARD_PREVIEW_H = 112;
   private static final int ACCESSORY_COLUMN_GAP = 10;
   private static final int ACCESSORY_ROW_STEP = 146;
   private static final int ACCESSORY_COLUMNS = 3;
   private static final int ACCESSORY_VISIBLE_ROWS = 3;
   private static final int ACCESSORY_VIEW_BOTTOM = 506;
   private static final int ACCESSORY_SCROLL_X = 699;
   private static final int PREVIEW_DRAG_X = 720;
   private static final int PREVIEW_DRAG_Y = 96;
   private static final int PREVIEW_DRAG_W = 229;
   private static final int PREVIEW_DRAG_H = 354;
   private static final float PREVIEW_ROTATION_SENSITIVITY = 0.65F;
   private static final int SIDEBAR_ROW_X = 16;
   private static final int SIDEBAR_ROW_Y = 66;
   private static final int SIDEBAR_ROW_W = 170;
   private static final int SIDEBAR_ROW_H = 38;
   private static final int SIDEBAR_ROW_STEP = 44;
   private static final int PET_POSITION_Y = 99;
   private static final int PET_POSITION_LEFT_X = 722;
   private static final int PET_POSITION_RIGHT_X = 751;
   private static final int PET_POSITION_UP_X = 780;
   private static final int PET_POSITION_DOWN_X = 809;
   private static final int PET_POSITION_RESET_X = 840;
   private static final int PET_POSITION_BUTTON_SIZE = 27;
   private static final int ACCESSORY_CONTROL_Y = 99;
   private static final int ACCESSORY_CONTROL_BUTTON_SIZE = 27;
   private static final int HEADWEAR_VARIANT_X = 754;
   private static final int HEADWEAR_VARIANT_W = 160;
   private static final int WING_POSITION_UP_X = 723;
   private static final int WING_POSITION_DOWN_X = 754;
   private static final int WING_POSITION_RESET_X = 785;
   private static final int TRIM_VIEW_TOP = 68;
   private static final int TRIM_VIEW_BOTTOM = 506;
   private static final int TRIM_GAP = 7;
   private static final int PATTERN_H = 36;
   private static final int OPTION_H = 30;
   private static final int FOOTER_Y = 525;
   private static final int BACK_BUTTON_Y = 486;
   private static final int PREVIEW_ACTION_X = 727;
   private static final int PREVIEW_ACTION_Y = 477;
   private static final int PREVIEW_ACTION_W = 215;
   private static final int PREVIEW_ACTION_H = 32;
   private static final int FROSTED_BLUR_RADIUS = 10;
   private static final int TEXT_PRIMARY = 0xFFF5F6FA;
   private static final int TEXT_SECONDARY = 0xFFD0D3DC;
   private static final int TEXT_MUTED = 0xFF8C919E;
   private static final int ACCENT = 0xFF15F26E;
   private static final int ACCENT_TEXT = 0xFF65FF9E;
   private static final int GLASS_BORDER = 0x805A6270;
   private static final int GLASS_ROOT = 0xD20B0E16;
   private static final int GLASS_PANEL = 0xA5121620;
   private static final int GLASS_CARD = 0xB51A202B;
   private static final int GLASS_CARD_HOVER = 0xCE252C39;
   private static final int GLASS_SELECTED = 0xD5353D4B;
   private static final Identifier LUNAR_LOCKER_ICON = uiTexture("locker");
   private static final Identifier LUNAR_LOGO_ICON = uiTexture("logo");
   private static final Identifier LUNAR_SETTINGS_ICON = uiTexture("settings");
   private static final Identifier LUNAR_CLOSE_ICON = uiTexture("close");
   private static final Identifier LUNAR_SEARCH_ICON = uiTexture("search");
   private static final Identifier LUNAR_GRID_ICON = uiTexture("grid");
   private static final Identifier LUNAR_COMPACT_ICON = uiTexture("compact");
   private static final Identifier LUNAR_EYE_ICON = uiTexture("eye");
   private static final Identifier LUNAR_ADD_ICON = uiTexture("add");
   private static final Identifier LUNAR_RESET_POSITION_ICON = uiTexture("reset_position");
   private static final Identifier LUNAR_MANNEQUIN_SKIN = uiTexture("mannequin");
   private static final Identifier[] LUNAR_CATEGORY_ICONS = new Identifier[]{
      uiTexture("cloak"), uiTexture("headwear"), uiTexture("pet"), uiTexture("wings"), uiTexture("armor"), uiTexture("item")
   };
   private static final List<String> TRIM_PATTERNS;
   private final Screen parent;
   private final boolean linEmbedded;
   private AccessorySelectorScreen.SelectorPage activePage = AccessorySelectorScreen.SelectorPage.COSMETICS;
   private ArtifactSkins.Artifact selectedArtifact;
   private AccessorySelectorScreen.CosmeticPage activeCosmeticPage = AccessorySelectorScreen.CosmeticPage.CAPES;
   private int scrollRow;
   private int capeScrollRow;
   private int petScrollRow;
   private int trimScroll;
   private int artifactScrollRow;
   private boolean sortAscending = true;
   private int originX;
   private int originY;
   private float uiScale = 1.0F;
   private GlassSearchBox searchBox;
   private int previousBlurRadius = -1;
   private boolean capeImporting;
   private String capeImportStatus = "";
   private long capeImportStatusUntil;
   private boolean previewDragging;
   private double previewDragStartX;
   private float previewDragStartYaw;
   private float previewYaw;

   public AccessorySelectorScreen(Screen parent) {
      this(parent, -1);
   }

   public AccessorySelectorScreen(Screen parent, int initialSidebarIndex) {
      super(Component.literal("Lin Client"));
      this.parent = parent;
      this.linEmbedded = initialSidebarIndex >= 0;
      if (initialSidebarIndex == 1) {
         this.activePage = AccessorySelectorScreen.SelectorPage.HEADWEAR;
      } else if (initialSidebarIndex == 4) {
         this.activePage = AccessorySelectorScreen.SelectorPage.TRIMS;
      } else if (initialSidebarIndex == 5) {
         this.activePage = AccessorySelectorScreen.SelectorPage.ARTIFACTS;
      } else if (initialSidebarIndex == 3) {
         this.activePage = AccessorySelectorScreen.SelectorPage.WINGS;
      }
   }

   @Override
   protected void init() {
      String previousQuery = this.searchBox == null ? "" : this.searchBox.getValue();
      this.searchBox = new GlassSearchBox(this.font, 0, 0, 350, 27, Component.literal("搜索饰品"));
      this.searchBox.setMaxLength(80);
      this.searchBox.setResponder(value -> {
          this.scrollRow = 0;
          this.capeScrollRow = 0;
          this.petScrollRow = 0;
      });
      this.searchBox.setValue(previousQuery);
      this.addRenderableWidget(this.searchBox);
      this.updateLayout();
   }

   @Override
   public void added() {
      super.added();
      if (this.minecraft != null && this.previousBlurRadius < 0) {
         this.previousBlurRadius = this.minecraft.options.getMenuBackgroundBlurriness();
         this.minecraft.options.menuBackgroundBlurriness().set(10);
      }
   }

   @Override
   public void removed() {
      if (this.minecraft != null && this.previousBlurRadius >= 0) {
         this.minecraft.options.menuBackgroundBlurriness().set(this.previousBlurRadius);
         this.previousBlurRadius = -1;
      }

      super.removed();
   }

   @Override
   public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
      this.updateLayout();
      AccessoryWorldRenderer.beginPreviewFrame();
      graphics.blurBeforeThisStratum();
      int localMouseX = (int)Math.floor(this.toLocalX(mouseX));
      int localMouseY = (int)Math.floor(this.toLocalY(mouseY));
      Matrix3x2fStack pose = graphics.pose();
      pose.pushMatrix();

      try {
          pose.translate(this.originX, this.originY);
          pose.scale(this.uiScale, this.uiScale);
          this.drawSelector(graphics, localMouseX, localMouseY);
          if (this.activePage != AccessorySelectorScreen.SelectorPage.ARTIFACTS) {
             this.drawPreview(graphics, mouseX, mouseY);
          }
      } finally {
         pose.popMatrix();
      }

      super.render(graphics, mouseX, mouseY, partialTick);
   }

   @Override
   public void renderBackground(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
   }

   private void drawSelector(GuiGraphics graphics, int mouseX, int mouseY) {
      OpenGlUiRenderer.glassPanel(graphics, PANEL_X, PANEL_Y, PANEL_W, PANEL_H, 10.0F, GLASS_ROOT, GLASS_BORDER, 0xD0000000);
      OpenGlUiRenderer.roundedRect(graphics, PANEL_X + 1, PANEL_Y + 1, SIDEBAR_W, PANEL_H - 2, 9.0F, 0x9E0C1018);
      OpenGlUiRenderer.roundedRect(graphics, PANEL_X + SIDEBAR_W, PANEL_Y + 1, 1.0F, PANEL_H - 2, 0.0F, 0x70404856);
      OpenGlUiRenderer.roundedRect(graphics, PREVIEW_X - 7, PANEL_Y + 1, 1.0F, PANEL_H - 2, 0.0F, 0x70404856);
      OpenGlUiRenderer.roundedRect(graphics, PREVIEW_X, 59, PREVIEW_W - 8, 408, 4.0F, 0x64111620);
      OpenGlUiRenderer.roundedRect(graphics, PREVIEW_X, 59, PREVIEW_W - 8, 34, 4.0F, 0x741A202B);

      drawUiTexture(graphics, LUNAR_LOGO_ICON, 16, 23, 24, 24, 24, 24);
      OpenGlUiRenderer.text(graphics, "Lin Client", 44.0F, 25.0F, 13.5F, TEXT_PRIMARY);
      drawUiTexture(graphics, LUNAR_SETTINGS_ICON, 156, 26, 17, 17, 20, 20);
      OpenGlUiRenderer.text(graphics, "⋮", 179.0F, 23.0F, 15.0F, TEXT_SECONDARY);

      drawUiTexture(graphics, LUNAR_LOCKER_ICON, 720, 24, 20, 20, 28, 28);
      OpenGlUiRenderer.text(graphics, "YOUR LOADOUT", 746.0F, 25.0F, 11.0F, TEXT_PRIMARY);

      String outfitTitle = "本地装扮";
      float outfitTitleWidth = FontManager.width(outfitTitle, 9.5F);
      OpenGlUiRenderer.text(
         graphics,
         outfitTitle,
         PREVIEW_X + (PREVIEW_W - 8 - outfitTitleWidth) * 0.5F,
         70.0F,
         9.5F,
         TEXT_PRIMARY
      );

      boolean closeHovered = OpenGlUiRenderer.inside(mouseX, mouseY, 927, 20, 22, 22);
      if (closeHovered) {
         OpenGlUiRenderer.roundedRect(graphics, 927.0F, 20.0F, 22.0F, 22.0F, 5.0F, GLASS_CARD_HOVER);
      }
      drawUiTexture(graphics, LUNAR_CLOSE_ICON, 931, 24, 14, 14, 17, 17);
      this.drawSidebar(graphics, mouseX, mouseY);
      if (this.activePage == AccessorySelectorScreen.SelectorPage.TRIMS) {
         this.drawTrimSelector(graphics, mouseX, mouseY);
       } else if (this.activePage == AccessorySelectorScreen.SelectorPage.ARTIFACTS) {
          this.drawArtifactSelector(graphics, mouseX, mouseY);
       } else if (this.activePage == AccessorySelectorScreen.SelectorPage.COSMETICS) {
          this.drawCosmeticsSelector(graphics, mouseX, mouseY);
       } else {
          this.drawAccessorySelector(graphics, mouseX, mouseY);
       }
    }

   private void drawCosmeticsSelector(GuiGraphics graphics, int mouseX, int mouseY) {
      if (this.activeCosmeticPage == AccessorySelectorScreen.CosmeticPage.CAPES) {
         this.drawCapeSelector(graphics, mouseX, mouseY);
         return;
      }
      if (this.activeCosmeticPage == AccessorySelectorScreen.CosmeticPage.PETS) {
         this.drawPetSelector(graphics, mouseX, mouseY);
         return;
      }

      this.activeCosmeticPage = AccessorySelectorScreen.CosmeticPage.CAPES;
      this.drawCapeSelector(graphics, mouseX, mouseY);
   }

   private void drawCapeSelector(GuiGraphics graphics, int mouseX, int mouseY) {
      List<LunarCape> values = this.filteredCapes();
      this.drawSearchBox(graphics, mouseX, mouseY);
      this.drawCapeStyleToggle(graphics, mouseX, mouseY);
      int first = this.capeScrollRow * ACCESSORY_COLUMNS;
      int itemCount = values.size() + 1;
      int last = Math.min(itemCount, first + ACCESSORY_COLUMNS * ACCESSORY_VISIBLE_ROWS);

      for (int slot = first; slot < last; slot++) {
         int relative = slot - first;
         int cardX = CONTENT_X + relative % ACCESSORY_COLUMNS * (ACCESSORY_CARD_W + ACCESSORY_COLUMN_GAP);
         int cardY = ACCESSORY_CARD_TOP + relative / ACCESSORY_COLUMNS * ACCESSORY_ROW_STEP;
         if (slot == 0) {
            this.drawAddCapeCard(graphics, mouseX, mouseY, cardX, cardY);
         } else {
            this.drawCapeCard(graphics, mouseX, mouseY, values.get(slot - 1), cardX, cardY);
         }
      }

      if (!this.capeImportStatus.isEmpty() && System.currentTimeMillis() < this.capeImportStatusUntil) {
         OpenGlUiRenderer.text(graphics, truncate(this.capeImportStatus, 7.0F, 205.0F), 536.0F, 39.0F, 7.0F, TEXT_SECONDARY);
      }

      this.drawCapeScrollbar(graphics, itemCount);
   }

   private void drawAddCapeCard(GuiGraphics graphics, int mouseX, int mouseY, int x, int y) {
      boolean hovered = OpenGlUiRenderer.inside(mouseX, mouseY, x, y, ACCESSORY_CARD_W, ACCESSORY_CARD_H);
      OpenGlUiRenderer.roundedPanel(
         graphics,
         x,
         y,
         ACCESSORY_CARD_W,
         ACCESSORY_CARD_PREVIEW_H,
         6.0F,
         hovered ? GLASS_CARD_HOVER : GLASS_CARD,
         hovered ? 0xB8848C9A : GLASS_BORDER,
         1.0F
      );
      int color = hovered ? TEXT_PRIMARY : TEXT_SECONDARY;
      if (this.capeImporting) {
         String loading = "...";
         float width = FontManager.width(loading, 13.0F);
         OpenGlUiRenderer.text(graphics, loading, x + (ACCESSORY_CARD_W - width) * 0.5F, y + 47.0F, 13.0F, color);
      } else {
         drawUiTexture(graphics, LUNAR_ADD_ICON, x + 64, y + 43, 25, 25, 16, 16);
      }
      String label = "自定义";
      float labelWidth = FontManager.width(label, 8.5F);
      OpenGlUiRenderer.text(graphics, label, x + (ACCESSORY_CARD_W - labelWidth) * 0.5F, y + 119.0F, 8.5F, TEXT_SECONDARY);
   }

   private void drawCapeStyleToggle(GuiGraphics graphics, int mouseX, int mouseY) {
      int x = 826;
      int y = 99;
      int width = 112;
      int height = 27;
      boolean hovered = OpenGlUiRenderer.inside(mouseX, mouseY, x, y, width, height);
      OpenGlUiRenderer.roundedPanel(
         graphics, x, y, width, height, 6.0F, hovered ? GLASS_CARD_HOVER : GLASS_CARD, hovered ? -1194141486 : GLASS_BORDER, 1.0F
      );
      drawUiTexture(graphics, LUNAR_COMPACT_ICON, x + 8, y + 6, 15, 15, 24, 24);
      String label = ClientAccessoryConfig.capePreviewAngled ? "侧向展示" : "正面展示";
      OpenGlUiRenderer.text(graphics, label, x + 27.0F, y + 9.0F, 8.0F, hovered ? TEXT_PRIMARY : TEXT_SECONDARY);
   }

   private void drawCapeCard(GuiGraphics graphics, int mouseX, int mouseY, LunarCape cape, int x, int y) {
      boolean selected = cape.id().equals(LunarCapeRegistry.selectedId());
      boolean hovered = OpenGlUiRenderer.inside(mouseX, mouseY, x, y, ACCESSORY_CARD_W, ACCESSORY_CARD_H);
      OpenGlUiRenderer.roundedPanel(
         graphics,
         x,
         y,
         ACCESSORY_CARD_W,
         ACCESSORY_CARD_PREVIEW_H,
         6.0F,
         selected ? GLASS_SELECTED : (hovered ? GLASS_CARD_HOVER : GLASS_CARD),
         selected ? 0xFF99A3B3 : (hovered ? 0xB8848C9A : GLASS_BORDER),
         selected ? 1.4F : 1.0F
      );
      LunarCapeTextureManager.PreviewTexture preview = LunarCapeTextureManager.preview(cape);
      if (preview == null) {
         this.drawMannequinPlaceholder(graphics, x, y);
      } else {
         this.renderCapeMannequin(graphics, x, y, preview);
      }
      String name = truncate(cape.displayName(), 8.5F, ACCESSORY_CARD_W - 18.0F);
      float nameWidth = FontManager.width(name, 8.5F);
      OpenGlUiRenderer.text(graphics, name, x + (ACCESSORY_CARD_W - nameWidth) * 0.5F, y + 119.0F, 8.5F, selected ? TEXT_PRIMARY : TEXT_SECONDARY);
      OpenGlUiRenderer.roundedRect(graphics, x + ACCESSORY_CARD_W - 10, y + 122, 6.0F, 6.0F, 3.0F, selected ? ACCENT : 0xFF3F444E);
   }

   private void drawMannequinPlaceholder(GuiGraphics graphics, int x, int y) {
      int centerX = x + ACCESSORY_CARD_W / 2;
      OpenGlUiRenderer.roundedRect(graphics, centerX - 13, y + 18, 26, 28, 3.0F, 0xFF7B8089);
      OpenGlUiRenderer.roundedRect(graphics, centerX - 20, y + 46, 40, 40, 3.0F, 0xFF696F79);
      OpenGlUiRenderer.roundedRect(graphics, centerX - 19, y + 86, 17, 24, 2.0F, 0xFF5D636D);
      OpenGlUiRenderer.roundedRect(graphics, centerX + 2, y + 86, 17, 24, 2.0F, 0xFF626873);
      OpenGlUiRenderer.icon(graphics, centerX, y + 64, 25.0F, TEXT_MUTED, OpenGlUiRenderer.UiIcon.CAPE);
   }

   private void renderCapeMannequin(
      GuiGraphics graphics, int x, int y, LunarCapeTextureManager.PreviewTexture preview
   ) {
      if (this.minecraft == null || this.minecraft.player == null) {
         this.drawMannequinPlaceholder(graphics, x, y);
         return;
      }

      EntityRenderDispatcher dispatcher = this.minecraft.getEntityRenderDispatcher();
      EntityRenderer<? super LivingEntity, ?> renderer = dispatcher.getRenderer(this.minecraft.player);
      EntityRenderState renderState = renderer.createRenderState(this.minecraft.player, 1.0F);
      renderState.lightCoords = 15728880;
      renderState.shadowPieces.clear();
      renderState.outlineColor = 0;
      if (renderState instanceof AvatarRenderState avatarState) {
         ClientAsset.ResourceTexture body = new ClientAsset.ResourceTexture(LUNAR_MANNEQUIN_SKIN, LUNAR_MANNEQUIN_SKIN);
         ClientAsset.ResourceTexture cape = new ClientAsset.ResourceTexture(preview.capeTexture(), preview.capeTexture());
         PlayerSkin original = avatarState.skin;
         avatarState.skin = new PlayerSkin(body, cape, cape, original.model(), false);
         avatarState.id = Integer.MIN_VALUE + x + y;
         avatarState.showCape = true;
         avatarState.capeFlap = 0.0F;
         avatarState.capeLean = 0.0F;
         avatarState.capeLean2 = 0.0F;
         avatarState.headItem.clear();
         avatarState.rightHandItemState.clear();
         avatarState.leftHandItemState.clear();
         avatarState.rightHandItemStack = ItemStack.EMPTY;
         avatarState.leftHandItemStack = ItemStack.EMPTY;
         avatarState.headEquipment = ItemStack.EMPTY;
         avatarState.chestEquipment = ItemStack.EMPTY;
         avatarState.legsEquipment = ItemStack.EMPTY;
         avatarState.feetEquipment = ItemStack.EMPTY;
      }
      if (renderState instanceof LivingEntityRenderState livingState) {
         livingState.bodyRot = ClientAccessoryConfig.capePreviewAngled ? 20.0F : 0.0F;
         livingState.yRot = 0.0F;
         livingState.xRot = 0.0F;
         livingState.walkAnimationPos = 0.0F;
         livingState.walkAnimationSpeed = 0.0F;
         livingState.boundingBoxWidth /= livingState.scale;
         livingState.boundingBoxHeight /= livingState.scale;
         livingState.scale = 1.0F;
      }

      int left = this.toScreenX(x + 2);
      int top = this.toScreenY(y + 2);
      int right = this.toScreenX(x + ACCESSORY_CARD_W - 2);
      int bottom = this.toScreenY(y + ACCESSORY_CARD_PREVIEW_H - 2);
      int scale = Math.max(1, Math.round(43.0F * this.uiScale));
      Quaternionf cameraRotation = new Quaternionf();
      Quaternionf orientation = new Quaternionf().rotateZ((float)Math.PI);
      Vector3f center = new Vector3f(0.0F, renderState.boundingBoxHeight / 2.0F - 0.08F, 0.0F);
      graphics.submitEntityRenderState(renderState, scale, center, orientation, cameraRotation, left, top, right, bottom);
   }

   private void drawCapeScrollbar(GuiGraphics graphics, int itemCount) {
      int rowCount = rows(itemCount, ACCESSORY_COLUMNS);
      int max = capeMaxScroll(itemCount);
      if (rowCount > 0 && max > 0) {
         int trackHeight = ACCESSORY_VIEW_BOTTOM - ACCESSORY_CARD_TOP;
         OpenGlUiRenderer.roundedRect(graphics, ACCESSORY_SCROLL_X, ACCESSORY_CARD_TOP, 3.0F, trackHeight, 1.5F, 0xFF252932);
         int thumbHeight = Math.min(trackHeight, Math.max(27, trackHeight * ACCESSORY_VISIBLE_ROWS / rowCount));
         int thumbY = ACCESSORY_CARD_TOP + Math.round((trackHeight - thumbHeight) * ((float)this.capeScrollRow / max));
         OpenGlUiRenderer.roundedRect(graphics, ACCESSORY_SCROLL_X, thumbY, 3.0F, thumbHeight, 1.5F, 0xFF59606C);
      }
   }

   private void drawPetSelector(GuiGraphics graphics, int mouseX, int mouseY) {
      List<LunarPet> values = this.filteredPets();
      this.drawSearchBox(graphics, mouseX, mouseY);
      this.drawPetPositionControls(graphics, mouseX, mouseY);
      int first = this.petScrollRow * ACCESSORY_COLUMNS;
      int last = Math.min(values.size(), first + ACCESSORY_COLUMNS * ACCESSORY_VISIBLE_ROWS);
      for (int index = first; index < last; index++) {
         int relative = index - first;
         int cardX = CONTENT_X + relative % ACCESSORY_COLUMNS * (ACCESSORY_CARD_W + ACCESSORY_COLUMN_GAP);
         int cardY = ACCESSORY_CARD_TOP + relative / ACCESSORY_COLUMNS * ACCESSORY_ROW_STEP;
         this.drawPetCard(graphics, mouseX, mouseY, values.get(index), cardX, cardY);
      }
      this.drawPetScrollbar(graphics, values.size());
   }

   private void drawPetPositionControls(GuiGraphics graphics, int mouseX, int mouseY) {
      this.drawPetPositionButton(graphics, mouseX, mouseY, PET_POSITION_LEFT_X, OpenGlUiRenderer.UiIcon.ARROW_LEFT);
      this.drawPetPositionButton(graphics, mouseX, mouseY, PET_POSITION_RIGHT_X, OpenGlUiRenderer.UiIcon.ARROW_RIGHT);
      this.drawPetPositionButton(graphics, mouseX, mouseY, PET_POSITION_UP_X, OpenGlUiRenderer.UiIcon.ARROW_UP);
      this.drawPetPositionButton(graphics, mouseX, mouseY, PET_POSITION_DOWN_X, OpenGlUiRenderer.UiIcon.ARROW_DOWN);

      boolean resetHovered = OpenGlUiRenderer.inside(mouseX, mouseY, PET_POSITION_RESET_X, PET_POSITION_Y, 50, PET_POSITION_BUTTON_SIZE);
      OpenGlUiRenderer.roundedPanel(
         graphics,
         PET_POSITION_RESET_X,
         PET_POSITION_Y,
         50.0F,
         PET_POSITION_BUTTON_SIZE,
         6.0F,
         resetHovered ? GLASS_CARD_HOVER : GLASS_CARD,
         resetHovered ? -1194141486 : GLASS_BORDER,
         1.0F
      );
      OpenGlUiRenderer.icon(
         graphics,
         PET_POSITION_RESET_X + 12.0F,
         PET_POSITION_Y + 13.5F,
         13.0F,
         resetHovered ? TEXT_PRIMARY : TEXT_SECONDARY,
         OpenGlUiRenderer.UiIcon.RESET
      );
      OpenGlUiRenderer.text(
         graphics,
         "重置",
         PET_POSITION_RESET_X + 22.0F,
         PET_POSITION_Y + 9.0F,
         8.0F,
         resetHovered ? TEXT_PRIMARY : TEXT_SECONDARY
      );

      String offsets = String.format(Locale.ROOT, "X %+.2f  Y %+.2f", ClientAccessoryConfig.petOffsetX, ClientAccessoryConfig.petOffsetY);
      OpenGlUiRenderer.textRegular(graphics, offsets, PREVIEW_X + 8.0F, 132.0F, 6.5F, TEXT_MUTED);
   }

   private void drawPetPositionButton(
      GuiGraphics graphics, int mouseX, int mouseY, int x, OpenGlUiRenderer.UiIcon icon
   ) {
      boolean hovered = OpenGlUiRenderer.inside(mouseX, mouseY, x, PET_POSITION_Y, PET_POSITION_BUTTON_SIZE, PET_POSITION_BUTTON_SIZE);
      OpenGlUiRenderer.roundedPanel(
         graphics,
         x,
         PET_POSITION_Y,
         PET_POSITION_BUTTON_SIZE,
         PET_POSITION_BUTTON_SIZE,
         6.0F,
         hovered ? GLASS_CARD_HOVER : GLASS_CARD,
         hovered ? -1194141486 : GLASS_BORDER,
         1.0F
      );
      OpenGlUiRenderer.icon(
         graphics,
         x + PET_POSITION_BUTTON_SIZE * 0.5F,
         PET_POSITION_Y + PET_POSITION_BUTTON_SIZE * 0.5F,
         14.0F,
         hovered ? TEXT_PRIMARY : TEXT_SECONDARY,
         icon
      );
   }

   private void drawPetCard(GuiGraphics graphics, int mouseX, int mouseY, LunarPet pet, int x, int y) {
      boolean selected = pet.id().equals(LunarPetRegistry.selectedId());
      boolean hovered = OpenGlUiRenderer.inside(mouseX, mouseY, x, y, ACCESSORY_CARD_W, ACCESSORY_CARD_H);
      OpenGlUiRenderer.roundedPanel(
         graphics,
         x,
         y,
         ACCESSORY_CARD_W,
         ACCESSORY_CARD_PREVIEW_H,
         6.0F,
         selected ? GLASS_SELECTED : (hovered ? GLASS_CARD_HOVER : GLASS_CARD),
         selected ? 0xFF99A3B3 : (hovered ? 0xB8848C9A : GLASS_BORDER),
         selected ? 1.4F : 1.0F
      );
      LunarPetTextureManager.RenderData renderData = LunarPetTextureManager.uiRenderData(pet);
      if (renderData == null) {
         OpenGlUiRenderer.icon(
            graphics, x + ACCESSORY_CARD_W * 0.5F, y + 56.0F, 36.0F, selected || hovered ? TEXT_PRIMARY : TEXT_SECONDARY, OpenGlUiRenderer.UiIcon.PET
         );
      } else {
         OpenGlUiRenderer.petModel(graphics, renderData, x + ACCESSORY_CARD_W * 0.5F, y + 57.0F, 92.0F);
      }
      String label = truncate(pet.displayName(), 8.5F, ACCESSORY_CARD_W - 18.0F);
      float labelWidth = FontManager.width(label, 8.5F);
      OpenGlUiRenderer.text(graphics, label, x + (ACCESSORY_CARD_W - labelWidth) * 0.5F, y + 119.0F, 8.5F, selected ? TEXT_PRIMARY : TEXT_SECONDARY);
      OpenGlUiRenderer.roundedRect(graphics, x + ACCESSORY_CARD_W - 10, y + 122, 6.0F, 6.0F, 3.0F, selected ? ACCENT : 0xFF3F444E);
   }

   private void drawPetScrollbar(GuiGraphics graphics, int itemCount) {
      int rowCount = rows(itemCount, ACCESSORY_COLUMNS);
      int max = capeMaxScroll(itemCount);
      if (rowCount > 0 && max > 0) {
         int trackHeight = ACCESSORY_VIEW_BOTTOM - ACCESSORY_CARD_TOP;
         OpenGlUiRenderer.roundedRect(graphics, ACCESSORY_SCROLL_X, ACCESSORY_CARD_TOP, 3.0F, trackHeight, 1.5F, 0xFF252932);
         int thumbHeight = Math.min(trackHeight, Math.max(27, trackHeight * ACCESSORY_VISIBLE_ROWS / rowCount));
         int thumbY = ACCESSORY_CARD_TOP + Math.round((trackHeight - thumbHeight) * ((float)this.petScrollRow / max));
         OpenGlUiRenderer.roundedRect(graphics, ACCESSORY_SCROLL_X, thumbY, 3.0F, thumbHeight, 1.5F, 0xFF59606C);
      }
   }

   private void drawAccessorySelector(GuiGraphics graphics, int mouseX, int mouseY) {
      AccessorySlot slot = this.activePage.slot;
      List<AccessoryDefinition> values = this.filteredAccessories(slot);
      this.drawSearchBox(graphics, mouseX, mouseY);
      int first = this.scrollRow * ACCESSORY_COLUMNS;
      int last = Math.min(values.size(), first + ACCESSORY_COLUMNS * ACCESSORY_VISIBLE_ROWS);

      for (int index = first; index < last; index++) {
         AccessoryDefinition definition = values.get(index);
         int relative = index - first;
         int row = relative / ACCESSORY_COLUMNS;
         int column = relative % ACCESSORY_COLUMNS;
         int cardX = CONTENT_X + column * (ACCESSORY_CARD_W + ACCESSORY_COLUMN_GAP);
         int currentY = ACCESSORY_CARD_TOP + row * ACCESSORY_ROW_STEP;
         boolean selected = definition.id().equals(AccessoryRegistry.selectedId(slot));
         boolean hovered = OpenGlUiRenderer.inside(mouseX, mouseY, cardX, currentY, ACCESSORY_CARD_W, ACCESSORY_CARD_H);
         int cardColor = selected ? GLASS_SELECTED : (hovered ? GLASS_CARD_HOVER : GLASS_CARD);
         OpenGlUiRenderer.roundedPanel(
            graphics,
            cardX,
            currentY,
            ACCESSORY_CARD_W,
            ACCESSORY_CARD_PREVIEW_H,
            6.0F,
            cardColor,
            selected ? 0xFF99A3B3 : (hovered ? 0xB8848C9A : GLASS_BORDER),
            selected ? 1.4F : 1.0F
         );
         this.renderAccessoryMannequin(graphics, cardX, currentY, definition, slot);
         String name = truncate(definition.displayName(), 8.5F, ACCESSORY_CARD_W - 18.0F);
         float nameWidth = FontManager.width(name, 8.5F);
         OpenGlUiRenderer.text(
            graphics,
            name,
            cardX + (ACCESSORY_CARD_W - nameWidth) * 0.5F,
            currentY + 119.0F,
            8.5F,
            selected ? TEXT_PRIMARY : TEXT_SECONDARY
         );
         OpenGlUiRenderer.roundedRect(graphics, cardX + ACCESSORY_CARD_W - 10, currentY + 122, 6.0F, 6.0F, 3.0F, selected ? ACCENT : 0xFF3F444E);
      }

      if (values.isEmpty()) {
         String emptyText = "没有找到饰品";
         float emptyWidth = FontManager.width(emptyText, 9.0F);
         OpenGlUiRenderer.text(graphics, emptyText, CONTENT_X + (396.0F - emptyWidth) * 0.5F, 264.0F, 9.0F, TEXT_MUTED);
      }

      this.drawAccessoryScrollbar(graphics, values.size());
   }

   private void renderAccessoryMannequin(
      GuiGraphics graphics, int x, int y, AccessoryDefinition definition, AccessorySlot slot
   ) {
      if (this.minecraft == null || this.minecraft.player == null) {
         int iconSize = 72;
         drawIcon(graphics, definition, x + (ACCESSORY_CARD_W - iconSize) / 2, y + 17, iconSize);
         return;
      }

      EntityRenderDispatcher dispatcher = this.minecraft.getEntityRenderDispatcher();
      EntityRenderer<? super LivingEntity, ?> renderer = dispatcher.getRenderer(this.minecraft.player);
      EntityRenderState renderState = renderer.createRenderState(this.minecraft.player, 1.0F);
      renderState.lightCoords = 15728880;
      renderState.shadowPieces.clear();
      renderState.outlineColor = 0;
      int previewId = -1_000_000 - x * 1000 - y;
      if (renderState instanceof AvatarRenderState avatarState) {
         ClientAsset.ResourceTexture body = new ClientAsset.ResourceTexture(LUNAR_MANNEQUIN_SKIN, LUNAR_MANNEQUIN_SKIN);
         PlayerSkin original = avatarState.skin;
         avatarState.skin = new PlayerSkin(body, null, null, original.model(), false);
         avatarState.id = previewId;
         avatarState.showCape = false;
         avatarState.headItem.clear();
         avatarState.rightHandItemState.clear();
         avatarState.leftHandItemState.clear();
         avatarState.rightHandItemStack = ItemStack.EMPTY;
         avatarState.leftHandItemStack = ItemStack.EMPTY;
         avatarState.headEquipment = ItemStack.EMPTY;
         avatarState.chestEquipment = ItemStack.EMPTY;
         avatarState.legsEquipment = ItemStack.EMPTY;
         avatarState.feetEquipment = ItemStack.EMPTY;
         if (slot == AccessorySlot.HEADWEAR) {
            this.minecraft
               .getItemModelResolver()
               .updateForLiving(avatarState.headItem, AccessoryItemModels.stack(definition), ItemDisplayContext.HEAD, this.minecraft.player);
         } else if (slot == AccessorySlot.WINGS) {
            AccessoryWorldRenderer.registerPreviewWing(previewId, definition);
         }
      }
      if (renderState instanceof LivingEntityRenderState livingState) {
         livingState.bodyRot = slot == AccessorySlot.WINGS ? 0.0F : 180.0F;
         livingState.yRot = 0.0F;
         livingState.xRot = 0.0F;
         livingState.walkAnimationPos = 0.0F;
         livingState.walkAnimationSpeed = 0.0F;
         livingState.boundingBoxWidth /= livingState.scale;
         livingState.boundingBoxHeight /= livingState.scale;
         livingState.scale = 1.0F;
      }

      int left = this.toScreenX(x + 2);
      int top = this.toScreenY(y + 2);
      int right = this.toScreenX(x + ACCESSORY_CARD_W - 2);
      int bottom = this.toScreenY(y + ACCESSORY_CARD_PREVIEW_H - 2);
      float mannequinScale = slot == AccessorySlot.WINGS ? 36.0F : 42.0F;
      int scale = Math.max(1, Math.round(mannequinScale * this.uiScale));
      Quaternionf orientation = new Quaternionf().rotateZ((float)Math.PI);
      Vector3f center = new Vector3f(0.0F, renderState.boundingBoxHeight / 2.0F - 0.08F, 0.0F);
      graphics.submitEntityRenderState(renderState, scale, center, orientation, new Quaternionf(), left, top, right, bottom);
   }

   private void drawArtifactSelector(GuiGraphics graphics, int mouseX, int mouseY) {
      drawUiTexture(graphics, LUNAR_CATEGORY_ICONS[5], CONTENT_X, 29, 18, 18, 40, 40);
      OpenGlUiRenderer.text(graphics, "神器皮肤", CONTENT_X + 23.0F, 29.0F, 9.5F, TEXT_PRIMARY);
      this.drawArtifactToggle(graphics, mouseX, mouseY, 514, 24, 84, "启用皮肤", ArtifactSkinConfig.enabled);
      this.drawArtifactToggle(graphics, mouseX, mouseY, 605, 24, 93, "仅自己", ArtifactSkinConfig.onlySelf);
      ArtifactSkins.Artifact[] artifacts = ArtifactSkins.Artifact.values();
      if (this.selectedArtifact == null && artifacts.length > 0) {
         this.selectedArtifact = artifacts[0];
      }
      int first = this.artifactScrollRow * ACCESSORY_COLUMNS;
      int last = Math.min(artifacts.length, first + ACCESSORY_COLUMNS * ACCESSORY_VISIBLE_ROWS);
      graphics.enableScissor(CONTENT_X - 4, ACCESSORY_CARD_TOP, CONTENT_X + CONTENT_W, ACCESSORY_VIEW_BOTTOM);

      try {
         for (int index = first; index < last; index++) {
            int relative = index - first;
            int cardX = CONTENT_X + relative % ACCESSORY_COLUMNS * (ACCESSORY_CARD_W + ACCESSORY_COLUMN_GAP);
            int cardY = ACCESSORY_CARD_TOP + relative / ACCESSORY_COLUMNS * ACCESSORY_ROW_STEP;
            this.drawArtifactListCard(graphics, mouseX, mouseY, artifacts[index], cardX, cardY);
         }
      } finally {
         graphics.disableScissor();
      }

      this.drawArtifactScrollbar(graphics, artifacts.length);
      this.drawArtifactDetails(graphics, mouseX, mouseY);
   }

   private void drawArtifactToggle(
      GuiGraphics graphics, int mouseX, int mouseY, int x, int y, int width, String label, boolean enabled
   ) {
      boolean hovered = OpenGlUiRenderer.inside(mouseX, mouseY, x, y, width, 29);
      int fill = enabled ? GLASS_SELECTED : (hovered ? GLASS_CARD_HOVER : GLASS_CARD);
      int border = enabled ? -1603280700 : (hovered ? -1194141486 : 855638015);
      OpenGlUiRenderer.roundedPanel(graphics, x, y, width, 29, 8.0F, fill, border, 1.0F);
      OpenGlUiRenderer.text(graphics, label, x + 10, y + 10, 7.0F, enabled ? TEXT_PRIMARY : TEXT_SECONDARY);
      OpenGlUiRenderer.roundedRect(graphics, x + width - 15, y + 11, 7.0F, 7.0F, 3.5F, enabled ? ACCENT : -665270405);
   }

   private void drawArtifactListCard(
      GuiGraphics graphics, int mouseX, int mouseY, ArtifactSkins.Artifact artifact, int x, int y
   ) {
      boolean focused = artifact == this.selectedArtifact;
      boolean enabled = ArtifactSkinConfig.enabled && ArtifactSkinConfig.isArtifactEnabled(artifact.id());
      boolean hovered = this.isInsideArtifactViewport(mouseX, mouseY)
         && OpenGlUiRenderer.inside(mouseX, mouseY, x, y, ACCESSORY_CARD_W, ACCESSORY_CARD_H);
      int fill = focused ? GLASS_SELECTED : (hovered ? GLASS_CARD_HOVER : GLASS_CARD);
      int border = focused ? 0xFF99A3B3 : (hovered ? 0xB8848C9A : GLASS_BORDER);
      OpenGlUiRenderer.roundedPanel(
         graphics, x, y, ACCESSORY_CARD_W, ACCESSORY_CARD_PREVIEW_H, 6.0F, fill, border, focused ? 1.4F : 1.0F
      );
      int iconSize = 76;
      drawArtifactIcon(graphics, ArtifactSkins.selected(artifact), x + (ACCESSORY_CARD_W - iconSize) / 2, y + 18, iconSize);
      String name = truncate(artifact.displayName(), 8.5F, ACCESSORY_CARD_W - 18.0F);
      float nameWidth = FontManager.width(name, 8.5F);
      OpenGlUiRenderer.text(
         graphics, name, x + (ACCESSORY_CARD_W - nameWidth) * 0.5F, y + 119.0F, 8.5F, focused ? TEXT_PRIMARY : TEXT_SECONDARY
      );
      OpenGlUiRenderer.roundedRect(graphics, x + ACCESSORY_CARD_W - 10, y + 122, 6.0F, 6.0F, 3.0F, enabled ? ACCENT : 0xFF3F444E);
   }

   private void drawArtifactScrollbar(GuiGraphics graphics, int artifactCount) {
      int max = artifactMaxScroll(artifactCount);
      if (max <= 0) {
         return;
      }

      int trackY = ACCESSORY_CARD_TOP + 4;
      int trackH = ACCESSORY_VIEW_BOTTOM - ACCESSORY_CARD_TOP - 8;
      int totalRows = rows(artifactCount, ACCESSORY_COLUMNS);
      int thumbH = Math.max(34, trackH * ACCESSORY_VISIBLE_ROWS / totalRows);
      int thumbY = trackY + Math.round((trackH - thumbH) * ((float)this.artifactScrollRow / max));
      OpenGlUiRenderer.roundedRect(graphics, ACCESSORY_SCROLL_X, trackY, 3.0F, trackH, 1.5F, 0xFF252932);
      OpenGlUiRenderer.roundedRect(graphics, ACCESSORY_SCROLL_X, thumbY, 3.0F, thumbH, 1.5F, 0xFF59606C);
   }

   private void drawArtifactDetails(GuiGraphics graphics, int mouseX, int mouseY) {
      ArtifactSkins.Artifact artifact = this.selectedArtifact == null ? ArtifactSkins.Artifact.DEATH_NOTE : this.selectedArtifact;
      List<ArtifactSkins.Option> options = ArtifactSkins.options(artifact);
      ArtifactSkins.Option selected = ArtifactSkins.selected(artifact);
      boolean hasSkins = options.size() > 1;
      boolean active = ArtifactSkinConfig.enabled && ArtifactSkinConfig.isArtifactEnabled(artifact.id());

      int detailX = PREVIEW_X + 8;
      int detailW = PREVIEW_W - 24;
      float artifactNameWidth = FontManager.width(artifact.displayName(), 9.0F);
      OpenGlUiRenderer.text(
         graphics, artifact.displayName(), detailX + (detailW - artifactNameWidth) * 0.5F, 109.0F, 9.0F, TEXT_PRIMARY
      );
      int previewSize = 126;
      drawArtifactIcon(graphics, selected, detailX + (detailW - previewSize) / 2, 155, previewSize);
      if (hasSkins) {
         OpenGlUiRenderer.text(graphics, "选择皮肤", detailX, 331.0F, 8.0F, TEXT_MUTED);
         for (int index = 0; index < options.size(); index++) {
            this.drawArtifactSkinCard(graphics, mouseX, mouseY, options.get(index), detailX + index * 109, 347, 102);
         }
      } else {
         String skinName = "当前皮肤 · " + selected.displayName();
         float skinNameWidth = FontManager.width(skinName, 8.0F);
         OpenGlUiRenderer.text(graphics, skinName, detailX + (detailW - skinNameWidth) * 0.5F, 347.0F, 8.0F, TEXT_MUTED);
      }

      OpenGlUiRenderer.roundedRect(graphics, detailX + 2, 409.0F, 7.0F, 7.0F, 3.5F, active ? ACCENT : 0xFF555B66);
      OpenGlUiRenderer.text(graphics, active ? "已启用" : "已停用", detailX + 17, 404.0F, 8.0F, active ? TEXT_PRIMARY : TEXT_SECONDARY);
      String scope = !active ? "使用原始材质" : (ArtifactSkinConfig.onlySelf ? "仅本地自己" : "本地显示所有玩家");
      OpenGlUiRenderer.text(graphics, truncate(scope + " · " + selected.displayName(), 6.5F, detailW - 17.0F), detailX + 17, 419.0F, 6.5F, TEXT_MUTED);
   }

   private void drawArtifactSkinCard(
      GuiGraphics graphics, int mouseX, int mouseY, ArtifactSkins.Option option, int x, int y, int width
   ) {
      boolean selected = option.equals(ArtifactSkins.selected(option.artifact()));
      boolean hovered = OpenGlUiRenderer.inside(mouseX, mouseY, x, y, width, 38);
      OpenGlUiRenderer.panel(
         graphics,
         x,
         y,
         width,
         38,
         selected ? GLASS_SELECTED : (hovered ? GLASS_CARD_HOVER : GLASS_CARD),
         selected ? -1603280700 : 855638015
      );
      drawArtifactIcon(graphics, option, x + 7, y + 7, 24);
      OpenGlUiRenderer.text(
         graphics,
         truncate(option.displayName(), 8.0F, width - 54.0F),
         x + 39,
         y + 14,
         8.0F,
         selected ? TEXT_PRIMARY : TEXT_SECONDARY
      );
      if (selected) {
         OpenGlUiRenderer.roundedRect(graphics, x + width - 7, y + 9, 3.0F, 20.0F, 1.5F, ACCENT);
      }
   }

   private void drawSearchBox(GuiGraphics graphics, int mouseX, int mouseY) {
      drawUiTexture(graphics, LUNAR_CATEGORY_ICONS[this.activeSidebarIndex()], CONTENT_X, 29, 18, 18, 40, 40);
      OpenGlUiRenderer.text(graphics, this.activeCategoryTitle(), CONTENT_X + 23.0F, 29.0F, 9.5F, TEXT_PRIMARY);
      boolean hovered = OpenGlUiRenderer.inside(mouseX, mouseY, SEARCH_X, SEARCH_Y, SEARCH_W, SEARCH_H);
      boolean focused = this.searchBox != null && this.searchBox.isFocused();
      int fill = focused ? 0x8A303846 : (hovered ? 0x71252C38 : 0x321A202A);
      int border = focused ? 0xB06F7888 : (hovered ? 0x705A6270 : 0x205A6270);
      if (focused) {
         OpenGlUiRenderer.softShadow(graphics, SEARCH_X, SEARCH_Y, SEARCH_W, SEARCH_H, 7.0F, 0x65000000);
      }

      OpenGlUiRenderer.roundedPanel(graphics, SEARCH_X, SEARCH_Y, SEARCH_W, SEARCH_H, 6.0F, fill, border, focused ? 1.3F : 1.0F);
      drawUiTexture(graphics, LUNAR_SEARCH_ICON, SEARCH_X + 10, SEARCH_Y + 9, 12, 12, 12, 12);
      GlassSearchBox.VisibleText visible = this.searchBox.visibleText();
      String value = this.searchBox.getValue();
      graphics.enableScissor(SEARCH_TEXT_X, SEARCH_Y + 2, SEARCH_X + SEARCH_W - 31, SEARCH_Y + SEARCH_H - 2);

      try {
         GlassSearchBox.SelectionRange selection = this.searchBox.selectionRange();
         int selectionStart = Math.max(selection.start(), visible.start());
         int selectionEnd = Math.min(selection.end(), visible.end());
         if (selectionStart < selectionEnd) {
            float startX = SEARCH_TEXT_X + FontManager.widthRegular(value.substring(visible.start(), selectionStart), 9.0F);
            float endX = SEARCH_TEXT_X + FontManager.widthRegular(value.substring(visible.start(), selectionEnd), 9.0F);
            OpenGlUiRenderer.roundedRect(graphics, startX - 1.0F, SEARCH_Y + 5, endX - startX + 2.0F, 20.0F, 4.0F, 0x684F5A70);
         }

         if (value.isEmpty()) {
             OpenGlUiRenderer.textRegular(graphics, "搜索...", SEARCH_TEXT_X, SEARCH_Y + 9, 9.0F, TEXT_MUTED);
         } else {
            OpenGlUiRenderer.textRegular(graphics, visible.text(), SEARCH_TEXT_X, SEARCH_Y + 9, 9.0F, TEXT_PRIMARY);
         }

         if (focused && (System.currentTimeMillis() / 500L & 1L) == 0L) {
            int cursor = this.searchBox.getCursorPosition();
            if (cursor >= visible.start() && cursor <= visible.end()) {
               float cursorX = SEARCH_TEXT_X + FontManager.widthRegular(value.substring(visible.start(), cursor), 9.0F);
               OpenGlUiRenderer.roundedRect(graphics, cursorX, SEARCH_Y + 6, 1.25F, 18.0F, 0.65F, ACCENT);
            }
         }
      } finally {
         graphics.disableScissor();
      }

      if (!value.isEmpty()) {
         int clearX = SEARCH_X + SEARCH_W - 27;
         boolean clearHovered = OpenGlUiRenderer.inside(mouseX, mouseY, clearX, SEARCH_Y, 27, SEARCH_H);
         if (clearHovered) {
            OpenGlUiRenderer.roundedRect(graphics, clearX + 4, SEARCH_Y + 4, 20.0F, SEARCH_H - 8, 5.0F, 0x50393E49);
         }

         OpenGlUiRenderer.closeIcon(graphics, clearX + 14, SEARCH_Y + SEARCH_H * 0.5F, 11.0F, clearHovered ? TEXT_PRIMARY : TEXT_MUTED);
      }

      int sortX = SEARCH_X + SEARCH_W + 7;
      boolean sortHovered = OpenGlUiRenderer.inside(mouseX, mouseY, sortX, SEARCH_Y, 65, SEARCH_H);
      OpenGlUiRenderer.roundedPanel(
         graphics,
         sortX,
         SEARCH_Y,
         65.0F,
         SEARCH_H,
         6.0F,
         sortHovered ? GLASS_CARD_HOVER : GLASS_CARD,
         sortHovered ? 0xFF414650 : GLASS_BORDER,
         1.0F
      );
      OpenGlUiRenderer.text(graphics, sortAscending ? "A-Z" : "Z-A", sortX + 14.0F, SEARCH_Y + 10.0F, 8.0F, sortHovered ? TEXT_PRIMARY : TEXT_SECONDARY);
      drawUiTexture(graphics, LUNAR_COMPACT_ICON, sortX + 44, SEARCH_Y + 7, 15, 15, 24, 24);

      int gridX = sortX + 72;
      boolean gridHovered = OpenGlUiRenderer.inside(mouseX, mouseY, gridX, SEARCH_Y, 30, SEARCH_H);
      OpenGlUiRenderer.roundedPanel(
         graphics,
         gridX,
         SEARCH_Y,
         30.0F,
         SEARCH_H,
         6.0F,
         gridHovered ? GLASS_CARD_HOVER : 0x541A202A,
         gridHovered ? 0xA05A6270 : 0x405A6270,
         1.0F
      );
      drawUiTexture(graphics, LUNAR_GRID_ICON, gridX + 7, SEARCH_Y + 7, 15, 15, 24, 24);
   }

   private void drawSidebar(GuiGraphics graphics, int mouseX, int mouseY) {
      String[] labels = new String[]{"披风", "头饰", "肩宠", "翅膀", "盔甲纹饰", "神器皮肤"};
      int[] counts = new int[]{
         LunarCapeRegistry.values().size(),
         AccessoryRegistry.values(AccessorySlot.HEADWEAR).size(),
         LunarPetRegistry.values().size(),
         AccessoryRegistry.values(AccessorySlot.WINGS).size(),
         LinTrimManager.PATTERNS.size(),
         ArtifactSkins.Artifact.values().length
      };

      int[] entries = this.linEmbedded ? new int[]{1, 3, 4, 5} : new int[]{0, 1, 2, 3, 4, 5};
      for (int row = 0; row < entries.length; row++) {
         int index = entries[row];
         int y = SIDEBAR_ROW_Y + row * SIDEBAR_ROW_STEP;
         boolean active = this.isSidebarEntryActive(index);
         boolean hovered = OpenGlUiRenderer.inside(mouseX, mouseY, SIDEBAR_ROW_X, y, SIDEBAR_ROW_W, SIDEBAR_ROW_H);
         OpenGlUiRenderer.roundedRect(
            graphics,
            SIDEBAR_ROW_X,
            y,
            SIDEBAR_ROW_W,
            SIDEBAR_ROW_H,
            6.0F,
            active ? 0xA22A3342 : (hovered ? 0x66242C38 : 0x0014171E)
         );
         int itemColor = active || hovered ? TEXT_PRIMARY : TEXT_SECONDARY;
         drawUiTexture(graphics, LUNAR_CATEGORY_ICONS[index], SIDEBAR_ROW_X + 10, y + 9, 20, 20, 40, 40);
         String label = labels[index];
         float labelX = SIDEBAR_ROW_X + 38.0F;
         OpenGlUiRenderer.text(graphics, label, labelX, y + 12.0F, 9.0F, itemColor);
         String count = " (" + counts[index] + ")";
         OpenGlUiRenderer.textRegular(
            graphics, count, labelX + FontManager.width(label, 9.0F), y + 12.0F, 9.0F, active || hovered ? TEXT_SECONDARY : TEXT_MUTED
         );
         OpenGlUiRenderer.roundedRect(
            graphics,
            SIDEBAR_ROW_X + SIDEBAR_ROW_W - 14.0F,
            y + 16.0F,
            6.0F,
            6.0F,
            3.0F,
             this.isSidebarEntryEnabled(index) ? ACCENT : 0xFF3E424C
         );
      }
   }

   private void drawAccessoryScrollbar(GuiGraphics graphics, int itemCount) {
      int rows = rows(itemCount, ACCESSORY_COLUMNS);
      int max = accessoryMaxScroll(itemCount);
      if (rows > 0 && max > 0) {
         int trackHeight = ACCESSORY_VIEW_BOTTOM - ACCESSORY_CARD_TOP;
         OpenGlUiRenderer.roundedRect(graphics, ACCESSORY_SCROLL_X, ACCESSORY_CARD_TOP, 3.0F, trackHeight, 1.5F, 0xFF252932);
         int thumbHeight = Math.min(trackHeight, Math.max(27, trackHeight * ACCESSORY_VISIBLE_ROWS / rows));
         int thumbY = ACCESSORY_CARD_TOP;
         if (max > 0) {
            thumbY += Math.round((trackHeight - thumbHeight) * ((float)this.scrollRow / max));
         }

         OpenGlUiRenderer.roundedRect(graphics, ACCESSORY_SCROLL_X, thumbY, 3.0F, thumbHeight, 1.5F, 0xFF59606C);
      }
   }

   private void drawPreview(GuiGraphics graphics, int screenMouseX, int screenMouseY) {
      if (this.minecraft != null && this.minecraft.player != null) {
         int previewLeft = this.toScreenX(PREVIEW_X + 2);
         int previewTop = this.toScreenY(118);
         int previewRight = this.toScreenX(PREVIEW_X + PREVIEW_W - 13);
         int previewBottom = this.toScreenY(426);
         int entityScale = Math.max(1, Math.round(78.0F * this.uiScale));
           if (this.isCapePage()) {
              renderEntityFixed(
                 graphics,
                 previewLeft,
                 previewTop,
                 previewRight,
                 previewBottom,
                 entityScale,
                 this.minecraft.player,
                 true,
                 this.previewYaw
              );
           } else {
              renderEntityFixed(
                 graphics,
                 previewLeft,
                 previewTop,
                 previewRight,
                 previewBottom,
                 entityScale,
                 this.minecraft.player,
                 false,
                 this.previewYaw
              );
           }
        }

        int localMouseX = (int)this.toLocalX(screenMouseX);
        int localMouseY = (int)this.toLocalY(screenMouseY);
        boolean previewHovered = this.canDragPreview()
           && OpenGlUiRenderer.inside(localMouseX, localMouseY, PREVIEW_DRAG_X, PREVIEW_DRAG_Y, PREVIEW_DRAG_W, PREVIEW_DRAG_H);
        int previewCenterX = PREVIEW_X + (PREVIEW_W - 8) / 2;
        int rotateColor = this.previewDragging ? ACCENT : (previewHovered ? TEXT_SECONDARY : TEXT_MUTED);
        OpenGlUiRenderer.icon(graphics, previewCenterX, 426.0F, 50.0F, rotateColor, OpenGlUiRenderer.UiIcon.ROTATE_HORIZONTAL);

        String hint = "按住拖动 · 360°预览";
      float hintWidth = FontManager.width(hint, 7.0F);
      OpenGlUiRenderer.text(graphics, hint, previewCenterX - hintWidth * 0.5F, 446.0F, 7.0F, TEXT_MUTED);
        if (this.activePage == AccessorySelectorScreen.SelectorPage.HEADWEAR) {
          this.drawHeadwearVariantControls(graphics, localMouseX, localMouseY);
       } else if (this.activePage == AccessorySelectorScreen.SelectorPage.WINGS) {
          this.drawWingPositionControls(graphics, localMouseX, localMouseY);
       }
    }

   private void drawPreviewAction(GuiGraphics graphics, int mouseX, int mouseY) {
      boolean equipped = this.hasActiveSelection();
      boolean hovered = OpenGlUiRenderer.inside(
         mouseX, mouseY, PREVIEW_ACTION_X, PREVIEW_ACTION_Y, PREVIEW_ACTION_W, PREVIEW_ACTION_H
      );
      int fill = equipped ? (hovered ? 0xFF174E2E : 0xFF123E25) : GLASS_CARD;
      int border = equipped ? (hovered ? 0xFF2FE17A : 0xFF238F50) : GLASS_BORDER;
      OpenGlUiRenderer.roundedPanel(
         graphics,
         PREVIEW_ACTION_X,
         PREVIEW_ACTION_Y,
         PREVIEW_ACTION_W,
         PREVIEW_ACTION_H,
         6.0F,
         fill,
         border,
         1.0F
      );
      String label = equipped ? "已装备 · 点击取消" : "请在左侧选择饰品";
      float labelWidth = FontManager.width(label, 8.0F);
      if (equipped) {
         OpenGlUiRenderer.roundedRect(graphics, PREVIEW_ACTION_X + 12, PREVIEW_ACTION_Y + 13, 6.0F, 6.0F, 3.0F, ACCENT);
      }
      OpenGlUiRenderer.text(
         graphics,
         label,
         PREVIEW_ACTION_X + (PREVIEW_ACTION_W - labelWidth) * 0.5F,
         PREVIEW_ACTION_Y + 11,
         8.0F,
         equipped ? ACCENT_TEXT : TEXT_MUTED
      );
   }

   private void drawHeadwearVariantControls(GuiGraphics graphics, int mouseX, int mouseY) {
      AccessoryDefinition selected = AccessoryRegistry.selected(AccessorySlot.HEADWEAR);
      if (selected == null) {
         return;
      }

      this.drawHeadwearVariantToggle(graphics, mouseX, mouseY, selected);
   }

   private void drawHeadwearVariantToggle(
      GuiGraphics graphics, int mouseX, int mouseY, AccessoryDefinition definition
   ) {
      HeadwearVariant variant = AccessoryRegistry.headwearVariant(definition);
      boolean hovered = OpenGlUiRenderer.inside(
         mouseX, mouseY, HEADWEAR_VARIANT_X, ACCESSORY_CONTROL_Y,
         HEADWEAR_VARIANT_W, ACCESSORY_CONTROL_BUTTON_SIZE
      );
      OpenGlUiRenderer.roundedPanel(
         graphics,
         HEADWEAR_VARIANT_X,
         ACCESSORY_CONTROL_Y,
         HEADWEAR_VARIANT_W,
         ACCESSORY_CONTROL_BUTTON_SIZE,
         6.0F,
         hovered ? GLASS_CARD_HOVER : GLASS_SELECTED,
         hovered ? 0xFF7D8797 : 0xFF68717F,
         1.0F
      );
      drawIcon(graphics, definition, variant, HEADWEAR_VARIANT_X + 6, ACCESSORY_CONTROL_Y + 4, 19);
      OpenGlUiRenderer.text(
         graphics,
         "款式：" + variant.displayName(),
         HEADWEAR_VARIANT_X + 31,
         ACCESSORY_CONTROL_Y + 9,
         8.0F,
         TEXT_PRIMARY
      );
      OpenGlUiRenderer.text(
         graphics, "切换", HEADWEAR_VARIANT_X + HEADWEAR_VARIANT_W - 31,
         ACCESSORY_CONTROL_Y + 9, 7.0F, hovered ? ACCENT_TEXT : TEXT_MUTED
      );
   }

   private void drawWingPositionControls(GuiGraphics graphics, int mouseX, int mouseY) {
      this.drawWingPositionButton(graphics, mouseX, mouseY, WING_POSITION_UP_X, OpenGlUiRenderer.UiIcon.ARROW_UP);
      this.drawWingPositionButton(graphics, mouseX, mouseY, WING_POSITION_DOWN_X, OpenGlUiRenderer.UiIcon.ARROW_DOWN);
      boolean resetHovered = OpenGlUiRenderer.inside(mouseX, mouseY, WING_POSITION_RESET_X, ACCESSORY_CONTROL_Y, 50, ACCESSORY_CONTROL_BUTTON_SIZE);
      OpenGlUiRenderer.roundedPanel(
         graphics,
         WING_POSITION_RESET_X,
         ACCESSORY_CONTROL_Y,
         50.0F,
         ACCESSORY_CONTROL_BUTTON_SIZE,
         6.0F,
         resetHovered ? GLASS_CARD_HOVER : GLASS_CARD,
         resetHovered ? -1194141486 : GLASS_BORDER,
         1.0F
      );
      OpenGlUiRenderer.icon(
         graphics,
         WING_POSITION_RESET_X + 12.0F,
         ACCESSORY_CONTROL_Y + 13.5F,
         13.0F,
         resetHovered ? TEXT_PRIMARY : TEXT_SECONDARY,
         OpenGlUiRenderer.UiIcon.RESET
      );
      OpenGlUiRenderer.text(
         graphics,
         "重置",
         WING_POSITION_RESET_X + 22.0F,
         ACCESSORY_CONTROL_Y + 9.0F,
         8.0F,
         resetHovered ? TEXT_PRIMARY : TEXT_SECONDARY
      );
      String offset = String.format(Locale.ROOT, "Y %+.2f", ClientAccessoryConfig.wingOffsetY);
      OpenGlUiRenderer.textRegular(graphics, offset, 845.0F, ACCESSORY_CONTROL_Y + 10.0F, 7.0F, TEXT_MUTED);
   }

   private void drawWingPositionButton(GuiGraphics graphics, int mouseX, int mouseY, int x, OpenGlUiRenderer.UiIcon icon) {
      boolean hovered = OpenGlUiRenderer.inside(mouseX, mouseY, x, ACCESSORY_CONTROL_Y, ACCESSORY_CONTROL_BUTTON_SIZE, ACCESSORY_CONTROL_BUTTON_SIZE);
      OpenGlUiRenderer.roundedPanel(
         graphics,
         x,
         ACCESSORY_CONTROL_Y,
         ACCESSORY_CONTROL_BUTTON_SIZE,
         ACCESSORY_CONTROL_BUTTON_SIZE,
         6.0F,
         hovered ? GLASS_CARD_HOVER : GLASS_CARD,
         hovered ? -1194141486 : GLASS_BORDER,
         1.0F
      );
      OpenGlUiRenderer.icon(
         graphics,
         x + ACCESSORY_CONTROL_BUTTON_SIZE * 0.5F,
         ACCESSORY_CONTROL_Y + ACCESSORY_CONTROL_BUTTON_SIZE * 0.5F,
         14.0F,
         hovered ? TEXT_PRIMARY : TEXT_SECONDARY,
         icon
      );
   }

   private static void renderEntityFixed(
      GuiGraphics graphics,
      int left,
      int top,
      int right,
      int bottom,
      int scale,
      LivingEntity entity,
      boolean showBack,
      float yaw
   ) {
      EntityRenderDispatcher dispatcher = Minecraft.getInstance().getEntityRenderDispatcher();
      EntityRenderer<? super LivingEntity, ?> renderer = dispatcher.getRenderer(entity);
      EntityRenderState renderState = renderer.createRenderState(entity, 1.0F);
      renderState.lightCoords = 15728880;
      renderState.shadowPieces.clear();
      renderState.outlineColor = 0;
      if (renderState instanceof LivingEntityRenderState livingState) {
         livingState.bodyRot = (showBack ? 0.0F : 180.0F) + yaw;
         // bodyRot is the complete turntable angle. yRot is relative head yaw,
         // so feeding yaw into both fields rotates the head a second time.
         livingState.yRot = 0.0F;
         livingState.xRot = 0.0F;
         livingState.boundingBoxWidth /= livingState.scale;
         livingState.boundingBoxHeight /= livingState.scale;
         livingState.scale = 1.0F;
      }

      Quaternionf cameraRotation = new Quaternionf();
      Quaternionf orientation = new Quaternionf().rotateZ((float)Math.PI);
      Vector3f center = new Vector3f(0.0F, renderState.boundingBoxHeight / 2.0F + 0.0625F, 0.0F);
      graphics.submitEntityRenderState(renderState, scale, center, orientation, cameraRotation, left, top, right, bottom);
   }

   private String previewSelectionName() {
      if (this.activePage == AccessorySelectorScreen.SelectorPage.TRIMS) {
         return LinTrimManager.displayName(LinTrimManager.pattern());
      }

       if (this.activePage == AccessorySelectorScreen.SelectorPage.COSMETICS
          && this.activeCosmeticPage == AccessorySelectorScreen.CosmeticPage.CAPES) {
          LunarCape selected = LunarCapeRegistry.selected();
          return selected == null ? "未选择披风" : selected.displayName();
       }

       if (this.activePage == AccessorySelectorScreen.SelectorPage.COSMETICS
          && this.activeCosmeticPage == AccessorySelectorScreen.CosmeticPage.PETS) {
          LunarPet selected = LunarPetRegistry.selected();
          return selected == null ? "未选择肩宠" : selected.displayName();
       }

      AccessoryDefinition selected = AccessoryRegistry.selected(this.activePage.slot);
      if (selected != null) {
         return selected.displayName();
      }
      return this.activePage == AccessorySelectorScreen.SelectorPage.WINGS ? "未选择翅膀" : "未选择头饰";
   }

   private boolean hasActiveSelection() {
      if (this.activePage == AccessorySelectorScreen.SelectorPage.TRIMS) {
         return LinTrimManager.isEnabled();
      }
      if (this.isCapePage()) {
         return LunarCapeRegistry.selected() != null;
      }
      if (this.isPetPage()) {
         return LunarPetRegistry.selected() != null;
      }
      return this.activePage.slot != null && AccessoryRegistry.selected(this.activePage.slot) != null;
   }

   private void clearActiveSelection() {
      if (!this.hasActiveSelection()) {
         return;
      }
      if (this.activePage == AccessorySelectorScreen.SelectorPage.TRIMS) {
         LinTrimManager.setPattern("none");
         return;
      }
      if (this.isCapePage()) {
         LunarCapeRegistry.clearSelection();
         LunarCapeTextureManager.selectionChanged();
      } else if (this.isPetPage()) {
         LunarPetRegistry.clearSelection();
         LunarPetTextureManager.selectionChanged();
      } else if (this.activePage.slot != null) {
         AccessoryRegistry.clearSelection(this.activePage.slot);
      }
      ClientAccessoryConfig.save();
   }

   private static AccessorySelectorScreen.SelectorPage sidebarPage(int index) {
      return switch (index) {
         case 0, 2 -> AccessorySelectorScreen.SelectorPage.COSMETICS;
         case 1 -> AccessorySelectorScreen.SelectorPage.HEADWEAR;
         case 3 -> AccessorySelectorScreen.SelectorPage.WINGS;
         case 4 -> AccessorySelectorScreen.SelectorPage.TRIMS;
         case 5 -> AccessorySelectorScreen.SelectorPage.ARTIFACTS;
          default -> null;
       };
   }

   private boolean isSidebarEntryActive(int index) {
      return switch (index) {
         case 0 -> this.isCapePage();
         case 1 -> this.activePage == AccessorySelectorScreen.SelectorPage.HEADWEAR;
         case 2 -> this.isPetPage();
         case 3 -> this.activePage == AccessorySelectorScreen.SelectorPage.WINGS;
         case 4 -> this.activePage == AccessorySelectorScreen.SelectorPage.TRIMS;
         case 5 -> this.activePage == AccessorySelectorScreen.SelectorPage.ARTIFACTS;
         default -> false;
      };
   }

   private boolean isSidebarEntryEnabled(int index) {
      return switch (index) {
         case 0 -> LunarCapeRegistry.selected() != null;
         case 1 -> AccessoryRegistry.selected(AccessorySlot.HEADWEAR) != null;
         case 2 -> LunarPetRegistry.selected() != null;
         case 3 -> AccessoryRegistry.selected(AccessorySlot.WINGS) != null;
         case 4 -> LinTrimManager.isEnabled();
         case 5 -> ArtifactSkinConfig.enabled;
         default -> false;
      };
   }

   private void drawTrimSelector(GuiGraphics graphics, int mouseX, int mouseY) {
      drawUiTexture(graphics, LUNAR_CATEGORY_ICONS[4], CONTENT_X, 29, 18, 18, 40, 40);
      OpenGlUiRenderer.text(graphics, "盔甲纹饰", CONTENT_X + 23.0F, 29.0F, 9.5F, TEXT_PRIMARY);
      graphics.enableScissor(CONTENT_X - 4, TRIM_VIEW_TOP, CONTENT_X + CONTENT_W, TRIM_VIEW_BOTTOM);

      try {
         int y = TRIM_VIEW_TOP - this.trimScroll;
         OpenGlUiRenderer.text(graphics, "纹饰图案", CONTENT_X, y + 2, 9.0F, TEXT_SECONDARY);
         y += 20;
         int cardW = ACCESSORY_CARD_W;

         for (int index = 0; index < TRIM_PATTERNS.size(); index++) {
            int cardX = CONTENT_X + index % ACCESSORY_COLUMNS * (cardW + ACCESSORY_COLUMN_GAP);
            int cardY = y + index / ACCESSORY_COLUMNS * 43;
            if (cardY + 36 >= TRIM_VIEW_TOP && cardY <= TRIM_VIEW_BOTTOM) {
               this.drawPatternCard(graphics, mouseX, mouseY, TRIM_PATTERNS.get(index), cardX, cardY, cardW);
            }
         }

         y += rows(TRIM_PATTERNS.size(), ACCESSORY_COLUMNS) * 43 - 7 + 22;
         OpenGlUiRenderer.text(graphics, "纹饰材质", CONTENT_X, y + 2, 9.0F, TEXT_SECONDARY);
         y += 20;
         int materialW = ACCESSORY_CARD_W;

         for (int index = 0; index < LinTrimManager.MATERIALS.size(); index++) {
            int cardX = CONTENT_X + index % ACCESSORY_COLUMNS * (materialW + ACCESSORY_COLUMN_GAP);
            int cardY = y + index / ACCESSORY_COLUMNS * 37;
            if (cardY + 30 >= TRIM_VIEW_TOP && cardY <= TRIM_VIEW_BOTTOM) {
               this.drawMaterialCard(graphics, mouseX, mouseY, LinTrimManager.MATERIALS.get(index), cardX, cardY, materialW);
            }
         }

         y += rows(LinTrimManager.MATERIALS.size(), ACCESSORY_COLUMNS) * 37 - 7 + 22;
         OpenGlUiRenderer.text(graphics, "预览盔甲", CONTENT_X, y + 2, 9.0F, TEXT_SECONDARY);
         y += 20;
         int armorW = ACCESSORY_CARD_W;
         LinTrimPreview[] previews = LinTrimPreview.values();

         for (int index = 0; index < previews.length; index++) {
            int cardX = CONTENT_X + index % ACCESSORY_COLUMNS * (armorW + ACCESSORY_COLUMN_GAP);
            int cardY = y + index / ACCESSORY_COLUMNS * 37;
            if (cardY + 30 >= TRIM_VIEW_TOP && cardY <= TRIM_VIEW_BOTTOM) {
               this.drawArmorCard(graphics, mouseX, mouseY, previews[index], cardX, cardY, armorW);
            }
         }
      } finally {
         graphics.disableScissor();
      }

      int max = this.trimMaxScroll();
      if (max > 0) {
         int trackY = TRIM_VIEW_TOP + 4;
         int trackH = TRIM_VIEW_BOTTOM - TRIM_VIEW_TOP - 8;
         int thumbH = Math.max(30, trackH * trackH / (trackH + max));
         int thumbY = trackY + Math.round((trackH - thumbH) * ((float)this.trimScroll / max));
         OpenGlUiRenderer.roundedRect(graphics, ACCESSORY_SCROLL_X, trackY, 3.0F, trackH, 1.5F, 0xFF252932);
         OpenGlUiRenderer.roundedRect(graphics, ACCESSORY_SCROLL_X, thumbY, 3.0F, thumbH, 1.5F, 0xFF59606C);
      }
   }

   private void drawPatternCard(GuiGraphics graphics, int mouseX, int mouseY, String pattern, int x, int y, int width) {
      boolean selected = pattern.equals(LinTrimManager.pattern());
      boolean hovered = this.isInsideTrimViewport(mouseX, mouseY) && OpenGlUiRenderer.inside(mouseX, mouseY, x, y, width, 36);
      OpenGlUiRenderer.roundedPanel(
         graphics,
         x,
         y,
         width,
         36,
         6.0F,
         selected ? GLASS_SELECTED : (hovered ? GLASS_CARD_HOVER : GLASS_CARD),
         selected ? 0xFF99A3B3 : (hovered ? 0xB8848C9A : GLASS_BORDER),
         selected ? 1.4F : 1.0F
      );
      if ("none".equals(pattern)) {
         OpenGlUiRenderer.closeIcon(graphics, x + 17, y + 18.0F, 13.0F, -1462575903);
      } else {
         Identifier texture = patternTexture(pattern);
         graphics.blit(RenderPipelines.GUI_TEXTURED, texture, x + 9, y + 10, 0.0F, 0.0F, 16, 16, 16, 16);
      }

      OpenGlUiRenderer.text(
         graphics, truncate(LinTrimManager.displayName(pattern), 8.0F, width - 45.0F), x + 32, y + 11, 8.0F, selected ? TEXT_PRIMARY : TEXT_SECONDARY
      );
      if (selected) {
         OpenGlUiRenderer.roundedRect(graphics, x + width - 7, y + 8, 3.0F, 20.0F, 1.5F, -10958981);
      }
   }

   private void drawMaterialCard(GuiGraphics graphics, int mouseX, int mouseY, String material, int x, int y, int width) {
      boolean selected = material.equals(LinTrimManager.material());
      boolean hovered = this.isInsideTrimViewport(mouseX, mouseY) && OpenGlUiRenderer.inside(mouseX, mouseY, x, y, width, 30);
      OpenGlUiRenderer.roundedPanel(
         graphics,
         x,
         y,
         width,
         30,
         6.0F,
         selected ? GLASS_SELECTED : (hovered ? GLASS_CARD_HOVER : GLASS_CARD),
         selected ? 0xFF99A3B3 : (hovered ? 0xB8848C9A : GLASS_BORDER),
         selected ? 1.4F : 1.0F
      );
      OpenGlUiRenderer.roundedRect(graphics, x + 9, y + 10, 10.0F, 10.0F, 3.5F, materialColor(material));
      OpenGlUiRenderer.text(
         graphics, truncate(LinTrimManager.displayName(material), 8.0F, width - 32.0F), x + 25, y + 9, 8.0F, selected ? TEXT_PRIMARY : TEXT_SECONDARY
      );
   }

   private void drawArmorCard(GuiGraphics graphics, int mouseX, int mouseY, LinTrimPreview preview, int x, int y, int width) {
      boolean selected = preview == LinTrimPreview.selected();
      boolean hovered = this.isInsideTrimViewport(mouseX, mouseY) && OpenGlUiRenderer.inside(mouseX, mouseY, x, y, width, 30);
      OpenGlUiRenderer.roundedPanel(
         graphics,
         x,
         y,
         width,
         30,
         6.0F,
         selected ? GLASS_SELECTED : (hovered ? GLASS_CARD_HOVER : GLASS_CARD),
         selected ? 0xFF99A3B3 : (hovered ? 0xB8848C9A : GLASS_BORDER),
         selected ? 1.4F : 1.0F
      );
      float textWidth = FontManager.width(preview.displayName(), 9.0F);
      OpenGlUiRenderer.text(graphics, preview.displayName(), x + (width - textWidth) * 0.5F, y + 9, 9.0F, selected ? TEXT_PRIMARY : TEXT_SECONDARY);
   }

   @Override
   public boolean mouseClicked(MouseButtonEvent click, boolean doubled) {
      if (click.button() != 0) {
         return true;
      } else {
         this.updateLayout();
         double mouseX = this.toLocalX(click.x());
         double mouseY = this.toLocalY(click.y());
         if (OpenGlUiRenderer.inside(mouseX, mouseY, 927, 20, 22, 22)) {
            this.onClose();
            return true;
         } else if (this.canDragPreview() && OpenGlUiRenderer.inside(mouseX, mouseY, PREVIEW_DRAG_X, PREVIEW_DRAG_Y, PREVIEW_DRAG_W, PREVIEW_DRAG_H)) {
            this.previewDragging = true;
            this.previewDragStartX = click.x();
            this.previewDragStartYaw = this.previewYaw;
            return true;
          } else if (this.isSearchPage()
             && this.hasSearchQuery()
            && OpenGlUiRenderer.inside(mouseX, mouseY, SEARCH_X + SEARCH_W - 27, SEARCH_Y, 27, SEARCH_H)) {
            this.searchBox.setValue("");
            this.setFocused(this.searchBox);
            this.searchBox.moveCursorToEnd(false);
            return true;
         } else if (this.isSearchPage()
            && OpenGlUiRenderer.inside(mouseX, mouseY, SEARCH_X + SEARCH_W + 7, SEARCH_Y, 65, SEARCH_H)) {
            this.sortAscending = !this.sortAscending;
            this.scrollRow = 0;
            this.capeScrollRow = 0;
            this.petScrollRow = 0;
            return true;
         } else if (super.mouseClicked(click, doubled)) {
            return true;
         } else {
            this.clearFocus();
            if (this.clickSidebar(mouseX, mouseY)) {
               return true;
             } else if (this.activePage == AccessorySelectorScreen.SelectorPage.ARTIFACTS) {
                return this.clickArtifactSelector(mouseX, mouseY, doubled);
             } else if (this.activePage == AccessorySelectorScreen.SelectorPage.COSMETICS) {
                return this.clickCosmeticsSelector(mouseX, mouseY, doubled);
             } else {
               return this.activePage == AccessorySelectorScreen.SelectorPage.TRIMS
                  ? this.clickTrimSelector(mouseX, mouseY)
                  : this.clickAccessorySelector(mouseX, mouseY);
            }
         }
      }
   }

   @Override
   public boolean mouseDragged(MouseButtonEvent click, double dragX, double dragY) {
      if (this.previewDragging && click.button() == 0) {
         double scale = Math.max(0.0001, this.uiScale);
         float totalMovementX = (float)((click.x() - this.previewDragStartX) / scale);
         this.previewYaw = normalizeDegrees(
            this.previewDragStartYaw - totalMovementX * PREVIEW_ROTATION_SENSITIVITY
         );
         return true;
      }

      return super.mouseDragged(click, dragX, dragY);
   }

   @Override
   public boolean mouseReleased(MouseButtonEvent click) {
      if (this.previewDragging && click.button() == 0) {
         this.previewDragging = false;
         return true;
      }

      return super.mouseReleased(click);
   }

   private boolean clickSidebar(double mouseX, double mouseY) {
      int[] entries = this.linEmbedded ? new int[]{1, 4, 5} : new int[]{0, 1, 2, 3, 4, 5};
      for (int row = 0; row < entries.length; row++) {
         int index = entries[row];
         int y = SIDEBAR_ROW_Y + row * SIDEBAR_ROW_STEP;
         if (OpenGlUiRenderer.inside(mouseX, mouseY, SIDEBAR_ROW_X, y, SIDEBAR_ROW_W, SIDEBAR_ROW_H)) {
            this.selectSidebarEntry(index);
            return true;
         }
      }

       return false;
    }

    private boolean clickCosmeticsSelector(double mouseX, double mouseY, boolean doubled) {
       if (this.activeCosmeticPage == AccessorySelectorScreen.CosmeticPage.CAPES) {
          return this.clickCapeSelector(mouseX, mouseY);
       }
       return this.activeCosmeticPage != AccessorySelectorScreen.CosmeticPage.PETS || this.clickPetSelector(mouseX, mouseY, doubled);
    }

   private boolean clickPetSelector(double mouseX, double mouseY, boolean doubled) {
      if (OpenGlUiRenderer.inside(mouseX, mouseY, PET_POSITION_LEFT_X, PET_POSITION_Y, PET_POSITION_BUTTON_SIZE, PET_POSITION_BUTTON_SIZE)) {
         ClientAccessoryConfig.movePet(-ClientAccessoryConfig.PET_OFFSET_STEP, 0.0F);
         return true;
      }
      if (OpenGlUiRenderer.inside(mouseX, mouseY, PET_POSITION_RIGHT_X, PET_POSITION_Y, PET_POSITION_BUTTON_SIZE, PET_POSITION_BUTTON_SIZE)) {
         ClientAccessoryConfig.movePet(ClientAccessoryConfig.PET_OFFSET_STEP, 0.0F);
         return true;
      }
      if (OpenGlUiRenderer.inside(mouseX, mouseY, PET_POSITION_UP_X, PET_POSITION_Y, PET_POSITION_BUTTON_SIZE, PET_POSITION_BUTTON_SIZE)) {
         ClientAccessoryConfig.movePet(0.0F, ClientAccessoryConfig.PET_OFFSET_STEP);
         return true;
      }
      if (OpenGlUiRenderer.inside(mouseX, mouseY, PET_POSITION_DOWN_X, PET_POSITION_Y, PET_POSITION_BUTTON_SIZE, PET_POSITION_BUTTON_SIZE)) {
         ClientAccessoryConfig.movePet(0.0F, -ClientAccessoryConfig.PET_OFFSET_STEP);
         return true;
      }
      if (OpenGlUiRenderer.inside(mouseX, mouseY, PET_POSITION_RESET_X, PET_POSITION_Y, 50, PET_POSITION_BUTTON_SIZE)) {
         ClientAccessoryConfig.resetPetPosition();
         return true;
      }

      List<LunarPet> values = this.filteredPets();
      int first = this.petScrollRow * ACCESSORY_COLUMNS;
      int last = Math.min(values.size(), first + ACCESSORY_COLUMNS * ACCESSORY_VISIBLE_ROWS);
      for (int index = first; index < last; index++) {
         int relative = index - first;
         int cardX = CONTENT_X + relative % ACCESSORY_COLUMNS * (ACCESSORY_CARD_W + ACCESSORY_COLUMN_GAP);
         int cardY = ACCESSORY_CARD_TOP + relative / ACCESSORY_COLUMNS * ACCESSORY_ROW_STEP;
         if (OpenGlUiRenderer.inside(mouseX, mouseY, cardX, cardY, ACCESSORY_CARD_W, ACCESSORY_CARD_H)) {
            LunarPet pet = values.get(index);
            if (pet.id().equals(LunarPetRegistry.selectedId())) {
               if (!doubled) {
                  return true;
               }
               LunarPetRegistry.clearSelection();
            } else {
               LunarPetRegistry.select(pet.id());
            }
            LunarPetTextureManager.selectionChanged();
            ClientAccessoryConfig.save();
            return true;
         }
      }
      return true;
   }

   private boolean clickCapeSelector(double mouseX, double mouseY) {
      if (OpenGlUiRenderer.inside(mouseX, mouseY, 826, 99, 112, 27)) {
         ClientAccessoryConfig.capePreviewAngled = !ClientAccessoryConfig.capePreviewAngled;
         ClientAccessoryConfig.save();
         return true;
      }

      List<LunarCape> values = this.filteredCapes();
      int first = this.capeScrollRow * ACCESSORY_COLUMNS;
      int last = Math.min(values.size() + 1, first + ACCESSORY_COLUMNS * ACCESSORY_VISIBLE_ROWS);
      for (int slot = first; slot < last; slot++) {
         int relative = slot - first;
         int cardX = CONTENT_X + relative % ACCESSORY_COLUMNS * (ACCESSORY_CARD_W + ACCESSORY_COLUMN_GAP);
         int cardY = ACCESSORY_CARD_TOP + relative / ACCESSORY_COLUMNS * ACCESSORY_ROW_STEP;
         if (OpenGlUiRenderer.inside(mouseX, mouseY, cardX, cardY, ACCESSORY_CARD_W, ACCESSORY_CARD_H)) {
            if (slot == 0) {
               this.openCustomCapeDialog();
               return true;
            }

            LunarCape cape = values.get(slot - 1);
            if (cape.id().equals(LunarCapeRegistry.selectedId())) {
               LunarCapeRegistry.clearSelection();
            } else {
               LunarCapeRegistry.select(cape.id());
            }
            ClientAccessoryConfig.save();
            LunarCapeTextureManager.selectionChanged();
            return true;
         }
      }
      return true;
   }

   private void openCustomCapeDialog() {
      if (this.capeImporting || this.minecraft == null) {
         return;
      }
      this.capeImporting = true;
      Minecraft client = this.minecraft;
      Thread picker = new Thread(() -> {
         try {
            String selected;
            try (MemoryStack stack = MemoryStack.stackPush()) {
               PointerBuffer filters = stack.mallocPointer(2);
               filters.put(stack.UTF8("*.png"));
               filters.put(stack.UTF8("*.webp"));
               filters.flip();
               selected = TinyFileDialogs.tinyfd_openFileDialog(
                  "导入自定义披风", LunarCapeRegistry.customDirectory().toString(), filters, "PNG / WebP 披风", false
               );
            }

            if (selected == null) {
               client.execute(() -> this.capeImporting = false);
               return;
            }

            LunarCape imported = LunarCapeRegistry.importCustomCape(Path.of(selected));
            client.execute(() -> {
               this.capeImporting = false;
               LunarCapeRegistry.select(imported.id());
               LunarCapeTextureManager.selectionChanged();
               ClientAccessoryConfig.save();
               this.capeScrollRow = 0;
               if (this.searchBox != null) {
                  this.searchBox.setValue("");
               }
               this.capeImportStatus = "已导入：" + imported.displayName();
               this.capeImportStatusUntil = System.currentTimeMillis() + 5000L;
            });
         } catch (Exception exception) {
            String message = exception.getMessage() == null ? exception.getClass().getSimpleName() : exception.getMessage();
            client.execute(() -> {
               this.capeImporting = false;
               this.capeImportStatus = "导入失败：" + message;
               this.capeImportStatusUntil = System.currentTimeMillis() + 6000L;
            });
         }
      }, "Lin Client Cape File Picker");
      picker.setDaemon(true);
      picker.start();
   }

   private boolean clickArtifactSelector(double mouseX, double mouseY, boolean doubled) {
      if (OpenGlUiRenderer.inside(mouseX, mouseY, 514, 24, 84, 29)) {
         ArtifactPackManager.setEnabled(!ArtifactSkinConfig.enabled);
         return true;
      }
      if (OpenGlUiRenderer.inside(mouseX, mouseY, 605, 24, 93, 29)) {
         ArtifactPackManager.setOnlySelf(!ArtifactSkinConfig.onlySelf);
         return true;
      }

      ArtifactSkins.Artifact[] artifacts = ArtifactSkins.Artifact.values();
      int first = this.artifactScrollRow * ACCESSORY_COLUMNS;
      int last = Math.min(artifacts.length, first + ACCESSORY_COLUMNS * ACCESSORY_VISIBLE_ROWS);
      if (this.isInsideArtifactViewport(mouseX, mouseY)) {
         for (int index = first; index < last; index++) {
            int relative = index - first;
            int cardX = CONTENT_X + relative % ACCESSORY_COLUMNS * (ACCESSORY_CARD_W + ACCESSORY_COLUMN_GAP);
            int cardY = ACCESSORY_CARD_TOP + relative / ACCESSORY_COLUMNS * ACCESSORY_ROW_STEP;
            if (OpenGlUiRenderer.inside(mouseX, mouseY, cardX, cardY, ACCESSORY_CARD_W, ACCESSORY_CARD_H)) {
               ArtifactSkins.Artifact artifact = artifacts[index];
               if (artifact != this.selectedArtifact) {
                  this.selectedArtifact = artifact;
               } else if (doubled) {
                  ArtifactPackManager.setArtifactEnabled(artifact, !ArtifactSkinConfig.isArtifactEnabled(artifact.id()));
               }
               return true;
            }
         }
      }

      ArtifactSkins.Artifact artifact = this.selectedArtifact == null ? ArtifactSkins.Artifact.DEATH_NOTE : this.selectedArtifact;
      List<ArtifactSkins.Option> options = ArtifactSkins.options(artifact);
      if (options.size() > 1) {
         for (int index = 0; index < options.size(); index++) {
            int cardX = PREVIEW_X + 8 + index * 109;
            if (OpenGlUiRenderer.inside(mouseX, mouseY, cardX, 347, 102, 38)) {
               ArtifactSkins.select(options.get(index));
               return true;
            }
         }
      }

      return true;
   }

   private boolean clickAccessorySelector(double mouseX, double mouseY) {
      AccessorySlot slot = this.activePage.slot;
      AccessoryDefinition selected = AccessoryRegistry.selected(slot);
      if (slot == AccessorySlot.HEADWEAR && selected != null) {
         if (OpenGlUiRenderer.inside(
            mouseX, mouseY, HEADWEAR_VARIANT_X, ACCESSORY_CONTROL_Y,
            HEADWEAR_VARIANT_W, ACCESSORY_CONTROL_BUTTON_SIZE
         )) {
            HeadwearVariant current = AccessoryRegistry.headwearVariant(selected);
            AccessoryRegistry.selectHeadwearVariant(
               selected.id(), current == HeadwearVariant.NORMAL
                  ? HeadwearVariant.SHINY : HeadwearVariant.NORMAL
            );
            ClientAccessoryConfig.save();
            return true;
         }
      }

      if (slot == AccessorySlot.WINGS) {
         if (OpenGlUiRenderer.inside(mouseX, mouseY, WING_POSITION_UP_X, ACCESSORY_CONTROL_Y, ACCESSORY_CONTROL_BUTTON_SIZE, ACCESSORY_CONTROL_BUTTON_SIZE)) {
            ClientAccessoryConfig.moveWings(ClientAccessoryConfig.WING_OFFSET_STEP);
            return true;
         }
         if (OpenGlUiRenderer.inside(mouseX, mouseY, WING_POSITION_DOWN_X, ACCESSORY_CONTROL_Y, ACCESSORY_CONTROL_BUTTON_SIZE, ACCESSORY_CONTROL_BUTTON_SIZE)) {
            ClientAccessoryConfig.moveWings(-ClientAccessoryConfig.WING_OFFSET_STEP);
            return true;
         }
         if (OpenGlUiRenderer.inside(mouseX, mouseY, WING_POSITION_RESET_X, ACCESSORY_CONTROL_Y, 50, ACCESSORY_CONTROL_BUTTON_SIZE)) {
            ClientAccessoryConfig.resetWingPosition();
            return true;
         }
      }

      List<AccessoryDefinition> values = this.filteredAccessories(slot);
      int first = this.scrollRow * ACCESSORY_COLUMNS;
      int last = Math.min(values.size(), first + ACCESSORY_COLUMNS * ACCESSORY_VISIBLE_ROWS);

      for (int index = first; index < last; index++) {
         int relative = index - first;
         int cardX = CONTENT_X + relative % ACCESSORY_COLUMNS * (ACCESSORY_CARD_W + ACCESSORY_COLUMN_GAP);
         int cardY = ACCESSORY_CARD_TOP + relative / ACCESSORY_COLUMNS * ACCESSORY_ROW_STEP;
         if (OpenGlUiRenderer.inside(mouseX, mouseY, cardX, cardY, ACCESSORY_CARD_W, ACCESSORY_CARD_H)) {
            AccessoryDefinition definition = values.get(index);
            if (definition.id().equals(AccessoryRegistry.selectedId(slot))) {
               AccessoryRegistry.clearSelection(slot);
            } else {
               AccessoryRegistry.select(slot, definition.id());
            }

            ClientAccessoryConfig.save();
            return true;
         }
      }

      return true;
   }

   private boolean clickTrimSelector(double mouseX, double mouseY) {
      if (!this.isInsideTrimViewport(mouseX, mouseY)) {
         return true;
      }

      int y = TRIM_VIEW_TOP - this.trimScroll + 20;
      int cardW = ACCESSORY_CARD_W;

      for (int index = 0; index < TRIM_PATTERNS.size(); index++) {
         int cardX = CONTENT_X + index % ACCESSORY_COLUMNS * (cardW + ACCESSORY_COLUMN_GAP);
         int cardY = y + index / ACCESSORY_COLUMNS * 43;
         if (OpenGlUiRenderer.inside(mouseX, mouseY, cardX, cardY, cardW, 36)) {
            LinTrimManager.setPattern(TRIM_PATTERNS.get(index));
            return true;
         }
      }

      y += rows(TRIM_PATTERNS.size(), ACCESSORY_COLUMNS) * 43 - 7 + 42;
      int materialW = ACCESSORY_CARD_W;

      for (int index = 0; index < LinTrimManager.MATERIALS.size(); index++) {
         int cardX = CONTENT_X + index % ACCESSORY_COLUMNS * (materialW + ACCESSORY_COLUMN_GAP);
         int cardY = y + index / ACCESSORY_COLUMNS * 37;
         if (OpenGlUiRenderer.inside(mouseX, mouseY, cardX, cardY, materialW, 30)) {
            LinTrimManager.setMaterial(LinTrimManager.MATERIALS.get(index));
            return true;
         }
      }

      y += rows(LinTrimManager.MATERIALS.size(), ACCESSORY_COLUMNS) * 37 - 7 + 42;
      int armorW = ACCESSORY_CARD_W;
      LinTrimPreview[] previews = LinTrimPreview.values();

      for (int index = 0; index < previews.length; index++) {
         int cardX = CONTENT_X + index % ACCESSORY_COLUMNS * (armorW + ACCESSORY_COLUMN_GAP);
         int cardY = y + index / ACCESSORY_COLUMNS * 37;
         if (OpenGlUiRenderer.inside(mouseX, mouseY, cardX, cardY, armorW, 30)) {
            LinTrimPreview.select(previews[index]);
            return true;
         }
      }

      return true;
   }

   @Override
   public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
      this.updateLayout();
      double localMouseX = this.toLocalX(mouseX);
      double localMouseY = this.toLocalY(mouseY);
      if (this.activePage == AccessorySelectorScreen.SelectorPage.ARTIFACTS) {
         if (!this.isInsideArtifactViewport(localMouseX, localMouseY)) {
            return false;
         }

         int maxScroll = artifactMaxScroll(ArtifactSkins.Artifact.values().length);
         this.artifactScrollRow = clamp(this.artifactScrollRow - (int)Math.signum(verticalAmount), 0, maxScroll);
       } else if (this.activePage == AccessorySelectorScreen.SelectorPage.TRIMS) {
         if (!this.isInsideTrimViewport(localMouseX, localMouseY)) {
            return false;
         }

          this.trimScroll = clamp(this.trimScroll - (int)Math.signum(verticalAmount) * 32, 0, this.trimMaxScroll());
       } else if (this.activePage == AccessorySelectorScreen.SelectorPage.COSMETICS) {
          if ((this.activeCosmeticPage != AccessorySelectorScreen.CosmeticPage.CAPES
             && this.activeCosmeticPage != AccessorySelectorScreen.CosmeticPage.PETS)
             || !OpenGlUiRenderer.inside(
                localMouseX,
                localMouseY,
                CONTENT_X,
                ACCESSORY_CARD_TOP,
                ACCESSORY_CARD_W * ACCESSORY_COLUMNS + ACCESSORY_COLUMN_GAP * (ACCESSORY_COLUMNS - 1),
                ACCESSORY_VIEW_BOTTOM - ACCESSORY_CARD_TOP
             )) {
             return false;
          }
          if (this.activeCosmeticPage == AccessorySelectorScreen.CosmeticPage.CAPES) {
             int maxScroll = capeMaxScroll(this.filteredCapes().size() + 1);
             this.capeScrollRow = clamp(this.capeScrollRow - (int)Math.signum(verticalAmount), 0, maxScroll);
          } else {
             int maxScroll = capeMaxScroll(this.filteredPets().size());
             this.petScrollRow = clamp(this.petScrollRow - (int)Math.signum(verticalAmount), 0, maxScroll);
          }
       } else {
         if (!OpenGlUiRenderer.inside(
            localMouseX,
            localMouseY,
            CONTENT_X,
            ACCESSORY_CARD_TOP,
            ACCESSORY_CARD_W * ACCESSORY_COLUMNS + ACCESSORY_COLUMN_GAP * (ACCESSORY_COLUMNS - 1),
            ACCESSORY_VIEW_BOTTOM - ACCESSORY_CARD_TOP
         )) {
            return false;
         }

         int maxScroll = accessoryMaxScroll(this.filteredAccessories(this.activePage.slot).size());
         this.scrollRow = clamp(this.scrollRow - (int)Math.signum(verticalAmount), 0, maxScroll);
      }

      return true;
   }

   @Override
   public boolean keyPressed(KeyEvent input) {
      if (input.key() == 256) {
         this.onClose();
         return true;
      }

       if (this.isSearchPage() && input.key() == 70 && input.hasControlDown()) {
         this.setFocused(this.searchBox);
         this.searchBox.moveCursorToEnd(false);
         return true;
      }

      if (this.searchBox != null && this.searchBox.isFocused() && this.searchBox.keyPressed(input)) {
         return true;
      }

      if (input.key() != 263 && input.key() != 262) {
         return super.keyPressed(input);
      }

      int direction = input.key() == 262 ? 1 : -1;
      if (this.linEmbedded) {
         int active = this.activeSidebarIndex();
         int position = active == 1 ? 0 : active == 4 ? 1 : 2;
         int[] entries = new int[]{1, 4, 5};
         this.selectSidebarEntry(entries[Math.floorMod(position + direction, entries.length)]);
      } else {
         this.selectSidebarEntry(Math.floorMod(this.activeSidebarIndex() + direction, 6));
      }
      return true;
   }

   @Override
   public void onClose() {
      if (this.minecraft != null) {
         this.minecraft.setScreen(this.parent);
      }
   }

   @Override
   public boolean isPauseScreen() {
      return false;
   }

   public boolean isTrimPage() {
      return this.activePage == AccessorySelectorScreen.SelectorPage.TRIMS;
   }

   public boolean isHeadwearPage() {
      return this.activePage == AccessorySelectorScreen.SelectorPage.HEADWEAR;
   }

   private boolean isInsideTrimViewport(double mouseX, double mouseY) {
      return OpenGlUiRenderer.inside(mouseX, mouseY, CONTENT_X - 4, TRIM_VIEW_TOP, CONTENT_W, TRIM_VIEW_BOTTOM - TRIM_VIEW_TOP);
   }

   private boolean isInsideArtifactViewport(double mouseX, double mouseY) {
      return OpenGlUiRenderer.inside(mouseX, mouseY, CONTENT_X - 4, ACCESSORY_CARD_TOP, CONTENT_W, ACCESSORY_VIEW_BOTTOM - ACCESSORY_CARD_TOP);
   }

   private static int artifactMaxScroll(int artifactCount) {
      return Math.max(0, rows(artifactCount, ACCESSORY_COLUMNS) - ACCESSORY_VISIBLE_ROWS);
   }

   private int trimMaxScroll() {
      return Math.max(0, trimContentHeight() - (TRIM_VIEW_BOTTOM - TRIM_VIEW_TOP));
   }

   private static int trimContentHeight() {
      return 20
         + rows(TRIM_PATTERNS.size(), ACCESSORY_COLUMNS) * 43
         - 7
         + 42
         + rows(LinTrimManager.MATERIALS.size(), ACCESSORY_COLUMNS) * 37
         - 7
         + 42
         + rows(LinTrimPreview.values().length, ACCESSORY_COLUMNS) * 37
         - 7
         + 8;
   }

   private static Identifier patternTexture(String pattern) {
      int split = pattern.indexOf(58);
      String path = split >= 0 ? pattern.substring(split + 1) : pattern;
      return Identifier.fromNamespaceAndPath("lin_client", "textures/trim_template/" + path + ".png");
   }

   private static Identifier uiTexture(String name) {
      return Identifier.fromNamespaceAndPath("lin_client", "textures/ui/lunar/" + name + ".png");
   }

   private static void drawUiTexture(
      GuiGraphics graphics,
      Identifier texture,
      int x,
      int y,
      int width,
      int height,
      int textureWidth,
      int textureHeight
   ) {
      graphics.blit(
         RenderPipelines.GUI_TEXTURED,
         texture,
         x,
         y,
         0.0F,
         0.0F,
         width,
         height,
         textureWidth,
         textureHeight,
         textureWidth,
         textureHeight
      );
   }

   private static int materialColor(String material) {
      return switch (material) {
         case "gold" -> -2051012;
         case "iron" -> -3682863;
         case "diamond" -> -11216430;
         case "netherite" -> -10331552;
         case "redstone" -> -2538942;
         case "copper" -> -4689077;
         case "emerald" -> -13252245;
         case "lapis" -> -12490296;
         case "quartz" -> -1515824;
         case "amethyst" -> -5870384;
         case "resin" -> -2586324;
         default -> -8087639;
      };
   }

   private void updateLayout() {
      float availableWidth = Math.max(1, this.width);
      float availableHeight = Math.max(1, this.height);
      this.uiScale = Math.min(MAX_UI_SCALE, Math.min(availableWidth / WIDTH, availableHeight / HEIGHT));
      this.originX = Math.round((this.width - WIDTH * this.uiScale) * 0.5F);
      this.originY = Math.round((this.height - HEIGHT * this.uiScale) * 0.5F);
      this.updateSearchBoxLayout();
   }

   private void updateSearchBoxLayout() {
      if (this.searchBox != null) {
         int left = this.toScreenX(SEARCH_X);
         int top = this.toScreenY(SEARCH_Y);
         int right = this.toScreenX(SEARCH_X + SEARCH_W);
         int bottom = this.toScreenY(SEARCH_Y + SEARCH_H);
         this.searchBox.setRectangle(Math.max(1, right - left), Math.max(1, bottom - top), left, top);
         this.searchBox.setVisualMetrics(this.uiScale, SEARCH_TEXT_X - SEARCH_X, SEARCH_TEXT_W, 9.0F);
          boolean visible = this.isSearchPage();
         this.searchBox.setVisible(visible);
         this.searchBox.active = visible;
      }
   }

   private void selectPage(AccessorySelectorScreen.SelectorPage page) {
      this.activePage = page;
      if (page == AccessorySelectorScreen.SelectorPage.COSMETICS && this.activeCosmeticPage == null) {
         this.activeCosmeticPage = AccessorySelectorScreen.CosmeticPage.CAPES;
      }
       this.scrollRow = 0;
       this.capeScrollRow = 0;
       this.petScrollRow = 0;
      this.trimScroll = 0;
      this.artifactScrollRow = 0;
       if (!this.isSearchPage() && this.searchBox != null && this.searchBox.isFocused()) {
         this.clearFocus();
      }

      this.updateSearchBoxLayout();
   }

   private int activeSidebarIndex() {
      for (int index = 0; index < 6; index++) {
         if (this.isSidebarEntryActive(index)) {
            return index;
         }
      }
      return 0;
   }

   private void selectSidebarEntry(int index) {
      if (index == 0) {
         this.activeCosmeticPage = AccessorySelectorScreen.CosmeticPage.CAPES;
         this.selectPage(AccessorySelectorScreen.SelectorPage.COSMETICS);
      } else if (index == 2) {
         this.activeCosmeticPage = AccessorySelectorScreen.CosmeticPage.PETS;
         this.selectPage(AccessorySelectorScreen.SelectorPage.COSMETICS);
      } else {
         AccessorySelectorScreen.SelectorPage page = sidebarPage(index);
         if (page != null) {
            this.selectPage(page);
         }
      }
   }

   private String activeCategoryTitle() {
      return switch (this.activeSidebarIndex()) {
         case 0 -> "全部披风";
         case 1 -> "全部头饰";
         case 2 -> "全部肩宠";
         case 3 -> "全部翅膀";
         case 4 -> "盔甲纹饰";
         case 5 -> "神器皮肤";
         default -> "饰品";
      };
   }

   private List<AccessoryDefinition> filteredAccessories(AccessorySlot slot) {
      List<AccessoryDefinition> values = AccessoryRegistry.values(slot);
      String[] terms = this.hasSearchQuery() ? normalizeSearch(this.searchBox.getValue()).split("\\s+") : new String[0];
      return values.stream()
         .filter(definition -> terms.length == 0 || matchesSearch(definition, terms))
         .sorted((left, right) -> this.compareNames(left.displayName(), right.displayName()))
         .toList();
   }

   private boolean hasSearchQuery() {
      return this.searchBox != null && !this.searchBox.getValue().isBlank();
   }

   private boolean isAccessoryPage() {
      return this.activePage == AccessorySelectorScreen.SelectorPage.HEADWEAR
         || this.activePage == AccessorySelectorScreen.SelectorPage.WINGS;
   }

   private boolean canDragPreview() {
      return this.activePage != AccessorySelectorScreen.SelectorPage.ARTIFACTS;
   }

   private boolean isCapePage() {
      return this.activePage == AccessorySelectorScreen.SelectorPage.COSMETICS
         && this.activeCosmeticPage == AccessorySelectorScreen.CosmeticPage.CAPES;
   }

   private boolean isPetPage() {
      return this.activePage == AccessorySelectorScreen.SelectorPage.COSMETICS
         && this.activeCosmeticPage == AccessorySelectorScreen.CosmeticPage.PETS;
   }

   private boolean isSearchPage() {
      return this.isAccessoryPage() || this.isCapePage() || this.isPetPage();
   }

   private List<LunarCape> filteredCapes() {
      List<LunarCape> values = LunarCapeRegistry.values();
      String[] terms = this.hasSearchQuery() ? normalizeSearch(this.searchBox.getValue()).split("\\s+") : new String[0];
      return values.stream()
         .filter(cape -> terms.length == 0 || matchesSearch(cape, terms))
         .sorted((left, right) -> this.compareNames(left.displayName(), right.displayName()))
         .toList();
   }

   private List<LunarPet> filteredPets() {
      List<LunarPet> values = LunarPetRegistry.values();
      String[] terms = this.hasSearchQuery() ? normalizeSearch(this.searchBox.getValue()).split("\\s+") : new String[0];
      return values.stream()
         .filter(pet -> terms.length == 0 || matchesSearch(pet, terms))
         .sorted((left, right) -> this.compareNames(left.displayName(), right.displayName()))
         .toList();
   }

   private int compareNames(String left, String right) {
      int comparison = left.compareToIgnoreCase(right);
      return this.sortAscending ? comparison : -comparison;
   }

   private static boolean matchesSearch(AccessoryDefinition definition, String[] terms) {
      String haystack = normalizeSearch(definition.id() + " " + definition.displayName());

      for (String term : terms) {
         if (!term.isEmpty() && !haystack.contains(term)) {
            return false;
         }
      }

      return true;
   }

   private static boolean matchesSearch(LunarCape cape, String[] terms) {
      String haystack = normalizeSearch(cape.id() + " " + cape.displayName() + " " + cape.relativePath());
      for (String term : terms) {
         if (!term.isEmpty() && !haystack.contains(term)) {
            return false;
         }
      }
      return true;
   }

   private static boolean matchesSearch(LunarPet pet, String[] terms) {
      String haystack = normalizeSearch(pet.id() + " " + pet.displayName() + " " + pet.definitionPath());
      for (String term : terms) {
         if (!term.isEmpty() && !haystack.contains(term)) {
            return false;
         }
      }
      return true;
   }

   private static String normalizeSearch(String value) {
      return value.toLowerCase(Locale.ROOT).replace('_', ' ').replace('-', ' ').trim();
   }

   private static int accessoryMaxScroll(int itemCount) {
      return Math.max(0, rows(itemCount, ACCESSORY_COLUMNS) - ACCESSORY_VISIBLE_ROWS);
   }

   private static int capeMaxScroll(int itemCount) {
      return Math.max(0, rows(itemCount, ACCESSORY_COLUMNS) - ACCESSORY_VISIBLE_ROWS);
   }

   private double toLocalX(double mouseX) {
      return (mouseX - this.originX) / this.uiScale;
   }

   private double toLocalY(double mouseY) {
      return (mouseY - this.originY) / this.uiScale;
   }

   private int toScreenX(int localX) {
      return Math.round(this.originX + localX * this.uiScale);
   }

   private int toScreenY(int localY) {
      return Math.round(this.originY + localY * this.uiScale);
   }

   private static void drawIcon(GuiGraphics graphics, AccessoryDefinition definition, int x, int y, int size) {
      drawIcon(graphics, definition, AccessoryRegistry.headwearVariant(definition), x, y, size);
   }

   private static void drawIcon(
      GuiGraphics graphics, AccessoryDefinition definition, HeadwearVariant variant, int x, int y, int size
   ) {
      Minecraft minecraft = Minecraft.getInstance();
      Matrix3x2fStack pose = graphics.pose();
      pose.pushMatrix();

      try {
         float scale = size / 16.0F;
         pose.translate(x, y);
         pose.scale(scale, scale);
         if (minecraft.player == null) {
            graphics.renderItem(AccessoryItemModels.stack(definition, variant), 0, 0, definition.customModelData());
         } else {
            graphics.renderItem(minecraft.player, AccessoryItemModels.stack(definition, variant), 0, 0, definition.customModelData());
         }
      } finally {
         pose.popMatrix();
      }
   }

   private static void drawArtifactIcon(GuiGraphics graphics, ArtifactSkins.Option option, int x, int y, int size) {
      Minecraft minecraft = Minecraft.getInstance();
      Matrix3x2fStack pose = graphics.pose();
      pose.pushMatrix();

      try {
         float scale = size / 16.0F;
         pose.translate(x, y);
         pose.scale(scale, scale);
         if (minecraft.player == null) {
            graphics.renderItem(ArtifactSkins.previewStack(option), 0, 0, option.seed());
         } else {
            graphics.renderItem(minecraft.player, ArtifactSkins.previewStack(option), 0, 0, option.seed());
         }
      } finally {
         pose.popMatrix();
      }
   }

   private static String truncate(String value, float size, float maxWidth) {
      if (value != null && !value.isEmpty()) {
         if (FontManager.width(value, size) <= maxWidth) {
            return value;
         }

         String suffix = "...";
         String current = value;

         while (!current.isEmpty() && FontManager.width(current + suffix, size) > maxWidth) {
            current = current.substring(0, current.length() - 1);
         }

         return current.isEmpty() ? "" : current + suffix;
      } else {
         return "";
      }
   }

   private static int rows(int count, int columns) {
      return (count + columns - 1) / columns;
   }

   private static int clamp(int value, int min, int max) {
      return Math.max(min, Math.min(max, value));
   }

   private static float clamp(float value, float min, float max) {
      return Math.max(min, Math.min(max, value));
   }

   private static float normalizeDegrees(float value) {
      float normalized = value % 360.0F;
      if (normalized > 180.0F) {
         normalized -= 360.0F;
      } else if (normalized < -180.0F) {
         normalized += 360.0F;
      }
      return normalized;
   }

   static {
      List<String> patterns = new ArrayList<>();
      patterns.add("none");
      patterns.addAll(LinTrimManager.PATTERNS);
      TRIM_PATTERNS = List.copyOf(patterns);
   }

    private enum SelectorPage {
      HEADWEAR(AccessorySlot.HEADWEAR),
      WINGS(AccessorySlot.WINGS),
       TRIMS(null),
       ARTIFACTS(null),
       COSMETICS(null);

      private final AccessorySlot slot;

      SelectorPage(AccessorySlot slot) {
         this.slot = slot;
       }
    }

    private enum CosmeticPage {
       CAPES,
       PETS
    }
}
