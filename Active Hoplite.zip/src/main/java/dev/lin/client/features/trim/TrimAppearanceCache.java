package dev.lin.client.features.trim;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.core.Holder;
import net.minecraft.core.Registry;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.world.item.equipment.trim.ArmorTrim;
import net.minecraft.world.item.equipment.trim.TrimMaterial;
import net.minecraft.world.item.equipment.trim.TrimPattern;

/** Render-only trims: real registered materials and distinct custom pattern identities. */
final class TrimAppearanceCache {
    private Registry<TrimMaterial> registry;
    private final Map<Selection, ArmorTrim> trims = new HashMap<>();
    private String lastPattern, lastMaterial;
    private ArmorTrim lastTrim;

    ArmorTrim get(Registry<TrimMaterial> materials, String pattern, String material) {
        if (materials != registry) {
            clear();
            registry = materials;
        }
        if (materials == null || pattern == null || "none".equals(pattern)) return null;
        if (pattern.equals(lastPattern) && material.equals(lastMaterial)) return lastTrim;
        Selection selection = new Selection(pattern, material);
        ArmorTrim trim = trims.get(selection);
        if (trim == null) {
            Identifier asset = Identifier.tryParse(pattern);
            var registeredMaterial = materials.get(Identifier.fromNamespaceAndPath("minecraft", material)).orElse(null);
            if (asset == null || registeredMaterial == null) return null;
            // Vanilla layerAssetId adds the layer directory and the material's palette suffix,
            // including its darker variant on armor made from the same material.
            var selectedPattern = Holder.direct(new TrimPattern(asset.withSuffix("_trim"),
                Component.literal(pattern), false));
            trim = new ArmorTrim(registeredMaterial, selectedPattern);
            trims.put(selection, trim);
        }
        lastPattern = pattern;
        lastMaterial = material;
        lastTrim = trim;
        return trim;
    }

    void clear() {
        trims.clear();
        registry = null;
        lastPattern = lastMaterial = null;
        lastTrim = null;
    }

    private record Selection(String pattern, String material) {}
}
