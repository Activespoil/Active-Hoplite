package dev.lin.client.shared.render;

/** Immutable circle samples shared by UI renderers; retains no frame or GPU state. */
public final class UnitCircle {
    private static final int MAX_CACHED_SEGMENTS = 128;
    private static final UnitCircle[] CACHED = new UnitCircle[MAX_CACHED_SEGMENTS + 1];
    static {
        for (int segments = 1; segments < CACHED.length; segments++) {
            CACHED[segments] = new UnitCircle(segments);
        }
    }
    private final float[] cosine;
    private final float[] sine;

    private UnitCircle(int segments) {
        cosine = new float[segments + 1];
        sine = new float[segments + 1];
        for (int point = 0; point <= segments; point++) {
            // Keep the exact original arithmetic and the separate endpoint at 2*pi.
            double angle = (Math.PI * 2) * point / segments;
            cosine[point] = (float) Math.cos(angle);
            sine[point] = (float) Math.sin(angle);
        }
    }

    public static UnitCircle of(int segments) {
        if (segments < 1) throw new IllegalArgumentException("segments must be positive");
        return segments <= MAX_CACHED_SEGMENTS ? CACHED[segments] : new UnitCircle(segments);
    }

    public float cos(int point) { return cosine[point]; }
    public float sin(int point) { return sine[point]; }
}
