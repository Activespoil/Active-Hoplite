package dev.lin.client.shared;

/** Lens-compatible spring feedback; native input and business values never depend on it.
 * Design/physics reference: MIT (c) 2026 DayDreamInAReverie, design-systems/Lens.
 * See META-INF/licenses/design-systems-Lens-MIT.txt for upstream attribution.
 */
public final class LensMotion {
    public static final int FAST_MS=160, NORMAL_MS=240, SETTLE_MS=280;
    private LensMotion() {}
    public static final class Spring {
        private float value, velocity, target;
        public Spring(float initial){snap(initial);}
        public float value(){return value;}
        public float velocity(){return velocity;}
        public boolean isSettled(){return Math.abs(velocity)<.025f && Math.abs(target-value)<.005f;}
        public void snap(float position){value=target=position;velocity=0;}
        /** Add feedback without teleporting the current pose or restarting its spring. */
        public void impulse(float amount){if(Float.isFinite(amount))velocity+=amount;}
        public float update(float next,double seconds){
            if(!Float.isFinite(next))return value;
            target=next;
            if(!Double.isFinite(seconds)||seconds<=0)return value;
            double remaining=Math.min(.08,seconds);
            while(remaining>0){
                float dt=(float)Math.min(remaining,1.0/180.0);
                velocity+=(260f*(target-value)-30f*velocity)*dt;
                value+=velocity*dt;remaining-=dt;
            }
            if(isSettled()){value=target;velocity=0;}
            return value;
        }
    }
}
