package dev.lin.client.shared;

import java.util.function.DoubleConsumer;

/** A native slider gesture: continuous values preview immediately; seeking commits once on release. */
public final class SliderGesture {
    private DoubleConsumer action;
    private boolean releaseOnly;
    private double value;

    public boolean active() { return action != null; }
    public boolean releaseOnly() { return releaseOnly; }
    public double value() { return value; }

    public void start(DoubleConsumer action, boolean releaseOnly, double value) {
        cancel();
        this.action = action;
        this.releaseOnly = releaseOnly;
        update(value);
    }

    public void update(double value) {
        if (action == null || !Double.isFinite(value)) return;
        this.value = Math.max(0, Math.min(1, value));
        if (!releaseOnly) action.accept(this.value);
    }

    public void release() {
        DoubleConsumer commit = releaseOnly ? action : null;
        cancel(); // Clear first, even if a business callback fails or changes the screen.
        if (commit != null) commit.accept(value);
    }

    public void cancel() { action = null; releaseOnly = false; }
}
