package dev.lin.client.shared;

/** Shared motion tokens and frame-rate-independent interpolation, with no renderer dependency. */
public final class UiMotion {
    public static final long ENTER_MS = 260, EXIT_MS = 170, HOVER_MS = 180;
    private UiMotion() {}
    public static long nowMillis() { return System.nanoTime() / 1_000_000L; }
    public static float clamp(float t) { return Math.max(0, Math.min(1, t)); }
    public static float out(float t) { float u=1-clamp(t); return 1-u*u*u; }
    public static float in(float t) { float u=clamp(t); return u*u*u; }
    public static float progress(long elapsed, long duration) {
        return duration<=0?1:clamp((float)elapsed/duration);
    }
    public static float follow(float value, float target, double seconds) {
        if(seconds<=0)return value;
        float next=target+(value-target)*(float)Math.exp(-3*seconds/(HOVER_MS/1000.0));
        return Math.abs(next-target)<0.001f?target:next;
    }
    public static float scale(float visibility) { return .968f+.032f*clamp(visibility); }
}
