package dev.lin.client.shared;
import java.util.*;import java.util.zip.*;
/** One immutable entry list per open ZipFile; never caches resource bytes or changes lookup order. */
public final class ZipEntrySnapshot {
 private static final Map<ZipFile,List<ZipEntry>> CACHE=Collections.synchronizedMap(new WeakHashMap<>());
 private ZipEntrySnapshot(){}
 public static Enumeration<? extends ZipEntry> entries(ZipFile zip){
  List<ZipEntry> list;
  synchronized(CACHE){
   list=CACHE.get(zip);
   if(list==null){list=List.copyOf(Collections.list(zip.entries()));CACHE.put(zip,list);}
  }
  return Collections.enumeration(list);
 }
}
