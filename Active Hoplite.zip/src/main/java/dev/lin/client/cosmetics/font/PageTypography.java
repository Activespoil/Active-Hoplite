package dev.lin.client.cosmetics.font;

/** Sizes are specified in shared-shell units; compensate only the legacy content fit. */
public final class PageTypography {
    // Shared with the native settings cards; sizes are shell units, not page-local pixels.
    public static final float BODY=13f, CAPTION=10f, TITLE=18f;
    public static float cosmetics(float oldSize,float contentToShell) {
        float target=oldSize<=7.5f?CAPTION:oldSize<=13f?BODY:TITLE;
        return target / Math.max(.01f,contentToShell);
    }
    public static float music(float oldSize,float contentToShell) {
        float target=oldSize<=11?CAPTION:oldSize<=13?BODY:oldSize<=19?14:oldSize<=27?TITLE:24;
        return target / Math.max(.01f,contentToShell);
    }
    private PageTypography() {}
}
