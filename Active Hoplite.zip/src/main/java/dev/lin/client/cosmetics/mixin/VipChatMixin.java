/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.llamalad7.mixinextras.injector.wrapoperation.Operation
 *  com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation
 *  com.mojang.authlib.GameProfile
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.ModifyArg
 */
package dev.lin.client.cosmetics.mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.mojang.authlib.GameProfile;
import dev.lin.client.cosmetics.vip.VipIcons;
import java.time.Instant;
import net.minecraft.client.GuiMessageTag;
import net.minecraft.client.gui.components.ChatComponent;
import net.minecraft.client.multiplayer.chat.ChatListener;
import net.minecraft.network.chat.ChatType;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MessageSignature;
import net.minecraft.network.chat.PlayerChatMessage;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;

@Mixin(value={ChatListener.class})
public abstract class VipChatMixin {
    @WrapOperation(method={"method_44943"}, at={@At(value="INVOKE", target="Lnet/minecraft/class_338;method_44811(Lnet/minecraft/class_2561;Lnet/minecraft/class_7469;Lnet/minecraft/class_7591;)V")})
    private void lin$vip(ChatComponent chat, Component displayed, MessageSignature signature, GuiMessageTag tag, Operation<Void> operation, ChatType.Bound bound, PlayerChatMessage signed, Component original, GameProfile profile, boolean secure, Instant received) {
        operation.call(new Object[]{chat, VipIcons.decorateChat(displayed, profile.id()), signature, tag});
    }

    @ModifyArg(method={"method_44736", "method_45745"}, at=@At(value="INVOKE", target="Lnet/minecraft/class_338;method_1812(Lnet/minecraft/class_2561;)V"), index=0)
    private Component lin$vipPluginChat(Component displayed) {
        return VipIcons.detectedChat(displayed);
    }
}

