package dev.lin.client.cosmetics.model;

import org.joml.Matrix4f;
import org.joml.Vector3f;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;

/** Small rigid joints for Hoplite's static item models; no mesh rebuilding per frame. */
public final class HoplitePetAnimation {
    private static final Map<CosmeticMesh, Rig> RIGS =
            Collections.synchronizedMap(new WeakHashMap<>());

    private HoplitePetAnimation() {}

    private record Rig(String name, List<HoplitePetRig.Part> parts, int[] joints,
                       Vector3f[] pivots) {}

    public static void register(String name, CosmeticMesh mesh, int[] elementEnds,
                                float centerX, float maxY, float centerZ) {
        List<HoplitePetRig.Part> parts = HoplitePetRig.parts(name);
        int[] joints = new int[mesh.vertexCount()];
        Arrays.fill(joints, -1);
        Vector3f[] pivots = new Vector3f[parts.size()];
        for (int joint = 0; joint < parts.size(); joint++) {
            HoplitePetRig.Part part = parts.get(joint);
            pivots[joint] = new Vector3f((part.x() - centerX) / 16f,
                    (-part.y() - maxY) / 16f, (part.z() - centerZ) / 16f);
            for (int element : part.elements()) {
                if (element < 0 || element >= elementEnds.length)
                    throw new IllegalArgumentException("Pet rig element outside model: " + name);
                int start = element == 0 ? 0 : elementEnds[element - 1];
                for (int vertex = start; vertex < elementEnds[element]; vertex++) {
                    if (joints[vertex] != -1)
                        throw new IllegalArgumentException("Overlapping pet joints: " + name);
                    joints[vertex] = joint;
                }
            }
        }
        RIGS.put(mesh, new Rig(name, parts, joints, pivots));
    }

    public static Pose pose(CosmeticMesh mesh, float ticks, float stride,
                            float movement, float lookYaw) {
        Rig rig = RIGS.get(mesh);
        if (rig == null || rig.parts.isEmpty()) return null;
        float active = Math.max(0f, Math.min(1f, movement));
        float time = ticks + (rig.name.hashCode() & 255);
        Matrix4f[] transforms = new Matrix4f[rig.parts.size()];
        for (int joint = 0; joint < transforms.length; joint++) {
            HoplitePetRig.Part part = rig.parts.get(joint);
            Vector3f pivot = rig.pivots[joint];
            Matrix4f transform = new Matrix4f().translation(pivot);
            float gait = (float) Math.sin(stride) * part.phase() * active;
            switch (part.kind()) {
                case HEAD -> transform.rotateY(lookYaw * (1f - active * .65f)
                                + (float) Math.sin(time * .045f) * .09f * part.phase())
                        .rotateX((float) Math.sin(time * .08f) * .025f);
                case TAIL -> transform.rotateY((float) Math.sin(time * .18f)
                        * (.16f + active * .15f));
                case LEG -> {
                    if ((rig.name.contains("spider") || rig.name.equals("crab_pet"))) {
                        transform.rotateY(gait * .18f)
                                .rotateZ((float) Math.cos(stride) * part.phase() * active * .08f);
                    } else {
                        transform.rotateX(gait * (rig.name.equals("bunny_carrot_pet") ? .25f : .42f));
                    }
                }
                case ARM -> transform.rotateX(gait * .3f)
                        .rotateZ(part.phase() * (.018f + (float) Math.sin(time * .055f) * .018f));
                case WING -> {
                    float flap = part.phase() * (.12f + (float) Math.sin(time * .5f) * (.2f + active * .16f));
                    if (rig.name.equals("valentines_allay_pet")) transform.rotateY(flap);
                    else transform.rotateZ(flap);
                }
                case LID -> transform.translate(0f,
                        -(0.015f + (float) (1.0 + Math.sin(time * .045f)) * .035f), 0f);
            }
            transforms[joint] = transform.translate(-pivot.x, -pivot.y, -pivot.z);
        }
        return new Pose(rig.joints, transforms);
    }

    public record Body(float lift, float pitch, float roll, float breath) {}

    public static Body body(String name, float ticks, float stride, float movement) {
        float active = Math.max(0f, Math.min(1f, movement));
        float time = ticks + (name.hashCode() & 255);
        boolean floats = name.equals("ghost_pet") || name.equals("flame_sprite_pet")
                || name.equals("baby_breeze_pet") || name.equals("sky_beluga_pet")
                || name.equals("valentines_allay_pet");
        float lift = floats ? .055f + (float) Math.sin(time * .09f) * .025f
                : Math.abs((float) Math.sin(stride)) * active * .025f;
        float pitch = (float) Math.sin(stride * 2f) * active * .025f;
        float roll = (float) Math.sin(stride) * active * .025f
                + (float) Math.sin(time * .055f) * (1f - active) * .012f;
        float breath = (float) Math.sin(time * .1f) * .006f;
        return new Body(lift, pitch, roll, breath);
    }

    public static final class Pose {
        private final int[] joints;
        private final Matrix4f[] transforms;

        private Pose(int[] joints, Matrix4f[] transforms) {
            this.joints = joints;
            this.transforms = transforms;
        }

        public void transform(int index, Vector3f position, Vector3f normal) {
            int joint = joints[index];
            if (joint < 0) return;
            transforms[joint].transformPosition(position);
            transforms[joint].transformDirection(normal);
        }
    }
}
