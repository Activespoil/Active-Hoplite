package dev.lin.client.cosmetics.assets;

import com.mojang.blaze3d.platform.NativeImage;
import java.awt.image.BufferedImage;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.Supplier;
import org.lwjgl.system.MemoryUtil;

/** Render-thread cache of decoded ABGR frames; owners release their entries with the texture. */
public final class AnimationFrameCache {
    private final long budget;
    private long bytes;
    private final Map<Key, Frame> frames = new LinkedHashMap<>(32, .75f, true);
    private record Key(Object owner, int frame, int variant) {}
    public AnimationFrameCache(long budget) { this.budget = Math.max(0, budget); }

    public Frame get(Object owner, int frame, int variant, Supplier<BufferedImage> decode) {
        Key key = new Key(owner, frame, variant);
        Frame cached = frames.get(key);
        if (cached != null) return cached;
        BufferedImage image = decode.get();
        int width = image.getWidth(), height = image.getHeight();
        int[] pixels = image.getRGB(0, 0, width, height, null, 0, width);
        for (int i = 0; i < pixels.length; i++) {
            int argb = pixels[i];
            pixels[i] = argb & 0xFF00FF00 | (argb & 0xFF0000) >>> 16 | (argb & 0xFF) << 16;
        }
        Frame result = new Frame(width, height, pixels);
        long size = result.bytes();
        if (size <= budget) {
            var it = frames.entrySet().iterator();
            while (bytes + size > budget && it.hasNext()) { bytes -= it.next().getValue().bytes(); it.remove(); }
            frames.put(key, result); bytes += size;
        }
        return result;
    }

    public void release(Object owner) {
        var it = frames.entrySet().iterator();
        while (it.hasNext()) {
            var entry = it.next();
            if (entry.getKey().owner == owner) { bytes -= entry.getValue().bytes(); it.remove(); }
        }
    }

    public static final class Frame {
        private final int width, height;
        private final int[] pixels;
        private Frame(int width, int height, int[] pixels) { this.width = width; this.height = height; this.pixels = pixels; }
        private long bytes() { return (long) pixels.length * Integer.BYTES; }
        public void write(NativeImage target) {
            if (target.format() != NativeImage.Format.RGBA)
                throw new IllegalArgumentException("Expected RGBA animation texture");
            long address = target.getPointer();
            if (address == 0) throw new IllegalStateException("Closed animation texture");
            int targetWidth = target.getWidth(), targetHeight = target.getHeight();
            int columns = Math.min(width, targetWidth), rows = Math.min(height, targetHeight);
            var buffer = MemoryUtil.memIntBuffer(address, Math.multiplyExact(targetWidth, targetHeight));
            for (int y = 0; y < rows; y++) buffer.position(y * targetWidth).put(pixels, y * width, columns);
        }
    }
}
