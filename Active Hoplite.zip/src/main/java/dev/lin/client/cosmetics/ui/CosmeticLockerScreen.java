package dev.lin.client.cosmetics.ui;

import dev.lin.client.features.accessory.AccessoryDefinition;
import dev.lin.client.features.accessory.AccessoryRegistry;
import dev.lin.client.features.accessory.AccessorySlot;
import dev.lin.client.features.accessory.HeadwearVariant;
import dev.lin.client.cosmetics.pods.PodSkins;
import dev.lin.client.features.artifact.ArtifactPackManager;
import dev.lin.client.features.artifact.ArtifactSkinConfig;
import dev.lin.client.features.artifact.ArtifactSkins;
import dev.lin.client.features.config.ClientAccessoryConfig;
import dev.lin.client.features.cape.LunarCape;
import dev.lin.client.features.cape.LunarCapeRegistry;
import dev.lin.client.features.cape.LunarCapeTextureManager;
import dev.lin.client.features.pet.LunarPetRegistry;
import dev.lin.client.features.render.AccessoryItemModels;
import dev.lin.client.features.render.AccessoryWorldRenderer;
import dev.lin.client.features.trim.LinTrimManager;
import dev.lin.client.features.trim.LinTrimPreview;
import dev.lin.client.cosmetics.LinClient;
import dev.lin.client.cosmetics.assets.CosmeticAssetManager;
import dev.lin.client.cosmetics.catalog.CosmeticCategory;
import dev.lin.client.cosmetics.catalog.CosmeticDefinition;
import dev.lin.client.cosmetics.catalog.LunarCatalog;
import dev.lin.client.cosmetics.config.CosmeticConfig;
import dev.lin.client.cosmetics.font.FontManager;
import dev.lin.client.cosmetics.model.BuiltinCosmeticMeshes;
import dev.lin.client.cosmetics.model.CosmeticMesh;
import dev.lin.client.cosmetics.model.CosmeticRenderData;
import dev.lin.client.cosmetics.render.CosmeticWorldRenderer;
import dev.lin.client.cosmetics.render.OpenGlUiRenderer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.renderer.entity.EntityRenderDispatcher;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.state.AvatarRenderState;
import net.minecraft.client.renderer.entity.state.EntityRenderState;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.core.ClientAsset;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.PlayerSkin;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import org.joml.Matrix3x2fStack;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.EnumMap;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/** Pixel-aligned standalone recreation of Lunar Client's Locker. */
public final class CosmeticLockerScreen extends Screen {
    private static final int DESIGN_WIDTH = 1252;
    private static final int DESIGN_HEIGHT = 536;
    private static final float GALLERY_LEFT = ClientShell.SIDE + 20;
    private static final float GALLERY_TOP = 82;
    private static final int GALLERY_HEIGHT = 1158;
    private static final int CATEGORY_HEIGHT = 36;
    private float categoryIndicator = -1;
    private static final int PANEL_X = 0;
    private static final int PANEL_Y = 0;
    private static final int PANEL_W = 1000;
    private static final int PANEL_H = 536;
    private static final int SIDEBAR_W = 60;
    private static final int NAV_STEP = 40;
    private static final LockerSection[] NAV_SECTIONS = {
            LockerSection.COSMETICS, LockerSection.LUNAR_WINGS,
            LockerSection.COMPANIONS, LockerSection.PETS, LockerSection.HEADWEAR,
            LockerSection.FLOATING_EFFECTS,
            LockerSection.ARROW_TRAILS, LockerSection.VIP_ICONS,
            LockerSection.ARMOR_TRIMS, LockerSection.ARTIFACT_SKINS};
    private static final int NAV_TOP = (PANEL_H - (NAV_SECTIONS.length + 1) * NAV_STEP) / 2;
    private static final int CONTENT_X = 100;
    private static final int CONTENT_RIGHT = 1226;
    private static final int PREVIEW_X = 2000;
    private static final int PREVIEW_W = 360;
    private static final int SEARCH_X = 100;
    private static final int SEARCH_Y = 9;
    private static final int SEARCH_W = 480;
    private static final int SEARCH_H = 54;
    private static final int SORT_X = SEARCH_X + SEARCH_W + 12;
    private static final int SORT_W = 126;
    private static final int FAVORITES_X = SORT_X + SORT_W + 12;
    private static final int FAVORITES_W = 114;
    private static final int CARD_TOP = 90;
    private static final int SOURCE_TAB_H = 48;
    // Six large showcases filling the 2x3 gallery canvas cleanly.
    private static final int COLUMNS = 3;
    private static final int VISIBLE_ROWS = 2;
    private static final int HEADWEAR_COLUMNS = COLUMNS;
    private static final int HEADWEAR_W = 354;
    private static final int HEADWEAR_TOP = 156;
    private static final int HEADWEAR_STEP = 514;
    private static final int HEADWEAR_H = 486;
    private static final int CARD_W = 354;
    private static final int CARD_H = 486;
    private static final int CARD_PREVIEW_H = 316;
    private static final int CARD_GAP = 32;
    private static final int ROW_STEP = 514;
    private static final int WING_CARD_H = 486;
    private static final int WING_PREVIEW_H = CARD_PREVIEW_H;
    private static final int WING_ROW_STEP = 514;
    private static final int CAPE_CARD_H = 486;
    private static final int CAPE_PREVIEW_H = CARD_PREVIEW_H;
    private static final int CAPE_ROW_STEP = 514;
    private static final int CAPE_VISIBLE_ROWS = VISIBLE_ROWS;
    private static final int CAPE_TAB_W =
            (CONTENT_RIGHT - CONTENT_X - CARD_GAP * 2) / 3;
    private static final int CAPE_VIEW_LUNAR = 0;
    private static final int CAPE_VIEW_OFFICIAL = 1;
    private static final int CAPE_VIEW_DUNGEON = 2;
    private static final int FLOATING_VIEW_LUNAR = 0;
    private static final int FLOATING_VIEW_HOPLITE = 1;
    private static final int FLOATING_ROW_STEP = 514;
    private static final int FLOATING_CARD_H = 486;
    private static final int FLOATING_PREVIEW_H = CARD_PREVIEW_H;
    private static final int FLOATING_SCOPE_X = PREVIEW_X + 16;
    private static final int FLOATING_SCOPE_Y = 22;
    private static final int FLOATING_SCOPE_W = 68;
    private static final int FLOATING_SCOPE_GAP = 6;
    private static final int FLOATING_NUMBER_X = PREVIEW_X + 172;
    private static final int FLOATING_NUMBER_Y = 22;
    private static final int FLOATING_NUMBER_W = 172;
    private static final int FLOATING_NUMBER_H = 28;
    private static final int FIT_CARD_W = CARD_W;
    private static final int FIT_CARD_H = 486;
    private static final int FIT_PREVIEW_H = CARD_PREVIEW_H;
    private static final int FIT_ROW_STEP = 514;
    private static final int FIT_COLUMNS = COLUMNS;
    private static final int FIT_VISIBLE_ROWS = VISIBLE_ROWS;
    private static final int VIEW_BOTTOM = 1158;
    private static final int SCROLL_X = CONTENT_RIGHT + 16;
    private static final int PREVIEW_DRAG_X = PREVIEW_X + 6;
    private static final int PREVIEW_DRAG_W = PREVIEW_W - 12;
    private static final int PREVIEW_ENTITY_TOP = 54;
    private static final int PREVIEW_ENTITY_BOTTOM = 506;
    private static final int PREVIEW_ENTITY_OFFSET_Y = 0;
    // Unified right preview column: large front-facing avatar, view bar, active slots, action button.
    private static final int PREVIEW_CONTENT_H = 774;
    private static final int PREVIEW_NAME_Y = 514;
    private static final int PREVIEW_STATUS_Y = 548;
    private static final int PREVIEW_ARMOR_LABEL_Y = 505;
    private static final int PREVIEW_HINT_Y = 590;
    private static final int PREVIEW_VIEW_ROW_Y = 582;
    private static final int PREVIEW_VIEW_BTN_W = 104;
    private static final int PREVIEW_VIEW_BTN_H = 34;
    private static final int PREVIEW_SLOTS_Y = 630;
    private static final int PREVIEW_ACTION_Y = 716;
    private static final int PREVIEW_ACTION_H = 52;
    private static final int PREVIEW_ACTION_TEXT_Y = PREVIEW_ACTION_Y + (PREVIEW_ACTION_H - 8) / 2;
    private static final int ARMOR_BUTTON_Y = 532;
    private static final int ARMOR_BUTTON_SIZE = 40;
    private static final int ARMOR_BUTTON_GAP = 9;
    private static final int SWORD_BUTTON_Y = ARMOR_BUTTON_Y;
    private static final int ARMOR_MENU_WIDTH = 112;
    private static final int ARMOR_MENU_ROW_HEIGHT = 27;
    private boolean customModelPicker;
    private boolean artifactHandSettings;
    private boolean artifactMainHand = true;
    private int draggingArtifactTransform = -1;
    private int customScroll;
    private int layoutWidth() {
        if (section != LockerSection.ARTIFACT_SKINS) return DESIGN_WIDTH;
        return artifactHandSettings ? DESIGN_WIDTH + 298 : customModelPicker ? DESIGN_WIDTH + 252 : DESIGN_WIDTH;
    }

    private void drawCustomDrawer(GuiGraphics graphics, int mouseX, int mouseY) {
        int x = ARTIFACT_HAND_DRAWER_X;
        var artifact = currentArtifact();
        var options = ArtifactSkins.customOptions(artifact);
        customScroll = clamp(customScroll, 0, Math.max(0, (options.size() + 1) / 2 - 3));
        OpenGlUiRenderer.roundedPanel(graphics, x, 48, 246, 470, 18, ClientShell.surface(), ClientShell.border(), 1);
        bodyText(graphics, "自定义 · " + artifact.displayName(), x + 12, 64, 11, TEXT_PRIMARY);
        drawFooterButton(graphics, mouseX, mouseY, x + 216, 55, 22, 24, "×", false);
        bodyText(graphics, "全部模型 · 选择后自动保存", x + 12, 90, 9, TEXT_SECONDARY);
        for (int i = customScroll * 2; i < Math.min(options.size(), customScroll * 2 + 6); i++) {
            var option = options.get(i);
            int v = i - customScroll * 2, cx = x + 10 + v % 2 * 116, cy = 115 + v / 2 * 108;
            boolean selected = option.id().equals(ArtifactSkinConfig.customSkins.get(artifact.id()));
            boolean hovered = inside(mouseX, mouseY, cx, cy, 108, 100);
            OpenGlUiRenderer.roundedPanel(graphics, cx, cy, 108, 100, 10,
                    selected ? ClientShell.selected() : hovered ? ClientShell.hoverSurface() : ClientShell.control(), ClientShell.border(), 1);
            drawArtifactIcon(graphics, option, cx + 24, cy + 8, 60);
            String name = truncate(option.displayName().replace("自定义 · ", ""), 9, 100);
            bodyText(graphics, name, cx + (108 - FontManager.widthRegular(name,bodyFont(9))) * .5f, cy + 78, 9, TEXT_PRIMARY);
            if (selected) bodyText(graphics, "✓", cx + 91, cy + 5, 11, TEXT_PRIMARY);
        }
        if (options.isEmpty()) bodyText(graphics, "暂无可用模型，保留原皮肤", x + 12, 170, 10, TEXT_SECONDARY);
        drawFooterButton(graphics, mouseX, mouseY, x + 12, 457, 222, 28, "恢复 Hoplite 皮肤", false);
        if (options.size() > 6) bodyText(graphics, "滚轮浏览更多模型", x + 12, 495, 9, TEXT_SECONDARY);
    }

    private boolean clickCustomDrawer(double mx, double my) {
        if (inside(mx, my, PREVIEW_X + 18, 22, 86, 28)) {
            customModelPicker = !customModelPicker;
            artifactHandSettings = false;
            customScroll = 0;
            return true;
        }
        if (!customModelPicker || !inside(mx, my, ARTIFACT_HAND_DRAWER_X, 48, 246, 470)) return false;
        if (inside(mx, my, ARTIFACT_HAND_DRAWER_X + 216, 55, 22, 24)) { customModelPicker = false; return true; }
        var artifact = currentArtifact();
        if (inside(mx, my, ARTIFACT_HAND_DRAWER_X + 12, 457, 222, 28)) {
            ArtifactSkinConfig.customSkins.remove(artifact.id()); ArtifactPackManager.selectionChanged(); return true;
        }
        var options = ArtifactSkins.customOptions(artifact);
        for (int i = customScroll * 2; i < Math.min(options.size(), customScroll * 2 + 6); i++) {
            int v = i - customScroll * 2;
            if (inside(mx, my, ARTIFACT_HAND_DRAWER_X + 10 + v % 2 * 116, 115 + v / 2 * 108, 108, 100)) {
                ArtifactSkinConfig.enabled = true;
                ArtifactSkinConfig.setArtifactEnabled(artifact.id(), true);
                ArtifactSkinConfig.customSkins.put(artifact.id(), options.get(i).id());
                ArtifactPackManager.selectionChanged(); return true;
            }
        }
        return true;
    }

    private void drawArtifactHandDrawer(GuiGraphics graphics, int mouseX, int mouseY) {
        OpenGlUiRenderer.roundedPanel(graphics, ARTIFACT_HAND_DRAWER_X, 48,
                ARTIFACT_HAND_DRAWER_W, 470, 18,
                ClientShell.surface(), ClientShell.border(), 1);
        String modelName = ArtifactSkins.selected(currentArtifact()).displayName();
        bodyText(graphics, "手持 · " + truncate(modelName, 16, 210),
                ARTIFACT_HAND_DRAWER_X + 14, 64, 11, TEXT_PRIMARY);
        drawFooterButton(graphics, mouseX, mouseY,
                ARTIFACT_HAND_DRAWER_X + ARTIFACT_HAND_DRAWER_W - 32,
                55, 22, 24, "×", false);
        drawFooterButton(graphics, mouseX, mouseY,
                ARTIFACT_HAND_DRAWER_X + 14, 94, 122, 28,
                "主手", artifactMainHand);
        drawFooterButton(graphics, mouseX, mouseY,
                ARTIFACT_HAND_DRAWER_X + 150, 94, 122, 28,
                "副手", !artifactMainHand);
        for (int index = 0; index < 5; index++) {
            drawArtifactTransformSlider(graphics, mouseX, mouseY, index);
        }
        drawFooterButton(graphics, mouseX, mouseY,
                ARTIFACT_HAND_DRAWER_X + 14, 468,
                ARTIFACT_HAND_DRAWER_W - 28, 28,
                artifactMainHand ? "重置主手" : "重置副手", false);
    }

    private void drawArtifactTransformSlider(GuiGraphics graphics,
                                             int mouseX, int mouseY, int index) {
        float min = index < 3 ? ArtifactSkinConfig.HAND_POSITION_MIN
                : ArtifactSkinConfig.HAND_ROTATION_MIN;
        float max = index < 3 ? ArtifactSkinConfig.HAND_POSITION_MAX
                : ArtifactSkinConfig.HAND_ROTATION_MAX;
        float value = artifactTransformValue(index);
        float progress = (value - min) / (max - min);
        int trackY = ARTIFACT_HAND_SLIDER_Y + index * ARTIFACT_HAND_SLIDER_STEP;
        String[] labels = {"X 横向位置", "Y 上下位置", "Z 前后位置", "旋转 X 上下倾斜", "旋转 Y 左右倾斜"};
        String number = index < 3
                ? String.format(Locale.ROOT, "%+.2f", value)
                : String.format(Locale.ROOT, "%+.0f°", value);
        bodyText(graphics, labels[index],
                ARTIFACT_HAND_TRACK_X, trackY - 20, 9, TEXT_PRIMARY);
        bodyText(graphics, number,
                ARTIFACT_HAND_TRACK_X + ARTIFACT_HAND_TRACK_W - 42,
                trackY - 20, 9, TEXT_SECONDARY);
        OpenGlUiRenderer.roundedRect(graphics, ARTIFACT_HAND_TRACK_X,
                trackY, ARTIFACT_HAND_TRACK_W, 5, 2.5F, ClientShell.border());
        float filled = ARTIFACT_HAND_TRACK_W * clampFloat(progress, 0, 1);
        OpenGlUiRenderer.roundedRect(graphics, ARTIFACT_HAND_TRACK_X,
                trackY, filled, 5, 2.5F, ACCENT);
        boolean hovered = inside(mouseX, mouseY, ARTIFACT_HAND_TRACK_X - 8,
                trackY - 10, ARTIFACT_HAND_TRACK_W + 16, 25);
        OpenGlUiRenderer.roundedRect(graphics,
                ARTIFACT_HAND_TRACK_X + filled - 6, trackY - 4,
                13, 13, 6.5F, hovered ? ClientShell.hoverSurface() : ClientShell.control());
    }

    private boolean clickArtifactHandControls(double mouseX, double mouseY) {
        if (inside(mouseX, mouseY, PREVIEW_X + 14, PREVIEW_ACTION_Y, PREVIEW_W - 28, PREVIEW_ACTION_H)) {
            artifactHandSettings = !artifactHandSettings;
            customModelPicker = false;
            draggingArtifactTransform = -1;
            return true;
        }
        if (!artifactHandSettings || !inside(mouseX, mouseY,
                ARTIFACT_HAND_DRAWER_X, 48, ARTIFACT_HAND_DRAWER_W, 470)) return false;
        if (inside(mouseX, mouseY,
                ARTIFACT_HAND_DRAWER_X + ARTIFACT_HAND_DRAWER_W - 32,
                55, 22, 24)) {
            artifactHandSettings = false;
            return true;
        }
        if (inside(mouseX, mouseY, ARTIFACT_HAND_DRAWER_X + 14, 94, 122, 28)) {
            artifactMainHand = true;
            return true;
        }
        if (inside(mouseX, mouseY, ARTIFACT_HAND_DRAWER_X + 150, 94, 122, 28)) {
            artifactMainHand = false;
            return true;
        }
        for (int index = 0; index < 5; index++) {
            int trackY = ARTIFACT_HAND_SLIDER_Y + index * ARTIFACT_HAND_SLIDER_STEP;
            if (inside(mouseX, mouseY, ARTIFACT_HAND_TRACK_X - 8,
                    trackY - 10, ARTIFACT_HAND_TRACK_W + 16, 25)) {
                draggingArtifactTransform = index;
                updateArtifactTransformFromMouse(mouseX);
                return true;
            }
        }
        if (inside(mouseX, mouseY, ARTIFACT_HAND_DRAWER_X + 14, 468,
                ARTIFACT_HAND_DRAWER_W - 28, 28)) {
            resetArtifactHand();
            ArtifactSkinConfig.save();
            return true;
        }
        return true;
    }
    private int artifactVariantScroll;
    private ArtifactSkins.Artifact variantArtifact;
    private int artifactVariantStart(ArtifactSkins.Artifact artifact) {
        if (variantArtifact != artifact) { variantArtifact = artifact; artifactVariantScroll = 0; }
        artifactVariantScroll = clamp(artifactVariantScroll, 0, Math.max(0, ArtifactSkins.options(artifact).size() - 8));
        return artifactVariantScroll;
    }
    private static final int EXTERNAL_VARIANT_SIZE = 40;
    private static final int EXTERNAL_VARIANT_GAP = 7;
    private static final int EXTERNAL_VARIANT_Y = 62;
    private static final int ARTIFACT_HAND_DRAWER_X = DESIGN_WIDTH + 2;
    private static final int ARTIFACT_HAND_DRAWER_W = 286;
    private static final int ARTIFACT_HAND_TRACK_X = ARTIFACT_HAND_DRAWER_X + 20;
    private static final int ARTIFACT_HAND_TRACK_W = ARTIFACT_HAND_DRAWER_W - 40;
    private static final int ARTIFACT_HAND_SLIDER_Y = 158;
    private static final int ARTIFACT_HAND_SLIDER_STEP = 62;
    private static final int SETTINGS_BUTTON_X = 10;
    private static final int SETTINGS_BUTTON_Y = NAV_TOP + NAV_SECTIONS.length * NAV_STEP;
    private static final int SETTINGS_BUTTON_W = 40;
    private static final int SETTINGS_BUTTON_H = 36;
    private static final int SETTINGS_PANEL_X = 280;
    private static final int SETTINGS_PANEL_Y = 58;
    private static final int SETTINGS_PANEL_W = 440;
    private static final int SETTINGS_PANEL_H = 420;
    private static final int SETTINGS_TRACK_X = 330;
    private static final int SETTINGS_TRACK_W = 340;
    private static final int BLUR_TRACK_Y = 156;
    private static final int OPACITY_TRACK_Y = 214;
    private static final int MENU_BLUR_TRACK_Y = 292;
    private static final int MENU_OPACITY_TRACK_Y = 350;
    private static final EquipmentSlot[] PREVIEW_ARMOR_SLOTS = {
            EquipmentSlot.HEAD, EquipmentSlot.CHEST,
            EquipmentSlot.LEGS, EquipmentSlot.FEET
    };
    private static final EquipmentSlot[] ISOLATED_EQUIPMENT_SLOTS = {
            EquipmentSlot.MAINHAND, EquipmentSlot.OFFHAND,
            EquipmentSlot.HEAD, EquipmentSlot.CHEST,
            EquipmentSlot.LEGS, EquipmentSlot.FEET
    };

    private static int TEXT_PRIMARY = ClientShell.text();
    private static int TEXT_SECONDARY = ClientShell.color("secondaryText",0xFF343945);
    private static int TEXT_MUTED = ClientShell.muted();
    private static int ACCENT = ClientShell.accent();
    private static int GLASS_BORDER = ClientShell.control();
    private static int GLASS_CARD = ClientShell.control();
    private static int GLASS_CARD_HOVER = ClientShell.hoverSurface();
    private static int GLASS_SELECTED = ClientShell.selected();
    private static final long OPEN_ANIMATION_NANOS = dev.lin.client.shared.UiMotion.ENTER_MS * 1_000_000L;
    private static final long CLOSE_ANIMATION_NANOS = dev.lin.client.shared.UiMotion.EXIT_MS * 1_000_000L;

    private static final Identifier LIN_LOGO = Identifier.fromNamespaceAndPath(
            LinClient.MOD_ID, "textures/ui/lin_logo.png");
    private static final Identifier LOCKER = uiTexture("locker");
    private static final Identifier CLOSE = uiTexture("close");
    private static final Identifier SEARCH = uiTexture("search");
    private static final Identifier COMPACT = uiTexture("compact");
    private static final Identifier GRID = uiTexture("grid");
    private static final Identifier EYE = uiTexture("eye");
    private static final Identifier ADD = uiTexture("add");
    private static final Identifier COSMETICS = uiTexture("cosmetics");
    private static final Identifier SUITS = uiTexture("suits");
    private static final Identifier STAR = uiTexture("star");
    private static final Identifier STAR_FILLED = uiTexture("star_filled");
    private static final Identifier ARROW_DOWN = uiTexture("arrow_down");
    private static final Identifier ARROW_UP = uiTexture("arrow_up");
    private static final Identifier PENCIL = uiTexture("pencil");
    private static final Identifier WARNING = uiTexture("warning");
    private static final Identifier CHECKED = uiTexture("checked");
    private static final Identifier COG = uiTexture("cog");
    private static final Identifier MANNEQUIN_SKIN = uiTexture("mannequin");

    private final Screen parent;
    private final dev.lin.client.cosmetics.catalog.LockerFilterCache filterCache =
            new dev.lin.client.cosmetics.catalog.LockerFilterCache();
    private LockerSection section = LockerSection.ALL;
    private CosmeticDefinition selected;
    private ArtifactSkins.Artifact selectedArtifact;
    private GlassSearchBox searchBox;
    private GlassSearchBox renameBox;
    private GlassSearchBox floatingNumberBox;
    private Integer renamingFitId;
    private int scrollRow;
    private int sidebarScroll;
    private float originX;
    private float originY;
    private float uiScale = 1;
    private float previewYaw = 0.0F;
    private float targetPreviewYaw = 0.0F;
    private boolean previewAutoTurning;
    private float visualScrollRow;
    private int lastScrollTop = HEADWEAR_TOP;
    private int lastScrollBottom = VIEW_BOTTOM;
    private int lastScrollMaxRow;
    private float lastScrollThumbY;
    private float lastScrollThumbH = 76F;
    private float scrollbarDragOffsetY;
    private boolean scrollbarDragging;
    private float scrollbarHover;
    private final dev.lin.client.shared.LensMotion.Spring subTabXSpring = new dev.lin.client.shared.LensMotion.Spring(CONTENT_X);
    private final dev.lin.client.shared.LensMotion.Spring subTabWSpring = new dev.lin.client.shared.LensMotion.Spring(CAPE_TAB_W);
    private String lastSubTabGroup = "";
    private float previewDragStartYaw;
    private double previewDragStartX;
    private boolean previewDragging;
    private EquipmentSlot armorDropdownSlot;
    private boolean swordDropdownOpen;
    private TrimFooterDropdown trimFooterDropdown;
    private boolean fitsView;
    private int capeView;
    private int companionView;
    private int floatingView;
    private boolean settingsOpen;
    private boolean draggingBlur;
    private boolean draggingOpacity;
    private boolean draggingMenuBlur;
    private boolean draggingMenuOpacity;
    private Integer selectedFitId;
    private int previousBlur = -1;
    private final Map<Integer, dev.lin.client.shared.LensMotion.Spring> cardHover = new HashMap<>();
    private final dev.lin.client.shared.LensMotion.Spring categoryMotion=new dev.lin.client.shared.LensMotion.Spring(0);
    private final dev.lin.client.shared.LensMotion.Spring galleryMotion=new dev.lin.client.shared.LensMotion.Spring(5);
    private final dev.lin.client.shared.LensMotion.Spring previewPresence=new dev.lin.client.shared.LensMotion.Spring(1);
    private String previousGalleryState;
    private CosmeticDefinition previousPreviewSelection;
    private long openedAtNanos = System.nanoTime();
    private long introStartedAtNanos = openedAtNanos;
    private long frameNowNanos = openedAtNanos;
    private long closingAtNanos = -1;
    private long lastFrameNanos = openedAtNanos;
    private long lastDragNanos;
    private double lastDragX;
    private float previewVelocity;
    private float frameSeconds;
    private final EnumMap<EquipmentSlot, PreviewArmorMaterial> previewArmor =
            new EnumMap<>(EquipmentSlot.class);
    private PreviewSwordMaterial previewSword = PreviewSwordMaterial.IRON;

    public CosmeticLockerScreen(Screen parent) {
        super(Component.translatable("screen.lin_client.locker"));
        this.parent = parent;
        SystemNavigation.prepare(parent);
        for (EquipmentSlot slot : PREVIEW_ARMOR_SLOTS) {
            previewArmor.put(slot, PreviewArmorMaterial.NONE);
        }
    }

    public CosmeticLockerScreen(Screen parent, CosmeticCategory category) {
        this(parent);
        section = sectionFor(category);
        previewYaw = targetPreviewYaw = 0.0F;
        selected = CosmeticConfig.equipped(category);
        if (selected != null && category == CosmeticCategory.COMPANION) {
            companionView = "HOPLITE_PET".equals(selected.indexType()) ? 1 : 0;
        }
    }

    @Override
    protected void init() {
        if (CosmeticConfig.favoritesOnly()) CosmeticConfig.setFavoritesOnly(false);
        String query = searchBox == null ? "" : searchBox.getValue();
        String renameValue = renameBox == null ? "" : renameBox.getValue();
        searchBox = new GlassSearchBox(font, 0, 0, 200, SEARCH_H,
                Component.translatable("screen.lin_client.search"));
        searchBox.setChangeListener(value -> scrollRow = 0);
        searchBox.setValue(query);
        addRenderableWidget(searchBox);
        renameBox = new GlassSearchBox(font, 0, 0, 200, 30,
                Component.literal("穿搭名称"));
        renameBox.setValue(renameValue);
        renameBox.visible = renamingFitId != null;
        addRenderableWidget(renameBox);
        floatingNumberBox = new GlassSearchBox(font, 0, 0, 100,
                FLOATING_NUMBER_H, Component.literal("漂浮数字"));
        floatingNumberBox.setMaxLength(4);
        floatingNumberBox.setFilter(value -> value.matches("\\d{0,4}"));
        floatingNumberBox.setValue(Integer.toString(
                ClientAccessoryConfig.floatingNumber));
        floatingNumberBox.setChangeListener(value -> {
            if (!value.isEmpty()) {
                ClientAccessoryConfig.setFloatingNumber(Integer.parseInt(value));
            }
        });
        addRenderableWidget(floatingNumberBox);
        updateLayout();
    }

    @Override
    public void added() {
        super.added();

    }

    public void suspendPage(){
        if(draggingArtifactTransform>=0)ArtifactSkinConfig.save();
        draggingArtifactTransform=-1;
        previewDragging=false;previewVelocity=0;scrollbarDragging=false;
        draggingBlur=false;draggingOpacity=false;draggingMenuBlur=false;draggingMenuOpacity=false;
        CosmeticAssetManager.preload(null);
        clearFocus();
    }

    @Override
    public void removed() {
        if(SystemNavigation.retaining(this))return;
        if(draggingArtifactTransform>=0)ArtifactSkinConfig.save();
        draggingArtifactTransform=-1;
        CosmeticConfig.save();
        CosmeticAssetManager.clearPreload();
        if (minecraft != null && previousBlur >= 0) {
            minecraft.options.menuBackgroundBlurriness().set(previousBlur);
            previousBlur = -1;
        }
        super.removed();
    }

    public float openProgress() {
        return transition(frameNowNanos);
    }

    public float introElapsedSeconds() {
        if (closingAtNanos >= 0) return com.linclient.client.gui.clickgui.ActiveOpenAnimation.DURATION_SECONDS;
        return Math.max(0.0F, (frameNowNanos - introStartedAtNanos) / 1_000_000_000.0F);
    }

    public boolean isIntroCurtainOpaque() {
        return closingAtNanos < 0
                && introElapsedSeconds() < com.linclient.client.gui.clickgui.ActiveOpenAnimation.OPAQUE_CURTAIN_END_SECONDS;
    }

    public boolean isIntroLogoFlying() {
        return closingAtNanos < 0 && introElapsedSeconds() < 1.24F;
    }

    public boolean isIntroActive() {
        return closingAtNanos < 0
                && introElapsedSeconds() < com.linclient.client.gui.clickgui.ActiveOpenAnimation.DURATION_SECONDS;
    }

    private boolean isIntroBlocking() {
        return closingAtNanos < 0
                && introElapsedSeconds() < com.linclient.client.gui.clickgui.ActiveOpenAnimation.SKIP_TARGET_SECONDS;
    }

    private void skipIntro() {
        if (isIntroBlocking()) {
            long now = System.nanoTime();
            frameNowNanos = now;
            introStartedAtNanos = now
                    - (long) (com.linclient.client.gui.clickgui.ActiveOpenAnimation.SKIP_TARGET_SECONDS * 1_000_000_000.0F);
        }
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        dev.lin.client.cosmetics.font.SharedScreenText.beginFrame();
        long now = System.nanoTime();
        frameNowNanos = now;
        frameSeconds = Math.min(0.05F, Math.max(0.001F,
                (now - lastFrameNanos) / 1_000_000_000.0F));
        lastFrameNanos = now;
        if (closingAtNanos >= 0 && now - closingAtNanos >= CLOSE_ANIMATION_NANOS) {
            if (minecraft != null) minecraft.setScreen(parent);
            return;
        }
        boolean introCurtain = isIntroCurtainOpaque();
        if (introCurtain) {
            if (searchBox != null) { searchBox.visible = false; if (searchBox.isFocused()) searchBox.setFocused(false); }
            if (floatingNumberBox != null) { floatingNumberBox.visible = false; if (floatingNumberBox.isFocused()) floatingNumberBox.setFocused(false); }
            graphics.blurBeforeThisStratum();
            return;
        }
        updateWardrobeMotion();
        updatePreviewInertia();
        AccessoryWorldRenderer.beginPreviewFrame();
        updateLayout();
        if (searchBox != null) {
            searchBox.visible = !settingsOpen;
            if ((!searchBox.visible) && searchBox.isFocused()) searchBox.setFocused(false);
        }
        floatingNumberBox.visible = !settingsOpen && isChampionFloatingSelected();
        if (!floatingNumberBox.visible && floatingNumberBox.isFocused()) {
            floatingNumberBox.setFocused(false);
        }
        graphics.blurBeforeThisStratum();
        SystemNavigation.draw(graphics, SystemNavigation.COSMETICS, mouseX, mouseY);
        int localMouseX = (int) Math.floor(toLocalX(mouseX));
        int localMouseY = (int) Math.floor(toLocalY(mouseX,mouseY));
        Matrix3x2fStack pose = graphics.pose();
        float vis = transition(now);
        boolean animatingOpen = vis < 0.999F;
        if (animatingOpen) {
            float tScale = 0.96F + 0.04F * vis;
            float liftY = (1.0F - vis) * 12.0F * ClientShell.layout(width, height).scale();
            pose.pushMatrix();
            pose.translate(width * 0.5F, height * 0.5F + liftY);
            pose.scale(tScale, tScale);
            pose.translate(-width * 0.5F, -height * 0.5F);
        }
        dev.lin.client.cosmetics.render.SkijaUiRaster.beginFrame();
        try {
            TEXT_PRIMARY=ClientShell.text();TEXT_SECONDARY=ClientShell.color("secondaryText",0xFF343945);TEXT_MUTED=ClientShell.muted();ACCENT=ClientShell.accent();
            GLASS_BORDER=ClientShell.border();GLASS_CARD=ClientShell.control();GLASS_CARD_HOVER=ClientShell.hoverSurface();GLASS_SELECTED=ClientShell.selected();
            ClientShell.render(graphics,width,height,activeShellKey(),mouseX,mouseY,false,!isIntroLogoFlying());
            renderShellHeader(graphics,mouseX,mouseY);
            if (!settingsOpen) renderSearchToolbar(graphics,mouseX,mouseY);
            pose.pushMatrix();
            try {
                pose.translate(originX, originY);
                pose.scale(uiScale, uiScale);
                drawLocker(graphics, localMouseX, localMouseY);
                renderPreviewRail(graphics,mouseX,mouseY);
                if (!fitsView && customModelPicker && section == LockerSection.ARTIFACT_SKINS) drawCustomDrawer(graphics, localMouseX, localMouseY);
                if (!fitsView && artifactHandSettings && section == LockerSection.ARTIFACT_SKINS) drawArtifactHandDrawer(graphics, localMouseX, localMouseY);
            } finally {
                pose.popMatrix();
            }
        } finally {
            dev.lin.client.cosmetics.render.SkijaUiRaster.endFrame();
            if (animatingOpen) pose.popMatrix();
        }
        super.render(graphics, mouseX, mouseY, partialTick);
    }

    @Override
    public void renderBackground(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
    }

    // Ten categories share one horizontal strip, with the same draw/hit geometry.
    private static float categoryWidth(){return (ClientShell.totalWidth()-ClientShell.SIDE-48)/NAV_SECTIONS.length;}
    private static float categoryX(int index){return ClientShell.SIDE+24+index*categoryWidth();}
    private static float categoryY(int index){return 94;}

    private String activeShellKey() {
        if (settingsOpen) return "settings";
        return switch (section) {
            case COSMETICS -> "cloaks";
            case HEADWEAR -> "headwear";
            case LUNAR_WINGS, WINGS -> "wings";
            case PETS, COMPANIONS -> "pets";
            case ARTIFACT_SKINS -> "artifacts";
            case ARMOR_TRIMS -> "trims";
            default -> "misc";
        };
    }

    private boolean isMiscSection() {
        return section == LockerSection.FLOATING_EFFECTS
                || section == LockerSection.ARROW_TRAILS
                || section == LockerSection.VIP_ICONS;
    }

    private boolean isPetSection() {
        return section == LockerSection.PETS || section == LockerSection.COMPANIONS;
    }

    private float uiStroke(float shellPx) {
        float shellScale = ClientShell.layout(width, height).scale();
        return shellPx * shellScale / Math.max(0.01f, uiScale);
    }

    private void renderShellHeader(GuiGraphics g,int mx,int my){
        ClientShell.Layout l=ClientShell.layout(width,height);var pose=g.pose();pose.pushMatrix();
        try{
            pose.translate(l.x(),l.y());pose.scale(l.scale(),l.scale());
            boolean closeHover=ClientShell.inside(l.localX(mx),l.localY(my),ClientShell.totalWidth()-56,26,36,36);
            OpenGlUiRenderer.roundedPanel(g,ClientShell.totalWidth()-56,26,36,36,8,
                    closeHover?ClientShell.hoverSurface():ClientShell.control(),ClientShell.border(),1.0f);
            OpenGlUiRenderer.closeIcon(g,ClientShell.totalWidth()-38,44,12,closeHover?TEXT_PRIMARY:TEXT_SECONDARY);
        }finally{pose.popMatrix();}
    }

    private void renderSharingSettings(GuiGraphics g) {
        var l=ClientShell.layout(width,height);var pose=g.pose();pose.pushMatrix();
        try {
            pose.translate(l.x(),l.y());pose.scale(l.scale(),l.scale());
            float x=ClientShell.totalWidth()-384,y=72,w=360;
            OpenGlUiRenderer.roundedPanel(g,x,y,w,244,16,ClientShell.control(),ClientShell.border(),1f);
            OpenGlUiRenderer.textRegular(g,"饰品互见",x+20,y+18,dev.lin.client.cosmetics.font.PageTypography.BODY,TEXT_PRIMARY);
            String[] labels={"分享我的装扮","显示其他人的装扮","大厅显示质量"};
            String[] values={CosmeticConfig.shareCosmetics()?"已开启":"仅自己可见",CosmeticConfig.receiveCosmetics()?"已开启":"已关闭",
                switch(CosmeticConfig.multiplayerQuality()){case 0->"省性能";case 2->"高质量";default->"均衡";}};
            for(int i=0;i<3;i++){
                float row=y+50+i*44;
                OpenGlUiRenderer.roundedPanel(g,x+12,row,w-24,38,9,ClientShell.hoverSurface(),ClientShell.border(),.5f);
                OpenGlUiRenderer.textRegular(g,labels[i],x+22,row+11,dev.lin.client.cosmetics.font.PageTypography.BODY,TEXT_PRIMARY);
                float tw=FontManager.widthRegular(values[i],dev.lin.client.cosmetics.font.PageTypography.CAPTION);
                OpenGlUiRenderer.textRegular(g,values[i],x+w-24-tw,row+12,dev.lin.client.cosmetics.font.PageTypography.CAPTION,ACCENT);
            }
            String status=dev.lin.client.cosmetics.sync.CosmeticSyncBridge.status();
            while(!status.isEmpty() && FontManager.widthRegular(status,11)>w-40)status=status.substring(0,status.length()-1);
            OpenGlUiRenderer.textRegular(g,status,x+20,y+194,11,TEXT_MUTED);
            OpenGlUiRenderer.textRegular(g,"使用 Lin 的正版玩家可互见 · 点击外侧关闭",x+20,y+216,10,TEXT_MUTED);
        }finally{pose.popMatrix();}
    }
    private boolean clickSharingSettings(MouseButtonEvent click) {
        var l=ClientShell.layout(width,height);float x=l.localX(click.x()),y=l.localY(click.y());
        if(settingsOpen){
            float left=ClientShell.totalWidth()-384;
            if(click.button()==0)for(int i=0;i<3;i++)if(ClientShell.inside(x,y,left+12,122+i*44,336,38)){
                switch(i){case 0->CosmeticConfig.setShareCosmetics(!CosmeticConfig.shareCosmetics());
                    case 1->CosmeticConfig.setReceiveCosmetics(!CosmeticConfig.receiveCosmetics());
                    case 2->CosmeticConfig.cycleMultiplayerQuality();}
                return true;
            }
            if(!ClientShell.inside(x,y,left,72,360,244))settingsOpen=false;
            return true;
        }
        if(click.button()==0 && ClientShell.inside(x,y,ClientShell.totalWidth()-288,26,106,36)){
            settingsOpen=true;setFocused(null);return true;
        }
        return false;
    }

    private float bodyFont(float original) {
        float shellScale=ClientShell.layout(width,height).scale();
        return dev.lin.client.cosmetics.font.PageTypography.cosmetics(original,uiScale/shellScale);
    }
    private void bodyText(GuiGraphics g,String text,float x,float y,float size,int color){
        float actual=bodyFont(size);
        OpenGlUiRenderer.textRegular(g,text,x,y-(actual-size)*.5f,actual,color);
    }
    /** Rail labels share the model/control centerline and the native font metrics. */
    private void previewText(GuiGraphics graphics,String value,float y,float shellSize,int color) {
        float size=shellSize*ClientShell.layout(width,height).scale()/uiScale;
        float maxWidth=PREVIEW_W-28;
        String visible=value;
        if(FontManager.widthRegular(visible,size)>maxWidth) {
            while(!visible.isEmpty() && FontManager.widthRegular(visible+"…",size)>maxWidth)
                visible=visible.substring(0,visible.offsetByCodePoints(visible.length(),-1));
            visible+="…";
        }
        float x=PREVIEW_X+(PREVIEW_W-FontManager.widthRegular(visible,size))*.5f;
        OpenGlUiRenderer.textRegular(graphics,visible,x,y,size,color);
    }
    private ClientShell.Layout previewLayout(){return ClientShell.railContent(width,height,PREVIEW_X,PREVIEW_W,PREVIEW_CONTENT_H);}
    private boolean hasPreviewArmorControls() {
        return false;
    }
    private int previewStageTop() {
        return PREVIEW_ENTITY_TOP;
    }
    private int previewStageBottom() {
        return PREVIEW_ENTITY_BOTTOM;
    }
    private static int previewArmorMenuY(int rows) {
        return ARMOR_BUTTON_Y - rows * ARMOR_MENU_ROW_HEIGHT - 16;
    }
    private void renderPreviewRail(GuiGraphics graphics,int mouseX,int mouseY){
        var l=previewLayout();var pose=graphics.pose();pose.pushMatrix();
        float oldX=originX,oldY=originY,oldScale=uiScale;
        try{
            pose.translate((l.x()-originX)/uiScale,(l.y()-originY)/uiScale);
            pose.scale(l.scale()/uiScale,l.scale()/uiScale);
            originX=l.x();originY=l.y();uiScale=l.scale();
            int localMouseX=(int)toLocalX(mouseX),localMouseY=(int)toLocalY(mouseX,mouseY);
            drawLoadout(graphics,localMouseX,localMouseY);
            drawAvatar(graphics, mouseX, mouseY);
            if (fitsView || !section.isExternal()) {
                if(hasPreviewArmorControls())drawPreviewArmorControls(graphics, localMouseX, localMouseY);
                drawFloatingNumberField(graphics, localMouseX, localMouseY);
                drawFloatingScopeSelector(graphics, localMouseX, localMouseY);
            } else {
                drawExternalVariantControls(graphics, localMouseX, localMouseY);
            }
            if(hasEntityPreviewStage()){
                drawPreviewAngleControls(graphics, localMouseX, localMouseY);
                drawPreviewEquippedSummary(graphics, localMouseX, localMouseY);
            }
            if (section == LockerSection.ARMOR_TRIMS
                    && trimFooterDropdown != null) {
                drawTrimFooterMenu(graphics, localMouseX, localMouseY);
            }
        }finally{originX=oldX;originY=oldY;uiScale=oldScale;pose.popMatrix();}
    }

    private boolean hasEntityPreviewStage() {
        return fitsView || (section != LockerSection.SPAWN_PODS && section != LockerSection.VIP_ICONS
                && section != LockerSection.ARROW_TRAILS && section != LockerSection.KILL_EFFECTS);
    }

    private void drawPreviewAngleControls(GuiGraphics graphics, int mouseX, int mouseY) {
        boolean isBack = Math.abs(normalizeDegrees(previewYaw)) >= 75.0F;
        int railX = PREVIEW_X + 12;
        int railW = PREVIEW_W - 24;
        OpenGlUiRenderer.roundedPanel(graphics, railX, PREVIEW_VIEW_ROW_Y, railW, PREVIEW_VIEW_BTN_H, 9,
                0x88101413, 0xFF252E2B, uiStroke(0.85F));
        int third = (railW - 12) / 3;
        drawPreviewAngleButton(graphics, mouseX, mouseY, railX + 3, PREVIEW_VIEW_ROW_Y + 3,
                third, PREVIEW_VIEW_BTN_H - 6, ClientShell.tr("正面", "Front"), !isBack);
        drawPreviewAngleButton(graphics, mouseX, mouseY, railX + 6 + third, PREVIEW_VIEW_ROW_Y + 3,
                third, PREVIEW_VIEW_BTN_H - 6, ClientShell.tr("重置", "Reset"), false);
        drawPreviewAngleButton(graphics, mouseX, mouseY, railX + 9 + third * 2, PREVIEW_VIEW_ROW_Y + 3,
                third, PREVIEW_VIEW_BTN_H - 6, ClientShell.tr("背面", "Back"), isBack);
    }

    private void drawPreviewEquippedSummary(GuiGraphics g, int mouseX, int mouseY) {
        int left = PREVIEW_X + 12;
        int gap = 8;
        int chipW = (PREVIEW_W - 24 - gap) / 2;
        int chipH = 34;
        String capeName = currentEquippedLabel(0);
        String hatName = currentEquippedLabel(1);
        String wingName = currentEquippedLabel(2);
        String petName = currentEquippedLabel(3);
        String[] slots = {
                ClientShell.tr("披风", "Cape"),
                ClientShell.tr("头饰", "Hat"),
                ClientShell.tr("翅膀", "Wing"),
                ClientShell.tr("宠物", "Pet")
        };
        String[] values = {capeName, hatName, wingName, petName};
        for (int i = 0; i < 4; i++) {
            int cx = left + (i % 2) * (chipW + gap);
            int cy = PREVIEW_SLOTS_Y + (i / 2) * (chipH + gap);
            boolean active = values[i] != null;
            boolean hovered = inside(mouseX, mouseY, cx, cy, chipW, chipH);
            float hv = animatedHover(-720_000 - i, hovered);
            OpenGlUiRenderer.roundedPanel(g, cx, cy, chipW, chipH, 8,
                    mixColor(0x99161D1B, 0xCC212B27, hv),
                    active ? mixColor(0x662F482B, 0xAA76E02A, hv) : mixColor(0xFF242D2A, 0xFF36453F, hv),
                    uiStroke(0.85F));
            OpenGlUiRenderer.roundedRect(g, cx + 10, cy + (chipH - 6) * 0.5F, 6, 6, 3,
                    active ? ACCENT : 0xFF47534F);
            float fSize = bodyFont(6.8F);
            String label = slots[i] + " · " + (active ? values[i] : ClientShell.tr("无", "None"));
            String shown = truncate(label, 6.8F, chipW - 28);
            OpenGlUiRenderer.textRegular(g, shown, cx + 22, cy + (chipH - fSize) * 0.5F, fSize,
                    active ? TEXT_PRIMARY : TEXT_MUTED);
        }
    }

    private String currentEquippedLabel(int idx) {
        return switch (idx) {
            case 0 -> {
                CosmeticDefinition c = CosmeticConfig.equipped(CosmeticCategory.CLOAK);
                if (c != null) yield c.name();
                LunarCape lc = LunarCapeRegistry.selected();
                yield lc != null ? lc.displayName() : null;
            }
            case 1 -> {
                AccessoryDefinition h = AccessoryRegistry.selected(AccessorySlot.HEADWEAR);
                yield h != null ? h.displayName() : null;
            }
            case 2 -> {
                CosmeticDefinition w = CosmeticConfig.equipped(CosmeticCategory.DRAGON_WINGS);
                if (w != null) yield w.name();
                AccessoryDefinition hw = AccessoryRegistry.selected(AccessorySlot.WINGS);
                yield hw != null ? hw.displayName() : null;
            }
            default -> {
                CosmeticDefinition p = CosmeticConfig.equipped(CosmeticCategory.PET);
                if (p != null) yield p.name();
                CosmeticDefinition comp = CosmeticConfig.equipped(CosmeticCategory.COMPANION);
                yield comp != null ? comp.name() : null;
            }
        };
    }

    private void drawPreviewAngleButton(GuiGraphics g, int mouseX, int mouseY,
                                        int x, int y, int w, int h, String label, boolean active) {
        boolean hovered = inside(mouseX, mouseY, x, y, w, h);
        float hv = animatedHover(-700_000 - x, hovered);
        int fill = active ? 0xDD1F311B : mixColor(0x00000000, 0x33FFFFFF, hv);
        int border = active ? 0x8876E02A : 0x00000000;
        if (active || hv > 0.01F) {
            OpenGlUiRenderer.roundedPanel(g, x, y, w, h, 7, fill, border, uiStroke(active ? 1.0F : 0.0F));
        }
        float fSize = bodyFont(7.2F);
        float lw = FontManager.widthRegular(label, fSize);
        OpenGlUiRenderer.textRegular(g, label, x + (w - lw) * 0.5F, y + (h - fSize) * 0.5F, fSize,
                active ? ACCENT : hovered ? TEXT_PRIMARY : TEXT_SECONDARY);
    }
    private int lastGalleryMouseX, lastGalleryMouseY;
    private void drawLocker(GuiGraphics graphics, int mouseX, int mouseY) {
        lastGalleryMouseX = mouseX;
        lastGalleryMouseY = mouseY;
        lastScrollMaxRow = 0;
        if (settingsOpen) {
            drawLockerSettingsPage(graphics, mouseX, mouseY);
            return;
        }
        drawCards(graphics, mouseX, mouseY);
    }

    private void drawSettingsToggleRow(GuiGraphics g, int mouseX, int mouseY, int id,
                                       int x, int y, int w, int h,
                                       String title, String desc, boolean enabled, String customBadge) {
        boolean hovered = inside(mouseX, mouseY, x, y, w, h);
        float hv = animatedHover(5_000_000 + id, hovered);
        drawLens(g, x, y, w, h, 16, hv, false);
        if (hv > 0.01F) {
            OpenGlUiRenderer.roundedRect(g, x + 22, y + 1.2F, (w - 44) * 0.42F, 1.4F, 0.7F,
                    withOpacity(0xFFFFFFFF, 0.14F * hv));
        }
        float titleSize = bodyFont(8.8F);
        float descSize = bodyFont(7.0F);
        float titleY = y + 22;
        OpenGlUiRenderer.textRegular(g, title, x + 28, titleY, titleSize, TEXT_PRIMARY);
        OpenGlUiRenderer.textRegular(g, desc, x + 28, titleY + titleSize * 1.35F, descSize, TEXT_MUTED);
        if (customBadge != null) {
            float pillW = 160, pillH = 44;
            float px = x + w - pillW - 26, py = y + (h - pillH) * 0.5F;
            OpenGlUiRenderer.roundedPanel(g, px, py, pillW, pillH, 10,
                    0xFF1F2F1C, 0x7776E02A, uiStroke(1.0F));
            float bSize = bodyFont(7.8F);
            float bw = FontManager.widthRegular(customBadge, bSize);
            OpenGlUiRenderer.textRegular(g, customBadge, px + (pillW - bw) * 0.5F,
                    py + (pillH - bSize) * 0.5F, bSize, ACCENT);
        } else {
            float switchW = 84, switchH = 42;
            float sx = x + w - switchW - 26, sy = y + (h - switchH) * 0.5F;
            float knobProgress = animatedHover(5_100_000 + id, enabled);
            int trackFill = mixColor(0xFF232B29, 0xFF243B1D, knobProgress);
            int trackBorder = mixColor(0xFF34403C, 0xAA76E02A, knobProgress);
            OpenGlUiRenderer.roundedPanel(g, sx, sy, switchW, switchH, switchH * 0.5F,
                    trackFill, trackBorder, uiStroke(1.0F));
            float knobSize = switchH - 10;
            float knobX = sx + 5 + (switchW - knobSize - 10) * knobProgress;
            int knobCol = mixColor(0xFF7B8783, ACCENT, knobProgress);
            OpenGlUiRenderer.roundedRect(g, knobX, sy + 5, knobSize, knobSize, knobSize * 0.5F, knobCol);
            String stateText = enabled ? ClientShell.tr("已开启", "ON") : ClientShell.tr("已关闭", "OFF");
            float sSize = bodyFont(7.2F);
            float sw = FontManager.widthRegular(stateText, sSize);
            OpenGlUiRenderer.textRegular(g, stateText, sx - sw - 18, y + (h - sSize) * 0.5F, sSize,
                    enabled ? ACCENT : TEXT_MUTED);
        }
    }

    private void drawLockerSettingsPage(GuiGraphics g, int mouseX, int mouseY) {
        int x = CONTENT_X;
        int w = CONTENT_RIGHT - CONTENT_X;
        float secSize = bodyFont(7.8F);
        OpenGlUiRenderer.textRegular(g, ClientShell.tr("图标与标签显示", "Badges & Nametags"),
                x + 6, CARD_TOP + 8, secSize, ACCENT);
        drawSettingsToggleRow(g, mouseX, mouseY, 0, x, CARD_TOP + 46, w, 92,
                ClientShell.tr("Tab 列表显示图标", "Show Icon in Tab List"),
                ClientShell.tr("在多人服务器 Tab 玩家列表中显示专属标志", "Display the badge icon in the multiplayer Tab list"),
                CosmeticConfig.showTabBadge(), null);
        drawSettingsToggleRow(g, mouseX, mouseY, 1, x, CARD_TOP + 154, w, 92,
                ClientShell.tr("名称标签显示图标", "Show Icon on Nametag"),
                ClientShell.tr("在玩家头顶的名称标签前显示专属标志", "Display the badge icon next to player nametags"),
                CosmeticConfig.showNametagBadge(), null);
        drawSettingsToggleRow(g, mouseX, mouseY, 5, x, CARD_TOP + 262, w, 92,
                ClientShell.tr("第三人称自身标签", "Third-Person Own Nametag"),
                ClientShell.tr("在第三人称视角（F5）下显示自己的头顶名称标签与图标", "Show your own nametag and badge in third-person view"),
                CosmeticConfig.thirdPersonNametag(), null);

        OpenGlUiRenderer.textRegular(g, ClientShell.tr("饰品互见与在线同步", "Cosmetic Sync & Visibility"),
                x + 6, CARD_TOP + 382, secSize, ACCENT);
        drawSettingsToggleRow(g, mouseX, mouseY, 2, x, CARD_TOP + 420, w, 92,
                ClientShell.tr("分享我的装扮", "Share My Cosmetics"),
                ClientShell.tr("允许附近同样使用本模组的正版玩家看到你的饰品", "Allow nearby verified players to see your cosmetics"),
                CosmeticConfig.shareCosmetics(), null);
        drawSettingsToggleRow(g, mouseX, mouseY, 3, x, CARD_TOP + 528, w, 92,
                ClientShell.tr("显示其他人的装扮", "Show Peer Cosmetics"),
                ClientShell.tr("同步并渲染附近其他玩家的饰品搭配", "Sync and render nearby players' equipped cosmetics"),
                CosmeticConfig.receiveCosmetics(), null);
        String qualityLabel = switch (CosmeticConfig.multiplayerQuality()) {
            case 0 -> ClientShell.tr("省性能", "Low");
            case 2 -> ClientShell.tr("高质量", "High");
            default -> ClientShell.tr("均衡", "Balanced");
        };
        drawSettingsToggleRow(g, mouseX, mouseY, 4, x, CARD_TOP + 636, w, 92,
                ClientShell.tr("大厅显示质量", "Lobby Render Quality"),
                ClientShell.tr("控制多人场景下他人饰品的渲染细节与性能开销", "Balance visual quality and FPS for peer cosmetics"),
                true, qualityLabel);

        int statusY = CARD_TOP + 756;
        int statusH = 98;
        OpenGlUiRenderer.roundedPanel(g, x, statusY, w, statusH, 16,
                ClientShell.inset(), 0xFF252E2B, uiStroke(1.0F));
        String syncStatus = dev.lin.client.cosmetics.sync.CosmeticSyncBridge.status();
        boolean synced = syncStatus != null && syncStatus.contains("已同步");
        OpenGlUiRenderer.roundedRect(g, x + 28, statusY + 26, 12, 12, 6, synced ? ACCENT : 0xFFE5B53B);
        float stSize = bodyFont(8.2F);
        float capSize = bodyFont(7.0F);
        OpenGlUiRenderer.textRegular(g, ClientShell.tr("互见同步状态：", "Sync Status: ") + syncStatus,
                x + 52, statusY + 19, stSize, TEXT_PRIMARY);
        OpenGlUiRenderer.textRegular(g,
                ClientShell.tr("在线服务器正版登录自动连接同步 · 单人/离线模式仅本地可见",
                        "Auto-syncs on verified online servers · Local only in singleplayer/offline"),
                x + 52, statusY + 19 + stSize * 1.38F, capSize, TEXT_MUTED);
    }

    private boolean clickLockerSettingsPage(double x, double y) {
        int left = CONTENT_X;
        int w = CONTENT_RIGHT - CONTENT_X;
        if (inside(x, y, left, CARD_TOP + 46, w, 92)) {
            CosmeticConfig.setShowTabBadge(!CosmeticConfig.showTabBadge());
            return true;
        }
        if (inside(x, y, left, CARD_TOP + 154, w, 92)) {
            CosmeticConfig.setShowNametagBadge(!CosmeticConfig.showNametagBadge());
            return true;
        }
        if (inside(x, y, left, CARD_TOP + 262, w, 92)) {
            CosmeticConfig.setThirdPersonNametag(!CosmeticConfig.thirdPersonNametag());
            return true;
        }
        if (inside(x, y, left, CARD_TOP + 420, w, 92)) {
            CosmeticConfig.setShareCosmetics(!CosmeticConfig.shareCosmetics());
            return true;
        }
        if (inside(x, y, left, CARD_TOP + 528, w, 92)) {
            CosmeticConfig.setReceiveCosmetics(!CosmeticConfig.receiveCosmetics());
            return true;
        }
        if (inside(x, y, left, CARD_TOP + 636, w, 92)) {
            CosmeticConfig.cycleMultiplayerQuality();
            return true;
        }
        return false;
    }

    private int smoothBaseRow(int maxRow) {
        return Math.max(0, (int) Math.floor(clampFloat(visualScrollRow, 0F, Math.max(0, maxRow))));
    }

    private int smoothFracOffset(int baseRow, int step) {
        return Math.round((visualScrollRow - baseRow) * step);
    }

    private ClientShell.Layout searchToolbarLayout() {
        ClientShell.Layout shell=ClientShell.layout(width,height);
        float left=ClientShell.SIDE+20;
        float available=ClientShell.WIDTH-ClientShell.SIDE-38;
        float scale=shell.scale()*Math.min(36f/SEARCH_H,available/(SORT_X+SORT_W-SEARCH_X));
        return new ClientShell.Layout(shell.x()+left*shell.scale()-SEARCH_X*scale,
                shell.y()+26*shell.scale()-SEARCH_Y*scale,scale);
    }

    private void renderSearchToolbar(GuiGraphics graphics,int mouseX,int mouseY) {
        ClientShell.Layout toolbar=searchToolbarLayout();
        float savedScale=uiScale;
        var pose=graphics.pose();pose.pushMatrix();
        try {
            pose.translate(toolbar.x(),toolbar.y());pose.scale(toolbar.scale(),toolbar.scale());
            uiScale=toolbar.scale();
            drawSearch(graphics,(int)Math.floor(toolbar.localX(mouseX)),(int)Math.floor(toolbar.localY(mouseY)));
        } finally {uiScale=savedScale;pose.popMatrix();}
    }

    private boolean clickSearchToolbar(MouseButtonEvent click,boolean doubled) {
        if(click.button()!=0||renamingFitId!=null)return false;
        ClientShell.Layout toolbar=searchToolbarLayout();
        double x=toolbar.localX(click.x()),y=toolbar.localY(click.y());
        if(inside(x,y,SEARCH_X,SEARCH_Y,SEARCH_W,SEARCH_H)) {
            setFocused(searchBox);
            searchBox.setFocused(true);
            if(!searchBox.getValue().isEmpty()&&inside(x,y,SEARCH_X+SEARCH_W-27,SEARCH_Y,27,SEARCH_H))
                searchBox.setValue("");
            else {searchBox.mouseClicked(click,doubled);setDragging(true);}
            return true;
        }
        if(inside(x,y,SORT_X,SEARCH_Y,SORT_W,SEARCH_H)) {
            CosmeticConfig.setSortAscending(!CosmeticConfig.sortAscending());scrollRow=0;return true;
        }
        if(supportsFavorites()&&inside(x,y,FAVORITES_X,SEARCH_Y,FAVORITES_W,SEARCH_H)) {
            CosmeticConfig.setFavoritesOnly(!CosmeticConfig.favoritesOnly());scrollRow=0;return true;
        }
        return false;
    }

    private void drawSearch(GuiGraphics graphics, int mouseX, int mouseY) {
        boolean hovered = inside(mouseX, mouseY, SEARCH_X, SEARCH_Y, SEARCH_W, SEARCH_H);
        boolean focused = searchBox != null && searchBox.isFocused();
        OpenGlUiRenderer.roundedPanel(graphics, SEARCH_X, SEARCH_Y, SEARCH_W, SEARCH_H, 10,
                focused ? 0xE6141A18 : hovered ? 0xDC161C1A : ClientShell.inset(),
                focused ? withOpacity(ACCENT, .65f) : 0xFF28312F, uiStroke(focused ? 1.2f : 1.0f));
        OpenGlUiRenderer.searchIcon(graphics, SEARCH_X + 21, SEARCH_Y + SEARCH_H / 2f, 16, TEXT_MUTED);
        GlassSearchBox.VisibleText visible = searchBox.visibleText();
        String value = searchBox.getValue();
        int textX = SEARCH_X + 40;
        graphics.enableScissor(textX, SEARCH_Y + 3, SEARCH_X + SEARCH_W - 35, SEARCH_Y + SEARCH_H - 3);
        try {
            String placeholder = ClientShell.isEnglish()
                    ? "Search " + section.topLabel() + "..."
                    : "搜索" + section.topLabel() + "名称";
            bodyText(graphics, value.isEmpty() ? placeholder : visible.text(), textX,
                    SEARCH_Y + (SEARCH_H - 8) / 2f, 8, value.isEmpty() ? TEXT_MUTED : TEXT_PRIMARY);
            if (focused && (System.currentTimeMillis() / 500 & 1) == 0) {
                int cursor = searchBox.getCursorPosition();
                if (cursor >= visible.start() && cursor <= visible.end()) {
                    float cursorX = textX + FontManager.widthRegular(value.substring(visible.start(), cursor),bodyFont(8));
                    OpenGlUiRenderer.roundedRect(graphics, cursorX, SEARCH_Y + (SEARCH_H - 20) / 2f, 1.1F, 20, .5F, TEXT_PRIMARY);
                }
            }
        } finally { graphics.disableScissor(); }
        if (!value.isEmpty()) OpenGlUiRenderer.closeIcon(graphics, SEARCH_X + SEARCH_W - 19,
                SEARCH_Y + SEARCH_H / 2f, 13, TEXT_MUTED);
        drawFooterButton(graphics,mouseX,mouseY,SORT_X,SEARCH_Y,SORT_W,SEARCH_H,
                CosmeticConfig.sortAscending() ? ClientShell.tr("名称 A–Z","Name A–Z") : ClientShell.tr("名称 Z–A","Name Z–A"),false);
        if (supportsFavorites()) drawFooterButton(graphics,mouseX,mouseY,FAVORITES_X,SEARCH_Y,
                FAVORITES_W,SEARCH_H,"仅看收藏",CosmeticConfig.favoritesOnly());
    }

    private boolean supportsFavorites() {
        return false;
    }

    private void drawSubTabStrip(GuiGraphics g, int mouseX, int mouseY, String groupKey,
                                 int activeIndex, String[] labels, int[] xs, int[] ws) {
        if (labels.length == 0) return;
        int railLeft = xs[0];
        int railRight = xs[xs.length - 1] + ws[ws.length - 1];
        OpenGlUiRenderer.roundedPanel(g, railLeft, CARD_TOP, railRight - railLeft, SOURCE_TAB_H, 13,
                0x99101413, 0xFF252D2B, uiStroke(0.9F));
        int clampedActive = clamp(activeIndex, 0, labels.length - 1);
        float targetX = xs[clampedActive] + 3;
        float targetW = ws[clampedActive] - 6;
        if (!groupKey.equals(lastSubTabGroup)) {
            subTabXSpring.snap(targetX);
            subTabWSpring.snap(targetW);
            lastSubTabGroup = groupKey;
        }
        float pillX = subTabXSpring.update(targetX, frameSeconds);
        float pillW = subTabWSpring.update(targetW, frameSeconds);
        for (int i = 0; i < labels.length; i++) {
            boolean active = i == clampedActive;
            boolean hovered = !active && inside(mouseX, mouseY, xs[i], CARD_TOP, ws[i], SOURCE_TAB_H);
            float h = animatedHover(-900_000 - groupKey.hashCode() * 17 - i, hovered);
            if (!active && h > 0.01F) {
                OpenGlUiRenderer.roundedRect(g, xs[i] + 3, CARD_TOP + 3, ws[i] - 6, SOURCE_TAB_H - 6, 10,
                        withOpacity(0xFFFFFFFF, 0.06F * h));
            }
        }
        OpenGlUiRenderer.roundedPanel(g, pillX, CARD_TOP + 3, pillW, SOURCE_TAB_H - 6, 10,
                0xEE1E2D1A, 0xAA76E02A, uiStroke(1.15F));
        OpenGlUiRenderer.roundedRect(g, pillX + 14, CARD_TOP + 4.2F, Math.max(0, (pillW - 28) * 0.45F), 1.2F, 0.6F,
                0x26FFFFFF);
        float fontSize = bodyFont(8.0F);
        for (int i = 0; i < labels.length; i++) {
            boolean active = i == clampedActive;
            boolean hovered = !active && inside(mouseX, mouseY, xs[i], CARD_TOP, ws[i], SOURCE_TAB_H);
            String visible = truncate(labels[i], 8.0F, ws[i] - 20);
            float lw = FontManager.widthRegular(visible, fontSize);
            OpenGlUiRenderer.textRegular(g, visible, xs[i] + (ws[i] - lw) * 0.5F,
                    CARD_TOP + (SOURCE_TAB_H - fontSize) * 0.5F, fontSize,
                    active ? ACCENT : hovered ? TEXT_PRIMARY : TEXT_SECONDARY);
        }
    }

    private void drawGalleryCard(GuiGraphics g,int x,float y,int w,int h,int previewHeight,
                                 boolean selected,boolean equipped,float hover) {
        drawLens(g,x,y,w,h,16,hover,false);
        if(hover>.01f){
            OpenGlUiRenderer.roundedRect(g,x+22,y+1.2f,Math.max(0,(w-44)*.46f),1.4f,.7f,
                    withOpacity(0xFFFFFFFF,.16f*clampFloat(hover,0,1)));
        }
        String badge=equipped?ClientShell.tr("已启用","Enabled"):ClientShell.tr("未启用","Disabled");
        float size=bodyFont(7.0f),badgeW=FontManager.widthRegular(badge,size)+24;
        OpenGlUiRenderer.roundedRect(g,x+18,y+16,badgeW,28,7,
                equipped?0xFF273720:0xFF252D2B);
        OpenGlUiRenderer.textRegular(g,badge,x+18+(badgeW-FontManager.widthRegular(badge,size))*.5f,
                y+16+(28-size)*.5f,size,equipped?0xFF8BE03A:TEXT_MUTED);
    }

    /** Shared Lens material for gallery cards, source tabs and action controls. */
    private void drawLens(GuiGraphics g,float x,float y,float w,float h,float radius,float hover,boolean selected){
        float hv=clampFloat(hover,0,1);
        int fill=mixColor(ClientShell.glassTile(),ClientShell.glassHover(),hv);
        if(selected)fill=mixColor(fill,ClientShell.selected(),.55f);
        int borderCol=selected?withOpacity(ACCENT,.65f):mixColor(0xFF2A3230,0xFF42524B,hv);
        OpenGlUiRenderer.roundedPanel(g,x,y,w,h,radius,fill,borderCol,uiStroke(selected?1.2f:1.0f));
    }

    private void drawFavorite(GuiGraphics g,float x,float y,boolean favorite) {
        var painter=ClientShell.painter(g);
        int color=favorite?ACCENT:TEXT_MUTED;
        if(favorite)OpenGlUiRenderer.roundedRect(g,x-16,y-16,32,32,9,ClientShell.selected());
        for(int i=0;i<10;i++){
            double a=-Math.PI/2+i*Math.PI/5,b=a+Math.PI/5;
            float r=(i&1)==0?10:4.6F,next=(i&1)==0?4.6F:10;
            painter.line(x+(float)Math.cos(a)*r,y+(float)Math.sin(a)*r,
                    x+(float)Math.cos(b)*next,y+(float)Math.sin(b)*next,color);
        }
    }

    private void drawGalleryTitle(GuiGraphics g,String title,int x,int y,int w,int h,int previewHeight,
                                  boolean equipped) {
        drawGalleryTitle(g, title, x, (float) y, w, h, previewHeight, equipped, 0F);
    }

    private void drawGalleryTitle(GuiGraphics g,String title,int x,float y,int w,int h,int previewHeight,
                                  boolean equipped,float hover) {
        float fontSize=bodyFont(8.2f),available=w-40;
        String visibleTitle=truncate(title,8.2f,available);
        float titleY=y+previewHeight+6;
        OpenGlUiRenderer.textRegular(g,visibleTitle,x+(w-FontManager.widthRegular(visibleTitle,fontSize))*.5f,
                titleY,fontSize,TEXT_PRIMARY);
        String subtitle=section.topLabel();
        float subSize=bodyFont(6.8f);
        float subY=titleY+fontSize*1.32f;
        OpenGlUiRenderer.textRegular(g,subtitle,x+(w-FontManager.widthRegular(subtitle,subSize))*.5f,
                subY,subSize,TEXT_MUTED);
        float btnW=w-52,btnH=48,btnX=x+26,btnY=y+h-64;
        OpenGlUiRenderer.roundedRect(g,btnX,btnY,btnW,btnH,10,
                mixColor(0xFF262E2C,0xFF32403B,clampFloat(hover,0,1)));
        String action=equipped?ClientShell.tr("装备中","Equipped"):ClientShell.tr("选择","Select");
        float actSize=bodyFont(7.5f);
        OpenGlUiRenderer.textRegular(g,action,btnX+(btnW-FontManager.widthRegular(action,actSize))*.5f,
                btnY+(btnH-actSize)*.5f,actSize,equipped?TEXT_PRIMARY:TEXT_SECONDARY);
        if(equipped){
            OpenGlUiRenderer.roundedRect(g,btnX+btnW-22,btnY+(btnH-9)*.5f,9,9,4.5f,ACCENT);
        }
    }

    private void drawSidebar(GuiGraphics graphics, int mouseX, int mouseY) {
        int railH = NAV_SECTIONS.length * NAV_STEP + 16;
        OpenGlUiRenderer.roundedPanel(graphics, 0, NAV_TOP - 8, SIDEBAR_W, railH,
                22, ClientShell.surface(), ClientShell.border(), GlassStyle.borderWidth());
        sidebarScroll = 0;
        LockerSection[] sections = NAV_SECTIONS;
        for (int i = 0; i < sections.length; i++) {
            int y = NAV_TOP + i * NAV_STEP;
            boolean active = !fitsView && section.navigationEntry() == sections[i];
            boolean hover = inside(mouseX, mouseY, 10, y, 40, 36);
            if (active || hover) {
                OpenGlUiRenderer.roundedRect(graphics, 10, y, 40, 36, 18,
                        active ? ClientShell.selected() : ClientShell.hoverSurface());
            }
            drawTexture(graphics, uiTexture(sections[i].icon), 21, y + 9, 18, 18, 40, 40);
        }
    }

    private void drawNavigationTooltip(GuiGraphics graphics, int mouseX, int mouseY) {
        String label = null;
        int tipY = 0;
        for (int i = 0; i < NAV_SECTIONS.length; i++) {
            int y = NAV_TOP + i * NAV_STEP;
            if (inside(mouseX, mouseY, 10, y, 40, 36)) {
                LockerSection entry = NAV_SECTIONS[i];
                label = entry.label + " (" + entry.count() + ")";
                tipY = y + 3;
                break;
            }
        }
        if (label != null) {
            float width = FontManager.widthRegular(label,bodyFont(11)) + 24;
            OpenGlUiRenderer.roundedPanel(graphics, 70, tipY, width, 30, 10,
                    ClientShell.surface(), GLASS_BORDER, 1);
            bodyText(graphics, label, 82, tipY + 8, 11, TEXT_PRIMARY);
        }
    }

    private void drawSettings(GuiGraphics graphics, int mouseX, int mouseY) {
        OpenGlUiRenderer.roundedRect(graphics, PANEL_X, PANEL_Y, PANEL_W, PANEL_H,
                10, 0xB8000000);
        OpenGlUiRenderer.glassPanel(graphics, SETTINGS_PANEL_X, SETTINGS_PANEL_Y,
                SETTINGS_PANEL_W, SETTINGS_PANEL_H, 20, ClientShell.surface(),
                ClientShell.border(), 0x60000000);
        bodyText(graphics, "设置", SETTINGS_PANEL_X + 24,
                SETTINGS_PANEL_Y + 23, 17, TEXT_PRIMARY);
        bodyText(graphics, "分别调整界面外背景与菜单面板",
                SETTINGS_PANEL_X + 24, SETTINGS_PANEL_Y + 50, 9, TEXT_MUTED);

        drawSettingsSlider(graphics, mouseX, mouseY, "界面外背景模糊",
                Integer.toString((int) GlassStyle.number("backdrop.blur.radius", GlassStyle.blur())),
                BLUR_TRACK_Y,
                GlassStyle.number("backdrop.blur.radius", GlassStyle.blur())
                        / (float) ClientAccessoryConfig.BACKGROUND_BLUR_MAX);
        int opacityPercent = Math.round(GlassStyle.number("backdrop.alpha", 0) * 100);
        drawSettingsSlider(graphics, mouseX, mouseY, "界面外背景透明度",
                opacityPercent + "%", OPACITY_TRACK_Y,
                (GlassStyle.number("backdrop.alpha", 0)
                        - ClientAccessoryConfig.BACKGROUND_OPACITY_MIN)
                        / (ClientAccessoryConfig.BACKGROUND_OPACITY_MAX
                        - ClientAccessoryConfig.BACKGROUND_OPACITY_MIN));

        drawSettingsSlider(graphics, mouseX, mouseY, "菜单面板模糊",
                Integer.toString(GlassStyle.blur()),
                MENU_BLUR_TRACK_Y, GlassStyle.blur()
                        / (float) ClientAccessoryConfig.BACKGROUND_BLUR_MAX);
        int menuOpacityPercent = Math.round((GlassStyle.panel() >>> 24) / 255f * 100);
        drawSettingsSlider(graphics, mouseX, mouseY, "菜单面板透明度",
                menuOpacityPercent + "%", MENU_OPACITY_TRACK_Y,
                (GlassStyle.panel() >>> 24) / 255f);

        int resetX = SETTINGS_PANEL_X + 222;
        int doneX = SETTINGS_PANEL_X + 302;
        int buttonY = SETTINGS_PANEL_Y + SETTINGS_PANEL_H - 42;
        drawSettingsButton(graphics, mouseX, mouseY, resetX, buttonY, 68, "重置", false);
        drawSettingsButton(graphics, mouseX, mouseY, doneX, buttonY, 74, "完成", true);
    }

    private void drawSettingsSlider(GuiGraphics graphics, int mouseX, int mouseY,
                                    String label, String value, int trackY,
                                    float progress) {
        bodyText(graphics, label, SETTINGS_TRACK_X,
                trackY - 27, 10, TEXT_SECONDARY);
        float valueWidth = FontManager.widthRegular(value,bodyFont(9));
        bodyText(graphics, value,
                SETTINGS_TRACK_X + SETTINGS_TRACK_W - valueWidth,
                trackY - 26, 9, TEXT_PRIMARY);
        OpenGlUiRenderer.roundedRect(graphics, SETTINGS_TRACK_X, trackY,
                SETTINGS_TRACK_W, 5, 2.5F, ClientShell.border());
        float filled = SETTINGS_TRACK_W * clampFloat(progress, 0, 1);
        OpenGlUiRenderer.roundedRect(graphics, SETTINGS_TRACK_X, trackY,
                filled, 5, 2.5F, ACCENT);
        float knobX = SETTINGS_TRACK_X + filled - 6;
        boolean hovered = inside(mouseX, mouseY, Math.round(knobX) - 4,
                trackY - 8, 20, 21)
                || inside(mouseX, mouseY, SETTINGS_TRACK_X, trackY - 5,
                SETTINGS_TRACK_W, 15);
        OpenGlUiRenderer.roundedRect(graphics, knobX, trackY - 4,
                13, 13, 6.5F, hovered ? ClientShell.hoverSurface() : ClientShell.control());
    }

    private void drawSettingsButton(GuiGraphics graphics, int mouseX, int mouseY,
                                    int x, int y, int width, String label,
                                    boolean primary) {
        boolean hovered = inside(mouseX, mouseY, x, y, width, 28);
        OpenGlUiRenderer.roundedPanel(graphics, x, y, width, 28, 6,
                primary ? hovered ? ClientShell.hoverSurface() : ClientShell.selected()
                        : hovered ? ClientShell.hoverSurface() : ClientShell.control(),
                primary ? ACCENT : ClientShell.border(), 1);
        float textWidth = FontManager.widthRegular(label,bodyFont(9));
        bodyText(graphics, label,
                x + (width - textWidth) * 0.5F, y + 9, 9, TEXT_PRIMARY);
    }

    private dev.lin.client.cosmetics.vip.VipIcons.Icon selectedVip = dev.lin.client.cosmetics.vip.VipIcons.selected();
    private boolean vipSaveFailed;

    private List<dev.lin.client.cosmetics.vip.VipIcons.Icon> filteredVipIcons() {
        String query = normalizedExternalQuery();
        return dev.lin.client.cosmetics.vip.VipIcons.ALL.stream()
                .filter(v -> query.isEmpty() || normalizeExternal(v.id() + " " + v.label()).contains(query)).toList();
    }

    private void drawVipIcon(GuiGraphics graphics, dev.lin.client.cosmetics.vip.VipIcons.Icon icon,
                             int centerX, int y, float scale) {
        scale = Math.min(scale, (PREVIEW_W - 28f) / Math.max(1, minecraft.font.width(icon.component())));
        graphics.pose().pushMatrix();
        graphics.pose().translate(centerX - minecraft.font.width(icon.component()) * scale / 2, y);
        graphics.pose().scale(scale, scale);
        graphics.drawString(minecraft.font, icon.component(), 0, 0, 0xffffffff, false);
        graphics.pose().popMatrix();
    }

    private void drawVipCards(GuiGraphics graphics, int mouseX, int mouseY) {
        var values = filteredVipIcons();
        int max = maxScroll(values.size());
        scrollRow = clamp(scrollRow, 0, max);
        int baseRow = smoothBaseRow(max);
        int fracY = smoothFracOffset(baseRow, ROW_STEP);
        int start = baseRow * COLUMNS;
        graphics.enableScissor(CONTENT_X - 4, HEADWEAR_TOP - 4, CONTENT_RIGHT + 4, VIEW_BOTTOM + 4);
        try {
            for (int i = start; i < Math.min(values.size(), (baseRow + cardRows() + 1) * COLUMNS); i++) {
                var value = values.get(i);
                int x = CONTENT_X + (i - start) % COLUMNS * (CARD_W + CARD_GAP);
                int y = HEADWEAR_TOP + (i - start) / COLUMNS * ROW_STEP - fracY;
                boolean equipped=value.equals(dev.lin.client.cosmetics.vip.VipIcons.selected());
                boolean hovered=inside(mouseX,mouseY,x,y,CARD_W,CARD_H);
                float hv=animatedHover(4_000_000+i,hovered);
                float lift=hv*5.0F;
                drawGalleryCard(graphics,x,y-lift,CARD_W,CARD_H,CARD_PREVIEW_H,value.equals(selectedVip),equipped,hv);
                float stageCenterY = y - lift + (54 + CARD_PREVIEW_H - 8) * 0.5F;
                drawVipIcon(graphics, value, x + CARD_W / 2, Math.round(stageCenterY - 20), 5 * (1F + hv * 0.05F));
                drawGalleryTitle(graphics,value.label(),x,y-lift,CARD_W,CARD_H,CARD_PREVIEW_H,equipped,hv);
            }
        } finally { graphics.disableScissor(); }
        drawScrollbar(graphics, values.size());
    }

    private dev.lin.client.cosmetics.render.ArrowTrails selectedArrowTrail = dev.lin.client.cosmetics.render.ArrowTrails.selected();
    private boolean trailSaveFailed;

    private List<dev.lin.client.cosmetics.render.ArrowTrails> filteredArrowTrails() {
        String query = normalizedExternalQuery();
        var values = java.util.Arrays.stream(dev.lin.client.cosmetics.render.ArrowTrails.values())
                .filter(v -> query.isEmpty() || normalizeExternal(v.id + " " + v.label).contains(query));
        return values.toList();
    }

    private void drawArrowTrailDemo(GuiGraphics graphics, dev.lin.client.cosmetics.render.ArrowTrails theme,
                                     int x, int y, int w, int h) {
        float head = (System.nanoTime() / 1_000_000L % 2400) / 2400F;
        for (int i = 24; i >= 0; i--) {
            float t = head - i * 0.012F;
            if (t < 0) continue;
            float px = x + 8 + t * (w - 20);
            float py = y + h * 0.8F - (float)Math.sin(t * Math.PI) * h * 0.58F;
            int color = (i % 2 == 0 ? theme.primary : theme.secondary)
                    | (Math.max(30, 240 - i * 8) << 24);
            if (i == 0) OpenGlUiRenderer.roundedRect(graphics, px, py, 10, 3, 1, TEXT_PRIMARY);
            else if (theme == dev.lin.client.cosmetics.render.ArrowTrails.BEATS && i % 4 == 0)
                bodyText(graphics, "♪", px, py - 3, 9, color);
            else OpenGlUiRenderer.roundedRect(graphics, px, py, 3, 3, 1.5F, color);
        }
    }

    private void drawArrowTrailCards(GuiGraphics graphics, int mouseX, int mouseY) {
        var values = filteredArrowTrails();
        int max = maxScroll(values.size());
        scrollRow = clamp(scrollRow, 0, max);
        int baseRow = smoothBaseRow(max);
        int fracY = smoothFracOffset(baseRow, ROW_STEP);
        int start = baseRow * COLUMNS;
        graphics.enableScissor(CONTENT_X - 4, HEADWEAR_TOP - 4, CONTENT_RIGHT + 4, VIEW_BOTTOM + 4);
        try {
            for (int i = start; i < Math.min(values.size(), (baseRow + cardRows() + 1) * COLUMNS); i++) {
                var value = values.get(i);
                int x = CONTENT_X + (i - start) % COLUMNS * (CARD_W + CARD_GAP);
                int y = HEADWEAR_TOP + (i - start) / COLUMNS * ROW_STEP - fracY;
                boolean equipped=value == dev.lin.client.cosmetics.render.ArrowTrails.selected();
                boolean hovered=inside(mouseX,mouseY,x,y,CARD_W,CARD_H);
                float hv=animatedHover(4_100_000+i,hovered);
                float lift=hv*5.0F;
                drawGalleryCard(graphics,x,y-lift,CARD_W,CARD_H,CARD_PREVIEW_H,value==selectedArrowTrail,equipped,hv);
                if (value != dev.lin.client.cosmetics.render.ArrowTrails.NONE)
                    drawTexture(graphics, Identifier.fromNamespaceAndPath("lin_client", "textures/arrow_trails/" + value.id + ".png"), x + 22, Math.round(y + 60 - lift), 32, 32, 16, 16);
                drawArrowTrailDemo(graphics, value, x + 44, Math.round(y + 62 - lift), CARD_W - 88, CARD_PREVIEW_H - 76);
                drawGalleryTitle(graphics,value.label,x,y-lift,CARD_W,CARD_H,CARD_PREVIEW_H,equipped,hv);
            }
        } finally { graphics.disableScissor(); }
        drawScrollbar(graphics, values.size());
    }


    private PodSkins.Skin selectedPod=PodSkins.selected()==null?PodSkins.ALL.getFirst():PodSkins.selected();
    private int podPart;
    private boolean podLarge,podSaveFailed;
    private List<PodSkins.Skin> filteredPods(){
        String query=normalizedExternalQuery();
        return PodSkins.ALL.stream().filter(v->query.isEmpty()||normalizeExternal(v.id+" "+v.name).contains(query)).toList();
    }
    private void drawPodCards(GuiGraphics graphics,int mouseX,int mouseY){
        var values=filteredPods();scrollRow=clamp(scrollRow,0,maxScroll(values.size()));int start=scrollRow*COLUMNS;
        graphics.enableScissor(CONTENT_X - 4, CARD_TOP - 4, CONTENT_RIGHT + 4, VIEW_BOTTOM + 4);
        try{for(int i=start;i<Math.min(values.size(),start+cardRows()*COLUMNS);i++){
            var value=values.get(i);int x=CONTENT_X+(i-start)%COLUMNS*(CARD_W+CARD_GAP),y=CARD_TOP+(i-start)/COLUMNS*ROW_STEP;
            boolean equipped=value==PodSkins.selected();
            drawGalleryCard(graphics,x,y,CARD_W,CARD_H,CARD_PREVIEW_H,value==selectedPod,equipped,
                    inside(mouseX,mouseY,x,y,CARD_W,CARD_H)?1:0);
            int previewSize=Math.min(CARD_W-56,CARD_PREVIEW_H-48);
            PodSkins.preview(graphics,value,0,false,true,x+(CARD_W-previewSize)/2,y+(CARD_PREVIEW_H-previewSize)/2,previewSize);
            drawGalleryTitle(graphics,value.name,x,y,CARD_W,CARD_H,CARD_PREVIEW_H,equipped);
        }}finally{graphics.disableScissor();}
        drawScrollbar(graphics,values.size());
    }

    private KillEffectPreview selectedKillEffect = KillEffectPreview.BOMB;
    private long killPreviewStart = System.nanoTime();

    private List<KillEffectPreview> filteredKillEffects() {
        String query = normalizedExternalQuery();
        return java.util.Arrays.stream(KillEffectPreview.values())
                .filter(value -> query.isEmpty() || normalizeExternal(value.id + " " + value.label).contains(query))
                .toList();
    }

    private void drawKillEffectCards(GuiGraphics graphics, int mouseX, int mouseY) {
        List<KillEffectPreview> values = filteredKillEffects();
        scrollRow = clamp(scrollRow, 0, maxScroll(values.size()));
        int start = scrollRow * COLUMNS;
        graphics.enableScissor(CONTENT_X - 4, CARD_TOP - 4, CONTENT_RIGHT + 4, VIEW_BOTTOM + 4);
        try {
            for (int i = start; i < Math.min(values.size(), start + cardRows() * COLUMNS); i++) {
                var value = values.get(i);
                int x = CONTENT_X + (i - start) % COLUMNS * (CARD_W + CARD_GAP);
                int y = CARD_TOP + (i - start) / COLUMNS * ROW_STEP;
                drawGalleryCard(graphics,x,y,CARD_W,CARD_H,CARD_PREVIEW_H,value==selectedKillEffect,false,
                        inside(mouseX,mouseY,x,y,CARD_W,CARD_H)?1:0);
                int previewSize=Math.min(CARD_W-56,CARD_PREVIEW_H-48);
                value.render(graphics, x + (CARD_W-previewSize)/2, y + (CARD_PREVIEW_H-previewSize)/2, previewSize, killPreviewStart);
                drawGalleryTitle(graphics,value.label,x,y,CARD_W,CARD_H,CARD_PREVIEW_H,false);
            }
        } finally { graphics.disableScissor(); }
        drawScrollbar(graphics, values.size());
    }

    private void drawMiscTabs(GuiGraphics graphics, int mouseX, int mouseY) {
        int gap = 20;
        int tabWidth = (CONTENT_RIGHT - CONTENT_X - gap * 3) / 4;
        String[] labels = {
                ClientShell.tr("Lunar 漂浮", "Lunar Float"),
                ClientShell.tr("Hoplite 漂浮", "Hoplite Float"),
                ClientShell.tr("抛物线轨迹", "Arrow Trails"),
                ClientShell.tr("身份图标", "VIP Icons")
        };
        int active = section == LockerSection.ARROW_TRAILS ? 2
                : section == LockerSection.VIP_ICONS ? 3
                : floatingView == FLOATING_VIEW_HOPLITE ? 1 : 0;
        int[] xs = {CONTENT_X, CONTENT_X + tabWidth + gap, CONTENT_X + (tabWidth + gap) * 2, CONTENT_X + (tabWidth + gap) * 3};
        int[] ws = {tabWidth, tabWidth, tabWidth, tabWidth};
        drawSubTabStrip(graphics, mouseX, mouseY, "misc", active, labels, xs, ws);
    }

    private void drawPetTabs(GuiGraphics graphics, int mouseX, int mouseY) {
        String[] labels = {
                ClientShell.tr("宠物", "Pets"),
                ClientShell.tr("Lunar 陪伴", "Lunar Companions"),
                ClientShell.tr("Hoplite 陪伴", "Hoplite Companions")
        };
        int active = section == LockerSection.PETS ? 0 : (companionView == 1 ? 2 : 1);
        int[] xs = {CONTENT_X, CONTENT_X + CAPE_TAB_W + CARD_GAP, CONTENT_X + (CAPE_TAB_W + CARD_GAP) * 2};
        int[] ws = {CAPE_TAB_W, CAPE_TAB_W, CAPE_TAB_W};
        drawSubTabStrip(graphics, mouseX, mouseY, "pets", active, labels, xs, ws);
    }

    private void drawCards(GuiGraphics graphics, int mouseX, int mouseY) {
        if (isWingSection()) {
            int width = (CONTENT_RIGHT - CONTENT_X - CARD_GAP) / 2;
            String[] labels = {
                    ClientShell.tr("Lunar 翅膀", "Lunar Wings"),
                    ClientShell.tr("Hoplite 翅膀", "Hoplite Wings")
            };
            int[] xs = {CONTENT_X, CONTENT_X + width + CARD_GAP};
            int[] ws = {width, width};
            drawSubTabStrip(graphics, mouseX, mouseY, "wings",
                    section == LockerSection.WINGS ? 1 : 0, labels, xs, ws);
        } else if (isPetSection()) {
            drawPetTabs(graphics, mouseX, mouseY);
        } else if (isMiscSection()) {
            drawMiscTabs(graphics, mouseX, mouseY);
        }
        if (section.isExternal()) {
            drawExternalCards(graphics, mouseX, mouseY);
            return;
        }
        if (section == LockerSection.FLOATING_EFFECTS) {
            drawFloatingCards(graphics, mouseX, mouseY);
            return;
        }
        if (section == LockerSection.COSMETICS || section == LockerSection.COMPANIONS) {
            drawSkinCards(graphics, mouseX, mouseY);
            return;
        }
        List<CosmeticDefinition> cosmetics = filtered();
        int maxScroll = maxScroll(cosmetics.size());
        scrollRow = clamp(scrollRow, 0, maxScroll);
        int baseRow = smoothBaseRow(maxScroll);
        int fracY = smoothFracOffset(baseRow, rowStep());
        int start = baseRow * COLUMNS;
        int end = Math.min(cosmetics.size(), (baseRow + cardRows() + 1) * COLUMNS);
        CosmeticAssetManager.preload(cosmetics.subList(start, end));
        int clipTop = hasSubTabs() ? HEADWEAR_TOP : CARD_TOP;
        graphics.enableScissor(CONTENT_X - 4, clipTop - 4, CONTENT_RIGHT + 4, VIEW_BOTTOM + 4);
        try {
            for (int index = start; index < end; index++) {
                int visibleIndex = index - start;
                int x = CONTENT_X + visibleIndex % COLUMNS * (CARD_W + CARD_GAP);
                int y = cardTop() + visibleIndex / COLUMNS * rowStep() - fracY;
                if (isWingSection()) {
                    drawCard(graphics, mouseX, mouseY, cosmetics.get(index), x, y,
                            WING_CARD_H, WING_PREVIEW_H);
                } else {
                    drawCard(graphics, mouseX, mouseY, cosmetics.get(index), x, y);
                }
            }
        } finally {
            graphics.disableScissor();
        }
        drawScrollbar(graphics, cosmetics.size());
        if (cosmetics.isEmpty()) {
            String empty = ClientShell.tr("没有找到匹配的饰品", "No matching cosmetics");
            float width = FontManager.widthRegular(empty,bodyFont(9));
            bodyText(graphics, empty,
                    (CONTENT_X + CONTENT_RIGHT - width) * 0.5F, 258, 9, TEXT_MUTED);
        }
    }

    private void drawExternalCards(GuiGraphics graphics, int mouseX, int mouseY) {
        switch (section) {
            case SPAWN_PODS -> drawPodCards(graphics, mouseX, mouseY);
            case VIP_ICONS -> drawVipCards(graphics, mouseX, mouseY);
            case ARROW_TRAILS -> drawArrowTrailCards(graphics, mouseX, mouseY);
            case KILL_EFFECTS -> drawKillEffectCards(graphics, mouseX, mouseY);
            case HEADWEAR -> drawHeadwearCards(graphics, mouseX, mouseY);
            case WINGS -> drawWingCards(graphics, mouseX, mouseY);
            case ARMOR_TRIMS -> drawTrimCards(graphics, mouseX, mouseY);
            case ARTIFACT_SKINS -> drawArtifactCards(graphics, mouseX, mouseY);
            default -> {
            }
        }
    }

    private void drawHeadwearCards(GuiGraphics graphics, int mouseX, int mouseY) {
        String[] hLabels = {"Hoplite", "KingMC"};
        int[] hXs = {CONTENT_X, CONTENT_X + CAPE_TAB_W + CARD_GAP};
        int[] hWs = {CAPE_TAB_W, CAPE_TAB_W};
        drawSubTabStrip(graphics, mouseX, mouseY, "headwear",
                AccessoryRegistry.kingmcHeadwear() ? 1 : 0, hLabels, hXs, hWs);
        drawFooterButton(graphics, mouseX, mouseY,
                CONTENT_X + (CAPE_TAB_W + CARD_GAP) * 2, CARD_TOP,
                CAPE_TAB_W, SOURCE_TAB_H,
                ClientShell.tr("使用范围：", "Scope: ") + AccessoryRegistry.headwearScope().label(), false);
        List<AccessoryDefinition> values = filteredHeadwear();
        int max = maxScroll(values.size());
        scrollRow = clamp(scrollRow, 0, max);
        int baseRow = smoothBaseRow(max);
        int fracY = smoothFracOffset(baseRow, HEADWEAR_STEP);
        int start = baseRow * HEADWEAR_COLUMNS;
        int end = Math.min(values.size(), (baseRow + VISIBLE_ROWS + 1) * HEADWEAR_COLUMNS);
        graphics.enableScissor(CONTENT_X - 4, HEADWEAR_TOP - 4, CONTENT_RIGHT + 4, VIEW_BOTTOM + 4);
        try {
            for (int index = start; index < end; index++) {
                int visible = index - start;
                int x = CONTENT_X + visible % HEADWEAR_COLUMNS * (HEADWEAR_W + CARD_GAP);
                int y = HEADWEAR_TOP + visible / HEADWEAR_COLUMNS * HEADWEAR_STEP - fracY;
                drawHeadwearCard(graphics, mouseX, mouseY, values.get(index), x, y);
            }
        } finally {
            graphics.disableScissor();
        }
        drawScrollbar(graphics, values.size());
    }

    private void drawHeadwearCard(GuiGraphics graphics, int mouseX, int mouseY,
                                  AccessoryDefinition definition, int x, int y) {
        boolean hovered = inside(mouseX, mouseY, x, y, HEADWEAR_W, HEADWEAR_H);
        boolean equipped = definition.id().equals(
                AccessoryRegistry.selectedId(AccessorySlot.HEADWEAR));
        float hover = animatedHover(1_000_000 + definition.customModelData(), hovered);
        float lift = hover * 5.0F;
        drawGalleryCard(graphics,x,y-lift,HEADWEAR_W,HEADWEAR_H,CARD_PREVIEW_H,equipped,equipped,hover);
        int iconSize = Math.round(160 * (1.0F + hover * 0.055F));
        float stageCenterY = y - lift + (54 + CARD_PREVIEW_H - 8) * 0.5F;
        drawHeadwearIcon(graphics, definition, x + (HEADWEAR_W - iconSize) / 2, Math.round(stageCenterY - iconSize * 0.5F), iconSize);
        drawGalleryTitle(graphics,definition.displayName(),x,y-lift,HEADWEAR_W,HEADWEAR_H,CARD_PREVIEW_H,equipped,hover);
    }

    private void drawWingCards(GuiGraphics graphics, int mouseX, int mouseY) {
        List<AccessoryDefinition> values = filteredWings();
        int max = maxScroll(values.size());
        scrollRow = clamp(scrollRow, 0, max);
        int baseRow = smoothBaseRow(max);
        int fracY = smoothFracOffset(baseRow, WING_ROW_STEP);
        int start = baseRow * COLUMNS;
        int end = Math.min(values.size(), (baseRow + cardRows() + 1) * COLUMNS);
        graphics.enableScissor(CONTENT_X - 4, HEADWEAR_TOP - 4, CONTENT_RIGHT + 4, VIEW_BOTTOM + 4);
        try {
            for (int index = start; index < end; index++) {
                int visible = index - start;
                int x = CONTENT_X + visible % COLUMNS * (CARD_W + CARD_GAP);
                int y = cardTop() + visible / COLUMNS * WING_ROW_STEP - fracY;
                drawWingCard(graphics, mouseX, mouseY, values.get(index), x, y);
            }
        } finally {
            graphics.disableScissor();
        }
        drawScrollbar(graphics, values.size());
    }

    private void drawWingCard(GuiGraphics graphics, int mouseX, int mouseY,
                              AccessoryDefinition definition, int x, int y) {
        boolean hovered = inside(mouseX, mouseY, x, y, CARD_W, WING_CARD_H);
        boolean equipped = definition.id().equals(
                AccessoryRegistry.selectedId(AccessorySlot.WINGS));
        float hover = animatedHover(1_100_000 + definition.customModelData(), hovered);
        float lift = hover * 5.0F;
        drawGalleryCard(graphics,x,y-lift,CARD_W,WING_CARD_H,WING_PREVIEW_H,equipped,equipped,hover);
        int iconSize = Math.round(168 * (1.0F + hover * 0.055F));
        float stageCenterY = y - lift + (54 + WING_PREVIEW_H - 8) * 0.5F;
        drawHeadwearIcon(graphics, definition, x + (CARD_W - iconSize) / 2, Math.round(stageCenterY - iconSize * 0.5F), iconSize);
        drawGalleryTitle(graphics,definition.displayName(),x,y-lift,CARD_W,WING_CARD_H,WING_PREVIEW_H,equipped,hover);
    }

    private void renderWingMannequin(GuiGraphics graphics,
                                     AccessoryDefinition definition,
                                     int x, int y) {
        if (minecraft == null || minecraft.player == null) {
            drawHeadwearIcon(graphics, definition, x + (CARD_W - 150) / 2, y + (WING_PREVIEW_H - 150) / 2, 150);
            return;
        }
        EntityRenderDispatcher dispatcher = minecraft.getEntityRenderDispatcher();
        EntityRenderer<? super LivingEntity, ?> renderer =
                dispatcher.getRenderer(minecraft.player);
        EntityRenderState state = renderer.createRenderState(minecraft.player, 1);
        state.lightCoords = 15728880;
        state.shadowPieces.clear();
        state.outlineColor = 0;
        state.nameTag = null;
        if (state instanceof AvatarRenderState avatar) {
            ClientAsset.ResourceTexture body = new ClientAsset.ResourceTexture(
                    MANNEQUIN_SKIN, MANNEQUIN_SKIN);
            PlayerSkin original = avatar.skin;
            avatar.skin = new PlayerSkin(body, null, null, original.model(), false);
            avatar.id = -3_100_000 - definition.customModelData();
            avatar.showCape = false;
            avatar.headItem.clear();
            avatar.rightHandItemState.clear();
            avatar.leftHandItemState.clear();
            avatar.rightHandItemStack = ItemStack.EMPTY;
            avatar.leftHandItemStack = ItemStack.EMPTY;
            avatar.headEquipment = ItemStack.EMPTY;
            avatar.chestEquipment = ItemStack.EMPTY;
            avatar.legsEquipment = ItemStack.EMPTY;
            avatar.feetEquipment = ItemStack.EMPTY;
            AccessoryWorldRenderer.registerPreviewWing(avatar.id, definition);
        }
        if (state instanceof LivingEntityRenderState living) {
            living.bodyRot = 315;
            living.yRot = 315;
            living.xRot = 0;
            living.walkAnimationPos = 0;
            living.walkAnimationSpeed = 0;
            living.boundingBoxWidth /= living.scale;
            living.boundingBoxHeight /= living.scale;
            living.scale = 1;
        }
        int left = toScreenX(x + 4);
        int top = toScreenY(y + 12);
        int right = toScreenX(x + CARD_W - 4);
        int bottom = toScreenY(y + WING_PREVIEW_H + 4);
        int scale = Math.max(1, Math.round(WING_PREVIEW_H * .36f * uiScale));
        Quaternionf orientation = new Quaternionf().rotateZ((float) Math.PI);
        Vector3f center = new Vector3f(0,
                state.boundingBoxHeight / 2 - 0.08F, 0);
        graphics.submitEntityRenderState(state, scale, center, orientation,
                new Quaternionf(), left, top, right, bottom);
    }

    private void renderHeadwearMannequin(GuiGraphics graphics,
                                         AccessoryDefinition definition,
                                         int x, int y) {
        if (minecraft == null || minecraft.player == null) {
            drawHeadwearIcon(graphics, definition, x + (HEADWEAR_W - 150) / 2, y + (CARD_PREVIEW_H - 150) / 2, 150);
            return;
        }
        EntityRenderDispatcher dispatcher = minecraft.getEntityRenderDispatcher();
        EntityRenderer<? super LivingEntity, ?> renderer =
                dispatcher.getRenderer(minecraft.player);
        EntityRenderState state = renderer.createRenderState(minecraft.player, 1);
        state.lightCoords = 15728880;
        state.shadowPieces.clear();
        state.outlineColor = 0;
        state.nameTag = null;
        if (state instanceof AvatarRenderState avatar) {
            ClientAsset.ResourceTexture body = new ClientAsset.ResourceTexture(
                    MANNEQUIN_SKIN, MANNEQUIN_SKIN);
            PlayerSkin original = avatar.skin;
            avatar.skin = new PlayerSkin(body, null, null, original.model(), false);
            avatar.id = -3_000_000 - definition.customModelData();
            avatar.showCape = false;
            avatar.headItem.clear();
            avatar.rightHandItemState.clear();
            avatar.leftHandItemState.clear();
            avatar.rightHandItemStack = ItemStack.EMPTY;
            avatar.leftHandItemStack = ItemStack.EMPTY;
            avatar.headEquipment = ItemStack.EMPTY;
            avatar.chestEquipment = ItemStack.EMPTY;
            avatar.legsEquipment = ItemStack.EMPTY;
            avatar.feetEquipment = ItemStack.EMPTY;
            minecraft.getItemModelResolver().updateForLiving(avatar.headItem,
                    AccessoryItemModels.stack(definition), ItemDisplayContext.HEAD,
                    minecraft.player);
        }
        if (state instanceof LivingEntityRenderState living) {
            living.bodyRot = 145;
            living.yRot = 0;
            living.xRot = 12;
            living.walkAnimationPos = 0;
            living.walkAnimationSpeed = 0;
            living.boundingBoxWidth /= living.scale;
            living.boundingBoxHeight /= living.scale;
            living.scale = 1;
        }
        int left = toScreenX(x + 4);
        int top = toScreenY(y + 4);
        int right = toScreenX(x + HEADWEAR_W - 4);
        int bottom = toScreenY(y + CARD_PREVIEW_H - 2);
        // Keep the hat and upper torso in one fixed portrait, facing down-right.
        // Move the framing center down with the smaller scale so the torso is visible.
        int scale = Math.max(1, Math.round(CARD_PREVIEW_H * .62f * uiScale));
        Quaternionf tilt = new Quaternionf().rotateX((float) Math.toRadians(-10));
        Quaternionf orientation = new Quaternionf().rotateZ((float) Math.PI).mul(tilt);
        Vector3f center = new Vector3f(0,
                state.boundingBoxHeight - 0.22F, 0);
        graphics.submitEntityRenderState(state, scale, center, orientation,
                new Quaternionf(tilt).conjugate(), left, top, right, bottom);
    }

    private void drawTrimCards(GuiGraphics graphics, int mouseX, int mouseY) {
        List<String> values = filteredTrimPatterns();
        int max = maxScroll(values.size());
        scrollRow = clamp(scrollRow, 0, max);
        int baseRow = smoothBaseRow(max);
        int fracY = smoothFracOffset(baseRow, rowStep());
        int start = baseRow * COLUMNS;
        int end = Math.min(values.size(), (baseRow + cardRows() + 1) * COLUMNS);
        graphics.enableScissor(CONTENT_X - 4, CARD_TOP - 4, CONTENT_RIGHT + 4, VIEW_BOTTOM + 4);
        try {
            for (int index = start; index < end; index++) {
                int visible = index - start;
                int x = CONTENT_X + visible % COLUMNS * (CARD_W + CARD_GAP);
                int y = cardTop() + visible / COLUMNS * rowStep() - fracY;
                drawTrimCard(graphics, mouseX, mouseY, values.get(index), x, y);
            }
        } finally {
            graphics.disableScissor();
        }
        drawScrollbar(graphics, values.size());
    }

    private void drawTrimCard(GuiGraphics graphics, int mouseX, int mouseY,
                              String pattern, int x, int y) {
        int cardH = cardHeight();
        int previewH = cardPreviewHeight();
        boolean hovered = inside(mouseX, mouseY, x, y, CARD_W, cardH);
        boolean equipped = pattern.equals(LinTrimManager.pattern());
        int stableId = 2_000_000 + LinTrimManager.PATTERNS.indexOf(pattern);
        float hover = animatedHover(stableId, hovered);
        float lift = hover * 5.0F;
        drawGalleryCard(graphics,x,y-lift,CARD_W,cardH,previewH,equipped,equipped,hover);
        Identifier texture = trimPatternTexture(pattern);
        int iconSize = Math.round(166 * (1.0F + hover * 0.055F));
        float stageCenterY = y - lift + (54 + previewH - 8) * 0.5F;
        graphics.blit(RenderPipelines.GUI_TEXTURED, texture,
                x + (CARD_W - iconSize) / 2, Math.round(stageCenterY - iconSize * 0.5F), 0, 0,
                iconSize, iconSize, 16, 16, 16, 16);
        drawGalleryTitle(graphics,LinTrimManager.displayName(pattern),x,y-lift,CARD_W,cardH,previewH,equipped,hover);
    }

    private void drawArtifactCards(GuiGraphics graphics, int mouseX, int mouseY) {
        List<ArtifactSkins.Artifact> values = filteredArtifacts();
        int max = maxScroll(values.size());
        scrollRow = clamp(scrollRow, 0, max);
        int baseRow = smoothBaseRow(max);
        int fracY = smoothFracOffset(baseRow, rowStep());
        int start = baseRow * COLUMNS;
        int end = Math.min(values.size(), (baseRow + cardRows() + 1) * COLUMNS);
        graphics.enableScissor(CONTENT_X - 4, CARD_TOP - 4, CONTENT_RIGHT + 4, VIEW_BOTTOM + 4);
        try {
            for (int index = start; index < end; index++) {
                int visible = index - start;
                int x = CONTENT_X + visible % COLUMNS * (CARD_W + CARD_GAP);
                int y = cardTop() + visible / COLUMNS * rowStep() - fracY;
                drawArtifactCard(graphics, mouseX, mouseY, values.get(index), x, y);
            }
        } finally {
            graphics.disableScissor();
        }
        drawScrollbar(graphics, values.size());
    }

    private void drawArtifactCard(GuiGraphics graphics, int mouseX, int mouseY,
                                  ArtifactSkins.Artifact artifact, int x, int y) {
        int cardH = cardHeight();
        int previewH = cardPreviewHeight();
        boolean hovered = inside(mouseX, mouseY, x, y, CARD_W, cardH);
        boolean current = artifact == currentArtifact();
        boolean enabled = ArtifactSkinConfig.enabled
                && ArtifactSkinConfig.isArtifactEnabled(artifact.id());
        float hover = animatedHover(3_000_000 + artifact.ordinal(), hovered);
        float lift = hover * 5.0F;
        drawGalleryCard(graphics,x,y-lift,CARD_W,cardH,previewH,current,enabled,hover);
        int iconSize = Math.round(176 * (1.0F + hover * 0.055F));
        float stageCenterY = y - lift + (54 + previewH - 8) * 0.5F;
        drawArtifactIcon(graphics, ArtifactSkins.selected(artifact),
                x + (CARD_W - iconSize) / 2, Math.round(stageCenterY - iconSize * 0.5F), iconSize);
        drawGalleryTitle(graphics,artifact.displayName(),x,y-lift,CARD_W,cardH,previewH,enabled,hover);
    }

    private void drawCard(GuiGraphics graphics, int mouseX, int mouseY,
                          CosmeticDefinition cosmetic, int x, int y) {
        drawCard(graphics, mouseX, mouseY, cosmetic, x, y,
                CARD_H, CARD_PREVIEW_H);
    }

    private void drawFloatingCards(GuiGraphics graphics, int mouseX, int mouseY) {
        if (floatingView == FLOATING_VIEW_HOPLITE) {
            List<AccessoryDefinition> values = filteredFloating();
            int max = maxScroll(values.size());
            scrollRow = clamp(scrollRow, 0, max);
            int baseRow = smoothBaseRow(max);
            int fracY = smoothFracOffset(baseRow, FLOATING_ROW_STEP);
            int start = baseRow * COLUMNS;
            int end = Math.min(values.size(), (baseRow + cardRows() + 1) * COLUMNS);
            graphics.enableScissor(CONTENT_X - 4, HEADWEAR_TOP - 4, CONTENT_RIGHT + 4, VIEW_BOTTOM + 4);
            try {
                for (int index = start; index < end; index++) {
                    int visible = index - start;
                    int x = CONTENT_X + visible % COLUMNS * (CARD_W + CARD_GAP);
                    int y = HEADWEAR_TOP + visible / COLUMNS * FLOATING_ROW_STEP - fracY;
                    drawFloatingCard(graphics, mouseX, mouseY,
                            values.get(index), x, y);
                }
            } finally {
                graphics.disableScissor();
            }
            drawScrollbar(graphics, values.size());
            return;
        }
        List<CosmeticDefinition> values = filtered();
        int max = maxScroll(values.size());
        scrollRow = clamp(scrollRow, 0, max);
        int baseRow = smoothBaseRow(max);
        int fracY = smoothFracOffset(baseRow, FLOATING_ROW_STEP);
        int start = baseRow * COLUMNS;
        int end = Math.min(values.size(), (baseRow + cardRows() + 1) * COLUMNS);
        CosmeticAssetManager.preload(values.subList(start, end));
        graphics.enableScissor(CONTENT_X - 4, HEADWEAR_TOP - 4, CONTENT_RIGHT + 4, VIEW_BOTTOM + 4);
        try {
            for (int index = start; index < end; index++) {
                int visible = index - start;
                int x = CONTENT_X + visible % COLUMNS * (CARD_W + CARD_GAP);
                int y = HEADWEAR_TOP + visible / COLUMNS * FLOATING_ROW_STEP - fracY;
                drawCard(graphics, mouseX, mouseY, values.get(index), x, y,
                        FLOATING_CARD_H, FLOATING_PREVIEW_H);
            }
        } finally {
            graphics.disableScissor();
        }
        drawScrollbar(graphics, values.size());
    }

    private void drawFloatingCard(GuiGraphics graphics, int mouseX, int mouseY,
                                  AccessoryDefinition definition, int x, int y) {
        boolean hovered = inside(mouseX, mouseY, x, y, CARD_W, FLOATING_CARD_H);
        boolean equipped = definition.id().equals(
                AccessoryRegistry.selectedId(AccessorySlot.FLOATING));
        float hover = animatedHover(1_200_000 + definition.customModelData(), hovered);
        float lift = hover * 5.0F;
        drawGalleryCard(graphics,x,y-lift,CARD_W,FLOATING_CARD_H,FLOATING_PREVIEW_H,equipped,equipped,hover);
        drawFloatingEffectPreview(graphics, definition, x,
                Math.round(y - lift));
        drawGalleryTitle(graphics,definition.displayName(),x,y-lift,CARD_W,FLOATING_CARD_H,FLOATING_PREVIEW_H,equipped,hover);
    }

    private void drawFloatingEffectPreview(GuiGraphics graphics,
                                           AccessoryDefinition definition,
                                           int x, int y) {
        Identifier texture = Identifier.fromNamespaceAndPath("civilization",
                "textures/item/ui/medallions/" + definition.id()
                        + "_smaller.png");
        double time = (System.nanoTime() - openedAtNanos) / 1_000_000_000.0;
        float stageCenterY = y + (54 + FLOATING_PREVIEW_H - 8) * 0.5F;
        boolean champion = "medallion_champion".equals(definition.id());
        float baseY = champion ? stageCenterY - 14 : stageCenterY;

        int sideSize = Math.round(52 * (1.0F + 0.03F * (float) Math.sin(time * 2.6 + 1.2)));
        int leftX = x + (CARD_W - sideSize) / 2 - 84;
        int leftY = Math.round(baseY + 12 + (float) Math.sin(time * 2.2 + 2.1) * 16 - sideSize * 0.5F);
        drawTexture(graphics, texture, leftX, leftY, sideSize, sideSize, 16, 16);

        int rightX = x + (CARD_W - sideSize) / 2 + 84;
        int rightY = Math.round(baseY - 8 + (float) Math.sin(time * 2.2 + 4.2) * 16 - sideSize * 0.5F);
        drawTexture(graphics, texture, rightX, rightY, sideSize, sideSize, 16, 16);

        int heroSize = Math.round(84 * (1.0F + 0.035F * (float) Math.sin(time * 2.4)));
        int heroX = x + (CARD_W - heroSize) / 2;
        int heroY = Math.round(baseY + (float) Math.sin(time * 2.2) * 12 - heroSize * 0.5F);
        drawTexture(graphics, texture, heroX, heroY, heroSize, heroSize, 16, 16);

        if (!champion) return;
        String rank = "#" + ClientAccessoryConfig.floatingNumber;
        float fontSize = bodyFont(7.2F);
        float openW = FontManager.widthRegular("[", fontSize);
        float rankW = FontManager.widthRegular(rank, fontSize);
        float closeW = FontManager.widthRegular("]", fontSize);
        float totalW = openW + rankW + closeW;
        float textX = x + (CARD_W - totalW) * 0.5F;
        float textY = baseY + heroSize * 0.5F + 18 + (float) Math.sin(time * 2.2 + 0.8) * 5;
        OpenGlUiRenderer.textRegular(graphics, "[", textX, textY, fontSize, TEXT_SECONDARY);
        OpenGlUiRenderer.textRegular(graphics, rank, textX + openW, textY, fontSize, ACCENT);
        OpenGlUiRenderer.textRegular(graphics, "]", textX + openW + rankW, textY, fontSize, TEXT_SECONDARY);
    }

    private void drawCard(GuiGraphics graphics, int mouseX, int mouseY,
                          CosmeticDefinition cosmetic, int x, int y,
                          int cardHeight, int previewHeight) {
        boolean hovered = inside(mouseX, mouseY, x, y, CARD_W, cardHeight);
        boolean equipped = CosmeticConfig.isEquipped(cosmetic.id());
        boolean current = selected != null && selected.id() == cosmetic.id();
        float hover = animatedHover(cosmetic.id(), hovered);
        float lift = hover * 5.0F;
        drawGalleryCard(graphics,x,y-lift,CARD_W,cardHeight,previewHeight,current,equipped,hover);

        CosmeticRenderData data = CosmeticAssetManager.getPreview(cosmetic);
        if (data == null) data = CosmeticAssetManager.get(cosmetic);
        if (data != null) {
            drawCardPreview(graphics, cosmetic, data, x, y, lift, hover,
                    previewHeight);
        } else {
            float pulse = 0.5F + 0.5F * (float) Math.sin(
                    System.currentTimeMillis() / 280.0 + cosmetic.id());
            int alpha = 25 + Math.round(pulse * 25);
            float size=Math.min(56,previewHeight-24);
            OpenGlUiRenderer.roundedRect(graphics,x+(CARD_W-size)/2,y+(previewHeight-size)/2-lift,
                    size,size,9,(alpha<<24)|(ClientShell.muted()&0xFFFFFF));
        }
        drawGalleryTitle(graphics,cosmetic.name(),x,y-lift,CARD_W,cardHeight,previewHeight,equipped,hover);
    }

    private void drawCardPreview(GuiGraphics graphics, CosmeticDefinition cosmetic,
                                 CosmeticRenderData data, int x, int y,
                                 float lift, float hover, int previewHeight) {
        CardDisplay display = CardDisplay.forCategory(cosmetic.category());
        int raisedY = Math.round(y - lift);
        int stageTop = raisedY + 54;
        int stageBottom = raisedY + previewHeight - 8;
        float stageCenterY = (stageTop + stageBottom) * 0.5F;
        float stageHeight = Math.max(80, stageBottom - stageTop);
        graphics.enableScissor(x + 8, stageTop, x + CARD_W - 8, stageBottom);
        try {
            float hoverZoom = 1.0F + clampFloat(hover, 0F, 1F) * 0.055F;
            if (display == CardDisplay.CLOAK) {
                OpenGlUiRenderer.cosmeticModel(graphics, CosmeticAssetManager.getPreview(cosmetic),
                        x + CARD_W * .5F, stageCenterY, stageHeight * .72F * hoverZoom, 0, 0);
                return;
            }
            CosmeticRenderData directData = CosmeticAssetManager.getPreview(cosmetic);
            if (directData == null) directData = data;
            if (display == CardDisplay.DIRECT || (directData != null && directData.mesh() != null && directData.mesh().vertexCount() > 0)) {
                float size = Math.min(CARD_W - 72, stageHeight * .80f) * hoverZoom;
                CosmeticRenderData previewData = directData;
                if (cosmetic.category() == CosmeticCategory.DRAGON_WINGS
                        && !cosmetic.gek()) {
                    CosmeticMesh frame = BuiltinCosmeticMeshes.wingFrame(
                            System.currentTimeMillis());
                    previewData = new CosmeticRenderData(directData.definition(), frame,
                            directData.texture(), directData.capeTexture(), directData.attachment(),
                            directData.doubleSided(), directData.translucent(), frame,
                            directData.referenceMesh(), System.nanoTime(), 1L);
                }
                if (cosmetic.category() == CosmeticCategory.DRAGON_WINGS
                        && !cosmetic.gek()) {
                    OpenGlUiRenderer.cosmeticModel(graphics, previewData,
                            x + CARD_W * 0.5F,
                            stageCenterY,
                            size * 1.05F, 215.0F, 0.0F);
                } else if (cosmetic.category() == CosmeticCategory.DRAGON_WINGS) {
                    OpenGlUiRenderer.cosmeticModel(graphics, previewData,
                            x + CARD_W * 0.5F,
                            stageCenterY,
                            size * 1.05F, 0.0F, 0.0F);
                } else {
                    OpenGlUiRenderer.cosmeticModel(graphics, previewData,
                            x + CARD_W * 0.5F,
                            stageCenterY, size);
                }
                return;
            }
            if (minecraft == null) return;
            int shiftX = Math.round((display.xOffset - 0.5F) * CARD_W);
            int shiftY = Math.round(display.yOffset * stageHeight);
            int left = toScreenX(x + 8);
            int top = toScreenY(stageTop);
            int right = toScreenX(x + CARD_W - 8);
            int bottom = toScreenY(stageBottom);
            int screenShiftX = Math.round(shiftX * uiScale);
            int screenShiftY = Math.round(shiftY * uiScale);
            int scale = Math.max(1, Math.round(
                    (stageHeight / 1.9F * display.zoom + hover * 1.5F) * uiScale));
            renderEntityFixed(graphics, left, top, right, bottom, scale,
                    minecraft.player, 0, List.of(cosmetic), true, display,
                    screenShiftX, screenShiftY);
        } finally {
            graphics.disableScissor();
        }
    }

    private void drawFits(GuiGraphics graphics, int mouseX, int mouseY) {
        List<CosmeticConfig.SavedFit> fits = filteredFits();
        int itemCount = fits.size() + 1;
        scrollRow = clamp(scrollRow, 0, maxFitScroll(itemCount));
        int start = scrollRow * FIT_COLUMNS;
        int end = Math.min(itemCount,
                start + FIT_VISIBLE_ROWS * FIT_COLUMNS);
        for (int index = start; index < Math.min(fits.size(), end); index++) {
            CosmeticAssetManager.preload(fitCosmetics(fits.get(index)));
        }
        graphics.enableScissor(CONTENT_X - 4, CARD_TOP - 4, CONTENT_RIGHT + 4, VIEW_BOTTOM + 4);
        try {
            for (int index = start; index < end; index++) {
                int visibleIndex = index - start;
                int x = CONTENT_X + visibleIndex % FIT_COLUMNS
                        * (FIT_CARD_W + CARD_GAP);
                int y = CARD_TOP + visibleIndex / FIT_COLUMNS * FIT_ROW_STEP;
                if (index < fits.size()) {
                    drawFitCard(graphics, mouseX, mouseY, fits.get(index), x, y);
                } else {
                    drawCreateFitCard(graphics, mouseX, mouseY, x, y);
                }
            }
        } finally {
            graphics.disableScissor();
        }
        drawFitScrollbar(graphics, itemCount);
    }

    private void drawFitCard(GuiGraphics graphics, int mouseX, int mouseY,
                             CosmeticConfig.SavedFit fit, int x, int y) {
        boolean hovered = inside(mouseX, mouseY, x, y, FIT_CARD_W, FIT_CARD_H);
        boolean active = CosmeticConfig.isActiveFit(fit.id());
        boolean current = selectedFitId != null && selectedFitId == fit.id();
        drawGalleryCard(graphics,x,y,FIT_CARD_W,FIT_CARD_H,FIT_PREVIEW_H,current,active,animatedHover(-2_000_000-fit.id(),hovered));
        drawTexture(graphics, SUITS, x + 9, y + 7,
                16, 16, 40, 40);
        boolean deleteHover = inside(mouseX, mouseY,
                x + FIT_CARD_W - 30, y, 30, 30);
        if (deleteHover) {
            OpenGlUiRenderer.roundedRect(graphics, x + FIT_CARD_W - 29,
                    y + 3, 25, 24, 5, ClientShell.hoverSurface());
        }
        drawTexture(graphics, CLOSE, x + FIT_CARD_W - 21,
                y + 9, 12, 12, 17, 17);

        List<CosmeticDefinition> cosmetics = fitCosmetics(fit);
        String count = cosmetics.size()
                + (cosmetics.size() == 1 ? " 件饰品" : " 件饰品");
        int shown = Math.min(6, cosmetics.size());
        for (int index = 0; index < shown; index++) {
            int column = index % 3;
            int row = index / 3;
            float centerX = x + FIT_CARD_W / 2.0F - 104 + column * 104;
            float centerY = y + 88 + row * 124;
            drawFitCosmetic(graphics, cosmetics.get(index),
                    centerX, centerY, 100);
        }
        if (cosmetics.isEmpty()) {
            bodyText(graphics, "空穿搭",
                    x + (FIT_CARD_W - FontManager.widthRegular("空穿搭",bodyFont(8))) * .5F, y + 68, 8, TEXT_MUTED);
        }
        if (cosmetics.size() > shown) {
            String more = "+" + (cosmetics.size() - shown);
            bodyText(graphics, more,
                    x + FIT_CARD_W - FontManager.widthRegular(more,bodyFont(7.5F)) - 8,
                    y + FIT_PREVIEW_H - 13, 7.5F, TEXT_MUTED);
        }

        String visibleName = truncate(fit.name(), 8.5F, FIT_CARD_W - 42);
        float nameWidth = FontManager.widthRegular(visibleName,bodyFont(8.5F));
        float nameX = x + (FIT_CARD_W - nameWidth - 15) * 0.5F;
        bodyText(graphics, visibleName,
                nameX, y + FIT_PREVIEW_H + 34, 8.5F,
                hovered || active || current ? TEXT_PRIMARY : TEXT_SECONDARY);
        drawTexture(graphics, PENCIL,
                Math.round(nameX + nameWidth + 5), y + FIT_PREVIEW_H + 32,
                10, 10, 24, 24);

        String meta = count + (active ? "  ·  已应用" : "");
        float metaWidth = FontManager.widthRegular(meta,bodyFont(7.5F));
        bodyText(graphics, meta,
                x + (FIT_CARD_W - metaWidth) * 0.5F,
                y + FIT_PREVIEW_H + 78, 7.5F, active ? ACCENT : TEXT_MUTED);
    }

    private void drawCreateFitCard(GuiGraphics graphics, int mouseX, int mouseY,
                                   int x, int y) {
        boolean hovered = inside(mouseX, mouseY, x, y,
                FIT_CARD_W, FIT_CARD_H);
        drawGalleryCard(graphics,x,y,FIT_CARD_W,FIT_CARD_H,FIT_PREVIEW_H,false,false,hovered?1:0);
        drawTexture(graphics, ADD,
                x + FIT_CARD_W / 2 - 8, y + 98,
                16, 16, 16, 16);
        String label = "新建穿搭";
        float labelWidth = FontManager.widthRegular(label,bodyFont(8.5F));
        bodyText(graphics, label,
                x + (FIT_CARD_W - labelWidth) * 0.5F,
                y + 137, 8.5F, hovered ? TEXT_SECONDARY : TEXT_MUTED);
    }

    private void drawModernScrollbar(GuiGraphics graphics, int top, int bottom,
                                     int currentRow, int maxRow, int visibleRows, int totalRows) {
        lastScrollTop = top;
        lastScrollBottom = bottom;
        lastScrollMaxRow = Math.max(0, maxRow);
        if (maxRow <= 0) {
            scrollbarHover = 0f;
            return;
        }
        boolean hovered = scrollbarDragging
                || inside(lastGalleryMouseX, lastGalleryMouseY, SCROLL_X - 8, top, 26, bottom - top);
        scrollbarHover = dev.lin.client.shared.UiMotion.follow(scrollbarHover, hovered ? 1f : 0f, frameSeconds);
        int trackHeight = Math.max(40, bottom - top);
        float trackW = 10f + 2.5f * scrollbarHover;
        float trackX = SCROLL_X - 1.25f * scrollbarHover;
        OpenGlUiRenderer.roundedPanel(graphics, trackX, top, trackW, trackHeight, trackW * 0.5F,
                0x88101413, mixColor(0x662B3431, 0x9943584E, scrollbarHover), uiStroke(0.8F));
        int thumbHeight = Math.max(76, Math.min(trackHeight - 8,
                Math.round(trackHeight * ((float) visibleRows / Math.max(visibleRows, totalRows)))));
        float progress = clampFloat(visualScrollRow / maxRow, 0f, 1f);
        float thumbY = top + 2 + (trackHeight - thumbHeight - 4) * progress;
        lastScrollThumbH = thumbHeight;
        lastScrollThumbY = thumbY;
        float thumbW = trackW - 2f;
        OpenGlUiRenderer.roundedPanel(graphics, trackX + 1f, thumbY, thumbW, thumbHeight, thumbW * 0.5F,
                mixColor(0xE02A3E25, 0xEE35522D, scrollbarHover),
                mixColor(0xAA76E02A, 0xEE8EF042, scrollbarHover), uiStroke(0.95F));
        OpenGlUiRenderer.roundedRect(graphics, trackX + thumbW * 0.35f, thumbY + 8, 2.2f, Math.max(12, thumbHeight - 16),
                1.1f, withOpacity(0xFFFFFFFF, 0.22f + 0.14f * scrollbarHover));
    }

    private void drawFitScrollbar(GuiGraphics graphics, int itemCount) {
        int max = maxFitScroll(itemCount);
        int rows = (itemCount + FIT_COLUMNS - 1) / FIT_COLUMNS;
        drawModernScrollbar(graphics, CARD_TOP, VIEW_BOTTOM, scrollRow, max, FIT_VISIBLE_ROWS, rows);
    }

    private void drawFitCosmetic(GuiGraphics graphics, CosmeticDefinition cosmetic,
                                 float centerX, float centerY, float scale) {
        CosmeticRenderData data = CosmeticAssetManager.getPreview(cosmetic);
        if (data != null) {
            OpenGlUiRenderer.cosmeticModel(graphics, data, centerX, centerY, scale);
        }
    }

    private void drawScrollbar(GuiGraphics graphics, int count) {
        drawScrollbar(graphics, count, VISIBLE_ROWS);
    }

    private void drawScrollbar(GuiGraphics graphics, int count, int visibleRows) {
        int rows = rows(count);
        int max = Math.max(0, rows - visibleRows);
        int top = hasSubTabs() ? HEADWEAR_TOP : CARD_TOP;
        drawModernScrollbar(graphics, top, VIEW_BOTTOM, scrollRow, max, visibleRows, rows);
    }

    private void drawLoadout(GuiGraphics graphics, int mouseX, int mouseY) {
        CosmeticConfig.SavedFit previewFit = selectedFit();
        OpenGlUiRenderer.roundedRect(graphics, PREVIEW_X + 14, PREVIEW_ACTION_Y - 16, PREVIEW_W - 28, 1,
                0, ClientShell.border());
        if (!fitsView && section == LockerSection.COSMETICS
                && capeView != CAPE_VIEW_LUNAR) {
            LunarCape cape = LunarCapeRegistry.selected();
            boolean equipped = capeView == CAPE_VIEW_OFFICIAL
                    ? LunarCapeRegistry.isOfficial(cape)
                    : LunarCapeRegistry.isDungeon(cape);
            if (equipped) {
                drawSelectedLoadoutFooter(graphics, mouseX, mouseY,
                        cape.displayName(), capeView == CAPE_VIEW_OFFICIAL
                                ? "官方披风" : "地下城披风", true);
            } else {
                String text = capeView == CAPE_VIEW_OFFICIAL
                        ? "选择一件官方披风" : "选择一件地下城披风";
                float width = FontManager.widthRegular(text,bodyFont(8));
                bodyText(graphics, text,
                        PREVIEW_X + (PREVIEW_W - width) * 0.5F,
                        PREVIEW_ACTION_TEXT_Y, 8, TEXT_MUTED);
            }
            return;
        }
        if (!fitsView && section == LockerSection.FLOATING_EFFECTS
                && floatingView == FLOATING_VIEW_HOPLITE) {
            AccessoryDefinition floating = AccessoryRegistry.selected(
                    AccessorySlot.FLOATING);
            if (floating == null) {
                drawCenteredFooterText(graphics, "选择一种 Hoplite 漂浮样式");
            } else {
                drawSelectedLoadoutFooter(graphics, mouseX, mouseY,
                        floating.displayName(), "Hoplite 漂浮", true);
            }
            return;
        }
        if (!fitsView && section.isExternal()) {
            drawExternalLoadoutFooter(graphics, mouseX, mouseY);
            return;
        }
        if (fitsView) {
            if (previewFit == null) {
                bodyText(graphics, "选择穿搭以预览",
                        PREVIEW_X + 34, PREVIEW_ACTION_TEXT_Y, 8, TEXT_MUTED);
            } else {
                boolean active = CosmeticConfig.isActiveFit(previewFit.id());
                boolean gearHover = inside(mouseX, mouseY,
                        PREVIEW_X + 10, PREVIEW_ACTION_Y, 27, PREVIEW_ACTION_H);
                OpenGlUiRenderer.roundedRect(graphics, PREVIEW_X + 10, PREVIEW_ACTION_Y,
                        27, PREVIEW_ACTION_H, 6, gearHover ? GLASS_CARD_HOVER : ClientShell.control());
                drawTexture(graphics, COG, PREVIEW_X + 16, PREVIEW_ACTION_Y + (PREVIEW_ACTION_H - 15) / 2,
                        15, 15, 16, 16);
                int applyX = PREVIEW_X + 44;
                int applyW = PREVIEW_W - 55;
                boolean applyHover = inside(mouseX, mouseY, applyX, PREVIEW_ACTION_Y, applyW, PREVIEW_ACTION_H);
                OpenGlUiRenderer.roundedRect(graphics, applyX, PREVIEW_ACTION_Y, applyW,
                        PREVIEW_ACTION_H, 6, active ? ClientShell.selected()
                                : applyHover ? ClientShell.hoverSurface() : ACCENT);
                String action = active ? "已应用" : "应用穿搭";
                float actionWidth = FontManager.widthRegular(action,bodyFont(8));
                int iconSize = active ? 11 : 10;
                float actionLeft = applyX + (applyW - actionWidth - iconSize - 5) * 0.5F;
                drawTexture(graphics, active ? WARNING : CHECKED,
                        Math.round(actionLeft), PREVIEW_ACTION_Y + (PREVIEW_ACTION_H - iconSize) / 2, iconSize, iconSize,
                        active ? 24 : 12, active ? 24 : 12);
                bodyText(graphics, action,
                        actionLeft + iconSize + 5,
                        PREVIEW_ACTION_TEXT_Y, 8, active ? ACCENT : ClientShell.accentText());
            }
        } else if (selected != null) {
            boolean equipped = CosmeticConfig.isEquipped(selected.id());
            if (!fitsView && section == LockerSection.COMPANIONS) {
                int buttonX = PREVIEW_X + 14;
                int buttonW = PREVIEW_W - 28;
                boolean buttonHover = inside(mouseX, mouseY, buttonX, PREVIEW_ACTION_Y,
                        buttonW, PREVIEW_ACTION_H);
                OpenGlUiRenderer.roundedPanel(graphics, buttonX,
                        PREVIEW_ACTION_Y, buttonW, PREVIEW_ACTION_H, 6,
                        equipped
                                ? buttonHover ? ClientShell.hoverSurface() : ClientShell.selected()
                                : buttonHover ? ClientShell.hoverSurface() : ClientShell.control(),
                        equipped ? ACCENT : ClientShell.border(), 1);
                String action = equipped ? "已装备" : "装备";
                float actionWidth = FontManager.widthRegular(action,bodyFont(7.5F));
                bodyText(graphics, action,
                        buttonX + (buttonW - actionWidth) * 0.5F,
                        PREVIEW_ACTION_TEXT_Y, 7.5F,
                        equipped ? ACCENT : TEXT_PRIMARY);
                return;
            }
            drawSelectedLoadoutFooter(graphics, mouseX, mouseY,
                    selected.name(), selected.category().displayName(), equipped);
        } else {
            String playerName = Minecraft.getInstance().getGameProfile().name();
            previewText(graphics, playerName == null || playerName.isEmpty() ? "Player" : playerName,
                    PREVIEW_NAME_Y, dev.lin.client.cosmetics.font.PageTypography.BODY, TEXT_PRIMARY);
            previewText(graphics, ClientShell.tr("当前装扮预览", "Current Loadout"),
                    PREVIEW_STATUS_Y, dev.lin.client.cosmetics.font.PageTypography.CAPTION, TEXT_MUTED);
            int buttonX = PREVIEW_X + 8, buttonW = PREVIEW_W - 16;
            OpenGlUiRenderer.roundedPanel(graphics, buttonX, PREVIEW_ACTION_Y, buttonW, PREVIEW_ACTION_H, 10,
                    0xFF1E2D19, 0x5576E02A, uiStroke(1.0f));
            String label = ClientShell.tr("已启用", "Enabled");
            float lw = FontManager.widthRegular(label, bodyFont(8));
            float startX = buttonX + (buttonW - lw - 18) * 0.5F;
            OpenGlUiRenderer.checkIcon(graphics, startX + 5, PREVIEW_ACTION_Y + PREVIEW_ACTION_H * 0.5F, 11, ACCENT);
            bodyText(graphics, label, startX + 18, PREVIEW_ACTION_TEXT_Y, 8, ACCENT);
            OpenGlUiRenderer.roundedRect(graphics, buttonX + buttonW - 22,
                    PREVIEW_ACTION_Y + (PREVIEW_ACTION_H - 9) * 0.5F, 9, 9, 4.5F, ACCENT);
        }

    }

    private void drawSelectedLoadoutFooter(GuiGraphics graphics,
                                           int mouseX, int mouseY,
                                           String displayName, String category, boolean equipped) {
        int buttonX = PREVIEW_X + 8, buttonW = PREVIEW_W - 16;
        previewText(graphics, displayName, PREVIEW_NAME_Y, dev.lin.client.cosmetics.font.PageTypography.BODY, TEXT_PRIMARY);
        previewText(graphics, category + (equipped ? ClientShell.tr(" · 已启用", " · Enabled") : ClientShell.tr(" · 正在预览", " · Preview")),
                PREVIEW_STATUS_Y, dev.lin.client.cosmetics.font.PageTypography.CAPTION, equipped ? ACCENT : TEXT_MUTED);
        boolean buttonHover = inside(mouseX, mouseY, buttonX, PREVIEW_ACTION_Y, buttonW, PREVIEW_ACTION_H);
        OpenGlUiRenderer.roundedPanel(graphics, buttonX, PREVIEW_ACTION_Y, buttonW, PREVIEW_ACTION_H, 10,
                equipped ? (buttonHover ? 0xFF24361E : 0xFF1E2D19) : (buttonHover ? 0xFF27312E : 0xFF202826),
                equipped ? 0x6676E02A : 0xFF333E3B, uiStroke(1.0f));
        String action = equipped ? ClientShell.tr("已启用", "Enabled") : ClientShell.tr("启用 ", "Enable ") + category;
        String visible = truncate(action, 8, buttonW - 44);
        float actionWidth = FontManager.widthRegular(visible,bodyFont(8));
        float textLeft = buttonX + (buttonW - actionWidth - (equipped ? 18 : 0)) * .5F;
        if (equipped) {
            OpenGlUiRenderer.checkIcon(graphics, textLeft + 5, PREVIEW_ACTION_Y + PREVIEW_ACTION_H * 0.5F, 11, ACCENT);
            textLeft += 18;
        }
        bodyText(graphics, visible, textLeft, PREVIEW_ACTION_TEXT_Y, 8,
                equipped ? ACCENT : TEXT_PRIMARY);
        if (equipped) {
            OpenGlUiRenderer.roundedRect(graphics, buttonX + buttonW - 22,
                    PREVIEW_ACTION_Y + (PREVIEW_ACTION_H - 9) * 0.5F, 9, 9, 4.5F, ACCENT);
        }
    }

    private void drawExternalLoadoutFooter(GuiGraphics graphics,
                                           int mouseX, int mouseY) {

        if(section==LockerSection.SPAWN_PODS){
            int count=selectedPod.previewModels(podLarge).size();
            drawFooterButton(graphics,mouseX,mouseY,PREVIEW_X+14,426,PREVIEW_W-28,27,"模型部件 "+(Math.floorMod(podPart,count)+1)+"/"+count+" · 点击切换",false);
            drawFooterButton(graphics,mouseX,mouseY,PREVIEW_X+14,462,PREVIEW_W-28,27,selectedPod.largeGroup.isEmpty()?"仅资源原始尺寸":podLarge?"预览尺寸：3×3":"预览尺寸：普通",podLarge);
            drawFooterButton(graphics,mouseX,mouseY,PREVIEW_X+14,PREVIEW_ACTION_Y,PREVIEW_W-28,PREVIEW_ACTION_H,podSaveFailed?"保存失败，请重试":selectedPod==PodSkins.selected()?"已选用 · 点击卸下":selectedPod.applicable()?"点击卡片选用":"该条目仅可预览",selectedPod==PodSkins.selected());
            return;
        }
        if (section == LockerSection.VIP_ICONS) {
            boolean active = selectedVip.equals(dev.lin.client.cosmetics.vip.VipIcons.selected());
            drawFooterButton(graphics, mouseX, mouseY, PREVIEW_X + 18, 22, PREVIEW_W - 36, 28,
                    CosmeticConfig.vipLobbyOnly() ? "显示范围：大厅" : "显示范围：全局", CosmeticConfig.vipLobbyOnly());
            drawFooterButton(graphics, mouseX, mouseY, PREVIEW_X + 8, PREVIEW_ACTION_Y, PREVIEW_W - 16, PREVIEW_ACTION_H,
                    vipSaveFailed ? "保存失败，点击重试" : active ? "已启用" : "点击卡片装备 · 双击卸下", active);
            return;
        }
        if (section == LockerSection.ARROW_TRAILS) {
            boolean active = selectedArrowTrail == dev.lin.client.cosmetics.render.ArrowTrails.selected();
            drawFooterButton(graphics, mouseX, mouseY, PREVIEW_X + 8, PREVIEW_ACTION_Y, PREVIEW_W - 16, PREVIEW_ACTION_H,
                    trailSaveFailed ? "保存失败，点击重试" : active ? "已启用" : "点击左侧卡片即可装备", active);
            return;
        }
        if (section == LockerSection.KILL_EFFECTS) {
            drawFooterButton(graphics, mouseX, mouseY, PREVIEW_X + 8, PREVIEW_ACTION_Y,
                    PREVIEW_W - 16, PREVIEW_ACTION_H, selectedKillEffect.actionLabel(), false);
            return;
        }
        if (section == LockerSection.HEADWEAR) {
            AccessoryDefinition headwear = AccessoryRegistry.selected(
                    AccessorySlot.HEADWEAR);
            if (headwear != null) {
                previewText(graphics, headwear.displayName(), PREVIEW_NAME_Y, dev.lin.client.cosmetics.font.PageTypography.BODY, TEXT_PRIMARY);
                previewText(graphics, "头饰 · 已启用", PREVIEW_STATUS_Y, dev.lin.client.cosmetics.font.PageTypography.CAPTION, ACCENT);
                drawFooterButton(graphics, mouseX, mouseY, PREVIEW_X + 8, PREVIEW_ACTION_Y,
                        PREVIEW_W - 16, PREVIEW_ACTION_H, "已启用 · 点击卸下", true);
            } else {
                String playerName = Minecraft.getInstance().getGameProfile().name();
                previewText(graphics, playerName == null || playerName.isEmpty() ? "Player" : playerName,
                        PREVIEW_NAME_Y, dev.lin.client.cosmetics.font.PageTypography.BODY, TEXT_PRIMARY);
                previewText(graphics, "选择头饰进行预览", PREVIEW_STATUS_Y, dev.lin.client.cosmetics.font.PageTypography.CAPTION, TEXT_MUTED);
            }
            return;
        }
        if (section == LockerSection.WINGS) {
            AccessoryDefinition wings = AccessoryRegistry.selected(AccessorySlot.WINGS);
            if (wings != null) {
                int controlWidth = (PREVIEW_W - 48) / 3;
                drawFooterButton(graphics, mouseX, mouseY, PREVIEW_X + 18, 22,
                        controlWidth, 28, "上移", false);
                drawFooterButton(graphics, mouseX, mouseY,
                        PREVIEW_X + 24 + controlWidth, 22,
                        controlWidth, 28, "重置", false);
                drawFooterButton(graphics, mouseX, mouseY,
                        PREVIEW_X + 30 + controlWidth * 2, 22,
                        controlWidth, 28, "下移", false);
                previewText(graphics, wings.displayName(), PREVIEW_NAME_Y, dev.lin.client.cosmetics.font.PageTypography.BODY, TEXT_PRIMARY);
                previewText(graphics, "Hoplite 翅膀 · 已启用", PREVIEW_STATUS_Y, dev.lin.client.cosmetics.font.PageTypography.CAPTION, ACCENT);
                drawFooterButton(graphics, mouseX, mouseY, PREVIEW_X + 8, PREVIEW_ACTION_Y,
                        PREVIEW_W - 16, PREVIEW_ACTION_H,
                        String.format(Locale.ROOT, "已启用 · 高度 %+.2f",
                                ClientAccessoryConfig.wingOffsetY), true);
            } else {
                String playerName = Minecraft.getInstance().getGameProfile().name();
                previewText(graphics, playerName == null || playerName.isEmpty() ? "Player" : playerName,
                        PREVIEW_NAME_Y, dev.lin.client.cosmetics.font.PageTypography.BODY, TEXT_PRIMARY);
                previewText(graphics, "选择翅膀进行预览", PREVIEW_STATUS_Y, dev.lin.client.cosmetics.font.PageTypography.CAPTION, TEXT_MUTED);
            }
            return;
        }
        if (section == LockerSection.ARMOR_TRIMS) {
            String pat = LinTrimManager.pattern();
            boolean enabled = LinTrimManager.isEnabled();
            previewText(graphics, enabled ? LinTrimManager.displayName(pat) : "未启用纹饰",
                    PREVIEW_NAME_Y, dev.lin.client.cosmetics.font.PageTypography.BODY, TEXT_PRIMARY);
            previewText(graphics, enabled ? ("盔甲纹饰 · " + trimMaterialName(LinTrimManager.material())) : "选择纹饰进行预览",
                    PREVIEW_STATUS_Y, dev.lin.client.cosmetics.font.PageTypography.CAPTION, enabled ? ACCENT : TEXT_MUTED);
            int width = (PREVIEW_W - 24) / 2;
            drawFooterButton(graphics, mouseX, mouseY, PREVIEW_X + 8, PREVIEW_ACTION_Y,
                    width, PREVIEW_ACTION_H, "材质：" + trimMaterialName(LinTrimManager.material()),
                    enabled);
            drawFooterButton(graphics, mouseX, mouseY,
                    PREVIEW_X + 16 + width, PREVIEW_ACTION_Y, width, PREVIEW_ACTION_H,
                    "盔甲：" + LinTrimPreview.selected().displayName(),
                    enabled);
            return;
        }
        ArtifactSkins.Artifact artifact = currentArtifact();
        boolean artifactOn = ArtifactSkinConfig.enabled && ArtifactSkinConfig.isArtifactEnabled(artifact.id());
        previewText(graphics, artifact.displayName(), PREVIEW_NAME_Y, dev.lin.client.cosmetics.font.PageTypography.BODY, TEXT_PRIMARY);
        previewText(graphics, artifactOn ? "神器皮肤 · 已启用" : "神器皮肤 · 未启用",
                PREVIEW_STATUS_Y, dev.lin.client.cosmetics.font.PageTypography.CAPTION, artifactOn ? ACCENT : TEXT_MUTED);
        drawFooterButton(graphics, mouseX, mouseY, PREVIEW_X + 8, PREVIEW_ACTION_Y,
                PREVIEW_W - 16, PREVIEW_ACTION_H, "调整手持位置", artifactHandSettings);
    }

    private void drawCenteredFooterText(GuiGraphics graphics, String value) {
        float width = FontManager.widthRegular(value,bodyFont(7.5F));
        bodyText(graphics, value,
                PREVIEW_X + (PREVIEW_W - width) * 0.5F,
                PREVIEW_ACTION_TEXT_Y, 7.5F, TEXT_MUTED);
    }

    private void drawFooterButton(GuiGraphics graphics, int mouseX, int mouseY,
                                  int x, int y, int width, int height,
                                  String label, boolean active) {
        boolean hovered=inside(mouseX,mouseY,x,y,width,height);
        float hover=animatedHover(-500_000-java.util.Objects.hash(x,y,width,height),hovered);
        boolean sourceTab=x<PREVIEW_X&&y==CARD_TOP&&height==SOURCE_TAB_H;
        drawLens(graphics,x,y,width,height,sourceTab?16:12,hover,active);
        float size=bodyFont(sourceTab||height>=40?8:7.5f);
        String visible=truncate(label,sourceTab||height>=40?8:7.5f,width-24);
        float labelWidth=FontManager.widthRegular(visible,size);
        OpenGlUiRenderer.textRegular(graphics,visible,x+(width-labelWidth)*.5f,y+(height-size)*.5f,size,
                active?ACCENT:TEXT_SECONDARY);
    }

    private void drawTrimFooterMenu(GuiGraphics graphics, int mouseX,
                                    int mouseY) {
        int footerWidth = (PREVIEW_W - 35) / 2;
        boolean materialMenu = trimFooterDropdown == TrimFooterDropdown.MATERIAL;
        int menuX = materialMenu ? PREVIEW_X + 12 : PREVIEW_X + 18 + footerWidth;
        int rows = materialMenu ? LinTrimManager.MATERIALS.size()
                : LinTrimPreview.values().length;
        int rowHeight = 27;
        int menuHeight = rows * rowHeight + 8;
        int menuY = PREVIEW_ACTION_Y - 4 - menuHeight;
        OpenGlUiRenderer.softShadow(graphics, menuX - 4, menuY - 4,
                footerWidth + 8, menuHeight + 8, 9, 0x8F000000);
        OpenGlUiRenderer.roundedPanel(graphics, menuX, menuY, footerWidth,
                menuHeight, 7, ClientShell.surface(), ClientShell.border(), 1);
        for (int index = 0; index < rows; index++) {
            int rowY = menuY + 4 + index * rowHeight;
            boolean hovered = inside(mouseX, mouseY, menuX + 4, rowY,
                    footerWidth - 8, rowHeight);
            boolean active;
            String label;
            ItemStack icon;
            if (materialMenu) {
                String value = LinTrimManager.MATERIALS.get(index);
                active = value.equals(LinTrimManager.material());
                label = trimMaterialName(value);
                icon = trimMaterialIcon(value);
            } else {
                LinTrimPreview value = LinTrimPreview.values()[index];
                active = value == LinTrimPreview.selected();
                label = value.displayName();
                icon = value.helmet();
            }
            if (hovered || active) {
                OpenGlUiRenderer.roundedRect(graphics, menuX + 4, rowY,
                        footerWidth - 8, rowHeight - 1, 5,
                        active ? ClientShell.selected() : ClientShell.control());
            }
            graphics.renderItem(icon, menuX + 9, rowY + 5);
            bodyText(graphics, label, menuX + 32,
                    rowY + 9, 8, active ? TEXT_PRIMARY : TEXT_SECONDARY);
        }
    }

    public static void renderEquippedThumbnail(GuiGraphics graphics,CosmeticCategory category,int x,int y,int width,int height){
        CosmeticDefinition definition=CosmeticConfig.equipped(category);
        if(definition==null)return;
        var data=CosmeticAssetManager.getPreview(definition);
        if(data==null)return;
        graphics.enableScissor(x,y,x+width,y+height);
        try{
            if(category==CosmeticCategory.CLOAK){
                OpenGlUiRenderer.cosmeticModel(graphics,data,x+width*.5f,y+height*.5f,height*.9f,0,0);
            }else{
                OpenGlUiRenderer.cosmeticModel(graphics,data,x+width*.5f,y+height*.5f,Math.min(width,height)*.85f);
            }
        }finally{graphics.disableScissor();}
    }

    private void drawAvatar(GuiGraphics graphics, int screenMouseX, int screenMouseY) {


        if(!fitsView && section==LockerSection.SPAWN_PODS){
            int size=Math.min(PREVIEW_W-24,220);
            previewText(graphics,selectedPod.name,94,dev.lin.client.cosmetics.font.PageTypography.BODY,TEXT_PRIMARY);
            PodSkins.preview(graphics,selectedPod,podPart,podLarge,false,PREVIEW_X+(PREVIEW_W-size)/2,134,size);
            previewText(graphics,"原资源部件预览 · 非整舱拼装动画",376,dev.lin.client.cosmetics.font.PageTypography.CAPTION,TEXT_SECONDARY);
            previewText(graphics,"仅本地替换兼容部件，碰撞不变",394,dev.lin.client.cosmetics.font.PageTypography.CAPTION,TEXT_MUTED);
            previewText(graphics,PodSkins.status(),410,dev.lin.client.cosmetics.font.PageTypography.CAPTION,TEXT_MUTED);
            return;
        }
        if (!fitsView && section == LockerSection.VIP_ICONS) {
            previewText(graphics, selectedVip.label(), PREVIEW_NAME_Y, dev.lin.client.cosmetics.font.PageTypography.BODY, TEXT_PRIMARY);
            drawVipIcon(graphics, selectedVip, PREVIEW_X + PREVIEW_W / 2, 210, 5.5F);
            String name = minecraft.player == null ? "Player" : minecraft.player.getGameProfile().name();
            var preview = net.minecraft.network.chat.Component.empty().append(selectedVip.component()).append(" " + name);
            graphics.drawString(minecraft.font, preview, PREVIEW_X + (PREVIEW_W - minecraft.font.width(preview)) / 2, 320, 0xffffffff, true);
            previewText(graphics, ClientShell.tr("Tab · 名称标签 · 聊天", "Tab · Nametag · Chat"), PREVIEW_STATUS_Y, dev.lin.client.cosmetics.font.PageTypography.CAPTION, ACCENT);
            previewText(graphics, ClientShell.tr("仅本机显示，不改变服务器权限", "Client-side visual only"), PREVIEW_VIEW_ROW_Y + 8, dev.lin.client.cosmetics.font.PageTypography.CAPTION, TEXT_MUTED);
            return;
        }
        if (!fitsView && section == LockerSection.ARROW_TRAILS) {
            previewText(graphics, selectedArrowTrail.label, PREVIEW_NAME_Y, dev.lin.client.cosmetics.font.PageTypography.BODY, TEXT_PRIMARY);
            drawArrowTrailDemo(graphics, selectedArrowTrail, PREVIEW_X + 18, 175, PREVIEW_W - 36, 260);
            previewText(graphics, ClientShell.tr("箭矢飞行拖尾 · 动态示意", "Arrow Flight Trail Preview"), PREVIEW_STATUS_Y, dev.lin.client.cosmetics.font.PageTypography.CAPTION, ACCENT);
            previewText(graphics, ClientShell.tr("客户端自制主题，仅本机可见", "Client-side custom trail"), PREVIEW_VIEW_ROW_Y + 8, dev.lin.client.cosmetics.font.PageTypography.CAPTION, TEXT_MUTED);
            return;
        }
        if (!fitsView && section == LockerSection.KILL_EFFECTS) {
            int size = Math.min(PREVIEW_W - 24, 240);
            selectedKillEffect.render(graphics, PREVIEW_X + (PREVIEW_W - size) / 2, 175, size, killPreviewStart);
            previewText(graphics, truncate(selectedKillEffect.label, 10, PREVIEW_W - 28), PREVIEW_NAME_Y, dev.lin.client.cosmetics.font.PageTypography.BODY, TEXT_PRIMARY);
            previewText(graphics, selectedKillEffect.kind, PREVIEW_STATUS_Y, dev.lin.client.cosmetics.font.PageTypography.BODY, TEXT_SECONDARY);
            previewText(graphics, ClientShell.tr("预览不代表服务器已装备", "Preview only"), PREVIEW_VIEW_ROW_Y + 8, dev.lin.client.cosmetics.font.PageTypography.CAPTION, TEXT_MUTED);
            return;
        }
        if (minecraft != null) {
            if (!fitsView && section == LockerSection.ARTIFACT_SKINS) {
                ArtifactSkins.Artifact artifact = currentArtifact();
                graphics.enableScissor(PREVIEW_X, previewStageTop(),
                        PREVIEW_X + PREVIEW_W, previewStageBottom());
                try {
                    int left = toScreenX(PREVIEW_X + 4);
                    int top = toScreenY(previewStageTop());
                    int right = toScreenX(PREVIEW_X + PREVIEW_W - 5);
                    int bottom = toScreenY(previewStageBottom());
                    int scale = previewRenderScale(132);
                    renderEntityFixedWithItem(graphics, left, top, right, bottom,
                            scale, minecraft.player, previewYaw + 35,
                            visibleEquipped(), false, CardDisplay.PLAYER_PREVIEW,
                            0, Math.round(PREVIEW_ENTITY_OFFSET_Y * uiScale), null, null, null, null, null,
                            artifact);
                } finally {
                    graphics.disableScissor();
                }
                return;
            }
            graphics.enableScissor(PREVIEW_X, previewStageTop(),
                    PREVIEW_X + PREVIEW_W, previewStageBottom());
            try {
                int left = toScreenX(PREVIEW_X + 4);
                int top = toScreenY(previewStageTop());
                int right = toScreenX(PREVIEW_X + PREVIEW_W - 5);
                int bottom = toScreenY(previewStageBottom());
                int scale = previewRenderScale(previewEntityScale());
                AccessoryDefinition headwear = !fitsView && section == LockerSection.HEADWEAR
                        ? AccessoryRegistry.selected(AccessorySlot.HEADWEAR) : null;
                AccessoryDefinition wings = !fitsView && section == LockerSection.WINGS
                        ? AccessoryRegistry.selected(AccessorySlot.WINGS) : null;
                if (!fitsView && section == LockerSection.FLOATING_EFFECTS
                        && floatingView == FLOATING_VIEW_HOPLITE) {
                    wings = AccessoryRegistry.selected(AccessorySlot.FLOATING);
                }
                LinTrimPreview trim = !fitsView && section == LockerSection.ARMOR_TRIMS
                        ? LinTrimPreview.selected() : null;
                List<CosmeticDefinition> outfit = previewOutfit();
                renderEntityFixed(graphics, left, top, right, bottom, scale,
                        minecraft.player,
                        previewYaw + 35,
                        outfit,
                        false, CardDisplay.PLAYER_PREVIEW, 0,
                        Math.round(PREVIEW_ENTITY_OFFSET_Y * uiScale),
                        !fitsView && section.isExternal() ? null : previewArmor,
                        !fitsView && section.isExternal() ? null : previewSword,
                        headwear, trim, wings);
            } finally {
                graphics.disableScissor();
            }
        }
    }

    private void drawFloatingNumberField(GuiGraphics graphics,
                                         int mouseX, int mouseY) {
        if (!isChampionFloatingSelected()) return;
        boolean focused = floatingNumberBox.isFocused();
        boolean hovered = inside(mouseX, mouseY, FLOATING_NUMBER_X,
                FLOATING_NUMBER_Y, FLOATING_NUMBER_W, FLOATING_NUMBER_H);
        OpenGlUiRenderer.roundedPanel(graphics, FLOATING_NUMBER_X,
                FLOATING_NUMBER_Y, FLOATING_NUMBER_W, FLOATING_NUMBER_H, 7,
                focused ? ClientShell.selected()
                        : hovered ? ClientShell.hoverSurface() : ClientShell.control(),
                focused ? ACCENT : ClientShell.border(),
                uiStroke(focused ? 1.2F : 1.0F));
        float fontSize = bodyFont(7.5F);
        float textY = FLOATING_NUMBER_Y + (FLOATING_NUMBER_H - fontSize) * 0.5F;
        String prefix = ClientShell.tr("排名 #", "Rank #");
        float prefixX = FLOATING_NUMBER_X + 10;
        OpenGlUiRenderer.textRegular(graphics, prefix, prefixX, textY, fontSize, TEXT_SECONDARY);
        float valX = prefixX + FontManager.widthRegular(prefix, fontSize) + 6;
        GlassSearchBox.VisibleText visible = floatingNumberBox.visibleText();
        String value = floatingNumberBox.getValue();
        String shown = value.isEmpty() ? Integer.toString(ClientAccessoryConfig.floatingNumber) : visible.text();
        OpenGlUiRenderer.textRegular(graphics, shown, valX, textY, fontSize, TEXT_PRIMARY);
        if (focused && !value.isEmpty()
                && (System.currentTimeMillis() / 500 & 1) == 0) {
            int cursor = floatingNumberBox.getCursorPosition();
            if (cursor >= visible.start() && cursor <= visible.end()) {
                float cursorX = valX
                        + FontManager.widthRegular(value.substring(
                        visible.start(), cursor), fontSize);
                OpenGlUiRenderer.roundedRect(graphics, cursorX,
                        FLOATING_NUMBER_Y + 6, 1.1F, FLOATING_NUMBER_H - 12,
                        0.5F, TEXT_PRIMARY);
            }
        }
    }

    private void drawFloatingScopeSelector(GuiGraphics graphics,
                                           int mouseX, int mouseY) {
        if (!isHopliteFloatingPage()) return;
        String[] labels = {ClientShell.tr("全局", "Global"), "Hoplite"};
        float fontSize = bodyFont(7.5F);
        float textY = FLOATING_SCOPE_Y + (FLOATING_NUMBER_H - fontSize) * 0.5F;
        for (int index = 0; index < labels.length; index++) {
            int x = FLOATING_SCOPE_X
                    + index * (FLOATING_SCOPE_W + FLOATING_SCOPE_GAP);
            boolean selectedScope = ClientAccessoryConfig.floatingGlobal
                    == (index == 0);
            boolean hovered = inside(mouseX, mouseY, x, FLOATING_SCOPE_Y,
                    FLOATING_SCOPE_W, FLOATING_NUMBER_H);
            OpenGlUiRenderer.roundedPanel(graphics, x, FLOATING_SCOPE_Y,
                    FLOATING_SCOPE_W, FLOATING_NUMBER_H, 7,
                    selectedScope ? ClientShell.selected()
                            : hovered ? ClientShell.hoverSurface() : ClientShell.control(),
                    selectedScope ? ACCENT : ClientShell.border(),
                    uiStroke(selectedScope ? 1.2F : 1.0F));
            float w = FontManager.widthRegular(labels[index], fontSize);
            OpenGlUiRenderer.textRegular(graphics, labels[index],
                    x + (FLOATING_SCOPE_W - w) * 0.5F, textY, fontSize,
                    selectedScope ? ACCENT : TEXT_SECONDARY);
        }
    }

    private boolean isHopliteFloatingPage() {
        return !fitsView && section == LockerSection.FLOATING_EFFECTS
                && floatingView == FLOATING_VIEW_HOPLITE;
    }

    private boolean isChampionFloatingSelected() {
        return isHopliteFloatingPage()
                && "medallion_champion".equals(
                AccessoryRegistry.selectedId(AccessorySlot.FLOATING));
    }

    private void drawPreviewArmorControls(GuiGraphics graphics,
                                          int mouseX, int mouseY) {
        previewText(graphics, "预览装备", PREVIEW_ARMOR_LABEL_Y, 10F, TEXT_MUTED);
        int startX = armorButtonsX();
        for (int index = 0; index < PREVIEW_ARMOR_SLOTS.length; index++) {
            EquipmentSlot slot = PREVIEW_ARMOR_SLOTS[index];
            int x = startX + index * (ARMOR_BUTTON_SIZE + ARMOR_BUTTON_GAP);
            int y = ARMOR_BUTTON_Y;
            boolean hovered = inside(mouseX, mouseY, x, y,
                    ARMOR_BUTTON_SIZE, ARMOR_BUTTON_SIZE);
            boolean open = armorDropdownSlot == slot;
            OpenGlUiRenderer.roundedPanel(graphics, x, y,
                    ARMOR_BUTTON_SIZE, ARMOR_BUTTON_SIZE, 6,
                    open ? ClientShell.selected() : hovered ? ClientShell.hoverSurface() : ClientShell.control(),
                    open ? ACCENT : ClientShell.border(), open ? 1.2F : 1);
            PreviewArmorMaterial material = previewArmor.getOrDefault(slot,
                    PreviewArmorMaterial.NONE);
            ItemStack icon = material.stack(slot);
            if (icon.isEmpty()) {
                icon = PreviewArmorMaterial.IRON.stack(slot);
            }
            drawPreviewEquipmentIcon(graphics, icon, x, y);
        }
        boolean swordHover = inside(mouseX, mouseY, swordButtonX(), SWORD_BUTTON_Y,
                ARMOR_BUTTON_SIZE, ARMOR_BUTTON_SIZE);
        OpenGlUiRenderer.roundedPanel(graphics, swordButtonX(), SWORD_BUTTON_Y,
                ARMOR_BUTTON_SIZE, ARMOR_BUTTON_SIZE, 6,
                swordDropdownOpen ? ClientShell.selected()
                        : swordHover ? ClientShell.hoverSurface() : ClientShell.control(),
                swordDropdownOpen ? ACCENT : ClientShell.border(),
                swordDropdownOpen ? 1.2F : 1);
        ItemStack swordIcon = previewSword.stack();
        if (swordIcon.isEmpty()) swordIcon = new ItemStack(Items.IRON_SWORD);
        drawPreviewEquipmentIcon(graphics, swordIcon, swordButtonX(), SWORD_BUTTON_Y);
        if (armorDropdownSlot != null) {
            drawArmorMaterialMenu(graphics, mouseX, mouseY);
        } else if (swordDropdownOpen) {
            drawSwordMaterialMenu(graphics, mouseX, mouseY);
        }
    }

    private static void drawPreviewEquipmentIcon(GuiGraphics graphics, ItemStack icon, int x, int y) {
        float size=24, inset=(ARMOR_BUTTON_SIZE-size)*.5f;
        var pose=graphics.pose();pose.pushMatrix();
        try {
            pose.translate(x+inset,y+inset);pose.scale(size/16,size/16);
            graphics.renderItem(icon,0,0);
        } finally { pose.popMatrix(); }
    }

    private void drawExternalVariantControls(GuiGraphics graphics,
                                             int mouseX, int mouseY) {
        int x = externalVariantX();
        if (section == LockerSection.HEADWEAR) {
            AccessoryDefinition headwear = AccessoryRegistry.selected(
                    AccessorySlot.HEADWEAR);
            if (headwear == null) return;
            HeadwearVariant selectedVariant = AccessoryRegistry.headwearVariant(headwear);
            HeadwearVariant[] variants = HeadwearVariant.values();
            for (int index = 0; index < variants.length; index++) {
                HeadwearVariant variant = variants[index];
                int y = EXTERNAL_VARIANT_Y
                        + index * (EXTERNAL_VARIANT_SIZE + EXTERNAL_VARIANT_GAP);
                boolean selectedVariantButton = variant == selectedVariant;
                boolean hovered = inside(mouseX, mouseY, x, y,
                        EXTERNAL_VARIANT_SIZE, EXTERNAL_VARIANT_SIZE);
                drawExternalVariantButton(graphics, x, y, hovered,
                        selectedVariantButton);
                drawHeadwearIcon(graphics, headwear, variant,
                        x + 8, y + 8, 24);
            }
            return;
        }
        if (section != LockerSection.ARTIFACT_SKINS) return;
        drawFooterButton(graphics, mouseX, mouseY, PREVIEW_X + 18, 22, 86, 28, ClientShell.tr("\u81ea\u5b9a\u4e49", "Custom"), customModelPicker);
        ArtifactSkins.Artifact artifact = currentArtifact();
        List<ArtifactSkins.Option> options = ArtifactSkins.options(artifact);
        if (options.size() < 2) return;
        ArtifactSkins.Option selectedOption = ArtifactSkins.standardSelected(artifact);
        artifactVariantStart(artifact);
        if (options.size() > 8) {
            bodyText(graphics, "滚轮切换 " + (artifactVariantScroll + 1) + "/" + options.size(),
                    x - 28, EXTERNAL_VARIANT_Y + 8 * (EXTERNAL_VARIANT_SIZE + EXTERNAL_VARIANT_GAP), 9, TEXT_PRIMARY);
        }
        for (int index = artifactVariantStart(artifact); index < Math.min(options.size(), artifactVariantScroll + 8); index++) {
            ArtifactSkins.Option option = options.get(index);
            int y = EXTERNAL_VARIANT_Y
                    + (index - artifactVariantScroll) * (EXTERNAL_VARIANT_SIZE + EXTERNAL_VARIANT_GAP);
            boolean selectedVariantButton = ArtifactSkins.sameSkin(option, selectedOption);
            boolean hovered = inside(mouseX, mouseY, x, y,
                    EXTERNAL_VARIANT_SIZE, EXTERNAL_VARIANT_SIZE);
            drawExternalVariantButton(graphics, x, y, hovered,
                    selectedVariantButton);
            drawArtifactIcon(graphics, option, x + 8, y + 8, 24);
            if (hovered) {
                String label = option.displayName();
                float tipWidth = FontManager.widthRegular(label,bodyFont(10)) + 16;
                OpenGlUiRenderer.roundedPanel(graphics, x - tipWidth - 6, y + 7, tipWidth, 26, 7, ClientShell.surface(), GLASS_BORDER, 1);
                bodyText(graphics, label, x - tipWidth + 2, y + 14, 10, TEXT_PRIMARY);
            }
        }
    }

    private void drawExternalVariantButton(GuiGraphics graphics, int x, int y,
                                           boolean hovered, boolean selectedButton) {
        OpenGlUiRenderer.roundedPanel(graphics, x, y,
                EXTERNAL_VARIANT_SIZE, EXTERNAL_VARIANT_SIZE, 8,
                selectedButton ? ClientShell.selected()
                        : hovered ? ClientShell.hoverSurface() : ClientShell.control(),
                selectedButton ? ACCENT : ClientShell.border(),
                uiStroke(selectedButton ? 1.2F : 1.0F));
        if (selectedButton) {
            OpenGlUiRenderer.roundedRect(graphics, x + 5, y + 5,
                    3, EXTERNAL_VARIANT_SIZE - 10, 1.5F, ACCENT);
        }
    }

    private void drawSkinCards(GuiGraphics graphics, int mouseX, int mouseY) {
        if (section != LockerSection.COMPANIONS) {
            String[] capeLabels = {
                    ClientShell.tr("Lunar 披风", "Lunar Capes"),
                    ClientShell.tr("官方披风", "Official Capes"),
                    ClientShell.tr("地下城披风", "Dungeon Capes")
            };
            int[] capeXs = {CONTENT_X, CONTENT_X + CAPE_TAB_W + CARD_GAP, CONTENT_X + (CAPE_TAB_W + CARD_GAP) * 2};
            int[] capeWs = {CAPE_TAB_W, CAPE_TAB_W, CAPE_TAB_W};
            drawSubTabStrip(graphics, mouseX, mouseY, "capes", capeView, capeLabels, capeXs, capeWs);
        }
        if (section == LockerSection.COSMETICS && capeView != CAPE_VIEW_LUNAR) {
            List<LunarCape> capes = filteredPackagedCapes();
            int max = skinMaxScroll(capes.size());
            scrollRow = clamp(scrollRow, 0, max);
            int baseRow = smoothBaseRow(max);
            int fracY = smoothFracOffset(baseRow, CAPE_ROW_STEP);
            int start = baseRow * COLUMNS;
            int end = Math.min(capes.size(), (baseRow + CAPE_VISIBLE_ROWS + 1) * COLUMNS);
            graphics.enableScissor(CONTENT_X - 4, HEADWEAR_TOP - 4, CONTENT_RIGHT + 4, VIEW_BOTTOM + 4);
            try {
                for (int index = start; index < end; index++) {
                    int visible = index - start;
                    int x = CONTENT_X + visible % COLUMNS * (CARD_W + CARD_GAP);
                    int y = HEADWEAR_TOP + visible / COLUMNS * CAPE_ROW_STEP - fracY;
                    drawOfficialCapeCard(graphics, mouseX, mouseY,
                            capes.get(index), x, y);
                }
            } finally {
                graphics.disableScissor();
            }
            drawSkinScrollbar(graphics, capes.size());
            return;
        }

        List<CosmeticDefinition> cosmetics = filtered();
        int max = skinMaxScroll(cosmetics.size());
        scrollRow = clamp(scrollRow, 0, max);
        int baseRow = smoothBaseRow(max);
        int fracY = smoothFracOffset(baseRow, CAPE_ROW_STEP);
        int start = baseRow * COLUMNS;
        int end = Math.min(cosmetics.size(), (baseRow + CAPE_VISIBLE_ROWS + 1) * COLUMNS);
        CosmeticAssetManager.preload(cosmetics.subList(start, end));
        graphics.enableScissor(CONTENT_X - 4, HEADWEAR_TOP - 4, CONTENT_RIGHT + 4, VIEW_BOTTOM + 4);
        try {
            for (int index = start; index < end; index++) {
                int visible = index - start;
                int x = CONTENT_X + visible % COLUMNS * (CARD_W + CARD_GAP);
                int y = HEADWEAR_TOP + visible / COLUMNS * CAPE_ROW_STEP - fracY;
                drawCard(graphics, mouseX, mouseY, cosmetics.get(index), x, y,
                        CAPE_CARD_H, CAPE_PREVIEW_H);
            }
        } finally {
            graphics.disableScissor();
        }
        drawSkinScrollbar(graphics, cosmetics.size());
    }

    private void drawOfficialCapeCard(GuiGraphics graphics, int mouseX, int mouseY,
                                      LunarCape cape, int x, int y) {
        boolean hovered = inside(mouseX, mouseY, x, y, CARD_W, CAPE_CARD_H);
        boolean equipped = cape.id().equals(LunarCapeRegistry.selectedId());
        float hover = animatedHover(cape.id().hashCode(), hovered);
        float lift = hover * 5.0F;
        drawGalleryCard(graphics,x,y-lift,CARD_W,CAPE_CARD_H,CAPE_PREVIEW_H,equipped,equipped,hover);
        LunarCapeTextureManager.PreviewTexture preview =
                LunarCapeTextureManager.preview(cape);
        if (preview != null && minecraft != null) {
            // Centered cape artwork scaled cleanly inside the card stage.
            float stageCenterY = y - lift + (54 + CAPE_PREVIEW_H - 8) * 0.5F;
            int h = Math.round((CAPE_PREVIEW_H - 62) * 0.72F * (1.0F + hover * 0.055F));
            int w = Math.round(h * (float) preview.width() / preview.height());
            if (w > CARD_W - 88) {
                w = CARD_W - 88;
                h = Math.round(w * (float) preview.height() / preview.width());
            }
            graphics.blit(RenderPipelines.GUI_TEXTURED, preview.texture(),
                    x + (CARD_W - w) / 2, Math.round(stageCenterY - h * 0.5F), 0, 0, w, h,
                    preview.width(), preview.height(), preview.width(), preview.height());
        }
        drawGalleryTitle(graphics,cape.displayName(),x,y-lift,CARD_W,CAPE_CARD_H,CAPE_PREVIEW_H,equipped,hover);
    }

    private void drawSkinScrollbar(GuiGraphics graphics, int count) {
        int rows = (count + COLUMNS - 1) / COLUMNS;
        int max = skinMaxScroll(count);
        drawModernScrollbar(graphics, HEADWEAR_TOP, VIEW_BOTTOM, scrollRow, max, CAPE_VISIBLE_ROWS, rows);
    }

    private void drawArmorMaterialMenu(GuiGraphics graphics,
                                       int mouseX, int mouseY) {
        int menuX = armorButtonsX();
        int menuY = previewArmorMenuY(PreviewArmorMaterial.values().length);
        int menuHeight = PreviewArmorMaterial.values().length
                * ARMOR_MENU_ROW_HEIGHT + 8;
        OpenGlUiRenderer.softShadow(graphics, menuX - 4, menuY - 4,
                ARMOR_MENU_WIDTH + 8, menuHeight + 8, 9, 0x8F000000);
        OpenGlUiRenderer.roundedPanel(graphics, menuX, menuY,
                ARMOR_MENU_WIDTH, menuHeight, 7, ClientShell.surface(),
                ClientShell.border(), 1);
        PreviewArmorMaterial selectedMaterial = previewArmor.getOrDefault(
                armorDropdownSlot, PreviewArmorMaterial.NONE);
        PreviewArmorMaterial[] materials = PreviewArmorMaterial.values();
        for (int index = 0; index < materials.length; index++) {
            PreviewArmorMaterial material = materials[index];
            int rowY = menuY + 4 + index * ARMOR_MENU_ROW_HEIGHT;
            boolean hovered = inside(mouseX, mouseY, menuX + 4, rowY,
                    ARMOR_MENU_WIDTH - 8, ARMOR_MENU_ROW_HEIGHT);
            boolean active = material == selectedMaterial;
            if (hovered || active) {
                OpenGlUiRenderer.roundedRect(graphics, menuX + 4, rowY,
                        ARMOR_MENU_WIDTH - 8, ARMOR_MENU_ROW_HEIGHT - 1, 5,
                        active ? ClientShell.selected() : ClientShell.control());
            }
            ItemStack icon = material == PreviewArmorMaterial.NONE
                    ? new ItemStack(Items.BARRIER)
                    : material.stack(armorDropdownSlot);
            graphics.renderItem(icon, menuX + 9, rowY + 5);
            bodyText(graphics, material.label,
                    menuX + 32, rowY + 9, 8,
                    active ? TEXT_PRIMARY : TEXT_SECONDARY);
        }
    }

    private void drawSwordMaterialMenu(GuiGraphics graphics,
                                       int mouseX, int mouseY) {
        int menuX = armorButtonsX();
        int menuY = previewArmorMenuY(PreviewSwordMaterial.values().length);
        int menuHeight = PreviewSwordMaterial.values().length
                * ARMOR_MENU_ROW_HEIGHT + 8;
        OpenGlUiRenderer.softShadow(graphics, menuX - 4, menuY - 4,
                ARMOR_MENU_WIDTH + 8, menuHeight + 8, 9, 0x8F000000);
        OpenGlUiRenderer.roundedPanel(graphics, menuX, menuY,
                ARMOR_MENU_WIDTH, menuHeight, 7, ClientShell.surface(),
                ClientShell.border(), 1);
        PreviewSwordMaterial[] materials = PreviewSwordMaterial.values();
        for (int index = 0; index < materials.length; index++) {
            PreviewSwordMaterial material = materials[index];
            int rowY = menuY + 4 + index * ARMOR_MENU_ROW_HEIGHT;
            boolean hovered = inside(mouseX, mouseY, menuX + 4, rowY,
                    ARMOR_MENU_WIDTH - 8, ARMOR_MENU_ROW_HEIGHT);
            boolean active = material == previewSword;
            if (hovered || active) {
                OpenGlUiRenderer.roundedRect(graphics, menuX + 4, rowY,
                        ARMOR_MENU_WIDTH - 8, ARMOR_MENU_ROW_HEIGHT - 1, 5,
                        active ? ClientShell.selected() : ClientShell.control());
            }
            ItemStack icon = material == PreviewSwordMaterial.NONE
                    ? new ItemStack(Items.BARRIER) : material.stack();
            graphics.renderItem(icon, menuX + 9, rowY + 5);
            bodyText(graphics, material.label,
                    menuX + 32, rowY + 9, 8,
                    active ? TEXT_PRIMARY : TEXT_SECONDARY);
        }
    }



    private void drawRenameDialog(GuiGraphics graphics, int mouseX, int mouseY) {
        int dialogX = 344;
        int dialogY = 194;
        int dialogW = 332;
        int dialogH = 148;
        int inputX = dialogX + 22;
        int inputY = dialogY + 48;
        int inputW = dialogW - 44;
        OpenGlUiRenderer.roundedRect(graphics, 0, 0, PANEL_W, PANEL_H,
                10, 0xA0000000);
        OpenGlUiRenderer.softShadow(graphics, dialogX, dialogY, dialogW,
                dialogH, 9, 0xE0000000);
        OpenGlUiRenderer.roundedPanel(graphics, dialogX, dialogY, dialogW,
                dialogH, 8, ClientShell.surface(), ClientShell.border(), 1);
        bodyText(graphics, "重命名穿搭", dialogX + 22,
                dialogY + 17, 12, TEXT_PRIMARY);
        OpenGlUiRenderer.roundedPanel(graphics, inputX, inputY, inputW, 31,
                6, ClientShell.control(),
                renameBox.isFocused() ? ACCENT : ClientShell.border(), 1);
        GlassSearchBox.VisibleText visible = renameBox.visibleText();
        String value = renameBox.getValue();
        if (value.isEmpty()) {
            bodyText(graphics, "穿搭名称", inputX + 11,
                    inputY + 11, 9, TEXT_MUTED);
        } else {
            bodyText(graphics, visible.text(), inputX + 11,
                    inputY + 11, 9, TEXT_PRIMARY);
        }
        if (renameBox.isFocused() && (System.currentTimeMillis() / 500 & 1) == 0) {
            int cursor = renameBox.getCursorPosition();
            if (cursor >= visible.start() && cursor <= visible.end()) {
                float cursorX = inputX + 11 + FontManager.widthRegular(
                        value.substring(visible.start(), cursor),bodyFont(9));
                OpenGlUiRenderer.roundedRect(graphics, cursorX, inputY + 7,
                        1.1F, 18, 0.5F, TEXT_PRIMARY);
            }
        }

        int cancelX = dialogX + dialogW - 164;
        int saveX = dialogX + dialogW - 86;
        int buttonY = dialogY + 105;
        boolean cancelHover = inside(mouseX, mouseY, cancelX, buttonY, 68, 27);
        boolean saveHover = inside(mouseX, mouseY, saveX, buttonY, 64, 27);
        boolean valid = !value.strip().isEmpty();
        OpenGlUiRenderer.roundedRect(graphics, cancelX, buttonY, 68, 27,
                6, cancelHover ? ClientShell.hoverSurface() : ClientShell.control());
        OpenGlUiRenderer.roundedRect(graphics, saveX, buttonY, 64, 27,
                6, !valid ? ClientShell.control()
                        : saveHover ? ClientShell.hoverSurface() : ACCENT);
        float cancelWidth = FontManager.widthRegular("取消",bodyFont(8));
        float saveWidth = FontManager.widthRegular("保存",bodyFont(8));
        bodyText(graphics, "取消",
                cancelX + (68 - cancelWidth) * 0.5F, buttonY + 9, 8,
                TEXT_SECONDARY);
        bodyText(graphics, "保存",
                saveX + (64 - saveWidth) * 0.5F, buttonY + 9, 8,
                valid ? ClientShell.accentText() : TEXT_MUTED);
    }

    private List<CosmeticDefinition> filtered() {
        String normalized = searchBox == null ? "" : searchBox.getValue()
                .toLowerCase(Locale.ROOT).replace('_', ' ').replace('-', ' ').trim();
        return filterCache.filter(LunarCatalog.all(), section, companionView, normalized,
                CosmeticConfig.sortAscending(), CosmeticConfig.favoritesOnly(), CosmeticConfig.favoritesSnapshot(),
                value -> isVisibleCosmetic(value) && section.contains(value)
                        && (section != LockerSection.COMPANIONS
                        || "HOPLITE_PET".equals(value.indexType()) == (companionView == 1)));
    }

    private List<AccessoryDefinition> filteredHeadwear() {
        String query = normalizedExternalQuery();
        Comparator<AccessoryDefinition> comparator = Comparator
                .comparing(AccessoryDefinition::displayName,
                        String.CASE_INSENSITIVE_ORDER)
                .thenComparing(AccessoryDefinition::id);
        if (!CosmeticConfig.sortAscending()) comparator = comparator.reversed();
        return AccessoryRegistry.visibleHeadwear().stream()
                .filter(value -> query.isEmpty()
                        || normalizeExternal(value.id() + " " + value.displayName())
                        .contains(query))
                .sorted(comparator)
                .toList();
    }

    private List<LunarCape> filteredPackagedCapes() {
        String query = normalizedExternalQuery();
        Comparator<LunarCape> comparator = Comparator
                .comparing(LunarCape::displayName, String.CASE_INSENSITIVE_ORDER)
                .thenComparing(LunarCape::id);
        if (!CosmeticConfig.sortAscending()) comparator = comparator.reversed();
        List<LunarCape> values = capeView == CAPE_VIEW_OFFICIAL
                ? LunarCapeRegistry.officialValues()
                : LunarCapeRegistry.dungeonValues();
        return values.stream()
                .filter(value -> query.isEmpty()
                        || normalizeExternal(value.id() + " " + value.displayName())
                        .contains(query))
                .sorted(comparator)
                .toList();
    }

    private List<AccessoryDefinition> filteredWings() {
        String query = normalizedExternalQuery();
        Comparator<AccessoryDefinition> comparator = Comparator
                .comparing(AccessoryDefinition::displayName,
                        String.CASE_INSENSITIVE_ORDER)
                .thenComparing(AccessoryDefinition::id);
        if (!CosmeticConfig.sortAscending()) comparator = comparator.reversed();
        return AccessoryRegistry.values(AccessorySlot.WINGS).stream()
                .filter(value -> query.isEmpty()
                        || normalizeExternal(value.id() + " " + value.displayName())
                        .contains(query))
                .sorted(comparator)
                .toList();
    }

    private List<AccessoryDefinition> filteredFloating() {
        String query = normalizedExternalQuery();
        Comparator<AccessoryDefinition> comparator = Comparator
                .comparing(AccessoryDefinition::displayName,
                        String.CASE_INSENSITIVE_ORDER)
                .thenComparing(AccessoryDefinition::id);
        if (!CosmeticConfig.sortAscending()) comparator = comparator.reversed();
        return AccessoryRegistry.values(AccessorySlot.FLOATING).stream()
                .filter(value -> query.isEmpty()
                        || normalizeExternal(value.id() + " " + value.displayName())
                        .contains(query))
                .sorted(comparator)
                .toList();
    }

    private List<String> filteredTrimPatterns() {
        String query = normalizedExternalQuery();
        Comparator<String> comparator = Comparator.comparing(
                LinTrimManager::displayName, String.CASE_INSENSITIVE_ORDER);
        if (!CosmeticConfig.sortAscending()) comparator = comparator.reversed();
        return LinTrimManager.PATTERNS.stream()
                .filter(value -> query.isEmpty()
                        || normalizeExternal(value + " "
                        + LinTrimManager.displayName(value)).contains(query))
                .sorted(comparator)
                .toList();
    }

    private List<ArtifactSkins.Artifact> filteredArtifacts() {
        String query = normalizedExternalQuery();
        Comparator<ArtifactSkins.Artifact> comparator = Comparator
                .comparing(ArtifactSkins.Artifact::displayName,
                        String.CASE_INSENSITIVE_ORDER)
                .thenComparing(ArtifactSkins.Artifact::id);
        if (!CosmeticConfig.sortAscending()) comparator = comparator.reversed();
        return ArtifactSkins.visibleArtifacts().stream()
                .filter(value -> query.isEmpty()
                        || normalizeExternal(value.id() + " " + value.displayName())
                        .contains(query))
                .sorted(comparator)
                .toList();
    }

    private int externalItemCount() {
        return switch (section) {
            case SPAWN_PODS -> filteredPods().size();
            case KILL_EFFECTS -> filteredKillEffects().size();
            case VIP_ICONS -> filteredVipIcons().size();
            case ARROW_TRAILS -> filteredArrowTrails().size();
            case HEADWEAR -> filteredHeadwear().size();
            case WINGS -> filteredWings().size();
            case ARMOR_TRIMS -> filteredTrimPatterns().size();
            case ARTIFACT_SKINS -> filteredArtifacts().size();
            default -> 0;
        };
    }

    private ArtifactSkins.Artifact currentArtifact() {
        if (selectedArtifact == null) {
            selectedArtifact = ArtifactSkins.Artifact.values()[0];
        }
        return selectedArtifact;
    }

    private String currentArtifactTransformKey() {
        return ArtifactSkins.handTransformKey(currentArtifact());
    }

    private String normalizedExternalQuery() {
        return searchBox == null ? "" : normalizeExternal(searchBox.getValue());
    }

    private static String normalizeExternal(String value) {
        return value.toLowerCase(Locale.ROOT)
                .replace('_', ' ').replace('-', ' ').trim();
    }

    private List<CosmeticConfig.SavedFit> filteredFits() {
        String normalized = searchBox == null ? "" : searchBox.getValue()
                .toLowerCase(Locale.ROOT).replace('_', ' ').replace('-', ' ').trim();
        Comparator<CosmeticConfig.SavedFit> comparator = Comparator
                .comparing(CosmeticConfig.SavedFit::name, String.CASE_INSENSITIVE_ORDER)
                .thenComparingInt(CosmeticConfig.SavedFit::id);
        if (!CosmeticConfig.sortAscending()) comparator = comparator.reversed();
        return CosmeticConfig.fits().stream()
                .filter(fit -> normalized.isEmpty()
                        || fit.name().toLowerCase(Locale.ROOT).contains(normalized))
                .sorted(comparator)
                .toList();
    }

    private static List<CosmeticDefinition> fitCosmetics(CosmeticConfig.SavedFit fit) {
        return fit.equipped().values().stream()
                .map(LunarCatalog::byId)
                .filter(java.util.Objects::nonNull)
                .filter(CosmeticLockerScreen::isVisibleCosmetic)
                .toList();
    }

    private static boolean isVisibleCosmetic(CosmeticDefinition definition) {
        return definition.category().isLockerEnabled();
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent click, boolean doubled) {
        if (SystemNavigation.click(SystemNavigation.COSMETICS, click.x(), click.y(), click.button())) return true;
        if (closingAtNanos >= 0) {
            return true;
        }
        if (isIntroBlocking()) {
            skipIntro();
            return true;
        }
        if (transition(System.nanoTime()) < 0.98F) {
            return true;
        }
        updateLayout();
        if(click.button()==0&&ClientShell.click(click.x(),click.y(),width,height,activeShellKey(),key->{
            fitsView=false;
            if("settings".equals(key)){
                settingsOpen=true;clearFocus();return;
            }
            settingsOpen=false;
            switch(key){
                case "cloaks"->selectSection(LockerSection.COSMETICS);
                case "headwear"->selectSection(LockerSection.HEADWEAR);
                case "wings"->selectSection(isWingSection()?section:LockerSection.LUNAR_WINGS);
                case "pets"->selectSection(isPetSection()?section:LockerSection.PETS);
                case "artifacts"->selectSection(LockerSection.ARTIFACT_SKINS);
                case "trims"->selectSection(LockerSection.ARMOR_TRIMS);
                case "misc"->selectSection(isMiscSection()?section:LockerSection.FLOATING_EFFECTS);
            }
        })){return true;}
        ClientShell.Layout shell=ClientShell.layout(width,height);
        float sx=shell.localX(click.x()),sy=shell.localY(click.y());
        if(click.button()==0&&ClientShell.inside(sx,sy,ClientShell.totalWidth()-56,26,36,36)){
            onClose();return true;
        }
        if(!settingsOpen && clickSearchToolbar(click,doubled))return true;
        if(!ClientShell.inside(sx,sy,GALLERY_LEFT,GALLERY_TOP,ClientShell.WIDTH-GALLERY_LEFT+8,ClientShell.HEIGHT-GALLERY_TOP) && !ClientShell.inRail(click.x(),click.y(),width,height))return false;

        double galleryX = (click.x() - originX) / uiScale;
        double galleryY = (click.y() - originY) / uiScale;
        if (click.button() == 0 && !settingsOpen && lastScrollMaxRow > 0
                && inside(galleryX, galleryY, SCROLL_X - 14, lastScrollTop - 4, 38, lastScrollBottom - lastScrollTop + 8)) {
            scrollbarDragging = true;
            if (galleryY >= lastScrollThumbY && galleryY <= lastScrollThumbY + lastScrollThumbH) {
                scrollbarDragOffsetY = (float) (galleryY - lastScrollThumbY);
            } else {
                scrollbarDragOffsetY = lastScrollThumbH * 0.5F;
            }
            updateScrollFromMouse(galleryY);
            setDragging(true);
            return true;
        }
        double x = toLocalX(click.x());
        double y = toLocalY(click.x(),click.y());
        if (click.button() == 0 && hasEntityPreviewStage()) {
            int railX = PREVIEW_X + 12;
            int railW = PREVIEW_W - 24;
            int third = (railW - 12) / 3;
            if (inside(x, y, railX + 3, PREVIEW_VIEW_ROW_Y + 3, third, PREVIEW_VIEW_BTN_H - 6)
                    || inside(x, y, railX + 6 + third, PREVIEW_VIEW_ROW_Y + 3, third, PREVIEW_VIEW_BTN_H - 6)) {
                targetPreviewYaw = 0.0F;
                previewAutoTurning = true;
                previewDragging = false;
                previewVelocity = 0;
                return true;
            }
            if (inside(x, y, railX + 9 + third * 2, PREVIEW_VIEW_ROW_Y + 3, third, PREVIEW_VIEW_BTN_H - 6)) {
                targetPreviewYaw = 145.0F;
                previewAutoTurning = true;
                previewDragging = false;
                previewVelocity = 0;
                return true;
            }
            int chipGap = 8;
            int chipW = (PREVIEW_W - 24 - chipGap) / 2;
            int chipH = 34;
            for (int i = 0; i < 4; i++) {
                int cx = railX + (i % 2) * (chipW + chipGap);
                int cy = PREVIEW_SLOTS_Y + (i / 2) * (chipH + chipGap);
                if (inside(x, y, cx, cy, chipW, chipH)) {
                    settingsOpen = false;
                    fitsView = false;
                    switch (i) {
                        case 0 -> selectSection(LockerSection.COSMETICS);
                        case 1 -> selectSection(LockerSection.HEADWEAR);
                        case 2 -> selectSection(isWingSection() ? section : LockerSection.LUNAR_WINGS);
                        case 3 -> selectSection(isPetSection() ? section : LockerSection.PETS);
                    }
                    return true;
                }
            }
        }
        if (settingsOpen) {
            if (click.button() == 0 && clickLockerSettingsPage(x, y)) return true;
            if (!ClientShell.inRail(click.x(), click.y(), width, height)) return true;
        }
        if (click.button() == 0 && isChampionFloatingSelected()
                && inside(x, y, FLOATING_NUMBER_X, FLOATING_NUMBER_Y,
                FLOATING_NUMBER_W, FLOATING_NUMBER_H)) {
            setFocused(floatingNumberBox);
            floatingNumberBox.onClick(click, doubled);
            return true;
        }
        if (click.button() == 0 && isHopliteFloatingPage()) {
            for (int index = 0; index < 2; index++) {
                int scopeX = FLOATING_SCOPE_X
                        + index * (FLOATING_SCOPE_W + FLOATING_SCOPE_GAP);
                if (inside(x, y, scopeX, FLOATING_SCOPE_Y,
                        FLOATING_SCOPE_W, FLOATING_NUMBER_H)) {
                    ClientAccessoryConfig.setFloatingGlobal(index == 0);
                    return true;
                }
            }
        }
        if (floatingNumberBox.isFocused()) floatingNumberBox.setFocused(false);
        if (renamingFitId != null) {
            int dialogX = 344;
            int dialogY = 194;
            int inputX = dialogX + 22;
            int inputY = dialogY + 48;
            int inputW = 288;
            int cancelX = dialogX + 168;
            int saveX = dialogX + 246;
            int buttonY = dialogY + 105;
            if (click.button() == 0 && inside(x, y, cancelX, buttonY, 68, 27)) {
                cancelRename();
                return true;
            }
            if (click.button() == 0 && inside(x, y, saveX, buttonY, 64, 27)) {
                saveRename();
                return true;
            }
            if (click.button() == 0 && inside(x, y, inputX, inputY, inputW, 31)) {
                setFocused(renameBox);
                return super.mouseClicked(click, doubled);
            }
            return true;
        }
        if (click.button() == 0 && inside(x, y,
                PREVIEW_X + PREVIEW_W - 27, 8, 27, 31)) {
            onClose();
            return true;
        }
        if (click.button() == 0 && hasPreviewArmorControls()) {
            int armorStartX = armorButtonsX();
            for (int index = 0; index < PREVIEW_ARMOR_SLOTS.length; index++) {
                EquipmentSlot slot = PREVIEW_ARMOR_SLOTS[index];
                int buttonX = armorStartX
                        + index * (ARMOR_BUTTON_SIZE + ARMOR_BUTTON_GAP);
                int buttonY = ARMOR_BUTTON_Y;
                if (inside(x, y, buttonX, buttonY,
                        ARMOR_BUTTON_SIZE, ARMOR_BUTTON_SIZE)) {
                    armorDropdownSlot = armorDropdownSlot == slot ? null : slot;
                    swordDropdownOpen = false;

                    return true;
                }
            }
            if (inside(x, y, swordButtonX(), SWORD_BUTTON_Y,
                    ARMOR_BUTTON_SIZE, ARMOR_BUTTON_SIZE)) {
                swordDropdownOpen = !swordDropdownOpen;
                armorDropdownSlot = null;

                return true;
            }
            if (armorDropdownSlot != null) {
                int menuX = armorButtonsX();
                int menuY = previewArmorMenuY(PreviewArmorMaterial.values().length);
                int index = (int) ((y - (menuY + 4)) / ARMOR_MENU_ROW_HEIGHT);
                if (x >= menuX + 4 && x < menuX + ARMOR_MENU_WIDTH - 4
                        && y >= menuY + 4
                        && index >= 0
                        && index < PreviewArmorMaterial.values().length) {
                    previewArmor.put(armorDropdownSlot,
                            PreviewArmorMaterial.values()[index]);
                    armorDropdownSlot = null;
                    return true;
                }
                armorDropdownSlot = null;
                if (inside(x, y, menuX, menuY, ARMOR_MENU_WIDTH,
                        PreviewArmorMaterial.values().length * ARMOR_MENU_ROW_HEIGHT + 8)) return true;
            }
            if (swordDropdownOpen) {
                int menuX = armorButtonsX();
                int menuY = previewArmorMenuY(PreviewSwordMaterial.values().length);
                int index = (int) ((y - (menuY + 4)) / ARMOR_MENU_ROW_HEIGHT);
                if (x >= menuX + 4 && x < menuX + ARMOR_MENU_WIDTH - 4
                        && y >= menuY + 4
                        && index >= 0
                        && index < PreviewSwordMaterial.values().length) {
                    previewSword = PreviewSwordMaterial.values()[index];
                    swordDropdownOpen = false;
                    return true;
                }
                swordDropdownOpen = false;
                if (inside(x, y, menuX, menuY, ARMOR_MENU_WIDTH,
                        PreviewSwordMaterial.values().length * ARMOR_MENU_ROW_HEIGHT + 8)) return true;
            }
        }
        if (click.button() == 0 && !fitsView && section == LockerSection.ARTIFACT_SKINS
                && clickArtifactHandControls(x, y)) return true;
        if (click.button() == 0 && !fitsView && section == LockerSection.ARTIFACT_SKINS && clickCustomDrawer(x, y)) return true;
        if (click.button() == 0 && !fitsView && section.isExternal()
                && clickExternalVariantControl(x, y)) {
            return true;
        }
        if (section == LockerSection.ARMOR_TRIMS
                && trimFooterDropdown != null && click.button() == 0) {
            int footerWidth = (PREVIEW_W - 35) / 2;
            boolean materialMenu = trimFooterDropdown
                    == TrimFooterDropdown.MATERIAL;
            int menuX = materialMenu ? PREVIEW_X + 12
                    : PREVIEW_X + 18 + footerWidth;
            int rows = materialMenu ? LinTrimManager.MATERIALS.size()
                    : LinTrimPreview.values().length;
            int menuY = PREVIEW_ACTION_Y - 4 - (rows * 27 + 8);
            int index = (int) ((y - (menuY + 4)) / 27);
            if (x >= menuX + 4 && x < menuX + footerWidth - 4
                    && y >= menuY + 4 && index >= 0 && index < rows) {
                if (materialMenu) {
                    LinTrimManager.setMaterial(
                            LinTrimManager.MATERIALS.get(index));
                } else {
                    LinTrimPreview.select(LinTrimPreview.values()[index]);
                }
            }
            trimFooterDropdown = null;
            return true;
        }
        if (click.button() == 0
                && inside(x, y, PREVIEW_DRAG_X, previewStageTop(),
                PREVIEW_DRAG_W, previewStageBottom() - previewStageTop())) {
            previewDragging = true;
            previewDragStartX = click.x();
            previewDragStartYaw = previewYaw;
            lastDragX = click.x();
            lastDragNanos = System.nanoTime();
            previewVelocity = 0;
            return true;
        }
        if (fitsView) {
            List<CosmeticConfig.SavedFit> fits = filteredFits();
            CosmeticConfig.SavedFit previewFit = selectedFit();
            if (previewFit != null && click.button() == 0
                    && inside(x, y, PREVIEW_X + 10, PREVIEW_ACTION_Y, 27, PREVIEW_ACTION_H)) {
                beginRename(previewFit);
                return true;
            }
            int applyX = PREVIEW_X + 44;
            int applyW = PREVIEW_W - 55;
            if (previewFit != null && click.button() == 0
                    && inside(x, y, applyX, PREVIEW_ACTION_Y, applyW, PREVIEW_ACTION_H)) {
                CosmeticConfig.applyFit(previewFit.id());
                return true;
            }
            int itemCount = fits.size() + 1;
            int start = scrollRow * FIT_COLUMNS;
            int end = Math.min(itemCount,
                    start + FIT_VISIBLE_ROWS * FIT_COLUMNS);
            for (int index = start; index < end; index++) {
                int visibleIndex = index - start;
                int cardX = CONTENT_X + visibleIndex % FIT_COLUMNS
                        * (FIT_CARD_W + CARD_GAP);
                int cardY = CARD_TOP + visibleIndex / FIT_COLUMNS * FIT_ROW_STEP;
                if (index == fits.size()) {
                    if (click.button() == 0 && inside(x, y, cardX, cardY,
                            FIT_CARD_W, FIT_CARD_H)) {
                        CosmeticConfig.SavedFit saved = CosmeticConfig.saveCurrentFit();
                        selectedFitId = saved.id();
                        scrollRow = clamp(scrollRow, 0,
                                maxFitScroll(filteredFits().size() + 1));
                        return true;
                    }
                    continue;
                }
                CosmeticConfig.SavedFit fit = fits.get(index);
                String visibleName = truncate(fit.name(), 8.5F, FIT_CARD_W - 42);
                float nameWidth = FontManager.widthRegular(visibleName,bodyFont(8.5F));
                float nameX = cardX + (FIT_CARD_W - nameWidth) * 0.5F;
                if (click.button() == 0 && inside(x, y,
                        Math.round(nameX - 4), cardY + FIT_PREVIEW_H + 24,
                        Math.round(nameWidth + 23), 20)) {
                    beginRename(fit);
                    return true;
                }
                if (click.button() == 0 && inside(x, y,
                        cardX + FIT_CARD_W - 30, cardY, 30, 30)) {
                    CosmeticConfig.deleteFit(fit.id());
                    if (selectedFitId != null && selectedFitId == fit.id()) {
                        selectedFitId = CosmeticConfig.activeFitId();
                        if (selectedFitId == null && !CosmeticConfig.fits().isEmpty()) {
                            selectedFitId = CosmeticConfig.fits().getFirst().id();
                        }
                    }
                    scrollRow = clamp(scrollRow, 0,
                            maxFitScroll(filteredFits().size() + 1));
                    return true;
                }
                if (click.button() == 0
                        && inside(x, y, cardX, cardY,
                        FIT_CARD_W, FIT_CARD_H)) {
                    selectedFitId = fit.id();
                    selected = null;
                    return true;
                }
            }
            if (super.mouseClicked(click, doubled)) return true;
            clearFocus();
            return true;
        }
        if (isPetSection() && click.button() == 0) {
            for (int tab = 0; tab < 3; tab++) {
                if (inside(x, y, CONTENT_X + tab * (CAPE_TAB_W + CARD_GAP), CARD_TOP, CAPE_TAB_W, SOURCE_TAB_H)) {
                    if (tab == 0) {
                        selectSection(LockerSection.PETS);
                    } else {
                        companionView = tab - 1;
                        selectSection(LockerSection.COMPANIONS);
                    }
                    return true;
                }
            }
        }
        if (isMiscSection() && click.button() == 0) {
            int gap = 20;
            int tabWidth = (CONTENT_RIGHT - CONTENT_X - gap * 3) / 4;
            for (int tab = 0; tab < 4; tab++) {
                if (inside(x, y, CONTENT_X + tab * (tabWidth + gap), CARD_TOP, tabWidth, SOURCE_TAB_H)) {
                    switch (tab) {
                        case 0 -> { floatingView = FLOATING_VIEW_LUNAR; selectSection(LockerSection.FLOATING_EFFECTS); }
                        case 1 -> { floatingView = FLOATING_VIEW_HOPLITE; selectSection(LockerSection.FLOATING_EFFECTS); }
                        case 2 -> selectSection(LockerSection.ARROW_TRAILS);
                        case 3 -> selectSection(LockerSection.VIP_ICONS);
                    }
                    return true;
                }
            }
        }
        if (section == LockerSection.COSMETICS || section == LockerSection.COMPANIONS) {
            if ((click.button() == 0 || (section == LockerSection.COMPANIONS && click.button() == 1))
                    && clickSkinSection(x, y, doubled, click.button())) {
                return true;
            }
            if (super.mouseClicked(click, doubled)) return true;
            clearFocus();
            return true;
        }
        if (section == LockerSection.FLOATING_EFFECTS) {
            if (click.button() == 0 && clickFloatingSection(x, y, doubled)) {
                return true;
            }
            if (super.mouseClicked(click, doubled)) return true;
            clearFocus();
            return true;
        }
        if (isWingSection() && click.button() == 0) {
            int tabWidth = (CONTENT_RIGHT - CONTENT_X - CARD_GAP) / 2;
            for (int tab = 0; tab < 2; tab++) {
                if (inside(x, y, CONTENT_X + tab * (tabWidth + CARD_GAP), CARD_TOP, tabWidth, SOURCE_TAB_H)) {
                    selectSection(tab == 0 ? LockerSection.LUNAR_WINGS : LockerSection.WINGS);
                    return true;
                }
            }
        }
        if (section.isExternal()) {
            if (click.button() == 0 && clickExternalSection(x, y, doubled)) {
                return true;
            }
            if (super.mouseClicked(click, doubled)) return true;
            clearFocus();
            return true;
        }
        List<CosmeticDefinition> cosmetics = filtered();
        int start = scrollRow * COLUMNS;
        int end = Math.min(cosmetics.size(), start + cardRows() * COLUMNS);
        for (int index = start; index < end; index++) {
            int visibleIndex = index - start;
            int cardX = CONTENT_X + visibleIndex % COLUMNS * (CARD_W + CARD_GAP);
            int cardY = cardTop() + visibleIndex / COLUMNS * rowStep();
            if (inside(x, y, cardX, cardY, CARD_W, cardHeight())) {
                CosmeticDefinition value = cosmetics.get(index);
                selected = value;
                if (click.button() == 0) {
                    if (doubled && CosmeticConfig.isEquipped(value.id())) {
                        CosmeticConfig.unequip(value);
                    } else if (!CosmeticConfig.isEquipped(value.id())) {
                        clearHopliteWingsBeforeLunar(value);
                        CosmeticConfig.equip(value);
                    }
                    CosmeticAssetManager.request(value);
                }
                return true;
            }
        }
        int footerButtonX = PREVIEW_X + 14;
        int footerButtonW = PREVIEW_W - 28;
        if (selected != null && click.button() == 0
                && inside(x, y, footerButtonX, PREVIEW_ACTION_Y, footerButtonW, PREVIEW_ACTION_H)) {
            if (!CosmeticConfig.isEquipped(selected.id())) {
                clearHopliteWingsBeforeLunar(selected);
            }
            CosmeticConfig.toggleEquip(selected);
            CosmeticAssetManager.request(selected);
            return true;
        }
        if (super.mouseClicked(click, doubled)) return true;
        clearFocus();
        return true;
    }

    private boolean clickSkinSection(double mouseX, double mouseY,
                                     boolean doubled, int button) {
        if (section != LockerSection.COMPANIONS) {
        for (int view = CAPE_VIEW_LUNAR; view <= CAPE_VIEW_DUNGEON; view++) {
            int tabX = CONTENT_X + view * (CAPE_TAB_W + CARD_GAP);
            if (inside(mouseX, mouseY, tabX, CARD_TOP, CAPE_TAB_W, SOURCE_TAB_H)) {
                capeView = view;
                selected = null;
                scrollRow = 0;
                return true;
            }
        }
        }
        if (section == LockerSection.COSMETICS && capeView != CAPE_VIEW_LUNAR) {
            LunarCape equipped = LunarCapeRegistry.selected();
            boolean selectedOnPage = capeView == CAPE_VIEW_OFFICIAL
                    ? LunarCapeRegistry.isOfficial(equipped)
                    : LunarCapeRegistry.isDungeon(equipped);
            if (selectedOnPage
                    && inside(mouseX, mouseY,
                    PREVIEW_X + 14, PREVIEW_ACTION_Y, PREVIEW_W - 28, PREVIEW_ACTION_H)) {
                LunarCapeRegistry.clearSelection();
                LunarCapeTextureManager.selectionChanged();
                ClientAccessoryConfig.save();
                return true;
            }
            List<LunarCape> capes = filteredPackagedCapes();
            int start = scrollRow * COLUMNS;
            int end = Math.min(capes.size(), start + CAPE_VISIBLE_ROWS * COLUMNS);
            for (int index = start; index < end; index++) {
                int visible = index - start;
                int cardX = CONTENT_X + visible % COLUMNS * (CARD_W + CARD_GAP);
                int cardY = HEADWEAR_TOP + visible / COLUMNS * CAPE_ROW_STEP;
                if (!inside(mouseX, mouseY, cardX, cardY,
                        CARD_W, CAPE_CARD_H)) continue;
                LunarCape cape = capes.get(index);
                if (doubled && cape.id().equals(LunarCapeRegistry.selectedId())) {
                    LunarCapeRegistry.clearSelection();
                } else {
                    CosmeticConfig.clearCategory(CosmeticCategory.CLOAK);
                    LunarCapeRegistry.select(cape.id());
                }
                LunarCapeTextureManager.selectionChanged();
                ClientAccessoryConfig.save();
                return true;
            }
            return false;
        }

        List<CosmeticDefinition> cosmetics = filtered();
        int start = scrollRow * COLUMNS;
        int end = Math.min(cosmetics.size(), start + CAPE_VISIBLE_ROWS * COLUMNS);
        for (int index = start; index < end; index++) {
            int visible = index - start;
            int cardX = CONTENT_X + visible % COLUMNS * (CARD_W + CARD_GAP);
            int cardY = HEADWEAR_TOP + visible / COLUMNS * CAPE_ROW_STEP;
            if (!inside(mouseX, mouseY, cardX, cardY,
                    CARD_W, CAPE_CARD_H)) continue;
            CosmeticDefinition value = cosmetics.get(index);
            selected = value;
            if (doubled && CosmeticConfig.isEquipped(value.id())) {
                CosmeticConfig.unequip(value);
            } else if (!CosmeticConfig.isEquipped(value.id())) {
                clearHopliteWingsBeforeLunar(value);
                CosmeticConfig.equip(value);
            }
            CosmeticAssetManager.request(value);
            return true;
        }
        if (button == 0 && selected != null && inside(mouseX, mouseY,
                PREVIEW_X + 14, PREVIEW_ACTION_Y, PREVIEW_W - 28, PREVIEW_ACTION_H)) {
            if (!CosmeticConfig.isEquipped(selected.id())) {
                clearHopliteWingsBeforeLunar(selected);
            }
            CosmeticConfig.toggleEquip(selected);
            CosmeticAssetManager.request(selected);
            return true;
        }
        return false;
    }

    private boolean clickFloatingSection(double mouseX, double mouseY,
                                         boolean doubled) {
        if (floatingView == FLOATING_VIEW_HOPLITE) {
            AccessoryDefinition equipped = AccessoryRegistry.selected(
                    AccessorySlot.FLOATING);
            if (equipped != null && inside(mouseX, mouseY,
                    PREVIEW_X + 14, PREVIEW_ACTION_Y, PREVIEW_W - 28, PREVIEW_ACTION_H)) {
                AccessoryRegistry.clearSelection(AccessorySlot.FLOATING);
                ClientAccessoryConfig.save();
                return true;
            }
            List<AccessoryDefinition> values = filteredFloating();
            int start = scrollRow * COLUMNS;
            int end = Math.min(values.size(), start + cardRows() * COLUMNS);
            for (int index = start; index < end; index++) {
                int visible = index - start;
                int cardX = CONTENT_X + visible % COLUMNS * (CARD_W + CARD_GAP);
                int cardY = HEADWEAR_TOP
                        + visible / COLUMNS * FLOATING_ROW_STEP;
                if (!inside(mouseX, mouseY, cardX, cardY,
                        CARD_W, FLOATING_CARD_H)) continue;
                AccessoryDefinition value = values.get(index);
                if (doubled && value.id().equals(
                        AccessoryRegistry.selectedId(AccessorySlot.FLOATING))) {
                    AccessoryRegistry.clearSelection(AccessorySlot.FLOATING);
                } else {
                    CosmeticConfig.clearCategory(CosmeticCategory.AURAS);
                    AccessoryRegistry.select(AccessorySlot.FLOATING, value.id());
                }
                ClientAccessoryConfig.save();
                return true;
            }
            return false;
        }

        List<CosmeticDefinition> values = filtered();
        int start = scrollRow * COLUMNS;
        int end = Math.min(values.size(), start + cardRows() * COLUMNS);
        for (int index = start; index < end; index++) {
            int visible = index - start;
            int cardX = CONTENT_X + visible % COLUMNS * (CARD_W + CARD_GAP);
            int cardY = HEADWEAR_TOP + visible / COLUMNS * FLOATING_ROW_STEP;
            if (!inside(mouseX, mouseY, cardX, cardY,
                    CARD_W, FLOATING_CARD_H)) continue;
            CosmeticDefinition value = values.get(index);
            selected = value;
            if (doubled && CosmeticConfig.isEquipped(value.id())) {
                CosmeticConfig.unequip(value);
            } else if (!CosmeticConfig.isEquipped(value.id())) {
                AccessoryRegistry.clearSelection(AccessorySlot.FLOATING);
                ClientAccessoryConfig.save();
                CosmeticConfig.equip(value);
            }
            CosmeticAssetManager.request(value);
            return true;
        }
        if (selected != null && inside(mouseX, mouseY,
                PREVIEW_X + 14, PREVIEW_ACTION_Y, PREVIEW_W - 28, PREVIEW_ACTION_H)) {
            if (!CosmeticConfig.isEquipped(selected.id())) {
                AccessoryRegistry.clearSelection(AccessorySlot.FLOATING);
                ClientAccessoryConfig.save();
            }
            CosmeticConfig.toggleEquip(selected);
            CosmeticAssetManager.request(selected);
            return true;
        }
        return false;
    }

    private boolean clickExternalSection(double mouseX, double mouseY,
                                         boolean doubled) {

        if(section==LockerSection.SPAWN_PODS){
            if(inside(mouseX,mouseY,PREVIEW_X+14,426,PREVIEW_W-28,27)){podPart++;return true;}
            if(inside(mouseX,mouseY,PREVIEW_X+14,462,PREVIEW_W-28,27)){if(!selectedPod.largeGroup.isEmpty()){podLarge=!podLarge;podPart=0;}return true;}
            if(inside(mouseX,mouseY,PREVIEW_X+14,PREVIEW_ACTION_Y,PREVIEW_W-28,PREVIEW_ACTION_H)){
                if(selectedPod.applicable())podSaveFailed=!PodSkins.select(selectedPod==PodSkins.selected()?null:selectedPod);return true;
            }
            var values=filteredPods();int start=scrollRow*COLUMNS;
            for(int i=start;i<Math.min(values.size(),start+cardRows()*COLUMNS);i++){
                int x=CONTENT_X+(i-start)%COLUMNS*(CARD_W+CARD_GAP),y=CARD_TOP+(i-start)/COLUMNS*ROW_STEP;
                if(inside(mouseX,mouseY,x,y,CARD_W,CARD_H)&&mouseY>=CARD_TOP&&mouseY<VIEW_BOTTOM){
                    selectedPod=values.get(i);podPart=0;podSaveFailed=false;
                    if(selectedPod.applicable())podSaveFailed=!PodSkins.select(doubled&&selectedPod==PodSkins.selected()?null:selectedPod);return true;
                }
            }return false;
        }
        if (section == LockerSection.VIP_ICONS) {
            if (inside(mouseX, mouseY, PREVIEW_X + 18, 22, PREVIEW_W - 36, 28)) {
                vipSaveFailed = !CosmeticConfig.setVipLobbyOnly(!CosmeticConfig.vipLobbyOnly());
                return true;
            }
            if (inside(mouseX, mouseY, PREVIEW_X + 8, PREVIEW_ACTION_Y, PREVIEW_W - 16, PREVIEW_ACTION_H)) {
                vipSaveFailed = !CosmeticConfig.setVipIcon(selectedVip.id());
                return true;
            }
            var values = filteredVipIcons();
            int start = scrollRow * COLUMNS;
            for (int i = start; i < Math.min(values.size(), start + cardRows() * COLUMNS); i++) {
                int x = CONTENT_X + (i - start) % COLUMNS * (CARD_W + CARD_GAP);
                int y = HEADWEAR_TOP + (i - start) / COLUMNS * ROW_STEP;
                if (inside(mouseX, mouseY, x, y, CARD_W, CARD_H) && mouseY >= HEADWEAR_TOP && mouseY < VIEW_BOTTOM) {
                    selectedVip = values.get(i);
                    boolean equipped = selectedVip.equals(dev.lin.client.cosmetics.vip.VipIcons.selected());
                    vipSaveFailed = !CosmeticConfig.setVipIcon(doubled && equipped ? "none" : selectedVip.id());
                    return true;
                }
            }
            return false;
        }
        if (section == LockerSection.ARROW_TRAILS) {
            if (inside(mouseX, mouseY, PREVIEW_X + 14, PREVIEW_ACTION_Y, PREVIEW_W - 28, PREVIEW_ACTION_H)) {
                trailSaveFailed = !CosmeticConfig.setArrowTrail(selectedArrowTrail.id);
                return true;
            }
            var values = filteredArrowTrails();
            int start = scrollRow * COLUMNS;
            for (int i = start; i < Math.min(values.size(), start + cardRows() * COLUMNS); i++) {
                int x = CONTENT_X + (i - start) % COLUMNS * (CARD_W + CARD_GAP);
                int y = HEADWEAR_TOP + (i - start) / COLUMNS * ROW_STEP;
                if (inside(mouseX, mouseY, x, y, CARD_W, CARD_H) && mouseY >= HEADWEAR_TOP && mouseY < VIEW_BOTTOM) {
                    selectedArrowTrail = values.get(i);
                    boolean equipped = selectedArrowTrail == dev.lin.client.cosmetics.render.ArrowTrails.selected();
                    trailSaveFailed = !CosmeticConfig.setArrowTrail(doubled && equipped ? "none" : selectedArrowTrail.id);
                    return true;
                }
            }
            return false;
        }
        if (section == LockerSection.KILL_EFFECTS) {
            if (inside(mouseX, mouseY, PREVIEW_X + 14, PREVIEW_ACTION_Y, PREVIEW_W - 28, PREVIEW_ACTION_H)) {
                selectedKillEffect.nextPart();
                killPreviewStart = System.nanoTime();
                return true;
            }
            List<KillEffectPreview> values = filteredKillEffects();
            int start = scrollRow * COLUMNS;
            for (int i = start; i < Math.min(values.size(), start + cardRows() * COLUMNS); i++) {
                int x = CONTENT_X + (i - start) % COLUMNS * (CARD_W + CARD_GAP);
                int y = CARD_TOP + (i - start) / COLUMNS * ROW_STEP;
                if (inside(mouseX, mouseY, x, y, CARD_W, CARD_H) && mouseY < VIEW_BOTTOM) {
                    selectedKillEffect = values.get(i);
                    killPreviewStart = System.nanoTime();
                    return true;
                }
            }
            return false;
        }
        if (section == LockerSection.HEADWEAR) {
            AccessoryDefinition selectedHeadwear = AccessoryRegistry.selected(
                    AccessorySlot.HEADWEAR);
            if (selectedHeadwear != null && inside(mouseX, mouseY,
                    PREVIEW_X + 14, PREVIEW_ACTION_Y, PREVIEW_W - 28, PREVIEW_ACTION_H)) {
                AccessoryRegistry.clearSelection(AccessorySlot.HEADWEAR);
                ClientAccessoryConfig.save();
                return true;
            }
            List<AccessoryDefinition> values = filteredHeadwear();
            int start = scrollRow * HEADWEAR_COLUMNS;
            int end = Math.min(values.size(), start + VISIBLE_ROWS * HEADWEAR_COLUMNS);
            for (int index = start; index < end; index++) {
                int visible = index - start;
                int cardX = CONTENT_X + visible % HEADWEAR_COLUMNS * (HEADWEAR_W + CARD_GAP);
                int cardY = HEADWEAR_TOP + visible / HEADWEAR_COLUMNS * HEADWEAR_STEP;
                if (inside(mouseX, mouseY, cardX, cardY, HEADWEAR_W, HEADWEAR_H)) {
                    AccessoryDefinition definition = values.get(index);
                    boolean equipped = definition.id().equals(
                            AccessoryRegistry.selectedId(AccessorySlot.HEADWEAR));
                    if (doubled && equipped) {
                        AccessoryRegistry.clearSelection(AccessorySlot.HEADWEAR);
                    } else {
                        AccessoryRegistry.select(AccessorySlot.HEADWEAR,
                                definition.id());
                    }
                    ClientAccessoryConfig.save();
                    return true;
                }
            }
            return false;
        }
        if (section == LockerSection.WINGS) {
            AccessoryDefinition selectedWings = AccessoryRegistry.selected(
                    AccessorySlot.WINGS);
            if (selectedWings != null) {
                int controlWidth = (PREVIEW_W - 48) / 3;
                if (inside(mouseX, mouseY, PREVIEW_X + 18, 22,
                        controlWidth, 28)) {
                    ClientAccessoryConfig.moveWings(
                            ClientAccessoryConfig.WING_OFFSET_STEP);
                    return true;
                }
                if (inside(mouseX, mouseY,
                        PREVIEW_X + 24 + controlWidth, 22,
                        controlWidth, 28)) {
                    ClientAccessoryConfig.resetWingPosition();
                    return true;
                }
                if (inside(mouseX, mouseY,
                        PREVIEW_X + 30 + controlWidth * 2, 22,
                        controlWidth, 28)) {
                    ClientAccessoryConfig.moveWings(
                            -ClientAccessoryConfig.WING_OFFSET_STEP);
                    return true;
                }
            }
            if (selectedWings != null && inside(mouseX, mouseY,
                    PREVIEW_X + 8, PREVIEW_ACTION_Y, PREVIEW_W - 16, PREVIEW_ACTION_H)) {
                AccessoryRegistry.clearSelection(AccessorySlot.WINGS);
                ClientAccessoryConfig.save();
                return true;
            }
            List<AccessoryDefinition> values = filteredWings();
            int start = scrollRow * COLUMNS;
            int end = Math.min(values.size(), start + cardRows() * COLUMNS);
            for (int index = start; index < end; index++) {
                int visible = index - start;
                int cardX = CONTENT_X + visible % COLUMNS * (CARD_W + CARD_GAP);
                int cardY = cardTop() + visible / COLUMNS * WING_ROW_STEP;
                if (inside(mouseX, mouseY, cardX, cardY, CARD_W, WING_CARD_H)) {
                    AccessoryDefinition definition = values.get(index);
                    boolean equipped = definition.id().equals(
                            AccessoryRegistry.selectedId(AccessorySlot.WINGS));
                    if (doubled && equipped) {
                        AccessoryRegistry.clearSelection(AccessorySlot.WINGS);
                    } else {
                        CosmeticConfig.clearCategory(CosmeticCategory.DRAGON_WINGS);
                        AccessoryRegistry.select(AccessorySlot.WINGS, definition.id());
                    }
                    ClientAccessoryConfig.save();
                    return true;
                }
            }
            return false;
        }
        if (section == LockerSection.ARMOR_TRIMS) {
            int width = (PREVIEW_W - 24) / 2;
            if (inside(mouseX, mouseY, PREVIEW_X + 8, PREVIEW_ACTION_Y, width, PREVIEW_ACTION_H)) {
                trimFooterDropdown = trimFooterDropdown == TrimFooterDropdown.MATERIAL
                        ? null : TrimFooterDropdown.MATERIAL;
                return true;
            }
            if (inside(mouseX, mouseY, PREVIEW_X + 16 + width, PREVIEW_ACTION_Y,
                    width, PREVIEW_ACTION_H)) {
                trimFooterDropdown = trimFooterDropdown == TrimFooterDropdown.ARMOR
                        ? null : TrimFooterDropdown.ARMOR;
                return true;
            }
            if (trimFooterDropdown != null) {
                boolean materialMenu = trimFooterDropdown
                        == TrimFooterDropdown.MATERIAL;
                int menuX = materialMenu ? PREVIEW_X + 12
                        : PREVIEW_X + 18 + width;
                int rows = materialMenu ? LinTrimManager.MATERIALS.size()
                        : LinTrimPreview.values().length;
                int menuHeight = rows * 27 + 8;
                int menuY = PREVIEW_ACTION_Y - 4 - menuHeight;
                int index = (int) ((mouseY - (menuY + 4)) / 27);
                if (mouseX >= menuX + 4 && mouseX < menuX + width - 4
                        && mouseY >= menuY + 4 && index >= 0 && index < rows) {
                    if (materialMenu) {
                        LinTrimManager.setMaterial(
                                LinTrimManager.MATERIALS.get(index));
                    } else {
                        LinTrimPreview.select(LinTrimPreview.values()[index]);
                    }
                    trimFooterDropdown = null;
                    return true;
                }
                trimFooterDropdown = null;
            }
            List<String> patterns = filteredTrimPatterns();
            int start = scrollRow * COLUMNS;
            int end = Math.min(patterns.size(), start + cardRows() * COLUMNS);
            for (int index = start; index < end; index++) {
                int visible = index - start;
                int cardX = CONTENT_X + visible % COLUMNS * (CARD_W + CARD_GAP);
                int cardY = cardTop() + visible / COLUMNS * rowStep();
                if (inside(mouseX, mouseY, cardX, cardY, CARD_W, cardHeight())) {
                    String pattern = patterns.get(index);
                    LinTrimManager.setPattern(doubled
                            && pattern.equals(LinTrimManager.pattern())
                            ? "none" : pattern);
                    return true;
                }
            }
            return false;
        }
        ArtifactSkins.Artifact artifact = currentArtifact();
        List<ArtifactSkins.Artifact> values = filteredArtifacts();
        int start = scrollRow * COLUMNS;
        int end = Math.min(values.size(), start + cardRows() * COLUMNS);
        for (int index = start; index < end; index++) {
            int visible = index - start;
            int cardX = CONTENT_X + visible % COLUMNS * (CARD_W + CARD_GAP);
            int cardY = cardTop() + visible / COLUMNS * rowStep();
            if (inside(mouseX, mouseY, cardX, cardY, CARD_W, cardHeight())) {
                ArtifactSkins.Artifact value = values.get(index);
                if (doubled && value == selectedArtifact) {
                    boolean enabled = ArtifactSkinConfig.enabled
                            && ArtifactSkinConfig.isArtifactEnabled(value.id());
                    if (!ArtifactSkinConfig.enabled) {
                        ArtifactPackManager.setEnabled(true);
                    }
                    ArtifactPackManager.setArtifactEnabled(value, !enabled);
                }
                selectedArtifact = value; customScroll = 0; customModelPicker = false;
                return true;
            }
        }
        return false;
    }

    private boolean clickExternalVariantControl(double mouseX, double mouseY) {
        int x = externalVariantX();
        if (section == LockerSection.HEADWEAR) {
            if (inside(mouseX, mouseY, CONTENT_X, CARD_TOP, CAPE_TAB_W, SOURCE_TAB_H)
                    || inside(mouseX, mouseY,
                    CONTENT_X + CAPE_TAB_W + CARD_GAP, CARD_TOP,
                    CAPE_TAB_W, SOURCE_TAB_H)) {
                AccessoryRegistry.setKingmcHeadwear(
                        mouseX >= CONTENT_X + CAPE_TAB_W + CARD_GAP);
                scrollRow = 0;
                ClientAccessoryConfig.save();
                return true;
            }
            if (inside(mouseX, mouseY,
                    CONTENT_X + (CAPE_TAB_W + CARD_GAP) * 2, CARD_TOP,
                    CAPE_TAB_W, SOURCE_TAB_H)) {
                AccessoryRegistry.setHeadwearScope(
                        AccessoryRegistry.headwearScope().next());
                ClientAccessoryConfig.save();
                return true;
            }

            AccessoryDefinition headwear = AccessoryRegistry.selected(
                    AccessorySlot.HEADWEAR);
            if (headwear == null) return false;
            HeadwearVariant[] variants = HeadwearVariant.values();
            for (int index = 0; index < variants.length; index++) {
                int y = EXTERNAL_VARIANT_Y
                        + index * (EXTERNAL_VARIANT_SIZE + EXTERNAL_VARIANT_GAP);
                if (inside(mouseX, mouseY, x, y,
                        EXTERNAL_VARIANT_SIZE, EXTERNAL_VARIANT_SIZE)) {
                    AccessoryRegistry.selectHeadwearVariant(headwear.id(),
                            variants[index]);
                    ClientAccessoryConfig.save();
                    return true;
                }
            }
            return false;
        }
        if (section != LockerSection.ARTIFACT_SKINS) return false;
        ArtifactSkins.Artifact artifact = currentArtifact();
        List<ArtifactSkins.Option> options = ArtifactSkins.options(artifact);
        if (options.size() < 2) return false;
        for (int index = artifactVariantStart(artifact); index < Math.min(options.size(), artifactVariantScroll + 8); index++) {
            int y = EXTERNAL_VARIANT_Y
                    + (index - artifactVariantScroll) * (EXTERNAL_VARIANT_SIZE + EXTERNAL_VARIANT_GAP);
            if (inside(mouseX, mouseY, x, y,
                    EXTERNAL_VARIANT_SIZE, EXTERNAL_VARIANT_SIZE)) {
                ArtifactSkins.select(options.get(index));
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent click, double dragX, double dragY) {
        if (click.button() == 0 && draggingArtifactTransform >= 0) {
            updateArtifactTransformFromMouse(toLocalX(click.x()));
            return true;
        }
        if (scrollbarDragging && click.button() == 0) {
            updateScrollFromMouse((click.y() - originY) / uiScale);
            return true;
        }
        if (click.button() == 0 && (draggingBlur || draggingOpacity
                || draggingMenuBlur || draggingMenuOpacity)) {
            double x = toLocalX(click.x());
            if (draggingBlur) updateBlurFromMouse(x);
            if (draggingOpacity) updateOpacityFromMouse(x);
            if (draggingMenuBlur) updateMenuBlurFromMouse(x);
            if (draggingMenuOpacity) updateMenuOpacityFromMouse(x);
            return true;
        }
        if (previewDragging && click.button() == 0) {
            previewAutoTurning = false;
            float movement = (float) ((click.x() - previewDragStartX)
                    / Math.max(0.001F, previewLayout().scale()));
            float target = normalizeDegrees(previewDragStartYaw - movement * 0.65F);
            long now = System.nanoTime();
            float elapsed = Math.max(0.001F, (now - lastDragNanos) / 1_000_000_000.0F);
            float delta = normalizeDegrees(target - previewYaw);
            previewYaw = target;
            previewVelocity = clampFloat((float) ((click.x() - lastDragX)
                    / Math.max(0.001F, previewLayout().scale()) / elapsed) * -0.08F, -180, 180);
            lastDragX = click.x();
            lastDragNanos = now;
            return true;
        }
        return super.mouseDragged(click, dragX, dragY);
    }

    private void updateScrollFromMouse(double galleryY) {
        if (lastScrollMaxRow <= 0) return;
        float usable = Math.max(1F, (lastScrollBottom - lastScrollTop - 4) - lastScrollThumbH);
        float progress = clampFloat((float) ((galleryY - scrollbarDragOffsetY - (lastScrollTop + 2)) / usable), 0F, 1F);
        float exactRow = progress * lastScrollMaxRow;
        scrollRow = clamp(Math.round(exactRow), 0, lastScrollMaxRow);
        visualScrollRow = exactRow;
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent click) {
        if (click.button() == 0 && scrollbarDragging) {
            scrollbarDragging = false;
            setDragging(false);
            return true;
        }
        if (click.button() == 0 && draggingArtifactTransform >= 0) {
            draggingArtifactTransform = -1;
            ArtifactSkinConfig.save();
            return true;
        }
        if (click.button() == 0 && (draggingBlur || draggingOpacity
                || draggingMenuBlur || draggingMenuOpacity)) {
            draggingBlur = false;
            draggingOpacity = false;
            draggingMenuBlur = false;
            draggingMenuOpacity = false;
            return true;
        }
        if (previewDragging && click.button() == 0) {
            previewDragging = false;
            return true;
        }
        return super.mouseReleased(click);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY,
                                 double horizontalAmount, double verticalAmount) {
        double x = toLocalX(mouseX);
        double y = toLocalY(mouseX,mouseY);
        if (!fitsView && customModelPicker && section == LockerSection.ARTIFACT_SKINS && inside(x, y, ARTIFACT_HAND_DRAWER_X, 48, 246, 470)) {
            customScroll = clamp(customScroll - (int)Math.signum(verticalAmount), 0, Math.max(0, (ArtifactSkins.customOptions(currentArtifact()).size() + 1) / 2 - 3));
            return true;
        }
        if (!fitsView && section == LockerSection.ARTIFACT_SKINS && inside(x, y, externalVariantX(), EXTERNAL_VARIANT_Y,
                EXTERNAL_VARIANT_SIZE, 8 * (EXTERNAL_VARIANT_SIZE + EXTERNAL_VARIANT_GAP))) {
            artifactVariantStart(currentArtifact());
            artifactVariantScroll = clamp(artifactVariantScroll - (int)Math.signum(verticalAmount), 0,
                Math.max(0, ArtifactSkins.options(currentArtifact()).size() - 8));
            return true;
        }
        if (inside(x, y, CONTENT_X, CARD_TOP, CONTENT_RIGHT - CONTENT_X,
                VIEW_BOTTOM - CARD_TOP)) {
            int max = fitsView ? maxFitScroll(filteredFits().size() + 1)
                    : section == LockerSection.COMPANIONS ? skinMaxScroll(filtered().size())
                    : section == LockerSection.COSMETICS
                    ? skinMaxScroll(capeView != CAPE_VIEW_LUNAR
                    ? filteredPackagedCapes().size() : filtered().size())
                    : section == LockerSection.FLOATING_EFFECTS
                    ? maxScroll(floatingView == FLOATING_VIEW_HOPLITE
                    ? filteredFloating().size() : filtered().size())
                    : section.isExternal() ? maxScroll(externalItemCount())
                    : maxScroll(filtered().size());
            scrollRow = clamp(scrollRow - (int) Math.signum(verticalAmount), 0, max);
            return true;
        }
        if (inside(x, y, 0, NAV_TOP - 8, SIDEBAR_W, (NAV_SECTIONS.length + 1) * NAV_STEP + 16)) {
            sidebarScroll = clamp(sidebarScroll - (int) Math.signum(verticalAmount),
                    0, 0);
            return true;
        }
        return false;
    }

    @Override
    public boolean keyPressed(KeyEvent input) {
        if (isIntroBlocking() && (input.key() == 32 || input.key() == 257 || input.key() == 335)) {
            skipIntro();
            return true;
        }
        if (renamingFitId != null) {
            if (input.key() == 256 && customModelPicker) { customModelPicker = false; return true; }
        if (input.key() == 256) {
                cancelRename();
                return true;
            }
            if (input.key() == 257 || input.key() == 335) {
                saveRename();
                return true;
            }
            return super.keyPressed(input);
        }
        if (input.key() == 256) {
            if (floatingNumberBox.isFocused()) {
                floatingNumberBox.setFocused(false);
            } else if (settingsOpen) {
                settingsOpen = false;
                draggingBlur = false;
                draggingOpacity = false;
                draggingMenuBlur = false;
                draggingMenuOpacity = false;
            } else if (artifactHandSettings) {
                artifactHandSettings = false;
                draggingArtifactTransform = -1;
            } else if (armorDropdownSlot != null) {
                armorDropdownSlot = null;
            } else if (swordDropdownOpen) {
                swordDropdownOpen = false;
            } else {
                onClose();
            }
            return true;
        }
        if (input.key() == 70 && input.hasControlDown()) {
            setFocused(searchBox);
            searchBox.moveCursorToEnd(false);
            return true;
        }
        return super.keyPressed(input);
    }

    private void updateBlurFromMouse(double localX) {
        float progress = clampFloat((float) ((localX - SETTINGS_TRACK_X)
                / SETTINGS_TRACK_W), 0, 1);
        int value = Math.round(progress * ClientAccessoryConfig.BACKGROUND_BLUR_MAX);
        GlassStyle.set("backdrop.blur.radius", value);
    }

    private void updateOpacityFromMouse(double localX) {
        float progress = clampFloat((float) ((localX - SETTINGS_TRACK_X)
                / SETTINGS_TRACK_W), 0, 1);
        float value = ClientAccessoryConfig.BACKGROUND_OPACITY_MIN
                + progress * (ClientAccessoryConfig.BACKGROUND_OPACITY_MAX
                - ClientAccessoryConfig.BACKGROUND_OPACITY_MIN);
        GlassStyle.set("backdrop.alpha", value);
    }

    private void updateMenuBlurFromMouse(double localX) {
        float progress = clampFloat((float) ((localX - SETTINGS_TRACK_X)
                / SETTINGS_TRACK_W), 0, 1);
        int value = Math.round(progress * ClientAccessoryConfig.BACKGROUND_BLUR_MAX);
        GlassStyle.set("panel.blur.radius", value);
        GlassStyle.set("blur.radius", value);
        if (minecraft != null) minecraft.options.menuBackgroundBlurriness().set(value);
    }

    private void updateMenuOpacityFromMouse(double localX) {
        float progress = clampFloat((float) ((localX - SETTINGS_TRACK_X)
                / SETTINGS_TRACK_W), 0, 1);
        GlassStyle.set("panel.alpha", Math.round(progress * 255));
    }

    private float artifactTransformValue(int index) {
        ArtifactSkinConfig.HandTransform transform =
                ArtifactSkinConfig.handTransform(currentArtifactTransformKey());
        if (artifactMainHand) {
            return switch (index) {
                case 0 -> transform.mainX();
                case 1 -> transform.mainY();
                case 2 -> transform.mainZ();
                case 3 -> transform.mainRotX();
                default -> transform.mainRotY();
            };
        }
        return switch (index) {
            case 0 -> transform.offX();
            case 1 -> transform.offY();
            case 2 -> transform.offZ();
            case 3 -> transform.offRotX();
            default -> transform.offRotY();
        };
    }

    private void setArtifactTransformValue(int index, float value) {
        ArtifactSkinConfig.setHandTransform(currentArtifactTransformKey(),
                artifactMainHand, index, value);
    }

    private void updateArtifactTransformFromMouse(double localX) {
        if (draggingArtifactTransform < 0) return;
        float progress = clampFloat((float) ((localX - ARTIFACT_HAND_TRACK_X)
                / ARTIFACT_HAND_TRACK_W), 0, 1);
        float min = draggingArtifactTransform < 3 ? ArtifactSkinConfig.HAND_POSITION_MIN
                : ArtifactSkinConfig.HAND_ROTATION_MIN;
        float max = draggingArtifactTransform < 3 ? ArtifactSkinConfig.HAND_POSITION_MAX
                : ArtifactSkinConfig.HAND_ROTATION_MAX;
        float value = min + progress * (max - min);
        value = draggingArtifactTransform < 3
                ? Math.round(value * 100) / 100.0F : Math.round(value);
        setArtifactTransformValue(draggingArtifactTransform, value);
    }

    private void resetArtifactHand() {
        ArtifactSkinConfig.resetHandTransform(currentArtifactTransformKey(), artifactMainHand);
    }

    @Override
    public void onClose() {
        if (minecraft == null || closingAtNanos >= 0) return;
        closingAtNanos = System.nanoTime();
        clearFocus();
        // removed() persists edits once; navigation must not wait for render/tick.
        minecraft.setScreen(parent);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    private final java.util.Map<LockerSection,Integer> sectionScrolls=new java.util.EnumMap<>(LockerSection.class);
    private final java.util.Map<LockerSection,CosmeticDefinition> sectionSelections=new java.util.EnumMap<>(LockerSection.class);
    private int savedFitScroll;

    private void rememberGallery() {
        if(fitsView){savedFitScroll=scrollRow;return;}
        sectionScrolls.put(section,scrollRow);
        if(selected!=null)sectionSelections.put(section,selected);else sectionSelections.remove(section);
    }

    private void selectSection(LockerSection value) {
        rememberGallery();
        if (draggingArtifactTransform >= 0) ArtifactSkinConfig.save();
        draggingArtifactTransform = -1;
        artifactHandSettings = false;
        customModelPicker = false;
        section = value;
        fitsView = false;
        armorDropdownSlot = null;
        swordDropdownOpen = false;
        previewDragging = false;
        previewVelocity = 0;

        trimFooterDropdown = null;
        scrollRow = sectionScrolls.getOrDefault(value,0);
        visualScrollRow = scrollRow;
        scrollbarDragging = false;
        selected = sectionSelections.get(value);
        targetPreviewYaw = 0.0F;
        previewAutoTurning = true;
    }

    private void selectFits() {
        rememberGallery();
        if (draggingArtifactTransform >= 0) ArtifactSkinConfig.save();
        draggingArtifactTransform = -1;
        artifactHandSettings = false;
        customModelPicker = false;
        armorDropdownSlot = null;
        swordDropdownOpen = false;
        trimFooterDropdown = null;
        previewDragging = false;
        previewVelocity = 0;
        fitsView = true;

        scrollRow = savedFitScroll;
        selected = null;
        selectedFitId = CosmeticConfig.activeFitId();
        if (selectedFitId == null && !CosmeticConfig.fits().isEmpty()) {
            selectedFitId = CosmeticConfig.fits().getFirst().id();
        }
    }

    private CosmeticConfig.SavedFit selectedFit() {
        if (selectedFitId == null) return null;
        for (CosmeticConfig.SavedFit fit : CosmeticConfig.fits()) {
            if (fit.id() == selectedFitId) return fit;
        }
        return null;
    }

    private void beginRename(CosmeticConfig.SavedFit fit) {

        renamingFitId = fit.id();
        renameBox.visible = true;
        renameBox.setValue(fit.name());
        renameBox.moveCursorToEnd(false);
        setFocused(renameBox);
    }

    private void saveRename() {
        if (renamingFitId == null || renameBox.getValue().strip().isEmpty()) return;
        CosmeticConfig.renameFit(renamingFitId, renameBox.getValue());
        cancelRename();
    }

    private void cancelRename() {
        renamingFitId = null;
        renameBox.visible = false;
        clearFocus();
    }

    private List<CosmeticDefinition> visibleEquipped() {
        return CosmeticConfig.equipped().stream()
                .filter(CosmeticLockerScreen::isVisibleCosmetic)
                .toList();
    }

    private List<CosmeticDefinition> previewOutfit() {
        if (fitsView) {
            CosmeticConfig.SavedFit fit = selectedFit();
            return fit == null ? visibleEquipped() : fitCosmetics(fit);
        }
        List<CosmeticDefinition> outfit = new ArrayList<>(visibleEquipped());
        if (section == LockerSection.FLOATING_EFFECTS) {
            outfit.removeIf(value -> value.category() != CosmeticCategory.AURAS);
        }
        if (selected != null && !CosmeticConfig.isEquipped(selected.id())) {
            outfit.removeIf(value -> value.category() == selected.category());
            outfit.add(selected);
        }
        return List.copyOf(outfit);
    }

    private static void clearHopliteWingsBeforeLunar(CosmeticDefinition definition) {
        if (definition.category() == CosmeticCategory.DRAGON_WINGS) {
            AccessoryRegistry.clearSelection(AccessorySlot.WINGS);
            ClientAccessoryConfig.save();
        } else if (definition.category() == CosmeticCategory.CLOAK) {
            LunarCapeRegistry.clearSelection();
            ClientAccessoryConfig.save();
        } else if (definition.category() == CosmeticCategory.PET) {
            LunarPetRegistry.clearSelection();
            ClientAccessoryConfig.save();
        }
    }

    private void jumpToCosmetic(CosmeticDefinition cosmetic) {
        searchBox.setValue("");
        section = sectionFor(cosmetic.category());
        if (section == LockerSection.COMPANIONS) {
            companionView = "HOPLITE_PET".equals(cosmetic.indexType()) ? 1 : 0;
        }
        fitsView = false;
        selected = cosmetic;
        scrollRow = 0;
        List<CosmeticDefinition> cosmetics = filtered();
        for (int index = 0; index < cosmetics.size(); index++) {
            if (cosmetics.get(index).id() == cosmetic.id()) {
                scrollRow = clamp(index / COLUMNS, 0, maxScroll(cosmetics.size()));
                break;
            }
        }
        CosmeticAssetManager.request(cosmetic);
    }

    private static LockerSection sectionFor(CosmeticCategory category) {
        return switch (category) {
            case CLOAK -> LockerSection.COSMETICS;
            case PET -> LockerSection.PETS;
            case COMPANION -> LockerSection.COMPANIONS;
            case AURAS -> LockerSection.FLOATING_EFFECTS;
            case DRAGON_WINGS -> LockerSection.LUNAR_WINGS;
            default -> LockerSection.COSMETICS;
        };
    }

    private void updateLayout() {
        float areaWidth=ClientShell.WIDTH-GALLERY_LEFT-6;
        float areaHeight=ClientShell.HEIGHT-GALLERY_TOP-16;
        boolean drawerOpen=section==LockerSection.ARTIFACT_SKINS&&(artifactHandSettings||customModelPicker);
        float virtualWidth=drawerOpen?(layoutWidth()-CONTENT_X):(CONTENT_RIGHT-CONTENT_X+34);
        float fit=Math.min(areaWidth/virtualWidth,areaHeight/(GALLERY_HEIGHT-CARD_TOP));
        ClientShell.Layout content=ClientShell.contentArea(width,height,GALLERY_LEFT,GALLERY_TOP,
                virtualWidth*fit,areaHeight,CONTENT_X,virtualWidth,GALLERY_HEIGHT-CARD_TOP);
        uiScale=content.scale();originX=content.x();
        originY=content.y()-CARD_TOP*uiScale+galleryMotion.value()*ClientShell.layout(width,height).scale();
        if (searchBox != null) {
            ClientShell.Layout toolbar=searchToolbarLayout();
            int left = Math.round(toolbar.x()+SEARCH_X*toolbar.scale());
            int top = Math.round(toolbar.y()+SEARCH_Y*toolbar.scale());
            int right = Math.round(toolbar.x()+(SEARCH_X+SEARCH_W)*toolbar.scale());
            int bottom = Math.round(toolbar.y()+(SEARCH_Y+SEARCH_H)*toolbar.scale());
            searchBox.setRectangle(Math.max(1, right - left), Math.max(1, bottom - top),
                    left, top);
            searchBox.setVisualMetrics(toolbar.scale(),40,SEARCH_W-75,
                    dev.lin.client.cosmetics.font.PageTypography.cosmetics(8,toolbar.scale()/ClientShell.layout(width,height).scale()));
        }
        if (renameBox != null) {
            int left = toScreenX(366);
            int top = toScreenY(242);
            int right = toScreenX(654);
            int bottom = toScreenY(273);
            renameBox.setRectangle(Math.max(1, right - left), Math.max(1, bottom - top),
                    left, top);
            renameBox.setVisualMetrics(uiScale, 11, 266,bodyFont(9));
        }
        if (floatingNumberBox != null) {
            var rail=previewLayout();
            int left = Math.round(rail.x()+FLOATING_NUMBER_X*rail.scale());
            int top = Math.round(rail.y()+FLOATING_NUMBER_Y*rail.scale());
            int right = Math.round(rail.x()+(FLOATING_NUMBER_X+FLOATING_NUMBER_W)*rail.scale());
            int bottom = Math.round(rail.y()+(FLOATING_NUMBER_Y+FLOATING_NUMBER_H)*rail.scale());
            floatingNumberBox.setRectangle(Math.max(1, right - left),
                    Math.max(1, bottom - top), left, top);
            floatingNumberBox.setVisualMetrics(rail.scale(), 62, 92, 11*ClientShell.layout(width,height).scale()/rail.scale());
        }
    }

    private float transition(long now) {
        if (closingAtNanos >= 0) {
            float progress = clampFloat((now - closingAtNanos)
                    / (float) CLOSE_ANIMATION_NANOS, 0, 1);
            return 1 - dev.lin.client.shared.UiMotion.in(progress);
        }
        float progress = clampFloat((now - openedAtNanos)
                / (float) OPEN_ANIMATION_NANOS, 0, 1);
        return dev.lin.client.shared.UiMotion.out(progress);
    }

    private void updatePreviewInertia() {
        if (previewDragging) {
            previewAutoTurning = false;
            return;
        }
        if (previewAutoTurning) {
            float delta = normalizeDegrees(targetPreviewYaw - previewYaw);
            if (Math.abs(delta) < 0.35F) {
                previewYaw = targetPreviewYaw;
                previewAutoTurning = false;
            } else {
                previewYaw = normalizeDegrees(previewYaw + delta * (1.0F - (float) Math.exp(-9.0F * frameSeconds)));
            }
            return;
        }
        if (Math.abs(previewVelocity) < 0.02F) return;
        previewYaw = normalizeDegrees(previewYaw + previewVelocity * frameSeconds);
        previewVelocity *= (float) Math.exp(-9F * frameSeconds);
        if(Math.abs(previewVelocity)<.02f)previewVelocity=0;
    }

    private float animatedHover(int id, boolean hovered) {
        var motion=cardHover.computeIfAbsent(id,key->new dev.lin.client.shared.LensMotion.Spring(0));
        float value=motion.update(hovered?1:0,frameSeconds);
        if(!hovered&&motion.isSettled())cardHover.remove(id);
        return clampFloat(value,0,1);
    }

    private void updateWardrobeMotion(){
        if (!scrollbarDragging) {
            float scrollDiff = scrollRow - visualScrollRow;
            if (Math.abs(scrollDiff) < 0.002F) {
                visualScrollRow = scrollRow;
            } else {
                visualScrollRow += scrollDiff * (1.0F - (float) Math.exp(-16.0 * frameSeconds));
            }
        }
        String state=section+":"+fitsView+":"+capeView+":"+companionView+":"+floatingView;
        if(previousGalleryState!=null&&!state.equals(previousGalleryState)){
            galleryMotion.impulse(Math.max(0,22-galleryMotion.velocity()));
            previewPresence.impulse(-.18f);
            cardHover.clear();
            visualScrollRow = scrollRow;
        }
        if(selected!=previousPreviewSelection)previewPresence.impulse(-.15f);
        previousGalleryState=state;previousPreviewSelection=selected;
        galleryMotion.update(0,frameSeconds);previewPresence.update(1,frameSeconds);
    }

    private static int mixColor(int from, int to, float amount) {
        float t = clampFloat(amount, 0, 1);
        int a = Math.round(((from >>> 24) & 0xFF) * (1 - t)
                + ((to >>> 24) & 0xFF) * t);
        int r = Math.round(((from >>> 16) & 0xFF) * (1 - t)
                + ((to >>> 16) & 0xFF) * t);
        int g = Math.round(((from >>> 8) & 0xFF) * (1 - t)
                + ((to >>> 8) & 0xFF) * t);
        int b = Math.round((from & 0xFF) * (1 - t) + (to & 0xFF) * t);
        return a << 24 | r << 16 | g << 8 | b;
    }

    private static int withOpacity(int color, float opacity) {
        int alpha = Math.round((color >>> 24 & 0xFF)
                * clampFloat(opacity, 0, 1));
        return alpha << 24 | color & 0xFFFFFF;
    }

    private static float easeInCubic(float value) {
        return value * value * value;
    }

    private static void renderEntityFixed(GuiGraphics graphics, int left, int top,
                                           int right, int bottom, int scale,
                                           LivingEntity entity, float yaw,
                                           List<CosmeticDefinition> previewOutfit) {
        renderEntityFixed(graphics, left, top, right, bottom, scale, entity, yaw,
                previewOutfit, false);
    }

    private static void renderEntityFixed(GuiGraphics graphics, int left, int top,
                                           int right, int bottom, int scale,
                                           LivingEntity entity, float yaw,
                                           List<CosmeticDefinition> previewOutfit,
                                           boolean mannequin) {
        renderEntityFixed(graphics, left, top, right, bottom, scale, entity, yaw,
                previewOutfit, mannequin, null);
    }

    private static void renderEntityFixed(GuiGraphics graphics, int left, int top,
                                           int right, int bottom, int scale,
                                           LivingEntity entity, float yaw,
                                           List<CosmeticDefinition> previewOutfit,
                                           boolean mannequin, CardDisplay display) {
        renderEntityFixed(graphics, left, top, right, bottom, scale, entity, yaw,
                previewOutfit, mannequin, display, 0, 0);
    }

    private static void renderEntityFixed(GuiGraphics graphics, int left, int top,
                                           int right, int bottom, int scale,
                                           LivingEntity entity, float yaw,
                                           List<CosmeticDefinition> previewOutfit,
                                           boolean mannequin, CardDisplay display,
                                           int offsetX, int offsetY) {
        renderEntityFixed(graphics, left, top, right, bottom, scale, entity, yaw,
                previewOutfit, mannequin, display, offsetX, offsetY, null, null);
    }

    private static void renderEntityFixed(GuiGraphics graphics, int left, int top,
                                           int right, int bottom, int scale,
                                           LivingEntity entity, float yaw,
                                           List<CosmeticDefinition> previewOutfit,
                                           boolean mannequin, CardDisplay display,
                                           int offsetX, int offsetY,
                                           Identifier capeTexture) {
        renderEntityFixedWithItem(graphics, left, top, right, bottom, scale,
                entity, yaw, previewOutfit, mannequin, display, offsetX, offsetY,
                null, null, null, null, null, null, capeTexture);
    }

    private static void renderEntityFixed(GuiGraphics graphics, int left, int top,
                                           int right, int bottom, int scale,
                                           LivingEntity entity, float yaw,
                                           List<CosmeticDefinition> previewOutfit,
                                           boolean mannequin, CardDisplay display,
                                           int offsetX, int offsetY,
                                           Map<EquipmentSlot, PreviewArmorMaterial> armor,
                                           PreviewSwordMaterial sword) {
        renderEntityFixed(graphics, left, top, right, bottom, scale, entity, yaw,
                previewOutfit, mannequin, display, offsetX, offsetY,
                armor, sword, null, null, null);
    }

    private static void renderEntityFixed(GuiGraphics graphics, int left, int top,
                                           int right, int bottom, int scale,
                                           LivingEntity entity, float yaw,
                                           List<CosmeticDefinition> previewOutfit,
                                           boolean mannequin, CardDisplay display,
                                           int offsetX, int offsetY,
                                           Map<EquipmentSlot, PreviewArmorMaterial> armor,
                                             PreviewSwordMaterial sword,
                                             AccessoryDefinition headwear,
                                             LinTrimPreview trimPreview,
                                             AccessoryDefinition wings) {
        renderEntityFixedWithItem(graphics, left, top, right, bottom, scale,
                entity, yaw, previewOutfit, mannequin, display, offsetX, offsetY,
                armor, sword, headwear, trimPreview, wings, null);
    }

    private static void renderEntityFixedWithItem(
                                            GuiGraphics graphics, int left, int top,
                                            int right, int bottom, int scale,
                                            LivingEntity entity, float yaw,
                                            List<CosmeticDefinition> previewOutfit,
                                            boolean mannequin, CardDisplay display,
                                            int offsetX, int offsetY,
                                            Map<EquipmentSlot, PreviewArmorMaterial> armor,
                                            PreviewSwordMaterial sword,
                                            AccessoryDefinition headwear,
                                            LinTrimPreview trimPreview,
                                            AccessoryDefinition wings,
                                            ArtifactSkins.Artifact artifactPreview) {
        renderEntityFixedWithItem(graphics, left, top, right, bottom, scale,
                entity, yaw, previewOutfit, mannequin, display, offsetX, offsetY,
                armor, sword, headwear, trimPreview, wings, artifactPreview, null);
    }

    private static void renderEntityFixedWithItem(
                                            GuiGraphics graphics, int left, int top,
                                            int right, int bottom, int scale,
                                            LivingEntity entity, float yaw,
                                            List<CosmeticDefinition> previewOutfit,
                                            boolean mannequin, CardDisplay display,
                                            int offsetX, int offsetY,
                                            Map<EquipmentSlot, PreviewArmorMaterial> armor,
                                            PreviewSwordMaterial sword,
                                            AccessoryDefinition headwear,
                                            LinTrimPreview trimPreview,
                                            AccessoryDefinition wings,
                                            ArtifactSkins.Artifact artifactPreview,
                                            Identifier capeTexture) {
        EntityRenderDispatcher dispatcher = Minecraft.getInstance().getEntityRenderDispatcher();
        EntityRenderer<? super LivingEntity, ?> renderer = entity==null?null:dispatcher.getRenderer(entity);
        EnumMap<EquipmentSlot, ItemStack> originalEquipment =
                new EnumMap<>(EquipmentSlot.class);
        ArtifactSkins.PreviewMode artifactMode = artifactPreview == null
                ? null : artifactPreview.previewMode();
        ItemStack artifactStack = artifactPreview == null
                ? ItemStack.EMPTY : ArtifactSkins.previewStack(artifactPreview);
        EntityRenderState state;
        if(entity==null){
            var avatar=dev.lin.client.cosmetics.render.MenuAvatarState.create();
            if(!mannequin && armor!=null){
                avatar.headEquipment=armor.getOrDefault(EquipmentSlot.HEAD,PreviewArmorMaterial.NONE).stack(EquipmentSlot.HEAD);
                avatar.chestEquipment=armor.getOrDefault(EquipmentSlot.CHEST,PreviewArmorMaterial.NONE).stack(EquipmentSlot.CHEST);
                avatar.legsEquipment=armor.getOrDefault(EquipmentSlot.LEGS,PreviewArmorMaterial.NONE).stack(EquipmentSlot.LEGS);
                avatar.feetEquipment=armor.getOrDefault(EquipmentSlot.FEET,PreviewArmorMaterial.NONE).stack(EquipmentSlot.FEET);
            }
            if(!mannequin && artifactMode == ArtifactSkins.PreviewMode.ELYTRA){
                avatar.chestEquipment=ArtifactSkins.wornPreviewStack(artifactPreview);
            } else if(!mannequin && artifactMode != null && artifactMode != ArtifactSkins.PreviewMode.HEAD){
                dev.lin.client.cosmetics.render.MenuAvatarState.resolveItem(avatar.rightHandItemState,
                        artifactStack, ItemDisplayContext.THIRD_PERSON_RIGHT_HAND, null, avatar.id);
                avatar.rightHandItemStack=artifactStack;
            } else if(!mannequin && sword != null){
                ItemStack stack=sword.stack();
                if(!stack.isEmpty()){
                    dev.lin.client.cosmetics.render.MenuAvatarState.resolveItem(avatar.rightHandItemState,
                            stack, ItemDisplayContext.THIRD_PERSON_RIGHT_HAND, null, avatar.id);
                    avatar.rightHandItemStack=stack;
                }
            }
            state=avatar;
        }else{
        try {
            for (EquipmentSlot slot : ISOLATED_EQUIPMENT_SLOTS) {
                originalEquipment.put(slot, entity.getItemBySlot(slot));
                entity.setItemSlot(slot, ItemStack.EMPTY);
            }
            if (!mannequin && armor != null) {
                for (EquipmentSlot slot : PREVIEW_ARMOR_SLOTS) {
                    PreviewArmorMaterial material = armor.getOrDefault(slot,
                            PreviewArmorMaterial.NONE);
                    ItemStack stack = material.stack(slot);
                    if (!stack.isEmpty()) entity.setItemSlot(slot, stack);
                }
            }
            if (!mannequin && artifactMode == ArtifactSkins.PreviewMode.ELYTRA) {
                entity.setItemSlot(EquipmentSlot.CHEST,
                        ArtifactSkins.wornPreviewStack(artifactPreview));
            } else if (!mannequin && artifactMode != null
                    && artifactMode != ArtifactSkins.PreviewMode.HEAD) {
                entity.setItemSlot(EquipmentSlot.MAINHAND, artifactStack);
            } else if (!mannequin && sword != null) {
                ItemStack stack = sword.stack();
                if (!stack.isEmpty()) entity.setItemSlot(EquipmentSlot.MAINHAND, stack);
            }
            state = renderer.createRenderState(entity, 1);
        } finally {
            for (EquipmentSlot slot : ISOLATED_EQUIPMENT_SLOTS) {
                ItemStack original = originalEquipment.get(slot);
                if (original != null) entity.setItemSlot(slot, original);
            }
        }
        }
        state.lightCoords = 15728880;
        state.shadowPieces.clear();
        state.outlineColor = 0;
        state.nameTag = null;
        if (state instanceof AvatarRenderState avatar && previewOutfit != null) {
            CosmeticWorldRenderer.setPreviewOutfit(avatar, previewOutfit);
            if (headwear != null) {
                Minecraft minecraft = Minecraft.getInstance();
                dev.lin.client.cosmetics.render.MenuAvatarState.resolveItem(avatar.headItem,
                        AccessoryItemModels.stack(headwear), ItemDisplayContext.HEAD,
                        entity, avatar.id);
            }
            if (trimPreview != null) {
                avatar.headEquipment = trimPreview.helmet();
                avatar.chestEquipment = trimPreview.chestplate();
                avatar.legsEquipment = trimPreview.leggings();
                avatar.feetEquipment = trimPreview.boots();
            }
            if (artifactMode == ArtifactSkins.PreviewMode.HEAD) {
                Minecraft minecraft = Minecraft.getInstance();
                dev.lin.client.cosmetics.render.MenuAvatarState.resolveItem(avatar.headItem,
                        artifactStack, ItemDisplayContext.HEAD, entity, avatar.id);
                avatar.headEquipment = ItemStack.EMPTY;
            }
            applyArtifactPreviewPose(avatar, artifactMode);
            AccessoryWorldRenderer.registerPreviewWing(avatar.id, wings);
            if (mannequin) {
                PlayerSkin skin = avatar.skin;
                ClientAsset.ResourceTexture body = new ClientAsset.ResourceTexture(
                        MANNEQUIN_SKIN, MANNEQUIN_SKIN);
                avatar.skin = new PlayerSkin(body, skin.cape(), skin.elytra(),
                        skin.model(), true);
                if (capeTexture != null) {
                    CosmeticWorldRenderer.setPreviewCape(avatar, capeTexture);
                }
            }
        }
        if (state instanceof LivingEntityRenderState living) {
            living.bodyRot = 180 + yaw;
            living.yRot = 0;
            living.xRot = 0;
            living.boundingBoxWidth /= living.scale;
            living.boundingBoxHeight /= living.scale;
            living.scale = 1;
        }
        if (display == CardDisplay.PLAYER_PREVIEW && state instanceof AvatarRenderState avatar) {
            // Natural 3/4 striding showcase pose, independent of crouching/flying/riding in the world.
            avatar.isCrouching = avatar.isFallFlying = avatar.isVisuallySwimming = avatar.isPassenger = false;
            avatar.swimAmount = 0;
            avatar.walkAnimationPos = 1.15F;
            avatar.walkAnimationSpeed = 0.42F;
            avatar.yRot = -10.0F;
            avatar.xRot = 3.5F;
            avatar.shouldApplyFlyingYRot = false;
            avatar.bedOrientation = null;
            avatar.pose = net.minecraft.world.entity.Pose.STANDING;
        }
        Quaternionf displayRotation = display == null
                ? new Quaternionf() : display.rotation();
        Quaternionf camera = new Quaternionf(displayRotation).conjugate();
        Quaternionf orientation = new Quaternionf().rotateZ((float) Math.PI)
                .mul(displayRotation);
        // Lunar applies its display offset before model scaling. Moving the PIP
        // rectangle would crop the model before the offset is applied, so convert
        // the native pixel offset back to model-space inside the fixed card texture.
        float inverseScale = scale == 0 ? 0 : 1.0F / scale;
        Vector3f center = new Vector3f(offsetX * inverseScale,
                state.boundingBoxHeight / 2 + 0.0625F + offsetY * inverseScale, 0);
        if (display == CardDisplay.PLAYER_PREVIEW) {
            var framing = LockerPreviewFraming.bounds(orientation, yaw, previewOutfit);
            scale = framing.scale(scale, right - left, bottom - top);
            center = framing.translation().add((float) offsetX / scale, (float) offsetY / scale, 0);
        }
        graphics.submitEntityRenderState(state, scale, center, orientation, camera,
                left, top, right, bottom);
    }

    private static void applyArtifactPreviewPose(AvatarRenderState avatar,
                                                  ArtifactSkins.PreviewMode mode) {
        if (mode == null || mode == ArtifactSkins.PreviewMode.HEAD
                || mode == ArtifactSkins.PreviewMode.ELYTRA) {
            return;
        }
        HumanoidModel.ArmPose pose = switch (mode) {
            case TWO_HAND_BOW -> HumanoidModel.ArmPose.BOW_AND_ARROW;
            case TWO_HAND_CROSSBOW, TWO_HAND_ITEM ->
                    HumanoidModel.ArmPose.CROSSBOW_HOLD;
            case TRIDENT -> HumanoidModel.ArmPose.THROW_TRIDENT;
            default -> HumanoidModel.ArmPose.ITEM;
        };
        if (avatar.mainArm == HumanoidArm.LEFT) {
            avatar.leftArmPose = pose;
            avatar.rightArmPose = HumanoidModel.ArmPose.EMPTY;
        } else {
            avatar.rightArmPose = pose;
            avatar.leftArmPose = HumanoidModel.ArmPose.EMPTY;
        }
    }


    private static boolean inside(double x, double y, int left, int top,
                                  int width, int height) {
        return x >= left && x < left + width && y >= top && y < top + height;
    }

    private double toLocalX(double x) {
        var shell=ClientShell.layout(width,height);
        if(shell.localX(x)>=ClientShell.WIDTH+ClientShell.RAIL_GAP){var l=previewLayout();return l.localX(x);}
        return (x-originX)/uiScale;
    }
    private double toLocalY(double x,double y) {
        var shell=ClientShell.layout(width,height);
        if(shell.localX(x)>=ClientShell.WIDTH+ClientShell.RAIL_GAP)return previewLayout().localY(y);
        return (y-originY)/uiScale;
    }
    private int toScreenX(int x) { return Math.round(originX + x * uiScale); }
    private int toScreenY(int y) { return Math.round(originY + y * uiScale); }
    private static int armorButtonsX() {
        return PREVIEW_X + (PREVIEW_W - (5 * ARMOR_BUTTON_SIZE + 4 * ARMOR_BUTTON_GAP)) / 2;
    }
    private static int swordButtonX() { return armorButtonsX() + 4 * (ARMOR_BUTTON_SIZE + ARMOR_BUTTON_GAP); }
    private static int externalVariantX() {
        return PREVIEW_X + PREVIEW_W - EXTERNAL_VARIANT_SIZE - 16;
    }

    private int previewRenderScale(int preferredScale) {
        float fittedScale=Math.min(preferredScale,(previewStageBottom()-previewStageTop())/2.3f);
        return Math.max(1,Math.round(fittedScale*uiScale*clampFloat(previewPresence.value(),.94f,1.02f)));
    }

    private int previewEntityScale() {
        boolean wide=isWingSection();
        for(CosmeticDefinition item:previewOutfit())
            if(item.category()==CosmeticCategory.DRAGON_WINGS||item.category()==CosmeticCategory.COMPANION)wide=true;
        if(wide)return 158;
        if(section==LockerSection.PETS||section==LockerSection.COMPANIONS)return 168;
        if(section==LockerSection.HEADWEAR)return 174;
        return 180;
    }

    private int previewContainerFill() {
        return ClientShell.control();
    }
    private int rows(int count) {
        int columns = section == LockerSection.HEADWEAR ? HEADWEAR_COLUMNS : COLUMNS;
        return (count + columns - 1) / columns;
    }
    private boolean isWingSection() { return section == LockerSection.WINGS || section == LockerSection.LUNAR_WINGS; }
    private boolean hasSubTabs() { return section != LockerSection.ARTIFACT_SKINS && section != LockerSection.ARMOR_TRIMS; }
    private int cardTop() { return isWingSection() || isPetSection() || isMiscSection() ? HEADWEAR_TOP : CARD_TOP; }
    private int cardRows() { return VISIBLE_ROWS; }
    private int rowStep() { return hasSubTabs() ? ROW_STEP : 544; }
    private int cardHeight() { return hasSubTabs() ? CARD_H : 516; }
    private int cardPreviewHeight() { return cardHeight() - 170; }
    private int maxScroll(int count) { return Math.max(0, rows(count) - cardRows()); }
    private static int skinMaxScroll(int count) {
        return Math.max(0, (count + COLUMNS - 1) / COLUMNS
                - CAPE_VISIBLE_ROWS);
    }
    private static int maxFitScroll(int count) {
        int rows = (count + FIT_COLUMNS - 1) / FIT_COLUMNS;
        return Math.max(0, rows - FIT_VISIBLE_ROWS);
    }
    private static int clamp(int value, int min, int max) { return Math.max(min, Math.min(max, value)); }
    private static float clampFloat(float value, float min, float max) {
        return Math.max(min, Math.min(max, value));
    }

    private static float normalizeDegrees(float value) {
        float normalized = value % 360;
        if (normalized > 180) normalized -= 360;
        if (normalized < -180) normalized += 360;
        return normalized;
    }

    private String truncate(String value, float size, float maxWidth) {
        if (FontManager.widthRegular(value,bodyFont(size)) <= maxWidth) return value;
        String current = value;
        while (!current.isEmpty()
                && FontManager.widthRegular(current + "...",bodyFont(size)) > maxWidth) {
            current = current.substring(0, current.length() - 1);
        }
        return current + "...";
    }

    private static void drawHeadwearIcon(GuiGraphics graphics,
                                         AccessoryDefinition definition,
                                         int x, int y, int size) {
        drawHeadwearIcon(graphics, definition,
                AccessoryRegistry.headwearVariant(definition), x, y, size);
    }

    private static void drawHeadwearIcon(GuiGraphics graphics,
                                         AccessoryDefinition definition,
                                         HeadwearVariant variant,
                                         int x, int y, int size) {
        Minecraft minecraft = Minecraft.getInstance();
        Matrix3x2fStack pose = graphics.pose();
        pose.pushMatrix();
        try {
            float scale = size / 16.0F;
            pose.translate(x, y);
            pose.scale(scale, scale);
            ItemStack stack = AccessoryItemModels.stack(definition, variant);
            if (minecraft.player == null) {
                graphics.renderItem(stack, 0, 0, definition.customModelData());
            } else {
                graphics.renderItem(minecraft.player, stack, 0, 0,
                        definition.customModelData());
            }
        } finally {
            pose.popMatrix();
        }
    }

    private static void drawArtifactIcon(GuiGraphics graphics,
                                         ArtifactSkins.Option option,
                                         int x, int y, int size) {
        Minecraft minecraft = Minecraft.getInstance();
        Matrix3x2fStack pose = graphics.pose();
        pose.pushMatrix();
        try {
            float scale = size / 16.0F;
            pose.translate(x, y);
            pose.scale(scale, scale);
            ItemStack stack = ArtifactSkins.previewStack(option);
            if (minecraft.player == null) {
                graphics.renderItem(stack, 0, 0, option.seed());
            } else {
                graphics.renderItem(minecraft.player, stack, 0, 0, option.seed());
            }
        } finally {
            pose.popMatrix();
        }
    }

    private static Identifier trimPatternTexture(String pattern) {
        int split = pattern.indexOf(':');
        String path = split >= 0 ? pattern.substring(split + 1) : pattern;
        return Identifier.fromNamespaceAndPath("civilization",
                "textures/item/cosmetics/trim_template/" + path + ".png");
    }

    private static ItemStack trimMaterialIcon(String value) {
        return new ItemStack(switch (value == null ? "" : value) {
            case "gold" -> Items.GOLD_INGOT;
            case "iron" -> Items.IRON_INGOT;
            case "diamond" -> Items.DIAMOND;
            case "netherite" -> Items.NETHERITE_INGOT;
            case "redstone" -> Items.REDSTONE;
            case "copper" -> Items.COPPER_INGOT;
            case "emerald" -> Items.EMERALD;
            case "lapis" -> Items.LAPIS_LAZULI;
            case "quartz" -> Items.QUARTZ;
            case "amethyst" -> Items.AMETHYST_SHARD;
            case "resin" -> Items.RESIN_CLUMP;
            default -> Items.BARRIER;
        });
    }

    private static String trimMaterialName(String value) {
        return switch (value == null ? "" : value) {
            case "gold" -> "金";
            case "iron" -> "铁";
            case "diamond" -> "钻石";
            case "netherite" -> "下界合金";
            case "redstone" -> "红石";
            case "copper" -> "铜";
            case "emerald" -> "绿宝石";
            case "lapis" -> "青金石";
            case "quartz" -> "石英";
            case "amethyst" -> "紫水晶";
            case "resin" -> "树脂";
            default -> value == null ? "" : value;
        };
    }

    private static Identifier uiTexture(String name) {
        return Identifier.fromNamespaceAndPath(LinClient.MOD_ID,
                "textures/ui/lunar/" + name + ".png");
    }

    private static void drawTexture(GuiGraphics graphics, Identifier texture,
                                    int x, int y, int width, int height,
                                    int textureWidth, int textureHeight) {
        graphics.blit(RenderPipelines.GUI_TEXTURED, texture, x, y, 0, 0,
                width, height, textureWidth, textureHeight,
                textureWidth, textureHeight);
    }

    /** Lunar's native cosmetic-card display presets from the current 1.21.11 client. */
    private enum CardDisplay {
        DIRECT(0, 0.5F, 0, 0.8F),
        PLAYER_PREVIEW(0, 0.5F, 0, 1.0F,
                axis(-15.5F, 1, 0, 0)),
        DEFAULT(3.8333333F, 0.5F, 0, 0.9F,
                axis(20, 1, 0, 0), axis(-90, 0, 1, 0), axis(135, 0, 1, 0)),
        SUITS(3.8333333F, 0.5F, 0, 0.75F,
                axis(20, 1, 0, 0), axis(-90, 0, 1, 0), axis(135, 0, 1, 0)),
        HAT(3.8333333F, 0.5F, 0.4F, 1.35F,
                axis(20, 1, 0, 0), axis(-90, 0, 1, 0), axis(135, 0, 1, 0)),
        CLOAK(3.8333333F, 0.55F, -0.15F, 1.35F,
                axis(20, 1, 0, 0), axis(135, 0, 1, 0)),
        WING(3.8333333F, 0.6F, 0, 0.8F,
                axis(20, 1, 0, 0), axis(135, 0, 1, 0)),
        SHOES(3.8333333F, 0.5F, -0.75F, 1.6F,
                axis(20, 1, 0, 0), axis(-90, 0, 1, 0), axis(115, 0, 1, 0)),
        BELT(3.8333333F, 0.5F, -0.275F, 1.75F,
                axis(20, 1, 0, 0), axis(-90, 0, 1, 0), axis(115, 0, 1, 0)),
        BUST(3.8333333F, 0.5F, 0.2F, 1.65F,
                axis(20, 1, 0, 0), axis(-90, 0, 1, 0), axis(115, 0, 1, 0)),
        ITEM(3.8333333F, 0.35F, 0, 0.9F, axis(70.5F, 0, 1, 0));

        @SuppressWarnings("unused")
        private final float scaleFactor;
        private final float xOffset;
        private final float yOffset;
        private final float zoom;
        private final AxisRotation[] rotations;

        CardDisplay(float scaleFactor, float xOffset, float yOffset, float zoom,
                    AxisRotation... rotations) {
            this.scaleFactor = scaleFactor;
            this.xOffset = xOffset;
            this.yOffset = yOffset;
            this.zoom = zoom;
            this.rotations = rotations;
        }

        private Quaternionf rotation() {
            Quaternionf result = new Quaternionf();
            for (AxisRotation rotation : rotations) {
                result.rotateAxis((float) Math.toRadians(rotation.degrees),
                        rotation.x, rotation.y, rotation.z);
            }
            return result;
        }

        static CardDisplay forCategory(CosmeticCategory category) {
            return switch (category) {
                case CLOAK, BACKPACK -> CLOAK;
                case HAT, BANDANNA, GLASSES, MASK -> HAT;
                case BODYWEAR, NECKWEAR -> BUST;
                case DRAGON_WINGS -> DIRECT;
                case SHOES -> SHOES;
                case BELTS -> BELT;
                case AURAS -> DIRECT;
                case SUITS -> SUITS;
                case ITEMS -> ITEM;
                case ALL, PET, COMPANION, WRISTWEAR, SHIELDS -> DIRECT;
            };
        }

        private static AxisRotation axis(float degrees, float x, float y, float z) {
            return new AxisRotation(degrees, x, y, z);
        }
    }

    private record AxisRotation(float degrees, float x, float y, float z) {
    }

    private enum TrimFooterDropdown {
        MATERIAL,
        ARMOR
    }

    private enum PreviewArmorMaterial {
        NONE("None", null, null, null, null),
        LEATHER("Leather", Items.LEATHER_HELMET, Items.LEATHER_CHESTPLATE,
                Items.LEATHER_LEGGINGS, Items.LEATHER_BOOTS),
        CHAINMAIL("Chainmail", Items.CHAINMAIL_HELMET, Items.CHAINMAIL_CHESTPLATE,
                Items.CHAINMAIL_LEGGINGS, Items.CHAINMAIL_BOOTS),
        IRON("Iron", Items.IRON_HELMET, Items.IRON_CHESTPLATE,
                Items.IRON_LEGGINGS, Items.IRON_BOOTS),
        GOLD("Gold", Items.GOLDEN_HELMET, Items.GOLDEN_CHESTPLATE,
                Items.GOLDEN_LEGGINGS, Items.GOLDEN_BOOTS),
        DIAMOND("Diamond", Items.DIAMOND_HELMET, Items.DIAMOND_CHESTPLATE,
                Items.DIAMOND_LEGGINGS, Items.DIAMOND_BOOTS),
        NETHERITE("Netherite", Items.NETHERITE_HELMET, Items.NETHERITE_CHESTPLATE,
                Items.NETHERITE_LEGGINGS, Items.NETHERITE_BOOTS);

        private final String label;
        private final Item head;
        private final Item chest;
        private final Item legs;
        private final Item feet;

        PreviewArmorMaterial(String label, Item head, Item chest,
                             Item legs, Item feet) {
            this.label = label;
            this.head = head;
            this.chest = chest;
            this.legs = legs;
            this.feet = feet;
        }

        ItemStack stack(EquipmentSlot slot) {
            Item item = switch (slot) {
                case HEAD -> head;
                case CHEST -> chest;
                case LEGS -> legs;
                case FEET -> feet;
                default -> null;
            };
            return item == null ? ItemStack.EMPTY : new ItemStack(item);
        }
    }

    private enum PreviewSwordMaterial {
        NONE("None", null),
        WOOD("Wood", Items.WOODEN_SWORD),
        STONE("Stone", Items.STONE_SWORD),
        IRON("Iron", Items.IRON_SWORD),
        GOLD("Gold", Items.GOLDEN_SWORD),
        DIAMOND("Diamond", Items.DIAMOND_SWORD),
        NETHERITE("Netherite", Items.NETHERITE_SWORD);

        private final String label;
        private final Item item;

        PreviewSwordMaterial(String label, Item item) {
            this.label = label;
            this.item = item;
        }

        ItemStack stack() {
            return item == null ? ItemStack.EMPTY : new ItemStack(item);
        }
    }

    private enum LockerSection {
        COSMETICS("披风", "披风", "cosmetics", EnumSet.of(CosmeticCategory.CLOAK)),
        PETS("宠物", "宠物", "pet", EnumSet.of(CosmeticCategory.PET)),
        COMPANIONS("陪伴", "陪伴", "companion", EnumSet.of(CosmeticCategory.COMPANION)),
        FLOATING_EFFECTS("漂浮", "漂浮", "auras", EnumSet.of(CosmeticCategory.AURAS)),
        SPAWN_PODS("初始舱", "初始舱皮肤", "armor", 10),
        KILL_EFFECTS("击杀特效", "击杀特效", "auras", 7),
        ARROW_TRAILS("抛物线轨迹", "抛物线轨迹", "auras", 8),
        VIP_ICONS("身份图标", "身份图标", "headwear", 9),
        LUNAR_WINGS("翅膀", "翅膀", "wings", EnumSet.of(CosmeticCategory.DRAGON_WINGS)),
        HEADWEAR("头饰", "头饰", "headwear", 1),
        WINGS("翅膀", "翅膀", "wings", 3),
        ARMOR_TRIMS("盔甲纹饰", "盔甲纹饰", "armor", 4),
        ARTIFACT_SKINS("神器皮肤", "神器皮肤", "item", 5);

        private static final LockerSection ALL = COSMETICS;
        private final String label;
        private final String topLabel;
        private final String icon;
        private final Set<CosmeticCategory> categories;
        private final int externalPage;

        LockerSection(String label, String topLabel, String icon,
                      Set<CosmeticCategory> categories) {
            this.label = label;
            this.topLabel = topLabel;
            this.icon = icon;
            this.categories = categories;
            this.externalPage = -1;
        }

        LockerSection(String label, String topLabel, String icon, int externalPage) {
            this.label = label;
            this.topLabel = topLabel;
            this.icon = icon;
            this.categories = EnumSet.noneOf(CosmeticCategory.class);
            this.externalPage = externalPage;
        }

        boolean contains(CosmeticDefinition definition) {
            return isVisibleCosmetic(definition)
                    && categories.contains(definition.category());
        }

        int count() {
            if(this==SPAWN_PODS)return PodSkins.ALL.size();
            if (this == LUNAR_WINGS) return LunarCatalog.category(CosmeticCategory.DRAGON_WINGS).size()
                    + AccessoryRegistry.values(AccessorySlot.WINGS).size();
            if (this == VIP_ICONS) return dev.lin.client.cosmetics.vip.VipIcons.ALL.size() - 1;
            if (this == ARROW_TRAILS) return 5;
            if (this == KILL_EFFECTS) return KillEffectPreview.values().length;
            if (this == FLOATING_EFFECTS) {
                return LunarCatalog.category(CosmeticCategory.AURAS).size()
                        + AccessoryRegistry.values(AccessorySlot.FLOATING).size();
            }
            if (externalPage == 1) {
                return AccessoryRegistry.visibleHeadwear().size();
            }
            if (externalPage == 3) {
                return AccessoryRegistry.values(AccessorySlot.WINGS).size();
            }
            if (externalPage == 4) {
                return LinTrimManager.PATTERNS.size();
            }
            if (externalPage == 5 || externalPage == 6) {
                return ArtifactSkins.visibleArtifacts().size();
            }
            int result = 0;
            for (CosmeticCategory category : categories) {
                if (category != CosmeticCategory.ALL) result += LunarCatalog.category(category).size();
            }
            return result;
        }

        LockerSection navigationEntry() { return this == WINGS ? LUNAR_WINGS : this; }
        String topLabel() {
            if (!ClientShell.isEnglish()) return topLabel;
            return switch (this) {
                case COSMETICS -> "Capes";
                case PETS -> "Pets";
                case COMPANIONS -> "Companions";
                case FLOATING_EFFECTS -> "Floating";
                case SPAWN_PODS -> "Spawn Pods";
                case KILL_EFFECTS -> "Kill Effects";
                case ARROW_TRAILS -> "Arrow Trails";
                case VIP_ICONS -> "VIP Icons";
                case LUNAR_WINGS, WINGS -> "Wings";
                case HEADWEAR -> "Headwear";
                case ARMOR_TRIMS -> "Armor Trims";
                case ARTIFACT_SKINS -> "Artifact Skins";
            };
        }

        boolean isExternal() { return externalPage >= 0; }
    }
}
