package dev.lin.client.cosmetics.ui;

import com.mojang.blaze3d.vertex.PoseStack;
import dev.lin.client.features.render.AccessoryItemModels;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.entity.state.AvatarRenderState;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.tags.ItemTags;
import org.joml.Quaternionf;
import org.joml.Vector3f;

/** The self HUD uses the equipped HEAD model, not its inventory thumbnail. */
public final class SelfInfoHeadPortrait {
    public static final int PREVIEW_ID = -7_800_080;
    private static final float[] HEAD_BOUNDS = headBounds();
    private static final CachedHead SELF = new CachedHead(), TARGET = new CachedHead();
    public static void clear() { SELF.clear(); TARGET.clear(); }
    private SelfInfoHeadPortrait() {}
    private static float[] headBounds() {
        PoseStack pose = new PoseStack();
        pose.scale(-0.9375F, -0.9375F, 0.9375F);
        pose.translate(0, -1.501F, 0);
        float[] bounds = {Float.POSITIVE_INFINITY, Float.POSITIVE_INFINITY,
                Float.NEGATIVE_INFINITY, Float.NEGATIVE_INFINITY};
        for (float px : new float[]{-0.28125F, 0.28125F})
            for (float py : new float[]{-0.53125F, -0.10F})
                include(bounds, new Vector3f(px, py, 0).mulPosition(pose.last().pose()));
        return bounds;
    }


    public static boolean enabled(Object entity, boolean self) {
        if (!(entity instanceof AbstractClientPlayer player)) return false;
        ItemStack original = player.getItemBySlot(EquipmentSlot.HEAD);
        return self ? AccessoryItemModels.hasNametagHead(original, true) : !original.isEmpty();
    }

    public static boolean enabledCard(Object entity, Object state, Object selfState) {
        return enabled(entity, state == selfState);
    }

    public static void render(Object graphicsObject, Object entityObject,
                              float x, float y, float hudScale, float portraitScale, boolean selfCard) {
        Minecraft mc = Minecraft.getInstance();
        if (!(entityObject instanceof AbstractClientPlayer player)) return;
        boolean self = player == mc.player;
        ItemStack headwear = portraitHead(player, self);
        if (headwear.isEmpty()) return;
        GuiGraphics graphics = (GuiGraphics) graphicsObject;
        // Pose and equipment models are resolved only when the image signature changes.
        HeadPortraitRenderState state = (selfCard ? SELF : TARGET).get(player, headwear);
        state.selfCard = selfCard;

        // Size from the head, not the accessory. Oversized headwear is clipped by
        // the portrait viewport instead of shrinking the player's face.
        float[] bounds = HEAD_BOUNDS;
        portraitScale = Math.max(0.5F, Math.min(self ? 1.0F : 1.5F, portraitScale));
        float pixels = (self ? 52.0F : 56.0F) * hudScale * portraitScale;
        float scale = pixels / Math.max(bounds[2] - bounds[0], bounds[3] - bounds[1]);
        Vector3f center = new Vector3f((bounds[0] + bounds[2]) * 0.5F,
                (bounds[1] + bounds[3]) * 0.5F, 0);
        int left = Math.round(x + 4 * hudScale);
        int top = Math.round(y + 4 * hudScale);
        int right = Math.round(x + 64 * hudScale);
        int bottom = Math.round(y + 68 * hudScale);
        graphics.enableScissor(left, top, right, bottom);
        try {
            graphics.submitEntityRenderState(state, scale, center,
                    new Quaternionf().rotateZ((float)Math.PI), new Quaternionf(),
                    left, top, right, bottom);
        } finally { graphics.disableScissor(); }
    }

    private static HeadPortraitRenderState create(AbstractClientPlayer player, ItemStack headwear) {
        Minecraft mc = Minecraft.getInstance();
        HeadPortraitRenderState state = new HeadPortraitRenderState();
        state.id = PREVIEW_ID;
        state.entityType = EntityType.PLAYER;
        state.skin = player.getSkin();
        state.showHat = true;
        state.scale = state.ageScale = 1.0F;
        state.bodyRot = 180.0F;
        state.boundingBoxHeight = 1.8F;
        state.boundingBoxWidth = 0.6F;
        state.lightCoords = 15728880;
        // The existing self portrait always used a single-item headwear stack.
        state.portraitHead = headwear.copyWithCount(player == mc.player ? 1 : headwear.getCount());
        // User-authorized HUD snapshot: animated textures and foil freeze in the
        // native portrait surface. World and inventory rendering stay animated.
        state.staticHead = true;
        if (headwear.is(ItemTags.HEAD_ARMOR)) {
            state.headEquipment = state.portraitHead;
        } else {
            mc.getItemModelResolver().updateForTopItem(state.headItem,
                    state.portraitHead, ItemDisplayContext.HEAD, player.level(), null, PREVIEW_ID);
        }

        return state;
    }

    private static ItemStack portraitHead(AbstractClientPlayer player, boolean self) {
        ItemStack original = player.getItemBySlot(EquipmentSlot.HEAD);
        ItemStack source = self ? AccessoryItemModels.nametagHeadSource(original, true) : original;
        return source.is(ItemTags.HEAD_ARMOR) ? source : AccessoryItemModels.replaceDefaultHelmetIcon(source);
    }

    private static final class CachedHead {
        private AbstractClientPlayer owner;
        private long generation;
        private int count;
        private HeadPortraitRenderState state;
        void clear() { owner = null; state = null; }
        HeadPortraitRenderState get(AbstractClientPlayer player, ItemStack headwear) {
            long current = StaticPortraitModels.generation();
            if (owner != player || state == null || generation != current || count != headwear.getCount()
                    || !state.skin.equals(player.getSkin())
                    || !ItemStack.isSameItemSameComponents(state.portraitHead, headwear)) {
                state = create(player, headwear); owner = player; generation = current; count = headwear.getCount();
            }
            return state;
        }
    }

    private static void include(float[] bounds, Vector3f point) {
        bounds[0] = Math.min(bounds[0], point.x);
        bounds[1] = Math.min(bounds[1], point.y);
        bounds[2] = Math.max(bounds[2], point.x);
        bounds[3] = Math.max(bounds[3], point.y);
    }
}
