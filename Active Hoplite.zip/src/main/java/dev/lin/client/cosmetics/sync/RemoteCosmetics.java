package dev.lin.client.cosmetics.sync;

import dev.lin.client.cosmetics.assets.CosmeticAssetManager;
import dev.lin.client.cosmetics.catalog.*;
import dev.lin.client.cosmetics.config.CosmeticConfig;
import dev.lin.client.cosmetics.model.BedrockModelLoader;
import dev.lin.client.features.accessory.*;
import dev.lin.client.features.cape.*;
import dev.lin.client.features.pet.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.entity.state.AvatarRenderState;
import java.util.*;

/** Client-thread visibility and lifetime policy. Rendering only reads these bounded snapshots. */
public final class RemoteCosmetics {
    public record View(AbstractClientPlayer player, CosmeticSyncBridge.Peer peer, boolean animated) {}
    private static Map<UUID,View> views=Map.of();
    private static final Map<UUID,BedrockModelLoader.AnimationContext> motion=new HashMap<>();
    private static final Map<String,AccessoryDefinition> accessories=new HashMap<>();
    private static final Map<String,LunarCape> capes=new HashMap<>();
    private static final Map<String,LunarPet> pets=new HashMap<>();
    private static Object world,connection,lastSnapshot;
    private static boolean indexed;
    private static long nextScan;
    private static int lastQuality=-1;
    public static long epoch;
    private RemoteCosmetics() {}
    private static void index() {
        // A first tick/resource initialization must not permanently cache an empty registry.
        if(indexed && !accessories.isEmpty())return;
        for(var slot:AccessorySlot.values())for(var d:AccessoryRegistry.values(slot))accessories.put(slot.name()+":"+d.id(),d);
        for(var d:LunarCapeRegistry.values())capes.put(d.id(),d);
        for(var d:LunarCapeRegistry.officialValues())capes.put(d.id(),d);
        for(var d:LunarCapeRegistry.dungeonValues())capes.put(d.id(),d);
        for(var d:LunarPetRegistry.values())pets.put(d.id(),d);
        indexed=!accessories.isEmpty();
    }
    public static Collection<View> views(){return views.values();}
    public static AbstractClientPlayer player(AvatarRenderState state){
        var mc=Minecraft.getInstance();
        return mc.level!=null && mc.level.getEntity(state.id) instanceof AbstractClientPlayer p ? p : null;
    }
    public static View view(AvatarRenderState state){
        return view(player(state));
    }
    public static View view(AbstractClientPlayer p){
        if(p==null || p.isInvisible() || p.isSpectator())return null;
        View v=views.get(p.getUUID());
        return v!=null && v.player()==p && CosmeticSyncBridge.remote(p.getUUID())!=null?v:null;
    }
    public static CosmeticSyncBridge.Outfit outfit(AvatarRenderState state){var v=view(state);return v==null?null:v.peer().outfit();}
    public static CosmeticSyncBridge.Outfit outfit(AbstractClientPlayer player){var v=view(player);return v==null?null:v.peer().outfit();}
    public static AccessoryDefinition accessory(CosmeticSyncBridge.Outfit outfit,AccessorySlot slot){
        if(outfit==null)return null;
        String key=switch(slot){case HEADWEAR->"headwear";case WINGS->"wings";case FLOATING->"floating";};
        return accessories.get(slot.name()+":"+outfit.accessories().get(key));
    }
    public static LunarCape cape(String id){return capes.get(id);}
    public static LunarPet pet(String id){return pets.get(id);}
    public static void tick(Minecraft mc){
        index();
        if(world!=mc.level || connection!=mc.getConnection()){
            world=mc.level;connection=mc.getConnection();epoch++;nextScan=0;BedrockModelLoader.resetLocal();
            views=Map.of();motion.clear();RemoteAssetLoader.clear();CosmeticAssetManager.clearRemote();
            dev.lin.client.cosmetics.render.CosmeticWorldRenderer.clearFollowers();
            dev.lin.client.features.render.AccessoryWorldRenderer.clearChannels();
        }
        if(mc.player!=null) updateMotion(mc.player,null);
        Map<UUID,View> next=new LinkedHashMap<>();
        int quality=CosmeticConfig.multiplayerQuality();
        int limit=switch(quality){case 0->16;case 2->48;default->32;};
        int dynamic=switch(quality){case 0->8;case 2->32;default->16;};
        if(mc.level!=null && mc.player!=null && CosmeticConfig.receiveCosmetics()){
            Object snap=CosmeticSyncBridge.snapshot();
            boolean scan=System.nanoTime()>=nextScan || quality!=lastQuality || snap!=lastSnapshot;
            lastSnapshot=snap;
            var nearby=scan?new ArrayList<>(mc.level.players()):new ArrayList<>(views.values().stream().map(View::player).toList());
            nearby.removeIf(p->p==mc.player || p.isInvisible() || p.isSpectator()
                || p.isRemoved() || p.distanceToSqr(mc.player)>64*64 || CosmeticSyncBridge.remote(p.getUUID())==null);
            if(scan){nearby.sort(Comparator.comparingDouble(p->p.distanceToSqr(mc.player)));nextScan=System.nanoTime()+200_000_000L;lastQuality=quality;}
            for(var p:nearby){
                if(next.size()>=limit)break;
                boolean animated=next.size()<dynamic && p.distanceToSqr(mc.player)<=48*48;
                next.put(p.getUUID(),new View(p,CosmeticSyncBridge.remote(p.getUUID()),animated));
                var context=motion.computeIfAbsent(p.getUUID(),ignored->new BedrockModelLoader.AnimationContext());
                updateMotion(p,context);
            }
        }
        views=Collections.unmodifiableMap(next);motion.keySet().retainAll(next.keySet());
        Set<String> capeIds=new LinkedHashSet<>(),petIds=new LinkedHashSet<>(),animatedCapes=new HashSet<>();
        for(var v:views.values()){
            var extras=v.peer().outfit().accessories();
            String cape=extras.get("cape"),pet=extras.get("pet");
            if(cape!=null){capeIds.add(cape);if(v.animated())animatedCapes.add(cape);}
            if(pet!=null)petIds.add(pet);
        }
        LunarCapeTextureManager.remoteTick(capeIds,animatedCapes);
        LunarPetTextureManager.remoteTick(petIds);
        CosmeticAssetManager.remoteTick(views.values(),motion);
    }
    public static void companionSpeed(AbstractClientPlayer player,float speed) {
        if(player==Minecraft.getInstance().player)BedrockModelLoader.updateCompanionMotion(speed);
        else {var context=motion.get(player.getUUID());if(context!=null)BedrockModelLoader.withContext(context,()->BedrockModelLoader.updateCompanionMotion(speed));}
    }
    private static void updateMotion(AbstractClientPlayer p,BedrockModelLoader.AnimationContext context){
        float x=(float)(p.getX()-p.xOld)*20,y=(float)(p.getY()-p.yOld)*20,z=(float)(p.getZ()-p.zOld)*20;
        float speed=(float)Math.hypot(x,z);
        Runnable update=()->BedrockModelLoader.updateWorldMotion(x,y,z,speed,(float)Math.sqrt(x*x+y*y+z*z),
            p.yBodyRot,p.getYRot(),p.yHeadRot,p.getXRot(),p.tickCount,p.getAbilities().flying,p.isFallFlying(),
            p.isSwimming(),p.onGround(),p.isCrouching(),p.isSprinting(),p.isInWater());
        if(context==null)update.run();else BedrockModelLoader.withContext(context,update);
    }
}
