package dev.lin.client.cosmetics.model;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.joml.Vector4f;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.List;

/** Minimal, strict OBJ loader for Lunar's legacy hats and bodywear assets. */
public final class ObjModelLoader {
    private ObjModelLoader() {
    }

    public static CosmeticMesh load(Reader source, JsonObject indexDefinition, boolean gui)
            throws IOException {
        List<Vector3f> positions = new ArrayList<>();
        List<Vector3f> texCoords = new ArrayList<>();
        List<Vector3f> normals = new ArrayList<>();
        List<CosmeticVertex> vertices = new ArrayList<>();
        positions.add(new Vector3f());
        texCoords.add(new Vector3f());
        normals.add(new Vector3f());

        Matrix4f transform = legacyTransform(indexDefinition, gui);
        try (BufferedReader reader = new BufferedReader(source)) {
            String line;
            while ((line = reader.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty() || line.charAt(0) == '#') {
                    continue;
                }
                String[] values = line.split("\\s+");
                switch (values[0]) {
                    case "v" -> positions.add(vector(values, 1));
                    case "vt" -> texCoords.add(vector2(values));
                    case "vn" -> normals.add(vector(values, 1));
                    case "f" -> addFace(vertices, values, positions, texCoords, normals, transform);
                    default -> {
                    }
                }
            }
        }
        if (vertices.isEmpty()) {
            throw new IOException("Legacy Lunar OBJ contains no visible faces");
        }
        return CosmeticMesh.of(vertices.toArray(CosmeticVertex[]::new), 1, 1);
    }

    private static void addFace(List<CosmeticVertex> target, String[] values,
                                List<Vector3f> positions, List<Vector3f> texCoords,
                                List<Vector3f> normals, Matrix4f transform) throws IOException {
        if (values.length < 4) {
            return;
        }
        Corner[] polygon = new Corner[values.length - 1];
        for (int index = 1; index < values.length; index++) {
            String[] fields = values[index].split("/", -1);
            polygon[index - 1] = new Corner(
                    resolve(fields, 0, positions.size()),
                    resolve(fields, 1, texCoords.size()),
                    resolve(fields, 2, normals.size()));
        }
        if (polygon.length == 4) {
            emitQuad(target, polygon[0], polygon[1], polygon[2], polygon[3],
                    positions, texCoords, normals, transform);
            return;
        }
        for (int index = 1; index + 1 < polygon.length; index++) {
            emitQuad(target, polygon[0], polygon[index], polygon[index + 1], polygon[index + 1],
                    positions, texCoords, normals, transform);
        }
    }

    private static void emitQuad(List<CosmeticVertex> target,
                                 Corner a, Corner b, Corner c, Corner d,
                                 List<Vector3f> positions, List<Vector3f> texCoords,
                                 List<Vector3f> normals, Matrix4f transform) throws IOException {
        Corner[] corners = {a, b, c, d};
        Vector3f[] transformed = new Vector3f[4];
        for (int index = 0; index < 4; index++) {
            if (corners[index].position <= 0 || corners[index].position >= positions.size()) {
                throw new IOException("OBJ face references an invalid position");
            }
            Vector3f raw = positions.get(corners[index].position);
            // Lunar's legacy OBJ files were authored directly in Minecraft
            // model coordinates (positive Y points down from the attached bone).
            Vector4f point = transform.transform(new Vector4f(raw.x, raw.y, raw.z, 1.0F));
            transformed[index] = new Vector3f(point.x, point.y, point.z);
        }
        Vector3f faceNormal = new Vector3f(transformed[1]).sub(transformed[0])
                .cross(new Vector3f(transformed[2]).sub(transformed[0]));
        if (faceNormal.lengthSquared() < 1.0E-10F) {
            faceNormal.set(0, 0, 1);
        } else {
            faceNormal.normalize();
        }
        for (int index = 0; index < 4; index++) {
            Corner corner = corners[index];
            Vector3f uv = corner.texture > 0 && corner.texture < texCoords.size()
                    ? texCoords.get(corner.texture) : new Vector3f();
            Vector3f normal = faceNormal;
            if (corner.normal > 0 && corner.normal < normals.size()) {
                Vector3f rawNormal = normals.get(corner.normal);
                Vector4f transformedNormal = transform.transform(
                        new Vector4f(rawNormal.x, rawNormal.y, rawNormal.z, 0.0F));
                if (transformedNormal.x * transformedNormal.x
                        + transformedNormal.y * transformedNormal.y
                        + transformedNormal.z * transformedNormal.z > 1.0E-10F) {
                    normal = new Vector3f(transformedNormal.x, transformedNormal.y,
                            transformedNormal.z).normalize();
                }
            }
            Vector3f point = transformed[index];
            target.add(new CosmeticVertex(point.x, point.y, point.z,
                    uv.x, 1.0F - uv.y, normal.x, normal.y, normal.z));
        }
    }

    private static Matrix4f legacyTransform(JsonObject definition, boolean gui) {
        Matrix4f result = new Matrix4f();
        JsonArray transformations = definition == null ? null
                : definition.getAsJsonArray("transformations");
        if (transformations == null) {
            return result;
        }
        for (JsonElement value : transformations) {
            if (!value.isJsonObject()) {
                continue;
            }
            JsonObject operation = value.getAsJsonObject();
            String type = string(operation, "transformType", "");
            JsonObject parameters = contextual(operation.get("values"), gui);
            if (parameters == null) {
                continue;
            }
            switch (type) {
                case "translate" -> result.translate(
                        number(parameters, "x", 0),
                        number(parameters, "y", 0),
                        number(parameters, "z", 0));
                case "scale" -> result.scale(
                        number(parameters, "x", 1),
                        number(parameters, "y", 1),
                        number(parameters, "z", 1));
                case "rotate" -> {
                    float angle = (float) Math.toRadians(number(parameters, "angle", 0));
                    Vector3f axis = new Vector3f(
                            number(parameters, "x", 0),
                            number(parameters, "y", 0),
                            number(parameters, "z", 0));
                    if (axis.lengthSquared() > 1.0E-8F) {
                        result.rotate(angle, axis.normalize());
                    }
                }
                default -> {
                }
            }
        }
        return result;
    }

    private static JsonObject contextual(JsonElement value, boolean gui) {
        if (value == null || !value.isJsonObject()) {
            return null;
        }
        JsonObject object = value.getAsJsonObject();
        String context = gui ? "gui" : "player";
        if (object.has(context) && object.get(context).isJsonObject()) {
            return object.getAsJsonObject(context);
        }
        if (object.has("x") || object.has("angle")) {
            return object;
        }
        for (String fallback : new String[]{"player", "gui", "skin_layer", "helmet", "chestplate"}) {
            if (object.has(fallback) && object.get(fallback).isJsonObject()) {
                return object.getAsJsonObject(fallback);
            }
        }
        return null;
    }

    private static int resolve(String[] fields, int field, int size) {
        if (field >= fields.length || fields[field].isEmpty()) {
            return 0;
        }
        int value = Integer.parseInt(fields[field]);
        return value < 0 ? size + value : value;
    }

    private static Vector3f vector(String[] values, int offset) {
        return new Vector3f(number(values, offset), number(values, offset + 1),
                number(values, offset + 2));
    }

    private static Vector3f vector2(String[] values) {
        return new Vector3f(number(values, 1), number(values, 2), 0);
    }

    private static float number(String[] values, int index) {
        return index < values.length ? Float.parseFloat(values[index]) : 0;
    }

    private static float number(JsonObject object, String key, float fallback) {
        return object.has(key) && object.get(key).isJsonPrimitive()
                ? object.get(key).getAsFloat() : fallback;
    }

    private static String string(JsonObject object, String key, String fallback) {
        return object.has(key) && object.get(key).isJsonPrimitive()
                ? object.get(key).getAsString() : fallback;
    }

    private record Corner(int position, int texture, int normal) {
    }
}
