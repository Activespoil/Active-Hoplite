package dev.lin.client.cosmetics.font;

import com.mojang.blaze3d.platform.NativeImage;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.resources.Identifier;
import org.joml.Matrix3x2fStack;

import java.awt.Font;
import java.awt.font.FontRenderContext;
import java.awt.geom.AffineTransform;
import java.awt.geom.Rectangle2D;
import java.io.InputStream;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;

/** Shared pages use settings-font GPU glyphs; legacy callers retain their raster path. */
public final class FontManager {
    private static final int PADDING = 2;
    private static final int RASTER_SCALE = 4;
    private static final int MAX_CACHED_LINES = 1024;
    private static final FontRenderContext FONT_CONTEXT = new FontRenderContext(
            new AffineTransform(), true, true);
    private static final Map<TextKey, TextLine> LINES = new LinkedHashMap<>(128,
            0.75F, true);
    private static final AtomicLong NEXT_TEXTURE = new AtomicLong();

    private static Font latinFace;
    private static Font latinRegularFace;
    private static Font cjkFace;
    private static Font cjkRegularFace;
    private static Font fallbackFace;
    private static Font fallbackRegularFace;

    private FontManager() {
    }

    public static float draw(GuiGraphics graphics, String text, float x, float y,
                             float size, int color) {
        return draw(graphics, text, x, y, size, color, true);
    }

    public static float drawRegular(GuiGraphics graphics, String text, float x, float y,
                                    float size, int color) {
        return draw(graphics, text, x, y, size, color, false);
    }

    private static float draw(GuiGraphics graphics, String text, float x, float y,
                              float size, int color, boolean bold) {
        if (text == null || text.isEmpty()) return 0;
        if (SharedScreenText.active()) {
            return SharedScreenText.draw(graphics, text, x, y, size, color);
        }
        TextLine line = line(text, size, color, bold);
        Matrix3x2fStack pose = graphics.pose();
        pose.pushMatrix();
        try {
            pose.translate(x - PADDING, y - PADDING - (uiSize(size) - size) / 2f);
            pose.scale(1.0F / RASTER_SCALE, 1.0F / RASTER_SCALE);
            graphics.blit(RenderPipelines.GUI_TEXTURED, line.texture(), 0, 0,
                    0, 0, line.width(), line.height(), line.width(), line.height());
        } finally {
            pose.popMatrix();
        }
        return line.advance();
    }

    public static float width(String text, float size) {
        return measure(text, size, true);
    }

    public static float widthRegular(String text, float size) {
        return measure(text, size, false);
    }

    private static float uiSize(float size) { return SharedScreenText.active() ? size : size < 11 ? size + 3.5f : size; }

    private static float measure(String text, float size, boolean bold) {
        if (text == null || text.isEmpty()) return 0;
        if (SharedScreenText.active()) return SharedScreenText.width(text,size);
        Font font = face(text, bold).deriveFont(Math.max(1.0F, uiSize(size)) * RASTER_SCALE);
        return (float) (font.getStringBounds(text, FONT_CONTEXT).getWidth()
                / RASTER_SCALE);
    }

    private static synchronized TextLine line(String text, float size, int color,
                                              boolean bold) {
        int sizeQuarter = Math.max(4, Math.round(uiSize(size) * 4));
        TextKey key = new TextKey(text, sizeQuarter, color, bold, SharedScreenText.active());
        TextLine cached = LINES.get(key);
        if (cached != null) return cached;

        float logicalSize = sizeQuarter / 4.0F;
        int padding = PADDING * RASTER_SCALE;
        int width,height;float advance;NativeImage nativeImage;
        Font font = face(text, bold).deriveFont(logicalSize * RASTER_SCALE);
        Rectangle2D bounds = font.getStringBounds(text, FONT_CONTEXT);
        width = Math.max(1, (int) Math.ceil(bounds.getWidth()) + padding * 2);
        height = Math.max(1, (int) Math.ceil(bounds.getHeight()) + padding * 2);
        java.awt.Shape outline = font.createGlyphVector(FONT_CONTEXT, text).getOutline(
                (float) (padding - bounds.getX()), (float) (padding - bounds.getY()));
        nativeImage=dev.lin.client.cosmetics.render.SkijaUiRaster.text(outline,width,height,color);
        advance=(float)bounds.getWidth()/RASTER_SCALE;

        Identifier texture = Identifier.fromNamespaceAndPath("lin_client",
                "dynamic_font/line_" + Long.toUnsignedString(
                        NEXT_TEXTURE.incrementAndGet(), 36));
        DynamicTexture dynamic = new DynamicTexture(() -> "Lin Client text", nativeImage) {
            @Override public com.mojang.blaze3d.textures.GpuSampler getSampler() {
                return key.shared() ? com.mojang.blaze3d.systems.RenderSystem.getSamplerCache()
                        .getClampToEdge(com.mojang.blaze3d.textures.FilterMode.LINEAR) : super.getSampler();
            }
        };
        Minecraft.getInstance().getTextureManager().register(texture, dynamic);
        TextLine created = new TextLine(texture, width, height,
                advance);
        LINES.put(key, created);
        trimCache();
        return created;
    }

    private static void trimCache() {
        Iterator<Map.Entry<TextKey, TextLine>> iterator = LINES.entrySet().iterator();
        while (LINES.size() > MAX_CACHED_LINES && iterator.hasNext()) {
            TextLine removed = iterator.next().getValue();
            iterator.remove();
            Minecraft.getInstance().getTextureManager().release(removed.texture());
        }
    }

    private static Font face(String text, boolean bold) {
        Font preferred;
        if (bold) {
            if (latinFace == null) latinFace = loadFont("harmony.ttf");
            preferred = latinFace;
        } else {
            if (latinRegularFace == null) latinRegularFace = loadFont("harmony.ttf");
            preferred = latinRegularFace;
        }
        if (preferred.canDisplayUpTo(text) < 0) return preferred;

        Font noto;
        if (bold) {
            if (cjkFace == null) cjkFace = loadFont("harmony.ttf")
                    .deriveFont(Font.BOLD);
            noto = cjkFace;
        } else {
            if (cjkRegularFace == null) {
                cjkRegularFace = loadFont("harmony.ttf")
                        .deriveFont(Font.PLAIN);
            }
            noto = cjkRegularFace;
        }
        if (noto.canDisplayUpTo(text) < 0) return noto;

        // A few Lunar UI marks (notably vertical ellipsis and chevrons) are
        // outside both bundled faces. Java's logical Dialog face delegates
        // those glyphs to Segoe UI Symbol while normal text stays Roboto.
        if (bold) {
            if (fallbackFace == null) fallbackFace = new Font("Dialog", Font.BOLD, 1);
            return fallbackFace;
        }
        if (fallbackRegularFace == null) {
            fallbackRegularFace = new Font("Dialog", Font.PLAIN, 1);
        }
        return fallbackRegularFace;
    }

    private static Font loadFont(String name) {
        try (InputStream stream = FontManager.class.getResourceAsStream(
                "/assets/lin_client/font/" + name)) {
            if (stream == null) throw new IllegalStateException(name + " is missing");
            return Font.createFont(Font.TRUETYPE_FONT, stream);
        } catch (Exception exception) {
            throw new IllegalStateException("Unable to load " + name, exception);
        }
    }

    public static synchronized void close() {
        SharedScreenText.close();
        for (TextLine line : LINES.values()) {
            Minecraft.getInstance().getTextureManager().release(line.texture());
        }
        LINES.clear();
        latinFace = null;
        latinRegularFace = null;
        cjkFace = null;
        cjkRegularFace = null;
        fallbackFace = null;
        fallbackRegularFace = null;
    }

    private record TextLine(Identifier texture, int width, int height,
                            float advance) {
    }

    private record TextKey(String text, int sizeQuarter, int color, boolean bold, boolean shared) {
    }
}
