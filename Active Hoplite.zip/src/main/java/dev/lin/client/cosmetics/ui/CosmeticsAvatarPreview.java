package dev.lin.client.cosmetics.ui;

import dev.lin.client.cosmetics.emote.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.entity.state.AvatarRenderState;
import net.minecraft.client.resources.DefaultPlayerSkin;
import net.minecraft.core.ClientAsset;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.player.PlayerSkin;
import org.joml.Quaternionf;
import org.joml.Vector3f;
import java.util.function.Supplier;

/** Isolated render states: never changes equipment, yaw, or pose on the live player. */
public final class CosmeticsAvatarPreview {
    private final Supplier<PlayerSkin> skin;
    public CosmeticsAvatarPreview() {
        Minecraft client = Minecraft.getInstance();
        skin = client.getSkinManager().createLookup(client.getGameProfile(), false);
    }
    public void draw(GuiGraphics g, int left, int top, int right, int bottom, int scale,
                     float yaw, EmoteCatalog.Action action, float frame, Identifier cape, int previewId) {
        if (right <= left || bottom <= top) return;
        Minecraft client = Minecraft.getInstance();
        AvatarRenderState state = new AvatarRenderState();
        PlayerSkin lookedUp = skin.get();
        PlayerSkin actual = lookedUp == null ? DefaultPlayerSkin.get(client.getGameProfile()) : lookedUp;
        ClientAsset.ResourceTexture capeAsset = cape == null ? null : new ClientAsset.ResourceTexture(cape, cape);
        state.skin = new PlayerSkin(actual.body(), capeAsset, capeAsset, actual.model(), actual.secure());
        state.entityType = EntityType.PLAYER;
        state.boundingBoxWidth = .6f; state.boundingBoxHeight = 1.8f; state.eyeHeight = 1.62f;
        state.scale = 1; state.bodyRot = 180 + yaw; state.yRot = 0; state.xRot = 0;
        state.id = Integer.MIN_VALUE + 9000 + previewId;
        state.mainArm = HumanoidArm.RIGHT;
        state.showHat = state.showJacket = state.showLeftPants = state.showRightPants = true;
        state.showLeftSleeve = state.showRightSleeve = true;
        state.showCape = cape != null;
        state.lightCoords = 15728880;
        if (action != null) ((EmoteRenderState)state).linEmoteSample(new EmoteRuntime.Sample(action, frame, 1));
        g.submitEntityRenderState(state, Math.max(1, scale),
                new Vector3f(0, state.boundingBoxHeight/2+.0625f, 0),
                new Quaternionf().rotateZ((float)Math.PI), new Quaternionf(),
                left, top, right, bottom);
    }
}
