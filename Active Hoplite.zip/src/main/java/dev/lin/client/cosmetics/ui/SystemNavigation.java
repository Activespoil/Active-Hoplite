package dev.lin.client.cosmetics.ui;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/** Shared cosmetics routing: keeps screen navigation inside ClientPageHost. */
public final class SystemNavigation {
    private static final Logger LOGGER = LoggerFactory.getLogger(SystemNavigation.class);
    public static final int COSMETICS = 2;
    private static Screen returnTo;
    private SystemNavigation() {}
    public static void begin(Screen parent) {
        if(!ClientFeaturePolicy.canOpenFeatures())return;
        returnTo = parent;
        open(COSMETICS);
    }
    public static void prepare(Screen parent) { if(!(Minecraft.getInstance().screen instanceof ClientPageHost))returnTo=parent; }
    public static void openFrom(Screen parent,int system){prepare(parent);open(system);}
    private static Screen adopted;
    public static Screen activeScreen(){Screen current=Minecraft.getInstance().screen;return current instanceof ClientPageHost host?host.activePage():current;}
    public static boolean isActive(Screen page){return activeScreen()==page;}
    public static boolean retaining(Screen page){return adopted==page;}
    public static Screen returnScreen(Screen page){Screen current=Minecraft.getInstance().screen;return current instanceof ClientPageHost host&&host.contains(page)?host:page;}
    static int pageId(Screen page){
        return page instanceof CosmeticLockerScreen ? COSMETICS : -1;
    }
    private static void route(int system){
        if(!ClientFeaturePolicy.canOpenFeatures())return;
        Minecraft client=Minecraft.getInstance();Screen current=client.screen;
        ClientPageHost host=current instanceof ClientPageHost existing?existing:new ClientPageHost(returnTo,pageId(current)>=0?current:null);
        Screen parent=host.returnTarget();
        try{
            Screen next=host.page(COSMETICS);
            if(next==null){
                next=new CosmeticLockerScreen(parent);
            }
            host.show(COSMETICS,next);
            if(current!=host){adopted=current;try{client.setScreen(host);}finally{adopted=null;}}
        }catch(RuntimeException e){
            LOGGER.error("Unable to open Lin Cosmetics locker {}",system,e);
            if(client.screen==host&&current!=host){host.removed();client.setScreen(current);}
        }
    }
    public static void open(int system) { route(system); }
    public static void draw(Object context, int current, int mx, int my) {}
    public static boolean click(int current, double x, double y, int button) {
        return false;
    }
}

