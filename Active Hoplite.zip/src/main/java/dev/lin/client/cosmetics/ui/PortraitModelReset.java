/*
 * Decompiled with CFR 0.152.
 */
package dev.lin.client.cosmetics.ui;

public interface PortraitModelReset {
    public void lin$restorePortraitModel();
}

