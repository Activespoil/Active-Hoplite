package dev.lin.client.cosmetics.sync;

import java.io.*;
import java.net.http.*;
import java.time.Duration;
import java.util.concurrent.*;

/** Bounded body reads and a shared network budget for pinned cosmetic downloads. */
public final class CosmeticHttp {
    private static final Semaphore DOWNLOAD = new Semaphore(4,true);
    private static final ScheduledThreadPoolExecutor DEADLINES = new ScheduledThreadPoolExecutor(1,r->{
        Thread t=new Thread(r,"Lin cosmetic HTTP deadlines");t.setDaemon(true);return t;
    });
    static { DEADLINES.setRemoveOnCancelPolicy(true); }
    public record Reply(int status,HttpHeaders headers,byte[] body) {}
    public static byte[] download(HttpClient client,HttpRequest request,long expected) throws IOException,InterruptedException {
        if(expected<1 || expected>32L*1024*1024)throw new IOException("Cosmetic asset size outside budget");
        DOWNLOAD.acquire();
        try {
            Reply reply=read(client,request,(int)expected,8*1024*1024);
            if(reply.status()!=200)throw new IOException("Cosmetic CDN HTTP "+reply.status());
            return reply.body();
        } finally { DOWNLOAD.release(); }
    }
    public static Reply read(HttpClient client,HttpRequest request,int limit,int bytesPerSecond) throws IOException,InterruptedException {
        long started=System.nanoTime();
        long timeout=request.timeout().orElse(Duration.ofSeconds(8)).toNanos();
        var response=client.send(request,HttpResponse.BodyHandlers.ofInputStream());
        try(InputStream input=response.body()) {
            long remaining=timeout-(System.nanoTime()-started);
            if(remaining<=0)throw new IOException("Cosmetic response deadline exceeded");
            var watchdog=DEADLINES.schedule(()->{try{input.close();}catch(IOException ignored){}},remaining,TimeUnit.NANOSECONDS);
            try {
                if(response.statusCode()!=200)return new Reply(response.statusCode(),response.headers(),new byte[0]);
                long declared=response.headers().firstValueAsLong("Content-Length").orElse(-1);
                if(declared>limit)throw new IOException("Cosmetic response is too large");
                ByteArrayOutputStream output=new ByteArrayOutputStream(Math.min(limit,8192));
                byte[] buffer=new byte[8192];long pacing=System.nanoTime();
                for(int count;(count=input.read(buffer))!=-1;) {
                    if(Thread.currentThread().isInterrupted())throw new InterruptedException();
                    if(System.nanoTime()-started>timeout)throw new IOException("Cosmetic response deadline exceeded");
                    if(count>limit-output.size())throw new IOException("Cosmetic response is too large");
                    output.write(buffer,0,count);
                    if(bytesPerSecond>0){
                        long due=pacing+(long)output.size()*1_000_000_000L/bytesPerSecond;
                        long wait=due-System.nanoTime();if(wait>0)TimeUnit.NANOSECONDS.sleep(wait);
                    }
                }
                if(System.nanoTime()-started>timeout)throw new IOException("Cosmetic response deadline exceeded");
                return new Reply(response.statusCode(),response.headers(),output.toByteArray());
            } finally { watchdog.cancel(false); }
        }
    }
    private CosmeticHttp() {}
}
