package dev.lin.client.cosmetics.model;

/** Where a cosmetic is attached when it is rendered on an avatar. */
public enum CosmeticAttachment {
    FULL_BODY,
    HEAD,
    BODY,
    BACK,
    LEFT_SHOULDER,
    FEET,
    HAND,
    CAPE,
    WINGS,
    COMPANION,
    AURA
}
