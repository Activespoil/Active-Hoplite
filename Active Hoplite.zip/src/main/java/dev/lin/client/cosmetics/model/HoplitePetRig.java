package dev.lin.client.cosmetics.model;

import java.util.List;

/**
 * Rigid element groups for the 26 imported Hoplite item models.
 * Indices are zero-based resource elements; pivots use original model units.
 * Apply each part after the authored element rotations, before mesh normalization.
 */
public final class HoplitePetRig {
    public enum Kind { HEAD, TAIL, LEG, ARM, WING, LID }

    public record Part(Kind kind, float x, float y, float z, float phase, int[] elements) {}

    private HoplitePetRig() {}

    public static List<Part> parts(String name) {
        return switch (name) {
            case "pink_fox_pet" -> List.of(
                    part(Kind.HEAD, 8, 6, 2, 1, 5, 6, 7, 8),
                    part(Kind.TAIL, 9.62f, 7, 14.09f, 1, 9, 10),
                    part(Kind.LEG, 6.05f, 6, 4, 1, 1),
                    part(Kind.LEG, 9.95f, 6, 4, -1, 2),
                    part(Kind.LEG, 6.05f, 6, 11, -1, 3),
                    part(Kind.LEG, 9.95f, 6, 11, 1, 4));
            case "roofus_the_dog_pet" -> List.of(
                    part(Kind.HEAD, 8, 12, 2, 1, 6, 7, 8, 9, 10, 11, 12, 13, 14),
                    part(Kind.TAIL, 8, 9, 16, 1, 3, 4, 5),
                    part(Kind.LEG, 4.5f, 10, 3, 1, 15, 16),
                    part(Kind.LEG, 11.5f, 10, 3, -1, 17, 18),
                    part(Kind.LEG, 4.5f, 9, 14, -1, 19, 20, 21),
                    part(Kind.LEG, 11.5f, 9, 14, 1, 22, 23, 24));
            case "baby_ender_dragon_pet" -> List.of(
                    part(Kind.HEAD, 8, 11, -3, 1, 16, 17, 18, 19, 20, 21),
                    part(Kind.TAIL, 8, 7.5f, 9, 1, 22, 23, 24, 25),
                    part(Kind.WING, 6, 11, 4, 1, 2, 3, 4, 5),
                    part(Kind.WING, 10, 11, 4, -1, 6, 7, 8, 9),
                    part(Kind.LEG, 5, 8, -1, 1, 10),
                    part(Kind.LEG, 11, 8, -1, -1, 11),
                    part(Kind.LEG, 4.5f, 7, 8, -1, 12, 13),
                    part(Kind.LEG, 11.5f, 7, 8, 1, 14, 15));
            case "baby_warden_pet" -> List.of(
                    part(Kind.HEAD, 8, 9, 8, 1, 5, 6),
                    part(Kind.ARM, 3, 9, 8, -1, 3),
                    part(Kind.ARM, 13, 9, 8, 1, 4),
                    part(Kind.LEG, 6, 3, 8, 1, 0),
                    part(Kind.LEG, 10, 3, 8, -1, 1));
            case "bert_piglin_pet" -> List.of(
                    part(Kind.HEAD, 8, 14, 8, 1, 7, 8, 9, 10, 11),
                    part(Kind.ARM, 3, 13, 8, -1, 12),
                    part(Kind.ARM, 13, 13, 8, 1, 13),
                    part(Kind.LEG, 6, 6, 8, 1, 0),
                    part(Kind.LEG, 10, 6, 8, -1, 1));
            case "cannibal_chibi_pet" -> List.of(
                    part(Kind.HEAD, 8, 10, 8, 1, 0, 1, 2, 3, 4),
                    part(Kind.ARM, 4, 9, 8, -1, 6, 7),
                    part(Kind.ARM, 12, 9, 8, 1, 8),
                    part(Kind.LEG, 6, 5, 8, 1, 9),
                    part(Kind.LEG, 10, 5, 8, -1, 10));
            case "mechanical_spider_pet" -> List.of(
                    part(Kind.HEAD, 8, 8, 2, 1, 10, 11, 12, 13, 14, 15),
                    part(Kind.LEG, 4, 8, 5.5f, 1, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27),
                    part(Kind.LEG, 12, 8, 8.5f, -1, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37),
                    part(Kind.LEG, 7, 8, -0.24148f, -1, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47),
                    part(Kind.LEG, 9, 8, -0.24148f, 1, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57),
                    part(Kind.LEG, 7, 8, 13.24148f, -1, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67),
                    part(Kind.LEG, 9, 8, 13.24148f, 1, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77));
            case "steam_spider_pet" -> List.of(
                    part(Kind.LEG, 1, 8, 8, 1, 15, 16, 17, 18, 19, 20),
                    part(Kind.LEG, 15, 8, 8, -1, 21, 22, 23, 24, 25, 26),
                    part(Kind.LEG, 2.41421f, 9, 2.41421f, -1, 27, 28, 29, 30, 31, 32),
                    part(Kind.LEG, 13.58579f, 9, 2.41421f, 1, 33, 34, 35, 36, 37, 38),
                    part(Kind.LEG, 2.41421f, 9, 13.58579f, -1, 39, 40, 41, 42, 43, 44),
                    part(Kind.LEG, 13.58579f, 9, 13.58579f, 1, 45, 46, 47, 48, 49, 50));
            case "valentines_allay_pet" -> List.of(
                    part(Kind.HEAD, 8, 10, 8, 1, 0, 1, 2, 3, 4),
                    part(Kind.ARM, 6.5f, 9, 8, -1, 7, 11, 12, 13, 14, 15, 16),
                    part(Kind.ARM, 9.5f, 9, 8, 1, 8),
                    // These butterfly wings flap around Y, unlike the other wing groups.
                    part(Kind.WING, 8, 8, 11, 1, 9),
                    part(Kind.WING, 8, 8, 11, -1, 10));
            case "polly_the_parrot_pet" -> List.of(
                    part(Kind.HEAD, 8, 5.75f, 5.5f, 1, 20, 21, 22, 23, 24, 25, 26, 27, 28),
                    part(Kind.TAIL, 8, 3, 11, 1, 29, 30),
                    part(Kind.WING, 6.5f, 5, 7, 1, 4, 5, 6, 7),
                    part(Kind.WING, 9.5f, 5, 7, -1, 8, 9, 10, 11),
                    part(Kind.LEG, 6.75f, 3.5f, 8.25f, 1, 12, 13, 14, 15),
                    part(Kind.LEG, 9.25f, 3.5f, 8.25f, -1, 16, 17, 18, 19));
            case "shulker_pet" -> List.of(part(Kind.LID, 8, 7, 8, 1, 0, 1, 2, 3, 4));
            case "chonky_pet" -> List.of(
                    part(Kind.HEAD, 8, 10, 3, 1, 1, 2, 3, 4, 5, 6, 7, 8),
                    part(Kind.TAIL, 8, 11, 14, 1, 9, 10),
                    part(Kind.LEG, 5, 5, 3, 1, 11),
                    part(Kind.LEG, 11, 5, 3, -1, 12),
                    part(Kind.LEG, 5, 5, 12, -1, 13),
                    part(Kind.LEG, 11, 5, 12, 1, 14));
            case "space_dog_pet" -> List.of(
                    part(Kind.HEAD, 8, 12, 2, 1, 6, 7, 8, 9, 10, 11),
                    part(Kind.TAIL, 8, 9, 16, 1, 3, 4, 5),
                    part(Kind.LEG, 4.5f, 10, 3, 1, 13, 14),
                    part(Kind.LEG, 11.5f, 10, 3, -1, 15, 16),
                    part(Kind.LEG, 4.5f, 9, 14, -1, 17, 18, 19),
                    part(Kind.LEG, 11.5f, 9, 14, 1, 20, 21, 22));
            case "bunny_carrot_pet" -> List.of(
                    part(Kind.HEAD, 8, 9, 5, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14),
                    part(Kind.TAIL, 8, 7.5f, 13, 1, 1),
                    part(Kind.LEG, 4.5f, 6, 12, -1, 15, 16),
                    part(Kind.LEG, 11.5f, 6, 12, 1, 17, 18),
                    part(Kind.LEG, 6, 4, 5, 1, 19),
                    part(Kind.LEG, 10, 4, 5, -1, 20));
            case "geoff_sharkdog_pet" -> List.of(
                    part(Kind.HEAD, 8, 7, 3, 1, 8, 9, 10, 11, 12, 13, 14),
                    part(Kind.TAIL, 8, 5.5f, 10, 1, 5, 6, 7),
                    part(Kind.LEG, 5.5f, 4, 4, 1, 0),
                    part(Kind.LEG, 10.5f, 4, 4, -1, 1),
                    part(Kind.LEG, 10.5f, 4, 10, 1, 2),
                    part(Kind.LEG, 5.5f, 4, 10, -1, 3));
            case "holiday_copper_golem_pet" -> List.of(
                    part(Kind.HEAD, 8, 11, 8, 1, 1, 2, 3, 4, 5, 6, 7),
                    part(Kind.ARM, 13, 11, 8, 1, 8),
                    part(Kind.ARM, 3, 11, 8, -1, 9),
                    part(Kind.LEG, 6, 5, 8, 1, 10),
                    part(Kind.LEG, 10, 5, 8, -1, 11));
            case "crazy_turkey" -> List.of(
                    part(Kind.HEAD, 8, 12, 2, 1, 3, 4, 5, 6, 7, 8, 9, 10),
                    part(Kind.TAIL, 8, 14, 13, 1, 0, 1),
                    part(Kind.WING, 2, 13, 6, 1, 11, 12),
                    part(Kind.WING, 14, 13, 6, -1, 13, 14),
                    part(Kind.LEG, 5, 7, 7, 1, 15, 16, 17),
                    part(Kind.LEG, 11, 7, 7, -1, 18, 19, 20));
            case "crab_pet" -> List.of(
                    part(Kind.LEG, 13, 1.5f, 15, 1, 8),
                    part(Kind.LEG, 3, 1.5f, 15, -1, 9),
                    part(Kind.LEG, 13, 1.5f, 11, -1, 10),
                    part(Kind.LEG, 3, 1.5f, 11, 1, 11),
                    part(Kind.LEG, 13, 1.5f, 7, 1, 12),
                    part(Kind.LEG, 3, 1.5f, 7, -1, 13),
                    part(Kind.ARM, 3.25f, 4.25f, 2.5f, -1, 18, 19, 20),
                    part(Kind.ARM, 12.75f, 4.25f, 2.5f, 1, 21, 22, 23));
            case "sky_beluga_pet" -> List.of(
                    part(Kind.WING, 3, 4.5f, 14, 1, 1),
                    part(Kind.WING, 13, 4.5f, 14, -1, 2),
                    part(Kind.TAIL, 8, 6, 20, 1, 5, 6, 7));
            case "snowman_pet" -> List.of(
                    part(Kind.HEAD, 8, 13, 8, 1, 5, 6, 7, 8),
                    part(Kind.ARM, 4, 9, 8, -1, 9, 10),
                    part(Kind.ARM, 12, 9, 8, 1, 11, 12, 13));
            case "flame_sprite_pet" -> List.of(
                    part(Kind.HEAD, 8, 8.5f, 8, 1, 2, 3),
                    part(Kind.ARM, 5.5f, 4.5f, 8, -1, 4),
                    part(Kind.ARM, 10.5f, 4.5f, 8, 1, 5),
                    part(Kind.LEG, 9.75f, 3, 8, -1, 0),
                    part(Kind.LEG, 6.25f, 3, 8, 1, 6));
            case "baby_breeze_pet" -> List.of(
                    part(Kind.HEAD, 8, 10, 8, 1, 0, 1, 2, 3));
            case "cerberus_pet" -> List.of(
                    // Preserve the authored three-head/flame assembly as a unit.
                    part(Kind.TAIL, 8, 8, 15, 1, 13, 14),
                    part(Kind.LEG, 10.4f, 6.5f, 13.6f, 1, 2, 3, 36),
                    part(Kind.LEG, 5.6f, 6.5f, 13.6f, -1, 4, 5, 37),
                    part(Kind.LEG, 10.6f, 5.5f, 4.5f, -1, 6, 7, 38),
                    part(Kind.LEG, 5.4f, 5.5f, 4.5f, 1, 8, 9, 39));
            case "undead_chicken_jockey_pet" -> List.of(
                    part(Kind.HEAD, 8, 10, 5, 1, 5, 6, 7, 8, 9),
                    part(Kind.HEAD, 8, 17.3f, 8, -1, 13, 14, 15, 16),
                    part(Kind.WING, 4.5f, 10, 5, 1, 10),
                    part(Kind.WING, 11.5f, 10, 5, -1, 11),
                    part(Kind.LEG, 6.5f, 5, 7.5f, 1, 27, 28, 29),
                    part(Kind.LEG, 9.5f, 5, 7.5f, -1, 30, 31));
            case "valkyrie_chibi_pet" -> List.of(
                    part(Kind.HEAD, 8, 14, 4, 1, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53),
                    part(Kind.TAIL, 8, 12.8f, 17, 1, 25, 26, 27),
                    part(Kind.WING, 6, 18, 6, 1, 28, 29, 30, 31, 32, 33),
                    part(Kind.WING, 10, 18, 6, -1, 34, 35, 36, 37, 38, 39),
                    part(Kind.LEG, 4.75f, 12, 4, 1, 0, 1, 2, 3),
                    part(Kind.LEG, 11.25f, 12, 4, -1, 4, 5, 6, 7),
                    part(Kind.LEG, 11.25f, 14, 16, 1, 8, 9, 10, 11, 12, 13),
                    part(Kind.LEG, 4.75f, 14, 16, -1, 14, 15, 16, 17, 18, 19));
            // Ghost is a continuous sheet: keep it intact and animate whole-body hover.
            default -> List.of();
        };
    }

    private static Part part(Kind kind, float x, float y, float z, float phase, int... elements) {
        return new Part(kind, x, y, z, phase, elements);
    }
}
