package dev.lin.client.cosmetics.assets;

import dev.lin.client.cosmetics.LinClient;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.attribute.BasicFileAttributes;
import java.nio.file.attribute.FileTime;
import java.security.MessageDigest;
import java.time.Duration;
import java.util.HexFormat;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class LunarAssetStore {
    private static final String CDN = "https://textures.lunarclientcdn.com/file/";
    private static final Path CACHE = FabricLoader.getInstance().getConfigDir()
            .resolve("lin-client/assets").toAbsolutePath().normalize();
    private static final Path LOCAL_JIT = Path.of(System.getProperty("user.home"),
            ".lunarclient", "jit", "assets", "lunar-jit").toAbsolutePath().normalize();
    private record VerifiedFile(long size, FileTime modified, FileTime created, Object fileKey,
                                String sha1) {}
    private static final Map<Path, VerifiedFile> VERIFIED = new ConcurrentHashMap<>();
    private static final ExecutorService EXECUTOR = Executors.newFixedThreadPool(4, task -> {
        Thread thread = new Thread(task, "Lunar Cosmetics Asset Loader");
        thread.setDaemon(true);
        return thread;
    });
    // Offline/bundled loads do not need an HTTP selector or worker threads.
    private static final class Remote {
      private static final HttpClient HTTP = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(20))
            .followRedirects(HttpClient.Redirect.NORMAL)
            .build();
    }
    private static final Map<String, CompletableFuture<Path>> ACTIVE =
            new ConcurrentHashMap<>();

    private LunarAssetStore() {
    }

    public static CompletableFuture<Path> obtainAsync(String logicalPath) {
        String normalized = LunarAssetIndex.normalize(logicalPath);
        // Publish before scheduling: a warm-cache completion must not remove an
        // entry inside computeIfAbsent, or leave an already completed owner behind.
        CompletableFuture<Path> owner = new CompletableFuture<>();
        CompletableFuture<Path> existing = ACTIVE.putIfAbsent(normalized, owner);
        if (existing != null) return existing;
        try {
            EXECUTOR.execute(() -> {
                    try {
                        Path result = obtain(normalized);
                        ACTIVE.remove(normalized, owner);
                        owner.complete(result);
                    } catch (Exception exception) {
                        ACTIVE.remove(normalized, owner);
                        owner.completeExceptionally(exception);
                    }
            });
        } catch (java.util.concurrent.RejectedExecutionException exception) {
            ACTIVE.remove(normalized, owner);
            owner.completeExceptionally(exception);
        }
        return owner;
    }

    public static Path obtain(String logicalPath) throws IOException {
        String normalized = LunarAssetIndex.normalize(logicalPath);
        if (normalized.isBlank() || normalized.contains("../") || normalized.startsWith("..")) {
            throw new IOException("Unsafe or empty Lunar asset path: " + logicalPath);
        }
        AssetRecord asset = LunarAssetIndex.get(normalized);
        if (asset == null) {
            throw new IOException("Asset is not present in the pinned index: " + normalized);
        }

        Path target = CACHE.resolve(asset.sha1()).normalize();
        if (!target.startsWith(CACHE)) {
            throw new IOException("Asset escaped the standalone cache: " + normalized);
        }
        if (valid(target, asset)) {
            return target;
        }

        synchronized (asset.sha1().intern()) {
            if (valid(target, asset)) {
                return target;
            }
            // The launcher, cape loader and pet loader may already own this exact
            // content hash. Reuse verified local bytes before contacting the CDN.
            Path local = LOCAL_JIT.resolve(normalized).normalize();
            if (local.startsWith(LOCAL_JIT) && valid(local, asset)) return local;
            for (String sibling : new String[]{"lunar-pet-cache", "lunar-cape-cache"}) {
                Path shared = CACHE.getParent().resolve(sibling).resolve(asset.sha1());
                if (valid(shared, asset)) return shared;
            }
            Files.createDirectories(CACHE);
            if (!extractBundled(asset, target)) {
                download(asset, target);
            }
            if (!valid(target, asset)) {
                throw new IOException("Asset verification failed: " + normalized);
            }
            return target;
        }
    }

    public static int indexedCount() {
        return LunarAssetIndex.entries().size();
    }

    public static long cachedCount() {
        if (!Files.isDirectory(CACHE)) {
            return 0;
        }
        try (var files = Files.list(CACHE)) {
            return files.filter(Files::isRegularFile).count();
        } catch (IOException ignored) {
            return 0;
        }
    }

    public static Path cacheDirectory() {
        return CACHE;
    }

    private static boolean extractBundled(AssetRecord asset, Path target) throws IOException {
        for (String resource : new String[]{"/assets/lunar/" + asset.logicalPath(),
                "/assets/lin_client/lunar_pet_assets/" + asset.sha1()}) {
            try (InputStream input = LunarAssetStore.class.getResourceAsStream(resource)) {
                if (input == null) continue;
                writeVerified(input.readAllBytes(), asset, target);
                return true;
            }
        }
        return false;
    }

    private static void download(AssetRecord asset, Path target) throws IOException {
        HttpRequest request = HttpRequest.newBuilder(URI.create(CDN + asset.sha1()))
                .timeout(Duration.ofSeconds(150))
                .header("User-Agent", "LunarCosmeticsStandalone/1.0.0")
                .GET()
                .build();
        try {
            byte[] body=dev.lin.client.cosmetics.sync.CosmeticHttp.download(Remote.HTTP,request,asset.size());
            writeVerified(body, asset, target);
        } catch (InterruptedException exception) {
            Thread.currentThread().interrupt();
            throw new IOException("Asset download interrupted", exception);
        }
    }

    private static void writeVerified(byte[] bytes, AssetRecord asset, Path target)
            throws IOException {
        if (bytes.length != asset.size() || !sha1(bytes).equals(asset.sha1())) {
            throw new IOException("Downloaded asset checksum mismatch: "
                    + asset.logicalPath());
        }
        Path staging = Files.createTempFile(CACHE, "asset-", ".tmp");
        try {
            Files.write(staging, bytes);
            try {
                Files.move(staging, target, StandardCopyOption.ATOMIC_MOVE,
                        StandardCopyOption.REPLACE_EXISTING);
            } catch (AtomicMoveNotSupportedException ignored) {
                Files.move(staging, target, StandardCopyOption.REPLACE_EXISTING);
            }
        } finally {
            Files.deleteIfExists(staging);
        }
    }

    /** Reuse the same stamped SHA-1 validation in legacy cape and shoulder-pet loaders. */
    public static boolean validPinned(Path file,String sha1,long size) {
        return sha1!=null && sha1.matches("[0-9a-f]{40}") && size>0
                && valid(file,new AssetRecord("",sha1,size));
    }
    private static boolean valid(Path file, AssetRecord asset) {
        try {
            BasicFileAttributes before = Files.readAttributes(file, BasicFileAttributes.class);
            if (!before.isRegularFile() || before.size() != asset.size()) {
                VERIFIED.remove(file);
                return false;
            }
            VerifiedFile stamp = new VerifiedFile(before.size(), before.lastModifiedTime(),
                    before.creationTime(), before.fileKey(), asset.sha1());
            if (stamp.equals(VERIFIED.get(file))) return true;
            if (!sha1(Files.readAllBytes(file)).equals(asset.sha1())) {
                VERIFIED.remove(file);
                return false;
            }
            BasicFileAttributes after = Files.readAttributes(file, BasicFileAttributes.class);
            VerifiedFile current = new VerifiedFile(after.size(), after.lastModifiedTime(),
                    after.creationTime(), after.fileKey(), asset.sha1());
            if (!stamp.equals(current)) return false;
            VERIFIED.put(file, stamp);
            return true;
        } catch (IOException ignored) {
            VERIFIED.remove(file);
            return false;
        }
    }

    private static String sha1(byte[] bytes) throws IOException {
        try {
            return HexFormat.of().formatHex(
                    MessageDigest.getInstance("SHA-1").digest(bytes));
        } catch (Exception exception) {
            throw new IOException("SHA-1 unavailable", exception);
        }
    }

    public static void close() {
        EXECUTOR.shutdownNow();
        ACTIVE.values().forEach(future -> future.cancel(false));
        ACTIVE.clear();
        VERIFIED.clear();
        LinClient.LOGGER.info("Standalone cosmetic asset cache: {} files in {}",
                cachedCount(), CACHE);
    }
}
