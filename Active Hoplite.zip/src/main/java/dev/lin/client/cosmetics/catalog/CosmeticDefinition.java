package dev.lin.client.cosmetics.catalog;

import java.util.List;

public record CosmeticDefinition(
        int id,
        String name,
        String resource,
        String sourceCategory,
        CosmeticCategory category,
        String indexType,
        boolean gek,
        boolean animated,
        boolean special,
        List<String> colors,
        List<String> tags,
        String releasedAt) {

    public String logicalResource() {
        if (resource == null) {
            return "";
        }
        int separator = resource.indexOf(':');
        return (separator >= 0 ? resource.substring(separator + 1) : resource)
                .replace('\\', '/');
    }

    public String searchText() {
        return (id + " " + name + " " + sourceCategory + " " + indexType + " "
                + String.join(" ", colors) + " " + String.join(" ", tags))
                .toLowerCase(java.util.Locale.ROOT)
                .replace('_', ' ')
                .replace('-', ' ');
    }
}
