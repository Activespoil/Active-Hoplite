package dev.lin.client.cosmetics.ui;

import dev.lin.client.cosmetics.assets.CosmeticAssetManager;
import dev.lin.client.cosmetics.catalog.CosmeticDefinition;
import dev.lin.client.cosmetics.model.CosmeticMesh;
import java.util.List;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;

/** Keep the avatar on the centerline; fit its outfit using stable reference bounds. */
public final class LockerPreviewFraming {
    private LockerPreviewFraming() {}

    public static Bounds bounds(Quaternionf orientation, float yaw, List<CosmeticDefinition> outfit) {
        // Use a yaw-invariant reference frame so rotating the avatar never zooms or wobbles the camera.
        Matrix4f body = new Matrix4f().rotation(orientation)
                .scale(-.9375f, -.9375f, .9375f).translate(0, -1.501f, 0);
        Bounds bounds = new Bounds();
        bounds.include(body, -.5f, -.5f, -.25f, .5f, 1.5f, .25f);
        bounds.anchorX = (bounds.minX + bounds.maxX) / 2;
        if (outfit == null) return bounds;
        for (var definition : outfit) {
            var data = CosmeticAssetManager.getPreview(definition);
            if (data == null) continue;
            if (data.attachment() == dev.lin.client.cosmetics.model.CosmeticAttachment.COMPANION) {
                continue;
            }
            CosmeticMesh mesh = data.referenceMesh() == null ? data.mesh() : data.referenceMesh();
            if (mesh == null || mesh.vertexCount() == 0) continue;
            Matrix4f transform = new Matrix4f(body);
            if (definition.gek()) {
                transform.translate(0, 1.5f, 0);
            } else if (data.attachment() == dev.lin.client.cosmetics.model.CosmeticAttachment.LEFT_SHOULDER) {
                transform.translate(-.72f, -.50f, .02f).rotateY((float) Math.toRadians(-18));
            }
            bounds.include(transform,
                    Math.max(-.85f, mesh.minX()), Math.max(-.65f, mesh.minY()), Math.max(-.65f, mesh.minZ()),
                    Math.min(.85f, mesh.maxX()), Math.min(1.65f, mesh.maxY()), Math.min(.65f, mesh.maxZ()));
        }
        return bounds;
    }

    public static final class Bounds {
        private float anchorX;
        private float minX = Float.POSITIVE_INFINITY, minY = Float.POSITIVE_INFINITY;
        private float maxX = Float.NEGATIVE_INFINITY, maxY = Float.NEGATIVE_INFINITY;
        public void include(Matrix4f transform, float x0, float y0, float z0, float x1, float y1, float z1) {
            Vector3f point = new Vector3f();
            for (int i = 0; i < 8; i++) {
                point.set((i & 1) == 0 ? x0 : x1, (i & 2) == 0 ? y0 : y1, (i & 4) == 0 ? z0 : z1)
                        .mulPosition(transform);
                minX = Math.min(minX, point.x); maxX = Math.max(maxX, point.x);
                minY = Math.min(minY, point.y); maxY = Math.max(maxY, point.y);
            }
        }
        public Vector3f translation() { return new Vector3f(-anchorX, -(minY + maxY) / 2, 0); }
        public int scale(int preferred, int width, int height) {
            return Math.max(1, (int) Math.floor(Math.min(preferred,
                    Math.min(width * .86f / Math.max(.001f, 2 * Math.max(anchorX - minX, maxX - anchorX)),
                            height * .88f / Math.max(.001f, maxY - minY)))));
        }
    }
}
