package dev.lin.client.cosmetics.sync;

import net.minecraft.client.Minecraft;
import java.util.*;
import java.util.concurrent.*;
import java.util.function.*;

/** One decoder for remote legacy assets. A full queue defers work to a later tick. */
public final class RemoteAssetLoader {
    private static final ThreadPoolExecutor IO = createExecutor();
    private static ThreadPoolExecutor createExecutor() {
        ThreadPoolExecutor exec = new ThreadPoolExecutor(4,4,30,TimeUnit.SECONDS,
            new ArrayBlockingQueue<>(64),r->{Thread t=new Thread(r,"Lin remote cosmetics");t.setDaemon(true);return t;});
        exec.allowCoreThreadTimeOut(true);
        return exec;
    }
    private static final Set<String> pending = new HashSet<>();
    private static final Map<String,Long> retry = new LinkedHashMap<>();
    private static long generation;
    @FunctionalInterface public interface Load<T> { T get() throws Exception; }
    public static <T> void request(String key, BooleanSupplier wanted, Load<T> load, Consumer<T> install) {
        if (!wanted.getAsBoolean() || pending.contains(key) || System.nanoTime()<retry.getOrDefault(key,0L)) return;
        long epoch=generation;pending.add(key);
        try { IO.execute(()->{
            T result=null;Exception failure=null;
            try { result=load.get(); } catch(Exception e) { failure=e; }
            T value=result;Exception error=failure;
            Minecraft.getInstance().execute(()->{
                if(epoch!=generation)return;
                pending.remove(key);
                if(error==null && wanted.getAsBoolean()) install.accept(value);
                else if(error!=null) {
                    retry.put(key,System.nanoTime()+8_000_000_000L);
                    while(retry.size()>128)retry.remove(retry.keySet().iterator().next());
                }
            });
        }); } catch(RejectedExecutionException full) { pending.remove(key); }
    }
    public static void clear() { generation++;IO.getQueue().clear();pending.clear();retry.clear(); }
    public static void close() { clear();IO.shutdownNow(); }
    private RemoteAssetLoader() {}
}
