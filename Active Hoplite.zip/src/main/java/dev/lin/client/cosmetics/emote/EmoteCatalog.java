package dev.lin.client.cosmetics.emote;

import com.google.gson.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Bundled Lunar curves: no runtime filesystem scan or network request. */
public final class EmoteCatalog {
    public record Action(String id, String name, int duration, boolean looping,
                         Map<String, Map<String, EmoteCurve>> bones) {
        public float value(String bone, String channel, float frame) {
            Map<String, EmoteCurve> channels = bones.get(bone);
            EmoteCurve curve = channels == null ? null : channels.get(channel);
            return curve == null ? 0 : curve.sample(frame);
        }
        public float previewFrame(double seconds) {
            return (float)(seconds * 20 % Math.max(1, duration));
        }
    }
    private static final List<Action> ACTIONS = load();
    private static final Map<String, Action> INDEX = new LinkedHashMap<>();
    static { for (Action action : ACTIONS) INDEX.put(action.id(), action); }
    private EmoteCatalog() {}
    public static List<Action> all() { return ACTIONS; }
    public static Action get(String id) { return INDEX.get(id); }
    private static JsonElement read(String path) throws IOException {
        try (InputStream in = EmoteCatalog.class.getResourceAsStream("/assets/lin_client/emotes/" + path)) {
            if (in == null) throw new FileNotFoundException(path);
            return JsonParser.parseReader(new InputStreamReader(in, StandardCharsets.UTF_8));
        }
    }
    private static List<Action> load() {
        List<Action> result = new ArrayList<>();
        try {
            for (JsonElement entry : read("catalog.json").getAsJsonArray()) {
                String id = entry.getAsJsonObject().get("id").getAsString();
                if (!id.matches("[a-z0-9_]+")) throw new IOException("Invalid emote ID");
                JsonObject data = read(id + ".json").getAsJsonObject();
                Map<String, Map<String, EmoteCurve>> bones = new LinkedHashMap<>();
                for (var bone : data.getAsJsonObject("bones").entrySet()) {
                    Map<String, EmoteCurve> channels = new LinkedHashMap<>();
                    for (var channel : bone.getValue().getAsJsonObject().entrySet()) {
                        JsonArray rows = channel.getValue().getAsJsonArray();
                        float[][] keys = new float[rows.size()][7];
                        for (int i = 0; i < rows.size(); i++) {
                            JsonArray row = rows.get(i).getAsJsonArray();
                            if (row.size() != 7) throw new IOException("Invalid curve " + id);
                            for (int j = 0; j < 7; j++) {
                                keys[i][j] = row.get(j).getAsFloat();
                                if (!Float.isFinite(keys[i][j])) throw new IOException("Nonfinite curve " + id);
                            }
                            if (i > 0 && keys[i][0] <= keys[i-1][0]) throw new IOException("Unsorted curve " + id);
                        }
                        channels.put(channel.getKey(), new EmoteCurve(keys));
                    }
                    bones.put(bone.getKey(), Map.copyOf(channels));
                }
                int duration = data.get("duration").getAsInt();
                if (duration < 1) throw new IOException("Invalid duration " + id);
                result.add(new Action(id, data.get("name").getAsString(), duration,
                        data.get("looping").getAsBoolean(), Map.copyOf(bones)));
            }
        } catch (IOException | RuntimeException e) {
            throw new IllegalStateException("Cannot load bundled emote catalog", e);
        }
        return List.copyOf(result);
    }
}
