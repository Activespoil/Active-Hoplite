package dev.lin.client.cosmetics.sync;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.lin.client.cosmetics.catalog.*;
import dev.lin.client.cosmetics.config.CosmeticConfig;
import dev.lin.client.features.accessory.*;
import dev.lin.client.features.cape.LunarCapeRegistry;
import dev.lin.client.features.pet.LunarPetRegistry;
import dev.lin.client.features.config.ClientAccessoryConfig;
import dev.lin.client.features.render.AccessoryItemModels;
import dev.lin.client.features.trim.LinTrimManager;
import dev.lin.client.features.artifact.ArtifactSkins;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.EquipmentSlot;
import java.util.*;

/** Host-owned data boundary: the embedded network module depends on this host, never vice versa. */
public final class CosmeticSyncBridge {
    private static final JsonObject CATALOG=loadCatalog();
    public static final String CATALOG_REVISION=CATALOG.get("revision").getAsString();
    public record Trim(String pattern,String material) {
        public Trim {
            if(!knownTrim(pattern,material))throw new IllegalArgumentException("Unsupported trim");
        }
    }
    public record Appearance(String vipIcon,boolean vipLobbyOnly,String arrowTrail,Map<String,String> skins) {
        public static final Appearance EMPTY=new Appearance("none",true,"none",Map.of());
        public Appearance { skins=Map.copyOf(skins); }
    }
    public record Outfit(Map<String,Integer> slots,Map<String,String> accessories,Map<String,String> options,Trim trim,Appearance appearance) {
        public static final Outfit EMPTY=new Outfit(Map.of(),Map.of(),Map.of());
        public Outfit(Map<String,Integer> slots,Map<String,String> accessories,Map<String,String> options) {
            this(slots,accessories,options,null);
        }
        public Outfit(Map<String,Integer> slots,Map<String,String> accessories,Map<String,String> options,Trim trim) {
            this(slots,accessories,options,trim,Appearance.EMPTY);
        }
        public Outfit { slots=Map.copyOf(slots);accessories=Map.copyOf(accessories);options=Map.copyOf(options);appearance=appearance==null?Appearance.EMPTY:appearance; }
        public float number(String name,float fallback){
            try{float n=Float.parseFloat(options.get(name));return Float.isFinite(n)?Math.max(-.8f,Math.min(.8f,n)):fallback;}
            catch(RuntimeException e){return fallback;}
        }
        public boolean flag(String key,boolean fallback){return Boolean.parseBoolean(options.getOrDefault(key,Boolean.toString(fallback)));}
        public int floatingCount(){try{return Math.max(0,Math.min(9999,Integer.parseInt(options.getOrDefault("floatingNumber","5"))));}catch(RuntimeException e){return 5;}}
    }
    public record Local(Outfit outfit,long revision,long changedAtNanos,boolean shared) {}
    public record Peer(Outfit outfit,String version,long deadline,List<CosmeticDefinition> definitions) {
        public Peer(Outfit outfit,String version,long deadline){this(outfit,version,deadline,resolveDefinitions(outfit));}
    }
    private static Local local=new Local(Outfit.EMPTY,0,System.nanoTime(),true);
    private static Map<UUID,Peer> peers=Map.of();
    private static String status="等待进入服务器";
    private static boolean unsupportedLocal;
    private CosmeticSyncBridge(){}
    private static JsonObject loadCatalog(){
        try(var in=CosmeticSyncBridge.class.getResourceAsStream("/assets/lin_client/cosmetics-sync-catalog.json")){
            if(in==null)throw new IllegalStateException("Missing shared cosmetic catalog");
            return JsonParser.parseString(new String(in.readAllBytes(),java.nio.charset.StandardCharsets.UTF_8)).getAsJsonObject();
        }catch(Exception e){throw new ExceptionInInitializerError(e);}
    }
    public static Local local(){return local;}
    public static Map<UUID,Peer> snapshot(){return peers;}
    public static Peer remote(UUID id){
        if(!CosmeticConfig.receiveCosmetics())return null;
        Peer p=peers.get(id);return p!=null && System.nanoTime()<p.deadline()?p:null;
    }
    public static void replace(Map<UUID,Peer> value){
        if(value.size()>1024)throw new IllegalArgumentException("Too many cosmetic peers");
        peers=Map.copyOf(value);
    }
    public static void clear(){peers=Map.of();}
    public static String status(){return status+(unsupportedLocal?" · 本地导入资源仅自己可见":"");}
    public static void status(String message){status=message;}
    public static void captureLocal(){
        Map<String,Integer> slots=new LinkedHashMap<>();
        for(var d:CosmeticConfig.equipped())slots.put(d.category().id(),d.id());
        slots.entrySet().removeIf(e->!knownSlot(e.getKey(),e.getValue()));
        Map<String,String> extras=new LinkedHashMap<>(),options=new LinkedHashMap<>();
        extras.put("headwear",AccessoryRegistry.selectedId(AccessorySlot.HEADWEAR));
        extras.put("wings",AccessoryRegistry.selectedId(AccessorySlot.WINGS));
        extras.put("floating",AccessoryRegistry.selectedId(AccessorySlot.FLOATING));
        extras.put("cape",LunarCapeRegistry.selectedId());extras.put("pet",LunarPetRegistry.selectedId());
        if(slots.containsKey("cloak"))extras.remove("cape");
        if(slots.containsKey("pet"))extras.remove("pet");
        if(slots.containsKey("dragon_wings"))extras.remove("wings");
        if(slots.containsKey("hat"))extras.remove("headwear");
        extras.values().removeIf(value->value==null || value.isBlank());
        unsupportedLocal=extras.entrySet().stream().anyMatch(e->!knownAccessory(e.getKey(),e.getValue()));
        extras.entrySet().removeIf(e->!knownAccessory(e.getKey(),e.getValue()));
        options.put("headwearVariant",AccessoryRegistry.headwearVariant(AccessoryRegistry.selected(AccessorySlot.HEADWEAR)).id());
        options.put("headwearScope",AccessoryRegistry.headwearScope().id());
        var player=Minecraft.getInstance().player;
        options.put("headwearActive",Boolean.toString(player!=null && AccessoryItemModels.shouldReplaceWorldHelmet(player.getItemBySlot(EquipmentSlot.HEAD))));
        options.put("petOffsetX",Float.toString(ClientAccessoryConfig.petOffsetX));
        options.put("petOffsetY",Float.toString(ClientAccessoryConfig.petOffsetY));
        options.put("wingOffsetY",Float.toString(ClientAccessoryConfig.wingOffsetY));
        options.put("floatingNumber",Integer.toString(ClientAccessoryConfig.floatingNumber));
        options.put("floatingGlobal",Boolean.toString(ClientAccessoryConfig.floatingGlobal));
        String pattern=LinTrimManager.pattern(),material=LinTrimManager.material();
        Trim trim=knownTrim(pattern,material)?new Trim(pattern,material):null;
        var appearance=new Appearance(CosmeticConfig.vipIcon(),CosmeticConfig.vipLobbyOnly(),CosmeticConfig.arrowTrail(),ArtifactSkins.sharedSelections());
        Outfit next=new Outfit(slots,extras,options,trim,appearance);boolean shared=CosmeticConfig.shareCosmetics();
        if(!next.equals(local.outfit()) || shared!=local.shared())local=new Local(next,local.revision()+1,System.nanoTime(),shared);
    }
    public static boolean knownAccessory(String category,String id){
        var group=CATALOG.getAsJsonObject("accessories").getAsJsonObject(category);
        return group!=null && id!=null && group.has(id);
    }
    public static boolean knownTrim(String pattern,String material){
        var trims=CATALOG.getAsJsonObject("trims");
        return trims!=null && pattern!=null && material!=null
            && trims.getAsJsonObject("patterns").has(pattern) && trims.getAsJsonObject("materials").has(material);
    }
    public static boolean known(String group,String id){
        return id!=null && CATALOG.has(group) && CATALOG.getAsJsonObject(group).has(id);
    }
    public static boolean knownSlot(String slot,int id){
        var value=CATALOG.getAsJsonObject("slots").get(Integer.toString(id));
        return value!=null && slot.equals(value.getAsString());
    }
    public static boolean knownSkin(String artifact,String skin){
        var group=CATALOG.getAsJsonObject("skins");
        return group!=null && artifact!=null && skin!=null && group.has(artifact) && group.getAsJsonObject(artifact).has(skin);
    }
    private static List<CosmeticDefinition> resolveDefinitions(Outfit outfit){
        List<CosmeticDefinition> result=new ArrayList<>();
        for(var e:outfit.slots().entrySet()){
            var d=LunarCatalog.byId(e.getValue());
            if(d!=null && d.category().isLockerEnabled() && d.category().id().equals(e.getKey()))result.add(d);
        }
        return List.copyOf(result);
    }
}
