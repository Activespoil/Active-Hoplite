package dev.lin.client.cosmetics.render;

import com.mojang.blaze3d.platform.NativeImage;
import io.github.humbleui.skija.*;
import io.github.humbleui.types.RRect;
import java.awt.Shape;
import java.awt.geom.PathIterator;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.gui.navigation.ScreenRectangle;
import net.minecraft.client.gui.render.TextureSetup;
import net.minecraft.client.gui.render.state.GuiElementRenderState;
import org.joml.Matrix3x2f;
import org.joml.Matrix3x2fc;
import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.resources.Identifier;

/** Skija masks submitted in Minecraft's GUI order, alongside entity/item previews.
 * No raw GL is issued while Minecraft is extracting the screen's render state. */
public final class SkijaUiRaster {
    private static final int PAD = 2;
    private static final long BUDGET = 64L * 1024 * 1024;
    private record Key(int w, int h, int radiusQuarter, int strokeQuarter) {}
    private record Tile(Identifier id, int w, int h) {}
    private static final Map<Key, Tile> CACHE = new LinkedHashMap<>(64, .75f, true);
    private static long bytes, sequence;
    private static boolean active;
    private SkijaUiRaster() {}

    public static void beginFrame() { trimCache(); active = true; }
    /** Call only before GUI extraction; queued masks must survive until the draw pass. */
    public static void trimCache() {
        // Evict only before extraction, never invalidate a texture already queued.
        var it = CACHE.entrySet().iterator();
        while ((bytes > BUDGET || CACHE.size() > 256) && it.hasNext()) {
            Tile tile = it.next().getValue(); it.remove();
            bytes -= (long) tile.w * tile.h * 4;
            Minecraft.getInstance().getTextureManager().release(tile.id);
        }
    }
    public static void endFrame() { active = false; }

    public static boolean round(GuiGraphics g, float x, float y, float w, float h,
                                float radius, int color, float stroke) {
        if (!active) return false;
        return roundQueued(g,x,y,w,h,radius,color,stroke);
    }
    /** Explicit deferred HUD path, independent of whether a menu page is active. */
    public static boolean roundQueued(GuiGraphics g,float x,float y,float w,float h,
                                      float radius,int color,float stroke) {
        if (w <= 0 || h <= 0 || color >>> 24 == 0) return true;
        float density = Math.max(2f, rasterDensity(g));
        int pw = Math.max(1, Math.round(w * density)), ph = Math.max(1, Math.round(h * density));
        int radiusQuarter = Math.max(0, Math.round(Math.min(radius, Math.min(w, h) / 2) * density * 4));
        int strokeQuarter = Math.max(0, Math.round(stroke * density * 4));
        float r = radiusQuarter / 4f, line = strokeQuarter / 4f;
        // Nine-slice a small mask: large glass panels never allocate full-screen textures.
        int corner = (int) Math.ceil(r + line);
        int maskW = Math.min(pw, 2 * corner + 2);
        int maskH = Math.min(ph, 2 * corner + 2);
        Key key = new Key(maskW, maskH, radiusQuarter, strokeQuarter);
        Tile tile = CACHE.get(key);
        if (tile == null) {
            int tw = maskW + PAD * 2, th = maskH + PAD * 2;
            Identifier id = Identifier.fromNamespaceAndPath("lin_client", "skija/mask_" + sequence++);
            Minecraft.getInstance().getTextureManager().register(id,
                    new DynamicTexture(() -> "Lin Skija UI mask", mask(maskW, maskH, r, line)) {
                        @Override public com.mojang.blaze3d.textures.GpuSampler getSampler() {
                            return com.mojang.blaze3d.systems.RenderSystem.getSamplerCache()
                                    .getClampToEdge(com.mojang.blaze3d.textures.FilterMode.LINEAR);
                        }
                    });
            tile = new Tile(id, tw, th);
            CACHE.put(key, tile);
            bytes += (long) tile.w * tile.h * 4;
        }
        var pose = new Matrix3x2f(g.pose());
        pose.translate(x - PAD / density, y - PAD / density);
        pose.scale(1f / density, 1f / density);
        int cx = Math.min(corner + PAD, (tile.w - 1) / 2);
        int cy = Math.min(corner + PAD, (tile.h - 1) / 2);
        int[] sx = {0, cx, tile.w - cx, tile.w};
        int[] sy = {0, cy, tile.h - cy, tile.h};
        float dw = w * density + PAD * 2, dh = h * density + PAD * 2;
        float[] dx = {0, Math.min(cx, dw / 2), Math.max(dw - cx, dw / 2), dw};
        float[] dy = {0, Math.min(cy, dh / 2), Math.max(dh - cy, dh / 2), dh};
        var scissor = g.scissorStack.peek();
        var bounds = new ScreenRectangle(0, 0, (int)Math.ceil(dw), (int)Math.ceil(dh)).transformMaxBounds(pose);
        if (scissor != null) bounds = bounds.intersection(scissor);
        if (bounds != null) {
            var texture = Minecraft.getInstance().getTextureManager().getTexture(tile.id);
            // One ordering/bounds decision for the whole mask; neighbouring slices share exact vertices.
            g.guiRenderState.submitGuiElement(new MaskState(pose,
                    TextureSetup.singleTexture(texture.getTextureView(), texture.getSampler()),
                    sx, sy, dx, dy, tile.w, tile.h, color, scissor, bounds));
        }
        return true;
    }

    private record MaskState(Matrix3x2fc pose, TextureSetup textureSetup,
                             int[] sx, int[] sy, float[] dx, float[] dy, int width, int height,
                             int color, ScreenRectangle scissorArea, ScreenRectangle bounds) implements GuiElementRenderState {
        @Override public RenderPipeline pipeline() { return RenderPipelines.GUI_TEXTURED; }
        @Override public void buildVertices(VertexConsumer consumer) {
            for (int row = 0; row < 3; row++) for (int col = 0; col < 3; col++) {
                if (dx[col + 1] <= dx[col] || dy[row + 1] <= dy[row]) continue;
                vertex(consumer, col, row); vertex(consumer, col, row + 1);
                vertex(consumer, col + 1, row + 1); vertex(consumer, col + 1, row);
            }
        }
        private void vertex(VertexConsumer consumer, int col, int row) {
            consumer.addVertexWith2DPose(pose, dx[col], dy[row])
                    .setUv((float)sx[col] / width, (float)sy[row] / height).setColor(color);
        }
    }

    /** Raster pixels per local unit, rounded up to reusable quarter-pixel density steps. */
    public static float rasterDensity(GuiGraphics graphics) {
        var pose = graphics.pose();
        double scale = Math.max(Math.hypot(pose.m00(), pose.m01()), Math.hypot(pose.m10(), pose.m11()));
        double density = scale * Minecraft.getInstance().getWindow().getGuiScale();
        if (!Double.isFinite(density)) return 2f;
        // The cap bounds mask/glyph allocation at extreme accessibility GUI scales.
        return (float) Math.max(1, Math.min(8, Math.ceil(density * 4) / 4));
    }

    static NativeImage mask(int w, int h, float radius, float stroke) {
        try (Surface surface = Surface.makeRasterN32Premul(w + PAD * 2, h + PAD * 2);
             Paint paint = new Paint().setAntiAlias(true).setColor(0xffffffff)) {
            surface.getCanvas().clear(0);
            float inset = stroke / 2f;
            if (stroke > 0) paint.setMode(PaintMode.STROKE).setStrokeWidth(stroke);
            surface.getCanvas().drawRRect(RRect.makeXYWH(PAD + inset, PAD + inset,
                    Math.max(0, w - stroke), Math.max(0, h - stroke), Math.max(0, radius - inset)), paint);
            NativeImage image = pixels(surface);
            // Straight-alpha filtering must interpolate white coverage, never transparent black.
            // Otherwise low-alpha edge samples acquire a dark fringe, especially on light glass.
            for (int y = 0; y < image.getHeight(); y++) for (int x = 0; x < image.getWidth(); x++)
                image.setPixel(x, y, image.getPixel(x, y) | 0x00ffffff);
            return image;
        }
    }

    public static NativeImage text(Shape outline, int width, int height, int color) {
        try (Surface surface = Surface.makeRasterN32Premul(width, height);
             Paint paint = new Paint().setAntiAlias(true).setColor(color);
             PathBuilder builder = new PathBuilder()) {
            float[] p = new float[6];
            for (PathIterator it = outline.getPathIterator(null); !it.isDone(); it.next()) {
                switch (it.currentSegment(p)) {
                    case PathIterator.SEG_MOVETO -> builder.moveTo(p[0], p[1]);
                    case PathIterator.SEG_LINETO -> builder.lineTo(p[0], p[1]);
                    case PathIterator.SEG_QUADTO -> builder.quadTo(p[0], p[1], p[2], p[3]);
                    case PathIterator.SEG_CUBICTO -> builder.cubicTo(p[0], p[1], p[2], p[3], p[4], p[5]);
                    case PathIterator.SEG_CLOSE -> builder.closePath();
                }
            }
            surface.getCanvas().clear(0);
            try (Path path = builder.detach()) { surface.getCanvas().drawPath(path, paint); }
            return pixels(surface);
        }
    }

    private static NativeImage pixels(Surface surface) {
        NativeImage image = new NativeImage(surface.getWidth(), surface.getHeight(), false);
        try (Pixmap target = Pixmap.make(new ImageInfo(image.getWidth(), image.getHeight(),
                ColorType.RGBA_8888, ColorAlphaType.UNPREMUL), image.getPointer(), image.getWidth() * 4)) {
            if (!surface.readPixels(target, 0, 0)) throw new IllegalStateException("Cannot copy Skija UI pixels");
            return image;
        } catch (RuntimeException | Error error) {
            image.close();
            throw error;
        }
    }
}
