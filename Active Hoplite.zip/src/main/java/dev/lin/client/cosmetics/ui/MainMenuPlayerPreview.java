package dev.lin.client.cosmetics.ui;

import dev.lin.client.cosmetics.assets.CosmeticAssetManager;
import dev.lin.client.cosmetics.config.CosmeticConfig;
import dev.lin.client.features.accessory.AccessoryDefinition;
import dev.lin.client.features.accessory.AccessoryRegistry;
import dev.lin.client.features.accessory.AccessorySlot;
import dev.lin.client.features.render.AccessoryItemModels;
import dev.lin.client.features.render.AccessoryWorldRenderer;
import dev.lin.client.features.artifact.ArtifactSkins;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.entity.EntityRenderDispatcher;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.state.AvatarRenderState;
import net.minecraft.client.renderer.entity.state.EntityRenderState;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.client.resources.DefaultPlayerSkin;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.entity.player.PlayerSkin;
import org.joml.Quaternionf;
import org.joml.Vector3f;
import java.util.function.Supplier;

/** Shares the Locker's avatar/cosmetic preview pipeline with the main menu. */
public final class MainMenuPlayerPreview {
    private static LivingEntity retainedPlayer;
    private static Supplier<PlayerSkin> skinLookup;
    private static final int TITLE_PREVIEW_ID = Integer.MIN_VALUE + 731;
    public static final int HOPLITE_WIDGET_PREVIEW_ID = TITLE_PREVIEW_ID - 1;

    private MainMenuPlayerPreview() {}

    public static void begin() {
        CosmeticAssetManager.setMenuPreviewActive(true);
        CosmeticAssetManager.preload(CosmeticConfig.equipped());
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.player != null) retainedPlayer = minecraft.player;
        skinLookup = minecraft.getSkinManager().createLookup(minecraft.getGameProfile(), false);
    }

    public static void end() {
        CosmeticAssetManager.setMenuPreviewActive(false);
        CosmeticAssetManager.clearPreload();
    }

    public static void render(GuiGraphics graphics, int width, int height) {
        Minecraft minecraft = Minecraft.getInstance();
        LivingEntity player = minecraft.player != null ? minecraft.player : retainedPlayer;
        int left = Math.round(width * 0.66F);
        int right = width - Math.max(10, Math.round(width * 0.025F));
        int top = Math.max(20, Math.round(height * 0.13F));
        int bottom = height - Math.max(12, Math.round(height * 0.06F));
        int scale = Math.max(45, Math.min(92, Math.round(height * 0.32F)));
        renderEntity(graphics, left, top, right, bottom, scale, player, 18.0F);
    }

    public static void renderHopliteWidget(GuiGraphics graphics, int left, int top, int right, int bottom) {
        Minecraft minecraft = Minecraft.getInstance();
        LivingEntity entity = minecraft.player != null ? minecraft.player : retainedPlayer;
        ItemStack dragonKatana = ArtifactSkins.previewStack(ArtifactSkins.Artifact.DRAGON_KATANA);
        EntityRenderState state;
        ItemStack previous = ItemStack.EMPTY;
        if (entity != null) {
            previous = entity.getItemBySlot(EquipmentSlot.OFFHAND).copy();
            entity.setItemSlot(EquipmentSlot.OFFHAND, dragonKatana);
            try {
                EntityRenderer<? super LivingEntity, ?> renderer = minecraft.getEntityRenderDispatcher().getRenderer(entity);
                state = renderer.createRenderState(entity, 1.0F);
            } finally {
                entity.setItemSlot(EquipmentSlot.OFFHAND, previous);
            }
        } else {
            AvatarRenderState avatar = new AvatarRenderState();
            PlayerSkin lookedUp = skinLookup == null ? null : skinLookup.get();
            avatar.skin = lookedUp == null ? DefaultPlayerSkin.get(minecraft.getGameProfile()) : lookedUp;
            avatar.entityType = EntityType.PLAYER;
            avatar.boundingBoxWidth = 0.6F;
            avatar.boundingBoxHeight = 1.8F;
            avatar.eyeHeight = 1.62F;
            avatar.id = HOPLITE_WIDGET_PREVIEW_ID;
            avatar.ageInTicks = (System.currentTimeMillis() % 60000L) / 50.0F;
            minecraft.getItemModelResolver().updateForTopItem(avatar.leftHandItemState,
                    dragonKatana, ItemDisplayContext.THIRD_PERSON_LEFT_HAND, null, null, avatar.id);
            avatar.leftHandItemStack = dragonKatana;
            state = avatar;
        }
        state.lightCoords = 15728880;
        state.shadowPieces.clear();
        state.outlineColor = 0;
        if (state instanceof AvatarRenderState avatar) {
            // createRenderState keeps the real entity id. Give this one menu-only
            // render a stable id so its final model pose can be isolated safely.
            avatar.id = HOPLITE_WIDGET_PREVIEW_ID;
            AccessoryWorldRenderer.registerPreviewWing(avatar.id, null);
            AccessoryDefinition headwear = AccessoryRegistry.selected(AccessorySlot.HEADWEAR);
            if (headwear != null) {
                if (entity != null) minecraft.getItemModelResolver().updateForLiving(avatar.headItem,
                        AccessoryItemModels.stack(headwear), ItemDisplayContext.HEAD, entity);
                else minecraft.getItemModelResolver().updateForTopItem(avatar.headItem,
                        AccessoryItemModels.stack(headwear), ItemDisplayContext.HEAD, null, null, avatar.id);
            }
            avatar.mainArm = HumanoidArm.RIGHT;
            avatar.showCape = false;
        }
        if (state instanceof LivingEntityRenderState living) {
            living.bodyRot = 180.0F;
            living.yRot = 0.0F;
            living.xRot = 0.0F;
            living.boundingBoxWidth /= living.scale;
            living.boundingBoxHeight /= living.scale;
            living.scale = 1.0F;
        }
        int widgetHeight = bottom - top;
        int scale = Math.max(40, Math.round(widgetHeight * 0.78F));
        Quaternionf orientation = new Quaternionf().rotateZ((float)Math.PI);
        Vector3f center = new Vector3f(0.0F,
                state.boundingBoxHeight / 2.0F + 0.0625F, 0.0F);
        graphics.submitEntityRenderState(state, scale, center, orientation, new Quaternionf(),
                left + Math.round((right - left) * 0.46F), top + Math.round(widgetHeight * 0.20F),
                right - 2, bottom + Math.round(widgetHeight * 0.50F));
    }

    public static boolean isHopliteWidgetPreview(int entityId) {
        return entityId == HOPLITE_WIDGET_PREVIEW_ID;
    }

    private static void renderEntity(GuiGraphics graphics, int left, int top,
                                     int right, int bottom, int scale,
                                     LivingEntity entity, float yaw) {
        Minecraft minecraft = Minecraft.getInstance();
        EntityRenderState state;
        if (entity != null) {
            EntityRenderDispatcher dispatcher = minecraft.getEntityRenderDispatcher();
            EntityRenderer<? super LivingEntity, ?> renderer = dispatcher.getRenderer(entity);
            state = renderer.createRenderState(entity, 1.0F);
        } else {
            AvatarRenderState avatar = new AvatarRenderState();
            PlayerSkin lookedUp = skinLookup == null ? null : skinLookup.get();
            avatar.skin = lookedUp == null
                    ? DefaultPlayerSkin.get(minecraft.getGameProfile()) : lookedUp;
            avatar.entityType = EntityType.PLAYER;
            avatar.boundingBoxWidth = 0.6F;
            avatar.boundingBoxHeight = 1.8F;
            avatar.eyeHeight = 1.62F;
            avatar.id = TITLE_PREVIEW_ID;
            avatar.ageInTicks = (System.currentTimeMillis() % 60000L) / 50.0F;
            state = avatar;
        }
        state.lightCoords = 15728880;
        state.shadowPieces.clear();
        state.outlineColor = 0;
        if (state instanceof AvatarRenderState avatar) {
            // The title preview deliberately stays lightweight: show the player's
            // Hoplite headwear only, without outfits, capes, wings, pets or orbiting FX.
            AccessoryWorldRenderer.registerPreviewWing(avatar.id, null);
            AccessoryDefinition headwear = AccessoryRegistry.selected(AccessorySlot.HEADWEAR);
            if (headwear != null) {
                if (entity != null) {
                    minecraft.getItemModelResolver().updateForLiving(avatar.headItem,
                            AccessoryItemModels.stack(headwear), ItemDisplayContext.HEAD, entity);
                } else {
                    minecraft.getItemModelResolver().updateForTopItem(avatar.headItem,
                            AccessoryItemModels.stack(headwear), ItemDisplayContext.HEAD,
                            null, null, TITLE_PREVIEW_ID);
                }
            }
            avatar.showCape = false;
        }
        if (state instanceof LivingEntityRenderState living) {
            living.bodyRot = 180.0F + yaw;
            living.yRot = 0.0F;
            living.xRot = 0.0F;
            living.boundingBoxWidth /= living.scale;
            living.boundingBoxHeight /= living.scale;
            living.scale = 1.0F;
        }
        Quaternionf orientation = new Quaternionf().rotateZ((float) Math.PI);
        Vector3f center = new Vector3f(0.0F,
                state.boundingBoxHeight / 2.0F + 0.0625F, 0.0F);
        graphics.submitEntityRenderState(state, scale, center, orientation,
                new Quaternionf(), left, top, right, bottom);
    }
}
