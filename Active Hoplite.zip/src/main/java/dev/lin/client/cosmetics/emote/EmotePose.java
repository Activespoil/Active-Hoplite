package dev.lin.client.cosmetics.emote;

import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.renderer.entity.state.AvatarRenderState;
import org.joml.*;

/** Adapts original curves to native rigid bones, leaving armor and skin layers native. */
public final class EmotePose {
    private EmotePose() {}
    public static void apply(HumanoidModel<?> model, AvatarRenderState state) {
        EmoteRuntime.Sample sample = ((EmoteRenderState)state).linEmoteSample();
        if (sample == null) sample = EmoteRuntime.current(state.id);
        if (sample == null || sample.weight() <= 0) return;
        var action = sample.action(); float frame = sample.frame(), weight = sample.weight();
        Quaternionf root = rotation(action, "anchor", frame);
        Vector3f translation = location(action, "anchor", frame);
        Quaternionf pelvis = new Quaternionf(root).mul(rotation(action, "low_body", frame));
        translation.add(location(action, "low_body", frame));
        Quaternionf torso = new Quaternionf(pelvis).mul(rotation(action, "body", frame));
        Vector3f torsoShift = new Vector3f(translation).add(location(action, "body", frame));
        part(model.body, "body", action, frame, torso, torsoShift, weight, true);
        part(model.head, "head", action, frame, torso, torsoShift, weight, false);
        part(model.leftArm, "left_arm", action, frame, torso, torsoShift, weight, false);
        part(model.rightArm, "right_arm", action, frame, torso, torsoShift, weight, false);
        part(model.leftLeg, "left_leg", action, frame, pelvis, translation, weight, false);
        part(model.rightLeg, "right_leg", action, frame, pelvis, translation, weight, false);
        // 1.21.11 skin overlays are children of their native body parts.
    }
    private static Quaternionf rotation(EmoteCatalog.Action action, String bone, float frame) {
        return new Quaternionf().rotateZYX(-action.value(bone, "rotation2", frame),
                -action.value(bone, "rotation1", frame), -action.value(bone, "rotation0", frame));
    }
    private static Vector3f location(EmoteCatalog.Action action, String bone, float frame) {
        return new Vector3f(action.value(bone, "location0", frame) * 16,
                -action.value(bone, "location1", frame) * 16,
                action.value(bone, "location2", frame) * 16);
    }
    private static void part(ModelPart part, String bone, EmoteCatalog.Action action, float frame,
                             Quaternionf parent, Vector3f shift, float weight, boolean torso) {
        var initial = part.getInitialPose();
        Vector3f position = new Vector3f(initial.x(), initial.y() - 12, initial.z());
        parent.transform(position); position.y += 12;
        position.add(shift);
        if (!torso) position.add(location(action, bone, frame));
        Quaternionf target = new Quaternionf(parent);
        if (!torso) target.mul(rotation(action, bone, frame));
        Quaternionf vanilla = new Quaternionf().rotateZYX(part.zRot, part.yRot, part.xRot);
        vanilla.slerp(target, weight);
        Vector3f euler = vanilla.getEulerAnglesZYX(new Vector3f());
        part.xRot = euler.x; part.yRot = euler.y; part.zRot = euler.z;
        part.x += (position.x - part.x) * weight;
        part.y += (position.y - part.y) * weight;
        part.z += (position.z - part.z) * weight;
    }
}
