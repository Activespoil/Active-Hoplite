package dev.lin.client.cosmetics.mixin;

import dev.lin.client.cosmetics.ui.PortraitModelState;
import net.minecraft.client.renderer.entity.player.AvatarRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(AvatarRenderer.class)
public abstract class PortraitHandVisibilityMixin {
    @Inject(method = {"renderRightHand", "renderLeftHand"}, at = @At("HEAD"))
    private void lin$restoreHandVisibility(CallbackInfo ci) {
        Object model = ((AvatarRenderer<?>)(Object)this).getModel();
        if (model instanceof PortraitModelState portrait) portrait.lin$restorePortraitVisibility();
    }
}
