package dev.lin.client.cosmetics.model;

import com.google.gson.JsonElement;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.Locale;
import java.util.concurrent.ThreadLocalRandom;

public final class MolangExpression {
   private final String value;
   private final Map<String, Double> variables;
   private int cursor;

   private MolangExpression(String value, Map<String, Double> variables) {
      this.value = value == null ? "" : value.trim().toLowerCase(Locale.ROOT);
      this.variables = variables;
   }

   public static float evaluate(JsonElement value) {
      return evaluate(value, new HashMap<>());
   }

   public static float evaluate(JsonElement value, Map<String, Double> variables) {
      if (value == null || value.isJsonNull()) {
         return 0.0F;
      }
      if (value.isJsonPrimitive() && value.getAsJsonPrimitive().isNumber()) {
         return value.getAsFloat();
      }
      try {
         double result = compiled(value.getAsString()).run(variables);
         return Double.isFinite(result) ? (float)result : 0.0F;
      } catch (RuntimeException ignored) {
         return 0.0F;
      }
   }


   @FunctionalInterface private interface Expression { double run(Map<String, Double> variables); }
   private record Statement(String assignment, boolean returns, Expression expression) {}
   private record Block(String source) implements Expression {
      @Override public double run(Map<String, Double> variables) { return compiled(source).run(variables); }
   }
   // Cache syntax, never variable values or random results. Access is shared by model workers.
   private static final Map<String, Expression> PROGRAMS = new java.util.LinkedHashMap<>(256, .75f, true);
   private static Expression compiled(String source) {
      synchronized (PROGRAMS) {
         Expression cached = PROGRAMS.get(source);
         if (cached != null) return cached;
      }
      Expression program;
      try { program = Compiler.script(source); }
      catch (RuntimeException invalidSyntax) {
         // Preserve the interpreter's partial assignments and error behavior on malformed assets.
         program = variables -> evaluateScript(source, variables);
      }
      synchronized (PROGRAMS) {
         Expression existing = PROGRAMS.get(source);
         if (existing != null) return existing;
         PROGRAMS.put(source, program);
         if (PROGRAMS.size() > 4096) PROGRAMS.remove(PROGRAMS.keySet().iterator().next());
      }
      return program;
   }

   private static final class Compiler {
      private final String source;
      private int cursor;
      private Compiler(String source) { this.source = source.trim().toLowerCase(Locale.ROOT); }
      static Expression script(String source) {
         List<Statement> statements = new ArrayList<>();
         for (String raw : splitStatements(source == null ? "" : source.toLowerCase(Locale.ROOT))) {
            String value = raw.trim();
            if (value.isEmpty()) continue;
            boolean returns = value.startsWith("return ");
            int assignment = returns ? -1 : assignmentIndex(value);
            String name = assignment > 0 ? value.substring(0, assignment).trim() : null;
            String expression = returns ? value.substring(7) : assignment > 0 ? value.substring(assignment + 1) : value;
            statements.add(new Statement(name, returns, new Compiler(expression).conditional()));
            if (returns) break;
         }
         Statement[] instructions = statements.toArray(Statement[]::new);
         return variables -> {
            double result = 0;
            for (Statement instruction : instructions) {
               result = instruction.expression.run(variables);
               if (instruction.returns) return result;
               if (instruction.assignment != null) variables.put(instruction.assignment, result);
            }
            return result;
         };
      }
      private Expression conditional() {
         Expression condition = coalescing();
         if (!take("?")) return condition;
         Expression yes = branch(); require(":"); Expression no = branch();
         return variables -> {
            boolean selected = truthy(condition.run(variables));
            double whenTrue = runBranch(yes, selected, variables);
            double whenFalse = runBranch(no, !selected, variables);
            return selected ? whenTrue : whenFalse;
         };
      }
      private static double runBranch(Expression branch, boolean selected, Map<String, Double> variables) {
         if (branch instanceof Block) return selected ? branch.run(variables) : 0;
         if (selected) return branch.run(variables);
         // The legacy evaluator eagerly visits a plain branch, restoring its variable writes.
         Map<String, Double> snapshot = new HashMap<>(variables);
         try { return branch.run(variables); }
         finally { variables.clear(); variables.putAll(snapshot); }
      }
      private Expression branch() {
         skip();
         if (!take("{")) return conditional();
         int start = cursor, depth = 1;
         while (cursor < source.length() && depth > 0) {
            char c = source.charAt(cursor++);
            if (c == '{') depth++; else if (c == '}') depth--;
         }
         if (depth != 0) throw new IllegalArgumentException("Unclosed Molang block");
         return new Block(source.substring(start, cursor - 1));
      }
      private Expression coalescing() {
         Expression node = or();
         while (take("??")) node = binary("??", node, or());
         return node;
      }
      private Expression or() {
         Expression node = and();
         while (take("||")) node = binary("||", node, and());
         return node;
      }
      private Expression and() {
         Expression node = equality();
         while (take("&&")) node = binary("&&", node, equality());
         return node;
      }
      private Expression equality() {
         Expression node = comparison();
         while (true) {
            if (take("==")) node = binary("==", node, comparison());
            else if (take("!=")) node = binary("!=", node, comparison());
            else return node;
         }
      }
      private Expression comparison() {
         Expression node = additive();
         while (true) {
            if (take("<=")) node = binary("<=", node, additive());
            else if (take(">=")) node = binary(">=", node, additive());
            else if (take("<")) node = binary("<", node, additive());
            else if (take(">")) node = binary(">", node, additive());
            else return node;
         }
      }
      private Expression additive() {
         Expression node = multiplicative();
         while (true) {
            if (take("+")) node = binary("+", node, multiplicative());
            else if (take("-")) node = binary("-", node, multiplicative());
            else return node;
         }
      }
      private Expression multiplicative() {
         Expression node = unary();
         while (true) {
            if (take("*")) node = binary("*", node, unary());
            else if (take("/")) node = binary("/", node, unary());
            else if (take("%")) node = binary("%", node, unary());
            else return node;
         }
      }
      private Expression unary() {
         if (take("+")) return unary();
         if (take("-")) { Expression node = unary(); return vars -> -node.run(vars); }
         if (take("!")) { Expression node = unary(); return vars -> truthy(node.run(vars)) ? 0 : 1; }
         return primary();
      }
      private Expression primary() {
         skip();
         if (take("(")) { Expression node = conditional(); require(")"); return node; }
         if (cursor < source.length() && (Character.isDigit(source.charAt(cursor)) || source.charAt(cursor) == '.')) {
            int start = cursor;
            while (cursor < source.length()) {
               char c = source.charAt(cursor);
               if (!Character.isDigit(c) && c != '.' && c != 'e' && c != 'f' && c != '+' && c != '-') break;
               if ((c == '+' || c == '-') && cursor > start && source.charAt(cursor - 1) != 'e') break;
               cursor++;
            }
            double value = Double.parseDouble(source.substring(start, cursor).replace("f", ""));
            return variables -> value;
         }
         int start = cursor;
         while (cursor < source.length()) {
            char c = source.charAt(cursor);
            if (!Character.isLetterOrDigit(c) && c != '_' && c != '.') break;
            cursor++;
         }
         String name = source.substring(start, cursor);
         if (name.isEmpty()) return variables -> 0;
         if (take("(")) {
            List<Expression> args = new ArrayList<>();
            if (!peek(")")) do { args.add(conditional()); } while (take(","));
            require(")"); Expression[] parameters = args.toArray(Expression[]::new);
            return variables -> {
               double first = parameters.length > 0 ? parameters[0].run(variables) : 0;
               double second = parameters.length > 1 ? parameters[1].run(variables) : 0;
               double third = parameters.length > 2 ? parameters[2].run(variables) : 0;
               for (int i = 3; i < parameters.length; i++) parameters[i].run(variables);
               return function(name, first, second, third, parameters.length, variables);
            };
         }
         return switch (name) {
            case "math.pi" -> variables -> Math.PI;
            case "true" -> variables -> 1;
            default -> variables -> variables.getOrDefault(name, 0.0);
         };
      }
      private static Expression binary(String operator, Expression left, Expression right) {
         return variables -> {
            double a = left.run(variables), b = right.run(variables);
            return switch (operator) {
               case "+" -> a + b; case "-" -> a - b; case "*" -> a * b;
               case "/" -> b == 0 ? 0 : a / b; case "%" -> b == 0 ? 0 : a % b;
               case "??" -> truthy(a) ? a : b;
               case "||" -> truthy(a) || truthy(b) ? 1 : 0;
               case "&&" -> truthy(a) && truthy(b) ? 1 : 0;
               case "==" -> a == b ? 1 : 0; case "!=" -> a != b ? 1 : 0;
               case "<" -> a < b ? 1 : 0; case ">" -> a > b ? 1 : 0;
               case "<=" -> a <= b ? 1 : 0; case ">=" -> a >= b ? 1 : 0;
               default -> throw new IllegalArgumentException(operator);
            };
         };
      }
      private void skip() { while (cursor < source.length() && Character.isWhitespace(source.charAt(cursor))) cursor++; }
      private boolean take(String token) { skip(); if (!source.startsWith(token, cursor)) return false; cursor += token.length(); return true; }
      private boolean peek(String token) { skip(); return source.startsWith(token, cursor); }
      private void require(String token) { if (!take(token)) throw new IllegalArgumentException("Expected " + token); }
   }

   private static double evaluateScript(String source, Map<String, Double> variables) {
      List<String> statements = splitStatements(source == null ? "" : source.toLowerCase(Locale.ROOT));
      double result = 0.0;
      for (String raw : statements) {
         String statement = raw.trim();
         if (statement.isEmpty()) {
            continue;
         }
         if (statement.startsWith("return ")) {
            return new MolangExpression(statement.substring(7), variables).parseConditional();
         }
         int assignment = assignmentIndex(statement);
         if (assignment > 0) {
            String name = statement.substring(0, assignment).trim();
            double assigned = new MolangExpression(statement.substring(assignment + 1), variables).parseConditional();
            variables.put(name, assigned);
            result = assigned;
         } else {
            result = new MolangExpression(statement, variables).parseConditional();
         }
      }
      return result;
   }

   private static List<String> splitStatements(String source) {
      List<String> result = new ArrayList<>();
      int start = 0;
      int parentheses = 0;
      int braces = 0;
      for (int index = 0; index < source.length(); index++) {
         char current = source.charAt(index);
         if (current == '(') {
            parentheses++;
         } else if (current == ')') {
            parentheses = Math.max(0, parentheses - 1);
         } else if (current == '{') {
            braces++;
         } else if (current == '}') {
            braces = Math.max(0, braces - 1);
         } else if (current == ';' && parentheses == 0 && braces == 0) {
            result.add(source.substring(start, index));
            start = index + 1;
         }
      }
      if (start < source.length()) {
         result.add(source.substring(start));
      }
      return result;
   }

   private static int assignmentIndex(String statement) {
      int parentheses = 0;
      int braces = 0;
      for (int index = 0; index < statement.length(); index++) {
         char current = statement.charAt(index);
         if (current == '(') {
            parentheses++;
         } else if (current == ')') {
            parentheses = Math.max(0, parentheses - 1);
         } else if (current == '{') {
            braces++;
         } else if (current == '}') {
            braces = Math.max(0, braces - 1);
         } else if (current == '=' && parentheses == 0 && braces == 0) {
            char before = index > 0 ? statement.charAt(index - 1) : 0;
            char after = index + 1 < statement.length() ? statement.charAt(index + 1) : 0;
            if (before != '=' && before != '<' && before != '>' && before != '!' && after != '=') {
               return index;
            }
         }
      }
      return -1;
   }

   private double parseConditional() {
      double condition = parseNullCoalescing();
      skipWhitespace();
      if (take('?')) {
         boolean selected = truthy(condition);
         double whenTrue = parseBranch(selected);
         require(':');
         double whenFalse = parseBranch(!selected);
         return selected ? whenTrue : whenFalse;
      }
      return condition;
   }

   private double parseBranch(boolean evaluate) {
      skipWhitespace();
      if (cursor < value.length() && value.charAt(cursor) == '{') {
         int start = ++cursor;
         int depth = 1;
         while (cursor < value.length() && depth > 0) {
            char current = value.charAt(cursor++);
            if (current == '{') {
               depth++;
            } else if (current == '}') {
               depth--;
            }
         }
         if (depth != 0) {
            throw new IllegalArgumentException("Unclosed Molang block");
         }
         if (!evaluate) {
            return 0.0;
         }
         return evaluateScript(value.substring(start, cursor - 1), variables);
      }
      if (evaluate) {
         return parseConditional();
      }
      Map<String, Double> snapshot = new HashMap<>(variables);
      try {
         return parseConditional();
      } finally {
         variables.clear();
         variables.putAll(snapshot);
      }
   }

   private double parseNullCoalescing() {
      double result = parseOr();
      while (take("??")) {
         double fallback = parseOr();
         if (!truthy(result)) {
            result = fallback;
         }
      }
      return result;
   }

   private double parseOr() {
      double result = parseAnd();
      while (take("||")) {
         double right = parseAnd();
         result = truthy(result) || truthy(right) ? 1.0 : 0.0;
      }
      return result;
   }

   private double parseAnd() {
      double result = parseEquality();
      while (take("&&")) {
         double right = parseEquality();
         result = truthy(result) && truthy(right) ? 1.0 : 0.0;
      }
      return result;
   }

   private double parseEquality() {
      double result = parseComparison();
      while (true) {
         if (take("==")) {
            result = result == parseComparison() ? 1.0 : 0.0;
         } else if (take("!=")) {
            result = result != parseComparison() ? 1.0 : 0.0;
         } else {
            return result;
         }
      }
   }

   private double parseComparison() {
      double result = parseAdditive();
      while (true) {
         if (take("<=")) {
            result = result <= parseAdditive() ? 1.0 : 0.0;
         } else if (take(">=")) {
            result = result >= parseAdditive() ? 1.0 : 0.0;
         } else if (take('<')) {
            result = result < parseAdditive() ? 1.0 : 0.0;
         } else if (take('>')) {
            result = result > parseAdditive() ? 1.0 : 0.0;
         } else {
            return result;
         }
      }
   }

   private double parseAdditive() {
      double result = parseMultiplicative();
      while (true) {
         if (take('+')) {
            result += parseMultiplicative();
         } else if (take('-')) {
            result -= parseMultiplicative();
         } else {
            return result;
         }
      }
   }

   private double parseMultiplicative() {
      double result = parseUnary();
      while (true) {
         if (take('*')) {
            result *= parseUnary();
         } else if (take('/')) {
            double divisor = parseUnary();
            result = divisor == 0.0 ? 0.0 : result / divisor;
         } else if (take('%')) {
            double divisor = parseUnary();
            result = divisor == 0.0 ? 0.0 : result % divisor;
         } else {
            return result;
         }
      }
   }

   private double parseUnary() {
      if (take('+')) {
         return parseUnary();
      }
      if (take('-')) {
         return -parseUnary();
      }
      if (take('!')) {
         return truthy(parseUnary()) ? 0.0 : 1.0;
      }
      return parsePrimary();
   }

   private double parsePrimary() {
      skipWhitespace();
      if (take('(')) {
         double result = parseConditional();
         require(')');
         return result;
      }
      if (cursor < value.length() && (Character.isDigit(value.charAt(cursor)) || value.charAt(cursor) == '.')) {
         return parseNumber();
      }
      String identifier = parseIdentifier();
      if (identifier.isEmpty()) {
         return 0.0;
      }
      if (take('(')) {
         List<Double> arguments = new ArrayList<>();
         if (!peek(')')) {
            do {
               arguments.add(parseConditional());
            } while (take(','));
         }
         require(')');
         return function(identifier, argument(arguments, 0), argument(arguments, 1), argument(arguments, 2), arguments.size(), variables);
      }
      return switch (identifier) {
         case "math.pi" -> Math.PI;
         case "true" -> 1.0;
         default -> variables.getOrDefault(identifier, 0.0);
      };
   }

   private double parseNumber() {
      int start = cursor;
      while (cursor < value.length()) {
         char current = value.charAt(cursor);
         if (!Character.isDigit(current) && current != '.' && current != 'e' && current != 'f'
            && current != '+' && current != '-') {
            break;
         }
         if ((current == '+' || current == '-') && cursor > start && value.charAt(cursor - 1) != 'e') {
            break;
         }
         cursor++;
      }
      String number = value.substring(start, cursor).replace("f", "");
      return Double.parseDouble(number);
   }

   private String parseIdentifier() {
      skipWhitespace();
      int start = cursor;
      while (cursor < value.length()) {
         char current = value.charAt(cursor);
         if (!Character.isLetterOrDigit(current) && current != '_' && current != '.') {
            break;
         }
         cursor++;
      }
      return value.substring(start, cursor);
   }

   private static double function(String name, double first, double second, double third, int count, Map<String, Double> variables) {
      return switch (name) {
         case "math.cos" -> Math.cos(Math.toRadians(first));
         case "math.sin" -> Math.sin(Math.toRadians(first));
         case "math.asin" -> Math.toDegrees(Math.asin(first));
         case "math.abs" -> Math.abs(first);
         case "math.floor" -> Math.floor(first);
         case "math.round" -> Math.round(first);
         case "math.sqrt" -> Math.sqrt(Math.max(0.0, first));
         case "math.pow" -> Math.pow(first, second);
         case "math.mod" -> second == 0.0 ? 0.0 : first % second;
         case "math.min" -> Math.min(first, second);
         case "math.max" -> Math.max(first, second);
         case "math.clamp" -> Math.max(second, Math.min(third, first));
         case "math.lerp", "math.lerprotate" -> first + (second - first) * third;
         case "math.random" -> random(first,
            count >= 2 ? second : 0.0);
         case "lunar.sigmoid" -> second * Math.tanh(
            first * Math.max(0.001, third) / Math.max(0.001, second)
         );
         case "lunar.sigmoid_swing" -> first * Math.tanh(
            third * Math.max(0.001, second)
               / Math.max(0.001, first)
         );
         case "lunar.movewave", "lunar.movewave_sin" -> {
            double time = variables.getOrDefault("q.life_time",
               variables.getOrDefault("query.life_time", 0.0));
            yield Math.sin(Math.toRadians(time * first + third))
               * second;
         }
         case "lunar.movewave_cos" -> {
            double time = variables.getOrDefault("q.life_time",
               variables.getOrDefault("query.life_time", 0.0));
            yield Math.cos(Math.toRadians(time * first + third))
               * second;
         }
         case "lunar.lopsided_wave", "lunar.speed_vibration", "lunar.linear_wave" -> Math.sin(Math.toRadians(first));
         case "lunar.interval" -> {
            double time = variables.getOrDefault("q.life_time",
               variables.getOrDefault("query.life_time", 0.0));
            double period = Math.max(0.001, Math.abs(first));
            double active = Math.max(0.0, Math.min(period, Math.abs(second)));
            double phase = (time % period + period) % period;
            yield phase < active ? 1.0 : 0.0;
         }
         case "lunar.smoothclamp" -> Math.max(second, Math.min(third, first));
         case "lunar.smoothmin" -> Math.min(first, second);
         case "lunar.easeinback" -> first * first * (2.70158 * first - 1.70158);
         case "lunar.random_integer" -> Math.round(random(first,
            count >= 2 ? second : 0.0));
         default -> first;
      };
   }

   private static double argument(List<Double> values, int index) {
      return index < values.size() ? values.get(index) : 0.0;
   }

   private static double random(double first, double second) {
      double minimum = Math.min(first, second);
      double maximum = Math.max(first, second);
      return maximum <= minimum ? minimum
         : ThreadLocalRandom.current().nextDouble(minimum, maximum);
   }

   private void require(char expected) {
      if (!take(expected)) {
         throw new IllegalArgumentException("Expected " + expected);
      }
   }

   private boolean peek(char expected) {
      skipWhitespace();
      return cursor < value.length() && value.charAt(cursor) == expected;
   }

   private boolean take(char expected) {
      skipWhitespace();
      if (cursor < value.length() && value.charAt(cursor) == expected) {
         cursor++;
         return true;
      }
      return false;
   }

   private boolean take(String expected) {
      skipWhitespace();
      if (value.startsWith(expected, cursor)) {
         cursor += expected.length();
         return true;
      }
      return false;
   }

   private void skipWhitespace() {
      while (cursor < value.length() && Character.isWhitespace(value.charAt(cursor))) {
         cursor++;
      }
   }

   private static boolean truthy(double value) {
      return Math.abs(value) > 1.0E-8;
   }
}
