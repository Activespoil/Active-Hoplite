package dev.lin.client.cosmetics.mixin;

import dev.lin.client.cosmetics.render.ArrowTrails;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.world.entity.projectile.arrow.AbstractArrow;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(AbstractArrow.class)
public abstract class ArrowTrailMixin {
    @Shadow protected abstract boolean isInGround();
    @Unique private Vec3 lin$trailStart;

    @Inject(method = "tick", at = @At("HEAD"))
    private void lin$start(CallbackInfo ci) {
        AbstractArrow arrow = (AbstractArrow)(Object)this;
        lin$trailStart = !isInGround() && ArrowTrails.replaces(arrow) ? arrow.position() : null;
    }

    @Inject(method = "tick", at = @At("TAIL"))
    private void lin$finish(CallbackInfo ci) {
        ArrowTrails.emit((AbstractArrow)(Object)this, lin$trailStart);
        lin$trailStart = null;
    }

    @Redirect(method = "tick", at = @At(value = "INVOKE", target =
            "Lnet/minecraft/world/level/Level;addParticle(Lnet/minecraft/core/particles/ParticleOptions;DDDDDD)V"))
    private void lin$replaceCrit(Level level, ParticleOptions particle, double x, double y, double z,
                                 double vx, double vy, double vz) {
        if (particle != ParticleTypes.CRIT || !ArrowTrails.replaces((AbstractArrow)(Object)this)) {
            level.addParticle(particle, x, y, z, vx, vy, vz);
        }
    }
}
