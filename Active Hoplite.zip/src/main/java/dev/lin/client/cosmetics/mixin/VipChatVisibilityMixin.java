/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.ModifyVariable
 */
package dev.lin.client.cosmetics.mixin;

import dev.lin.client.cosmetics.vip.VipIcons;
import net.minecraft.util.FormattedCharSequence;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(targets={"net/minecraft/class_338$class_12333", "net/minecraft/class_338$class_12235", "net/minecraft/class_338$class_12234"})
public abstract class VipChatVisibilityMixin {
    @ModifyVariable(method={"method_75807"}, at=@At(value="HEAD"), argsOnly=true, ordinal=0)
    private FormattedCharSequence lin$visible(FormattedCharSequence text) {
        return VipIcons.filterChat(text);
    }
}

