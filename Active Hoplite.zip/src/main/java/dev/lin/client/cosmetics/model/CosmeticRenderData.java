package dev.lin.client.cosmetics.model;

import dev.lin.client.cosmetics.catalog.CosmeticDefinition;
import net.minecraft.resources.Identifier;

/** GPU-ready result shared by Locker previews and the in-world renderer. */
public record CosmeticRenderData(
        CosmeticDefinition definition,
        CosmeticMesh mesh,
        Identifier texture,
        Identifier capeTexture,
        CosmeticAttachment attachment,
        boolean doubleSided,
        boolean translucent,
        CosmeticMesh previousMesh,
        CosmeticMesh referenceMesh,
        long meshTransitionNanos,
        long meshTransitionDurationNanos) {

    public CosmeticRenderData(CosmeticDefinition definition,
                              CosmeticMesh mesh,
                              Identifier texture,
                              Identifier capeTexture,
                              CosmeticAttachment attachment,
                              boolean doubleSided,
                              boolean translucent) {
        this(definition, mesh, texture, capeTexture, attachment, doubleSided,
                translucent, mesh, mesh, System.nanoTime(), 1L);
    }

    public float meshProgress() {
        if (previousMesh == null || previousMesh == mesh
                || previousMesh.vertexCount() != mesh.vertexCount()) {
            return 1.0F;
        }
        long elapsed = System.nanoTime() - meshTransitionNanos;
        return Math.max(0.0F, Math.min(1.0F,
                elapsed / (float) Math.max(1L, meshTransitionDurationNanos)));
    }
}
