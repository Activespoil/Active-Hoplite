package dev.lin.client.cosmetics.catalog;

import java.util.Comparator;
import java.util.List;
import java.util.Set;
import java.util.function.Predicate;

/** Keeps only the current locker result. The source and favorite set must be immutable snapshots. */
public final class LockerFilterCache {
    private record Key(Object section, int companionView, String query, boolean ascending,
                       boolean favoritesOnly, Set<Integer> favorites) {}
    private List<CosmeticDefinition> source;
    private Key key;
    private List<CosmeticDefinition> result = List.of();

    public List<CosmeticDefinition> filter(List<CosmeticDefinition> source, Object section, int companionView,
            String query, boolean ascending, boolean favoritesOnly, Set<Integer> favorites,
            Predicate<CosmeticDefinition> visibleInSection) {
        Key next = new Key(section, companionView, query, ascending, favoritesOnly,
                favoritesOnly ? favorites : Set.of());
        if (this.source == source && next.equals(key)) return result;
        String[] terms = query.isEmpty() ? new String[0] : query.split("\\s+");
        Comparator<CosmeticDefinition> order = Comparator
                .comparing(CosmeticDefinition::name, String.CASE_INSENSITIVE_ORDER)
                .thenComparingInt(CosmeticDefinition::id);
        if (!ascending) order = order.reversed();
        List<CosmeticDefinition> filtered = source.stream()
                .filter(visibleInSection)
                .filter(value -> !favoritesOnly || favorites.contains(value.id()))
                .filter(value -> terms.length == 0 || matches(value.searchText(), terms))
                .sorted(order).toList();
        this.source = source;
        key = next;
        result = filtered;
        return result;
    }

    private static boolean matches(String text, String[] terms) {
        for (String term : terms) if (!text.contains(term)) return false;
        return true;
    }
}
