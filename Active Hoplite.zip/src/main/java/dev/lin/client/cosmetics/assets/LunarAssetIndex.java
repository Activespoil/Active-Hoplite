package dev.lin.client.cosmetics.assets;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

public final class LunarAssetIndex {
    private static final String RESOURCE =
            "/assets/lin_client/catalog/jit_index";
    private static Map<String, AssetRecord> entries = Map.of();

    private LunarAssetIndex() {
    }

    public static synchronized void load() {
        if (!entries.isEmpty()) {
            return;
        }
        Map<String, AssetRecord> loaded = new LinkedHashMap<>();
        try (InputStream input = LunarAssetIndex.class.getResourceAsStream(RESOURCE)) {
            if (input == null) {
                throw new IllegalStateException("Missing Lunar asset index");
            }
            BufferedReader reader = new BufferedReader(
                    new InputStreamReader(input, StandardCharsets.UTF_8));
            String line;
            while ((line = reader.readLine()) != null) {
                String[] columns = line.trim().split("\\s+", 4);
                if (columns.length < 3) {
                    continue;
                }
                String path = normalize(columns[0]);
                loaded.put(path, new AssetRecord(path, columns[1], Long.parseLong(columns[2])));
            }
        } catch (Exception exception) {
            throw new IllegalStateException("Unable to read Lunar asset index", exception);
        }
        entries = Collections.unmodifiableMap(loaded);
    }

    public static AssetRecord get(String logicalPath) {
        return entries.get(normalize(logicalPath));
    }

    public static Map<String, AssetRecord> entries() {
        return entries;
    }

    public static String normalize(String value) {
        String path = value == null ? "" : value.replace('\\', '/');
        if (path.startsWith("lunar:")) {
            path = path.substring("lunar:".length());
        }
        if (path.startsWith("/")) {
            path = path.substring(1);
        }
        if (path.startsWith("assets/lunar/")) {
            path = path.substring("assets/lunar/".length());
        }
        return path;
    }
}
