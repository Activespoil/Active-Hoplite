package dev.lin.client.cosmetics;

import com.mojang.blaze3d.platform.InputConstants.Type;
import dev.lin.client.features.LinFeatures;
import dev.lin.client.cosmetics.assets.CosmeticAssetManager;
import dev.lin.client.cosmetics.assets.LunarAssetIndex;
import dev.lin.client.cosmetics.assets.LunarAssetStore;
import dev.lin.client.cosmetics.catalog.CosmeticDefinition;
import dev.lin.client.cosmetics.catalog.LunarCatalog;
import dev.lin.client.cosmetics.config.CosmeticConfig;
import dev.lin.client.cosmetics.font.FontManager;
import dev.lin.client.cosmetics.render.CosmeticWorldRenderer;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.KeyMapping.Category;
import net.minecraft.resources.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class LinClient implements ClientModInitializer {
    public static final String MOD_ID = "lin_client";
    public static final Logger LOGGER = LoggerFactory.getLogger("Lin Client");
    private static final KeyMapping OPEN_LOCKER = KeyBindingHelper.registerKeyBinding(
            new KeyMapping("key.lin_client.open_locker", Type.KEYSYM, 344,
                    Category.register(Identifier.fromNamespaceAndPath(MOD_ID, "general"))));

    @Override
    public void onInitializeClient() {
        com.linclient.client.presence.LinPresence.initialize();
        dev.lin.client.cosmetics.emote.EmoteRuntime.initialize();
        LunarAssetIndex.load();
        LunarCatalog.load();
        CosmeticConfig.load();
        ClientTickEvents.END_CLIENT_TICK.register(LinClient::tick);
        WorldRenderEvents.AFTER_ENTITIES.register(
                CosmeticWorldRenderer::renderWorldCompanion);
        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> close());
        LOGGER.info("Lin Client ready: {} cosmetics, {} pinned assets",
                LunarCatalog.all().size(), LunarAssetStore.indexedCount());
    }

    private static void tick(Minecraft minecraft) {
        com.linclient.client.presence.LinPresence.tick(minecraft);
        dev.lin.client.cosmetics.sync.CosmeticSyncBridge.captureLocal();
        com.linclient.client.presence.CosmeticSyncClient.tick(minecraft);
        dev.lin.client.cosmetics.sync.RemoteCosmetics.tick(minecraft);
        CosmeticAssetManager.tick();
        dev.lin.client.cosmetics.emote.EmoteRuntime.tick(minecraft);
        while (OPEN_LOCKER.consumeClick()) {
            if (minecraft.screen == null) {
                dev.lin.client.cosmetics.ui.SystemNavigation.begin(minecraft.screen);
            }
        }
        for (CosmeticDefinition definition : CosmeticConfig.equipped()) {
            CosmeticAssetManager.request(definition);
        }
    }

    private static void close() {
        com.linclient.client.presence.CosmeticSyncClient.close();
        com.linclient.client.presence.LinPresence.close();
        dev.lin.client.cosmetics.emote.EmoteRuntime.clear();
        CosmeticConfig.save();
        dev.lin.client.cosmetics.sync.RemoteAssetLoader.close();
        CosmeticAssetManager.close();
        LunarAssetStore.close();
        FontManager.close();
        LinFeatures.closeClientResources();
    }
}
