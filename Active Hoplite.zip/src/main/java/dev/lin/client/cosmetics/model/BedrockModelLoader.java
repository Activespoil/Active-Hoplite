package dev.lin.client.cosmetics.model;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.joml.Vector4f;

public final class BedrockModelLoader {
   private static final float PIXEL = 1.0F / 16.0F;
   /** Motion belongs to an avatar; persistent Molang variables belong to its asset instance. */
   public static final class AnimationContext {
   private float worldXVelocity;
   private float worldYVelocity;
   private float worldZVelocity;
   private float worldGroundSpeed;
   private float worldAbsoluteSpeed;
   private float worldLocalXVelocity;
   private float worldLocalYVelocity;
   private float worldLocalZVelocity;
   private float worldSmoothLocalXVelocity;
   private float worldSmoothLocalYVelocity;
   private float worldSmoothLocalZVelocity;
   private float worldDistanceMoved;
   private float worldEntityYaw;
   private float worldEntityYawTarget;
   private float worldHeadYaw;
   private float worldHeadPitch;
   private boolean worldFlying;
   private boolean worldElytraFlying;
   private boolean worldSwimming;
   private boolean worldOnGround;
   private boolean worldCrouching;
   private boolean worldSprinting;
   private boolean worldInWater;
   private float worldCompanionGroundSpeed;
   private long lastMotionNanos;
   private int lastMotionTick = Integer.MIN_VALUE;
   private Map<JsonObject, PersistentAnimationVariables> PERSISTENT_VARIABLES =
      Collections.synchronizedMap(new WeakHashMap<>());


      public synchronized AnimationContext snapshot() {
         AnimationContext copy = new AnimationContext();
         copy.worldXVelocity = worldXVelocity;
         copy.worldYVelocity = worldYVelocity;
         copy.worldZVelocity = worldZVelocity;
         copy.worldGroundSpeed = worldGroundSpeed;
         copy.worldAbsoluteSpeed = worldAbsoluteSpeed;
         copy.worldLocalXVelocity = worldLocalXVelocity;
         copy.worldLocalYVelocity = worldLocalYVelocity;
         copy.worldLocalZVelocity = worldLocalZVelocity;
         copy.worldSmoothLocalXVelocity = worldSmoothLocalXVelocity;
         copy.worldSmoothLocalYVelocity = worldSmoothLocalYVelocity;
         copy.worldSmoothLocalZVelocity = worldSmoothLocalZVelocity;
         copy.worldDistanceMoved = worldDistanceMoved;
         copy.worldEntityYaw = worldEntityYaw;
         copy.worldEntityYawTarget = worldEntityYawTarget;
         copy.worldHeadYaw = worldHeadYaw;
         copy.worldHeadPitch = worldHeadPitch;
         copy.worldFlying = worldFlying;
         copy.worldElytraFlying = worldElytraFlying;
         copy.worldSwimming = worldSwimming;
         copy.worldOnGround = worldOnGround;
         copy.worldCrouching = worldCrouching;
         copy.worldSprinting = worldSprinting;
         copy.worldInWater = worldInWater;
         copy.worldCompanionGroundSpeed = worldCompanionGroundSpeed;
         copy.lastMotionNanos = lastMotionNanos;
         copy.lastMotionTick = lastMotionTick;
         copy.PERSISTENT_VARIABLES = PERSISTENT_VARIABLES;
         return copy;
      }
   }
   private static AnimationContext LOCAL_CONTEXT = new AnimationContext();
   private static final ThreadLocal<AnimationContext> CURRENT = new ThreadLocal<>();
   private static AnimationContext context() {
      AnimationContext current = CURRENT.get();
      return current == null ? LOCAL_CONTEXT : current;
   }
   public static synchronized void resetLocal() { LOCAL_CONTEXT=new AnimationContext(); }
   public static AnimationContext localSnapshot() {
      synchronized (BedrockModelLoader.class) { return LOCAL_CONTEXT.snapshot(); }
   }
   public static void withContext(AnimationContext value, Runnable action) {
      AnimationContext old = CURRENT.get();
      CURRENT.set(value);
      try { action.run(); } finally { if (old == null) CURRENT.remove(); else CURRENT.set(old); }
   }
   public static CosmeticMesh load(CompiledGeometry geometry, JsonObject animation,
          JsonObject definition, float time, boolean gui, AnimationContext context) {
      AnimationContext old = CURRENT.get();
      CURRENT.set(context);
      try { return load(geometry, animation, definition, time, gui); }
      finally { if (old == null) CURRENT.remove(); else CURRENT.set(old); }
   }

   public static CosmeticMesh loadForInstance(CompiledGeometry geometry, JsonObject animation,
          JsonObject definition, float time, AnimationContext motion, AnimationContext instance) {
      motion.PERSISTENT_VARIABLES = instance.PERSISTENT_VARIABLES;
      return load(geometry,animation,definition,time,false,motion);
   }

   private BedrockModelLoader() {
   }

   public static synchronized void updateWorldMotion(
                                        float xVelocity, float yVelocity,
                                        float zVelocity, float groundSpeed,
                                        float absoluteSpeed, float entityYaw,
                                        float entityYawTarget, float headYaw,
                                        float headPitch, int tick, boolean flying,
                                        boolean elytraFlying, boolean swimming,
                                        boolean onGround, boolean crouching,
                                        boolean sprinting, boolean inWater) {
      float radians = (float)Math.toRadians(entityYaw);
      float cos = (float)Math.cos(radians);
      float sin = (float)Math.sin(radians);
      float localX = xVelocity * cos + zVelocity * sin;
      float localZ = zVelocity * cos - xVelocity * sin;
      long now = System.nanoTime();
      float elapsed = context().lastMotionNanos == 0L ? 1.0F
         : Math.max(0.0F, Math.min(0.1F, (now - context().lastMotionNanos) / 1_000_000_000.0F));
      float smoothing = context().lastMotionNanos == 0L ? 1.0F
         : 1.0F - (float)Math.exp(-12.0F * elapsed);
      context().worldSmoothLocalXVelocity += (localX - context().worldSmoothLocalXVelocity) * smoothing;
      context().worldSmoothLocalYVelocity += (yVelocity - context().worldSmoothLocalYVelocity) * smoothing;
      context().worldSmoothLocalZVelocity += (localZ - context().worldSmoothLocalZVelocity) * smoothing;
      context().lastMotionNanos = now;
      if (tick != context().lastMotionTick) {
         int passed = context().lastMotionTick == Integer.MIN_VALUE ? 1
            : Math.max(1, Math.min(5, tick - context().lastMotionTick));
         context().worldDistanceMoved += groundSpeed * passed / 20.0F;
         context().lastMotionTick = tick;
      }
      context().worldXVelocity = xVelocity;
      context().worldYVelocity = yVelocity;
      context().worldZVelocity = zVelocity;
      context().worldGroundSpeed = Math.max(0.0F, groundSpeed);
      context().worldAbsoluteSpeed = Math.max(0.0F, absoluteSpeed);
      context().worldLocalXVelocity = localX;
      context().worldLocalYVelocity = yVelocity;
      context().worldLocalZVelocity = localZ;
      context().worldEntityYaw = entityYaw;
      context().worldEntityYawTarget = entityYawTarget;
      context().worldHeadYaw = wrapDegrees(headYaw - entityYaw);
      context().worldHeadPitch = headPitch;
      context().worldFlying = flying;
      context().worldElytraFlying = elytraFlying;
      context().worldSwimming = swimming;
      context().worldOnGround = onGround;
      context().worldCrouching = crouching;
      context().worldSprinting = sprinting;
      context().worldInWater = inWater;
   }

   public static void updateCompanionMotion(float groundSpeed) {
      context().worldCompanionGroundSpeed = Math.max(0.0F, groundSpeed);
   }

   public static CosmeticMesh load(JsonObject root) {
      return load(root, null, null);
   }

   public static CosmeticMesh load(JsonObject root, JsonObject animationRoot) {
      return load(root, animationRoot, null);
   }

   public static CosmeticMesh load(JsonObject root, JsonObject animationRoot, JsonObject definitionRoot) {
      return load(root, animationRoot, definitionRoot, 0.0F, true);
   }

   public static CosmeticMesh load(JsonObject root, JsonObject animationRoot,
                                   JsonObject definitionRoot, float timeSeconds,
                                   boolean inGui) {
      return load(compile(root, animationRoot), animationRoot, definitionRoot, timeSeconds, inGui);
   }

   /** Owned by one loaded asset; source geometry is immutable for that asset's lifetime. */
   public static final class CompiledGeometry {
      private final float textureWidth, textureHeight;
      private Map<JsonObject, KeyframeTrack> tracks = Map.of();
      private JsonObject animationSource;
      private final List<CompiledBone> bones;
      private final int vertexCapacity;
      private final Map<String, CompiledBone> byName;
      private CompiledGeometry(float width, float height, List<CompiledBone> bones,
                               Map<String, CompiledBone> byName) {
         this.textureWidth = width; this.textureHeight = height;
         this.bones = bones; this.byName = byName;
         this.vertexCapacity = bones.stream().flatMap(bone -> bone.cubes.stream()).mapToInt(cube -> cube.faces.size() * 4).sum();
      }
   }
   private record CompiledBone(String name, String parent, Vector3f pivot,
                               Vector3f rotation, float inflate, boolean mirror,
                               List<CompiledCube> cubes) {}

   private record Keyframe(double time, JsonElement value) {}
   private static final class KeyframeTrack {
      final List<Keyframe> source;
      final Keyframe[] sorted;
      KeyframeTrack(List<Keyframe> keys) {
         source = List.copyOf(keys);
         // Exceptional non-finite tracks retain the original selection rules.
         if (keys.stream().anyMatch(key -> !Double.isFinite(key.time))) { sorted = null; return; }
         List<Keyframe> ordered = new ArrayList<>(keys);
         ordered.sort((a, b) -> a.time == b.time ? 0 : Double.compare(a.time, b.time));
         List<Keyframe> unique = new ArrayList<>();
         for (Keyframe key : ordered)
            if (unique.isEmpty() || key.time != unique.getLast().time) unique.add(key);
         sorted = unique.toArray(Keyframe[]::new);
      }
      int ceiling(double time) {
         int low = 0, high = sorted.length;
         while (low < high) {
            int mid = (low + high) >>> 1;
            if (sorted[mid].time < time) low = mid + 1; else high = mid;
         }
         return low;
      }
   }


   public static CompiledGeometry compile(JsonObject root, JsonObject animations) {
      CompiledGeometry geometry = compile(root);
      Map<JsonObject, KeyframeTrack> tracks = new java.util.IdentityHashMap<>();
      compileTracks(animations, tracks);
      geometry.tracks = Collections.unmodifiableMap(tracks);
      geometry.animationSource = animations;
      return geometry;
   }

   private static void compileTracks(JsonElement value, Map<JsonObject, KeyframeTrack> tracks) {
      if (value == null) return;
      if (value.isJsonArray()) {
         for (JsonElement child : value.getAsJsonArray()) compileTracks(child, tracks);
      } else if (value.isJsonObject()) {
         JsonObject object = value.getAsJsonObject();
         List<Keyframe> keys = new ArrayList<>();
         for (var entry : object.entrySet()) {
            try { keys.add(new Keyframe(Double.parseDouble(entry.getKey()), entry.getValue())); }
            catch (NumberFormatException ignored) {}
            compileTracks(entry.getValue(), tracks);
         }
         // Stable sorting keeps the first authored value at equivalent numeric times.
         tracks.put(object, new KeyframeTrack(keys));
      }
   }

   public static CompiledGeometry compile(JsonObject root) {
      JsonArray geometries = root.getAsJsonArray("minecraft:geometry");
      if (geometries == null || geometries.isEmpty()) {
         throw new IllegalArgumentException("pet geometry is empty");
      }
      JsonObject geometry = geometries.get(0).getAsJsonObject();
      JsonObject description = geometry.getAsJsonObject("description");
      float textureWidth = number(description, "texture_width", 64.0F);
      float textureHeight = number(description, "texture_height", 64.0F);
      JsonArray bones = geometry.getAsJsonArray("bones");
      if (bones == null) {
         throw new IllegalArgumentException("pet geometry has no bones");
      }

      List<CompiledBone> compiled = new ArrayList<>();
      Map<String, CompiledBone> byName = new HashMap<>();
      for (JsonElement value : bones) {
         JsonObject bone = value.getAsJsonObject();
         String name = bone.has("name") ? bone.get("name").getAsString() : "";
         List<CompiledCube> cubes = new ArrayList<>();
         JsonArray sourceCubes = bone.getAsJsonArray("cubes");
         if (sourceCubes != null) for (JsonElement cube : sourceCubes) cubes.add(compileCube(cube.getAsJsonObject(), number(bone, "inflate", 0.0F), booleanValue(bone, "mirror", false)));
         CompiledBone entry = new CompiledBone(name,
            bone.has("parent") ? bone.get("parent").getAsString() : null,
            lunarPosition(vector(bone.getAsJsonArray("pivot"))),
            lunarRotation(vector(bone.getAsJsonArray("rotation"))),
            sourceCubes == null ? 0.0F : number(bone, "inflate", 0.0F),
            sourceCubes != null && booleanValue(bone, "mirror", false), List.copyOf(cubes));
         compiled.add(entry);
         if (bone.has("name")) byName.put(name, entry);
      }
      return new CompiledGeometry(textureWidth, textureHeight, List.copyOf(compiled), Map.copyOf(byName));
   }

   public static CosmeticMesh load(CompiledGeometry geometry, JsonObject animationRoot,
                                   JsonObject definitionRoot, float timeSeconds, boolean inGui) {
      float textureWidth = geometry.textureWidth, textureHeight = geometry.textureHeight;
      Map<String, CompiledBone> byName = geometry.byName;
      Map<String, Matrix4f> transforms = new HashMap<>();
      Map<String, AnimationTransform> animation = animationTransforms(
         animationRoot, definitionRoot, timeSeconds, inGui,
         geometry.animationSource == animationRoot ? geometry.tracks : Map.of());
      List<CosmeticVertex> vertices = new ArrayList<>(geometry.vertexCapacity);
      List<String> visiting = new ArrayList<>();
      for (CompiledBone bone : geometry.bones) {
         Matrix4f transform = boneTransform(bone, byName, transforms, animation, visiting);
         for (CompiledCube cube : bone.cubes) {
            addCube(vertices, cube, transform, textureWidth, textureHeight);
         }
      }
      if (vertices.isEmpty()) {
         throw new IllegalArgumentException("pet geometry has no visible cubes");
      }
      return CosmeticMesh.of(vertices.toArray(CosmeticVertex[]::new),
         Math.max(1, Math.round(textureWidth)), Math.max(1, Math.round(textureHeight)));
   }

   private static Matrix4f boneTransform(
      CompiledBone bone,
      Map<String, CompiledBone> bones,
      Map<String, Matrix4f> cache,
      Map<String, AnimationTransform> animation,
      List<String> visiting
   ) {
      String name = bone.name;
      Matrix4f cached = cache.get(name);
      if (cached != null) {
         return cached;
      }
      if (visiting.contains(name)) {
         return new Matrix4f();
      }
      visiting.add(name);
      Matrix4f transform = new Matrix4f();
      if (bone.parent != null) {
         CompiledBone parent = bones.get(bone.parent);
         if (parent != null) {
            transform.set(boneTransform(parent, bones, cache, animation, visiting));
         }
      }
      Vector3f pivot = bone.pivot;
      Vector3f rotation = bone.rotation;
      AnimationTransform animated = animation.getOrDefault(name, AnimationTransform.IDENTITY);
      transform.translate(-animated.position.x, animated.position.y, animated.position.z);
      transform.translate(pivot.x, pivot.y, pivot.z)
         .rotateZ((float)Math.toRadians(rotation.z + animated.rotation.z))
         .rotateY((float)Math.toRadians(rotation.y - animated.rotation.y))
         .rotateX((float)Math.toRadians(rotation.x - animated.rotation.x))
         .scale(animated.scale)
         .translate(-pivot.x, -pivot.y, -pivot.z);
      visiting.remove(name);
      cache.put(name, transform);
      return transform;
   }

   private record CompiledFace(float u, float v, float width, float height, float[] positions) {}
   private record CompiledCube(Vector3f pivot, Vector3f rotation, boolean mirror, List<CompiledFace> faces) {}

   private static void addCube(List<CosmeticVertex> target, CompiledCube cube,
                               Matrix4f boneTransform, float textureWidth, float textureHeight) {
      Matrix4f transform = new Matrix4f(boneTransform);
      // Preserve the original multiplication order; do not pre-transform vertices.
      if (cube.rotation != null) rotateAround(transform, cube.pivot, cube.rotation);
      for (CompiledFace face : cube.faces) {
         addBoxUvFace(target, transform, textureWidth, textureHeight, cube.mirror,
            face.u, face.v, face.width, face.height, face.positions);
      }
   }

   private static CompiledCube compileCube(JsonObject cube, float inheritedInflate, boolean inheritedMirror) {
      Vector3f origin = vector(cube.getAsJsonArray("origin"));
      Vector3f size = vector(cube.getAsJsonArray("size"));
      float inflate = number(cube, "inflate", inheritedInflate);
      float x0 = -(origin.x + size.x) - inflate;
      float y0 = origin.y - inflate;
      float z0 = origin.z - inflate;
      float x1 = -origin.x + inflate;
      float y1 = origin.y + size.y + inflate;
      float z1 = origin.z + size.z + inflate;
      // Opposite faces of zero-thickness cubes otherwise compete at exactly
      // the same depth in the no-cull entity pass (visible as flashing feathers).
      // 0.01 authored pixel is subpixel at preview size and preserves both UV sides.
      if (Math.abs(x1 - x0) < 1.0E-6F) { x0 -= 0.005F; x1 += 0.005F; }
      if (Math.abs(y1 - y0) < 1.0E-6F) { y0 -= 0.005F; y1 += 0.005F; }
      if (Math.abs(z1 - z0) < 1.0E-6F) { z0 -= 0.005F; z1 += 0.005F; }
      Vector3f pivot = cube.has("rotation") ? vector(cube.getAsJsonArray("pivot")) : null;
      Vector3f rotation = cube.has("rotation") ? vector(cube.getAsJsonArray("rotation")) : null;
      List<CompiledFace> target = new ArrayList<>(6);
      boolean mirror = booleanValue(cube, "mirror", inheritedMirror);
      JsonElement uv = cube.get("uv");
      if (uv != null && uv.isJsonObject()) {
         JsonObject faces = uv.getAsJsonObject();
         compileFace(target, faces, "west",  size.z, size.y,
            x0, y1, z1, x0, y1, z0, x0, y0, z0, x0, y0, z1);
         compileFace(target, faces, "east",  size.z, size.y,
            x1, y1, z0, x1, y1, z1, x1, y0, z1, x1, y0, z0);
         compileFace(target, faces, "north",  size.x, size.y,
            x0, y1, z0, x1, y1, z0, x1, y0, z0, x0, y0, z0);
         compileFace(target, faces, "south",  size.x, size.y,
            x1, y1, z1, x0, y1, z1, x0, y0, z1, x1, y0, z1);
         compileFace(target, faces, "up",  size.x, size.z,
            x0, y1, z1, x1, y1, z1, x1, y1, z0, x0, y1, z0);
         compileFace(target, faces, "down",  size.x, size.z,
            x0, y0, z0, x1, y0, z0, x1, y0, z1, x0, y0, z1);
      } else {
         Vector3f baseUv = uv != null && uv.isJsonArray() ? vector2(uv.getAsJsonArray()) : new Vector3f();
         float u = baseUv.x;
         float v = baseUv.y;
         target.add(new CompiledFace( u + size.z + size.x, v + size.z, size.z, size.y, new float[]{x0, y1, z1, x0, y1, z0, x0, y0, z0, x0, y0, z1}));
         target.add(new CompiledFace( u, v + size.z, size.z, size.y, new float[]{x1, y1, z0, x1, y1, z1, x1, y0, z1, x1, y0, z0}));
         target.add(new CompiledFace( u + size.z, v + size.z, size.x, size.y, new float[]{x0, y1, z0, x1, y1, z0, x1, y0, z0, x0, y0, z0}));
         target.add(new CompiledFace( u + size.z * 2 + size.x, v + size.z, size.x, size.y, new float[]{x1, y1, z1, x0, y1, z1, x0, y0, z1, x1, y0, z1}));
         target.add(new CompiledFace( u + size.z, v, size.x, size.z, new float[]{x0, y1, z1, x1, y1, z1, x1, y1, z0, x0, y1, z0}));
         target.add(new CompiledFace( u + size.z + size.x, v + size.z, size.x, -size.z, new float[]{x0, y0, z0, x1, y0, z0, x1, y0, z1, x0, y0, z1}));
      }
      return new CompiledCube(pivot, rotation, mirror, List.copyOf(target));
   }

   private static void compileFace(
      List<CompiledFace> target, JsonObject faces, String name,
      float defaultWidth, float defaultHeight, float... positions
   ) {
      JsonObject face = faces.getAsJsonObject(name);
      if (face == null || !face.has("uv")) {
         return;
      }
      Vector3f uv = vector2(face.getAsJsonArray("uv"));
      Vector3f uvSize = face.has("uv_size") ? vector2(face.getAsJsonArray("uv_size")) : new Vector3f(defaultWidth, defaultHeight, 0.0F);
      target.add(new CompiledFace(uv.x, uv.y, uvSize.x, uvSize.y, positions));
   }

   // Face generation is synchronous and non-recursive. Keep scratch state per worker;
   // only immutable CosmeticVertex values escape into the completed mesh.
   private static final ThreadLocal<FaceScratch> FACE_SCRATCH =
      ThreadLocal.withInitial(FaceScratch::new);

   private static final class FaceScratch {
      final Vector3f raw0 = new Vector3f(), raw1 = new Vector3f(), raw2 = new Vector3f();
      final Vector3f authoredNormal = new Vector3f(), edge = new Vector3f(), normal = new Vector3f();
      final Vector4f transformed = new Vector4f();
      final Vector3f[] points = {new Vector3f(), new Vector3f(), new Vector3f(), new Vector3f()};
   }

   private static void addBoxUvFace(
      List<CosmeticVertex> target, Matrix4f transform, float textureWidth, float textureHeight, boolean mirror,
      float u, float v, float width, float height, float... positions
   ) {
      FaceScratch scratch = FACE_SCRATCH.get();
      Vector3f raw0 = scratch.raw0.set(positions[0], positions[1], positions[2]);
      Vector3f raw1 = scratch.raw1.set(positions[3], positions[4], positions[5]);
      Vector3f raw2 = scratch.raw2.set(positions[6], positions[7], positions[8]);
      Vector3f authoredNormal = scratch.authoredNormal.set(raw1).sub(raw0)
         .cross(scratch.edge.set(raw2).sub(raw0));
      if (authoredNormal.lengthSquared() < 1.0E-8F) {
         return;
      }
      Vector3f[] points = scratch.points;
      for (int index = 0; index < 4; index++) {
         Vector4f transformed = transform.transform(scratch.transformed.set(positions[index * 3], positions[index * 3 + 1], positions[index * 3 + 2], 1.0F));
         points[index].set(transformed.x, transformed.y, transformed.z);
      }
      Vector3f normal = scratch.normal.set(points[1]).sub(points[0]).cross(scratch.edge.set(points[2]).sub(points[0]));
      if (normal.lengthSquared() < 1.0E-8F) {
         normal.set(authoredNormal);
      }
      normal.normalize();
      float u0 = u / textureWidth;
      float u1 = (u + width) / textureWidth;
      float v0 = v / textureHeight;
      float v1 = (v + height) / textureHeight;
      if (mirror) {
         float swap = u0;
         u0 = u1;
         u1 = swap;
      }
      float outerU = mirror ? u0 : u1;
      float innerU = mirror ? u1 : u0;
      // Minecraft's entity cutout pipeline consumes QUADS. Supplying the old
      // triangle list made every four adjacent triangle vertices form an
      // unrelated quad, stretching both the pet bones and their texture.
      for (int index = 0; index < 4; index++) {
         Vector3f point = points[index];
         target.add(new CosmeticVertex(point.x * PIXEL, -point.y * PIXEL, point.z * PIXEL, (index == 0 || index == 3) ? outerU : innerU, index < 2 ? v0 : v1, normal.x, -normal.y, normal.z));
      }
   }

   private static Map<String, AnimationTransform> animationTransforms(
      JsonObject root, JsonObject definitionRoot, float timeSeconds, boolean inGui, Map<JsonObject, KeyframeTrack> tracks
   ) {
      if (root == null) {
         return Map.of();
      }
      JsonObject animations = root.getAsJsonObject("animations");
      if (animations == null || animations.isEmpty()) {
         return Map.of();
      }
      Map<String, Double> variables = animationVariables(
         timeSeconds, inGui, definitionRoot);
      List<String> selectedNames = selectedAnimations(definitionRoot, animations, variables);
      Map<String, AnimationTransformBuilder> merged = new HashMap<>();
      for (String selectedName : selectedNames) {
         JsonObject selected = animations.getAsJsonObject(selectedName);
         if (selected == null) {
            continue;
         }
         JsonObject animatedBones = selected.getAsJsonObject("bones");
         if (animatedBones == null) {
            continue;
         }
         float length = number(selected, "animation_length", 0.0F);
         float animationTime = length > 0.0F
            ? (booleanValue(selected, "loop", true) ? timeSeconds % length : Math.min(timeSeconds, length))
            : timeSeconds;
         queryVariable(variables, "anim_time", animationTime);
         for (Map.Entry<String, JsonElement> entry : animatedBones.entrySet()) {
            if (!entry.getValue().isJsonObject()) {
               continue;
            }
            JsonObject channels = entry.getValue().getAsJsonObject();
            AnimationTransformBuilder transform = merged.computeIfAbsent(entry.getKey(), ignored -> new AnimationTransformBuilder());
            if (channels.has("position")) {
               transform.position = animationVector(channels.get("position"), new Vector3f(), variables, animationTime, tracks);
            }
            if (channels.has("rotation")) {
               transform.rotation = animationVector(channels.get("rotation"), new Vector3f(), variables, animationTime, tracks);
            }
            if (channels.has("scale")) {
               transform.scale = animationVector(channels.get("scale"), new Vector3f(1.0F, 1.0F, 1.0F), variables, animationTime, tracks);
            }
         }
      }
      Map<String, AnimationTransform> result = new HashMap<>();
      for (Map.Entry<String, AnimationTransformBuilder> entry : merged.entrySet()) {
         result.put(entry.getKey(), entry.getValue().build());
      }
      persistVariables(definitionRoot, variables, inGui);
      return result;
   }

   public static List<String> previewAnimationNames(JsonObject animationRoot, JsonObject definitionRoot) {
      if (animationRoot == null) {
         return List.of();
      }
      JsonObject animations = animationRoot.getAsJsonObject("animations");
      if (animations == null || animations.isEmpty()) {
         return List.of();
      }
      return List.copyOf(selectedAnimations(definitionRoot, animations,
         animationVariables(0.0F, true, null)));
   }

   private static List<String> selectedAnimations(
      JsonObject definitionRoot, JsonObject animations, Map<String, Double> variables
   ) {
      List<String> selected = new ArrayList<>();
      String type = definitionRoot != null && definitionRoot.has("type")
         ? definitionRoot.get("type").getAsString() : "";
      if (type.equalsIgnoreCase("companion")) {
         boolean inWater = variables.getOrDefault("q.is_in_water", 0.0) > 0.5;
         boolean sprinting = variables.getOrDefault("q.is_sprinting", 0.0) > 0.5;
         boolean moving = variables.getOrDefault("q.is_moving", 0.0) > 0.5;
         if (inWater && animations.has("swimming")) return List.of("swimming");
         if (sprinting && animations.has("run")) return List.of("run");
         if (moving && animations.has("walk")) return List.of("walk");
         if (animations.has("idle")) return List.of("idle");
      }
      JsonObject stateMachine = definitionRoot == null ? null : definitionRoot.getAsJsonObject("state_machine");
      JsonArray controllers = stateMachine == null ? null : stateMachine.getAsJsonArray("controllers");
      if (controllers != null) {
         for (JsonElement controllerValue : controllers) {
            if (!controllerValue.isJsonObject()) {
               continue;
            }
            JsonArray states = controllerValue.getAsJsonObject().getAsJsonArray("states");
            if (states == null) {
               continue;
            }
            for (JsonElement stateValue : states) {
               if (!stateValue.isJsonObject()) {
                  continue;
               }
               JsonObject state = stateValue.getAsJsonObject();
               JsonElement animationName = state.get("anim");
               JsonElement condition = state.get("plays_when");
               if (animationName == null || !animationName.isJsonPrimitive() || condition == null) {
                  continue;
               }
               if (MolangExpression.evaluate(condition, new HashMap<>(variables)) != 0.0F) {
                  String name = animationName.getAsString();
                  if (animations.has(name)) {
                     selected.add(name);
                  }
                  break;
               }
            }
         }
      }
      if (!selected.isEmpty()) {
         return selected;
      }
      JsonElement defaultAnimation = definitionRoot == null
         ? null : definitionRoot.get("default_anim");
      if (defaultAnimation != null) {
         if (defaultAnimation.isJsonPrimitive()) {
            String name = defaultAnimation.getAsString();
            if (animations.has(name)) return List.of(name);
         } else if (defaultAnimation.isJsonObject()) {
            for (Map.Entry<String, JsonElement> entry
               : defaultAnimation.getAsJsonObject().entrySet()) {
               if (animations.has(entry.getKey())
                  && MolangExpression.evaluate(entry.getValue(),
                     new HashMap<>(variables)) != 0.0F) {
                  return List.of(entry.getKey());
               }
            }
         }
      }
      if (animations.has("main")) {
         return List.of("main");
      }
      for (Map.Entry<String, JsonElement> entry : animations.entrySet()) {
         if (entry.getKey().endsWith(".main") && entry.getValue().isJsonObject()) {
            return List.of(entry.getKey());
         }
      }
      boolean guiPreview = variables.getOrDefault("q.is_in_gui",
         variables.getOrDefault("is_in_gui", 0.0)) > 0.5;
      if (guiPreview) {
         if (animations.has("gui") && animations.get("gui").isJsonObject()) {
            return List.of("gui");
         }
         if (animations.has("preview") && animations.get("preview").isJsonObject()) {
            return List.of("preview");
         }
         if (animations.has("idle") && animations.get("idle").isJsonObject()) {
            return List.of("idle");
         }
         List<String> idleLayers = new ArrayList<>();
         for (Map.Entry<String, JsonElement> entry : animations.entrySet()) {
            if (entry.getKey().toLowerCase(java.util.Locale.ROOT).endsWith(".idle")
               && entry.getValue().isJsonObject()) {
               idleLayers.add(entry.getKey());
            }
         }
         if (!idleLayers.isEmpty()) return List.copyOf(idleLayers);
         List<String> previewLayers = new ArrayList<>();
         for (Map.Entry<String, JsonElement> entry : animations.entrySet()) {
            String name = entry.getKey().toLowerCase(java.util.Locale.ROOT);
            if (entry.getValue().isJsonObject()
               && (name.endsWith(".gui") || name.endsWith(".preview"))) {
               previewLayers.add(entry.getKey());
            }
         }
         if (!previewLayers.isEmpty()) return List.copyOf(previewLayers);
         for (Map.Entry<String, JsonElement> entry : animations.entrySet()) {
            if (entry.getValue().isJsonObject()) {
               return List.of(entry.getKey());
            }
         }
      }
      if (definitionRoot == null) {
         for (Map.Entry<String, JsonElement> entry : animations.entrySet()) {
            if (entry.getValue().isJsonObject()) {
               return List.of(entry.getKey());
            }
         }
      }
      return List.of();
   }

   private static Map<String, Double> animationVariables(float timeSeconds,
                                                          boolean inGui,
                                                          JsonObject definitionRoot) {
      Map<String, Double> variables = new HashMap<>();
      if (definitionRoot != null) {
         synchronized (context().PERSISTENT_VARIABLES) {
            PersistentAnimationVariables contexts =
               context().PERSISTENT_VARIABLES.get(definitionRoot);
            Map<String, Double> saved = contexts == null ? null
               : contexts.forContext(inGui);
            if (saved != null) variables.putAll(saved);
         }
         JsonArray options = definitionRoot.getAsJsonArray("cosmetic_options");
         if (options != null) {
            for (JsonElement optionValue : options) {
               if (!optionValue.isJsonObject()) continue;
               JsonObject option = optionValue.getAsJsonObject();
               if (!option.has("molang_query") || !option.has("default")) continue;
               JsonElement defaultValue = option.get("default");
               if (!defaultValue.isJsonPrimitive()) continue;
               double value;
               if (defaultValue.getAsJsonPrimitive().isBoolean()) {
                  value = defaultValue.getAsBoolean() ? 1.0 : 0.0;
               } else if (defaultValue.getAsJsonPrimitive().isNumber()) {
                  value = defaultValue.getAsDouble();
               } else {
                  continue;
               }
               variables.put(option.get("molang_query").getAsString()
                  .toLowerCase(java.util.Locale.ROOT), value);
            }
         }
      }
      boolean companion = definitionRoot != null && definitionRoot.has("type")
         && "companion".equalsIgnoreCase(
            definitionRoot.get("type").getAsString());
      float groundSpeed = inGui ? 0.0F
         : companion ? context().worldCompanionGroundSpeed : context().worldGroundSpeed;
      float absoluteSpeed = inGui ? 0.0F
         : companion ? context().worldCompanionGroundSpeed : context().worldAbsoluteSpeed;
      float xVelocity = inGui ? 0.0F : context().worldXVelocity;
      float yVelocity = inGui ? 0.0F : context().worldYVelocity;
      float zVelocity = inGui ? 0.0F : context().worldZVelocity;
      float localXVelocity = inGui ? 0.0F : context().worldLocalXVelocity;
      float localYVelocity = inGui ? 0.0F : context().worldLocalYVelocity;
      float localZVelocity = inGui ? 0.0F
         : companion ? context().worldCompanionGroundSpeed : context().worldLocalZVelocity;
      float smoothLocalX = inGui ? 0.0F : context().worldSmoothLocalXVelocity;
      float smoothLocalY = inGui ? 0.0F : context().worldSmoothLocalYVelocity;
      float smoothLocalZ = inGui ? 0.0F : context().worldSmoothLocalZVelocity;
      queryVariable(variables, "is_in_gui", inGui ? 1.0 : 0.0);
      queryVariable(variables, "is_in_preview_model", inGui ? 1.0 : 0.0);
      queryVariable(variables, "x_velocity", xVelocity);
      queryVariable(variables, "y_velocity", yVelocity);
      queryVariable(variables, "z_velocity", zVelocity);
      queryVariable(variables, "local_x_velocity", localXVelocity);
      queryVariable(variables, "local_y_velocity", localYVelocity);
      queryVariable(variables, "local_z_velocity", localZVelocity);
      queryVariable(variables, "is_on_ground",
         !inGui && context().worldOnGround ? 1.0 : 0.0);
      queryVariable(variables, "absolute_speed", absoluteSpeed);
      queryVariable(variables, "ground_speed", groundSpeed);
      queryVariable(variables, "instant_ground_speed", groundSpeed);
      queryVariable(variables, "is_moving",
         !inGui && groundSpeed > 0.25F ? 1.0 : 0.0);
      queryVariable(variables, "is_flying", !inGui && context().worldFlying ? 1.0 : 0.0);
      queryVariable(variables, "is_elytra_flying", !inGui && context().worldElytraFlying ? 1.0 : 0.0);
      queryVariable(variables, "is_swimming", !inGui && context().worldSwimming ? 1.0 : 0.0);
      queryVariable(variables, "is_crouching", !inGui && context().worldCrouching ? 1.0 : 0.0);
      boolean sprinting = companion
         ? context().worldCompanionGroundSpeed > 2.4F : context().worldSprinting;
      queryVariable(variables, "is_sprinting", !inGui && sprinting ? 1.0 : 0.0);
      queryVariable(variables, "is_running", !inGui && sprinting ? 1.0 : 0.0);
      queryVariable(variables, "is_in_water", !inGui && context().worldInWater ? 1.0 : 0.0);
      queryVariable(variables, "entity_y_rotation", inGui ? 0.0F : context().worldEntityYaw);
      queryVariable(variables, "entity_y_rotation_target",
         inGui ? 0.0F : context().worldEntityYawTarget);
      queryVariable(variables, "body_y_rotation", 0.0F);
      queryVariable(variables, "body_x_rotation",
         !inGui && context().worldSwimming ? context().worldHeadPitch : 0.0F);
      queryVariable(variables, "head_y_rotation", inGui ? 0.0F : context().worldHeadYaw);
      queryVariable(variables, "head_x_rotation", inGui ? 0.0F : context().worldHeadPitch);
      queryVariable(variables, "life_time", timeSeconds);
      queryVariable(variables, "anim_time", timeSeconds);
      queryVariable(variables, "tick", Math.floor(timeSeconds * 20.0F));
      queryVariable(variables, "partial_ticks",
         timeSeconds * 20.0F - (float)Math.floor(timeSeconds * 20.0F));
      variables.put("in_water", !inGui && context().worldInWater ? 1.0 : 0.0);
      variables.put("c.afk_timer", 0.0);
      variables.put("c.tmul", 150.0);
      variables.put("c.ftmul", 220.0);
      variables.put("c.normalized_ground_speed",
         (double)Math.min(1.0F, groundSpeed / 4.317F));
      variables.put("c.local_x_velocity_smoothed", (double)smoothLocalX);
      variables.put("c.local_y_velocity_smoothed", (double)smoothLocalY);
      variables.put("c.local_z_velocity_smoothed", (double)smoothLocalZ);
      variables.put("c.y_velocity_smoothed", (double)smoothLocalY);
      variables.put("c.lvs_x", (double)smoothLocalX);
      variables.put("c.lvs_y", (double)smoothLocalY);
      variables.put("c.lvs_z", (double)smoothLocalZ);
      variables.put("c.distance_moved", inGui ? 0.0 : (double)context().worldDistanceMoved);
      variables.put("c.is_swimming_smoothed",
         !inGui && context().worldSwimming ? 1.0 : 0.0);
      variables.put("c.in_special_env", 0.0);
      return variables;
   }

   private static void persistVariables(JsonObject definitionRoot,
                                        Map<String, Double> variables,
                                        boolean inGui) {
      if (definitionRoot == null) return;
      Map<String, Double> saved = new HashMap<>();
      for (Map.Entry<String, Double> entry : variables.entrySet()) {
         if (entry.getKey().startsWith("v.")
            || entry.getKey().startsWith("variable.")) {
            saved.put(entry.getKey(), entry.getValue());
         }
      }
      synchronized (context().PERSISTENT_VARIABLES) {
         PersistentAnimationVariables contexts = context().PERSISTENT_VARIABLES
            .computeIfAbsent(definitionRoot,
               ignored -> new PersistentAnimationVariables());
         contexts.set(inGui, saved);
      }
   }

   private static float wrapDegrees(float value) {
      float wrapped = value % 360.0F;
      if (wrapped >= 180.0F) wrapped -= 360.0F;
      if (wrapped < -180.0F) wrapped += 360.0F;
      return wrapped;
   }

   private static void queryVariable(Map<String, Double> variables, String name, double value) {
      variables.put("q." + name, value);
      variables.put("query." + name, value);
   }

   private static Vector3f animationVector(JsonElement value, Vector3f fallback,
                                           Map<String, Double> variables, float time, Map<JsonObject, KeyframeTrack> tracks) {
      if (value == null || value.isJsonNull()) {
         return new Vector3f(fallback);
      }
      if (value.isJsonArray()) {
         JsonArray values = value.getAsJsonArray();
         return new Vector3f(
            animationComponent(values, 0, fallback.x, variables),
            animationComponent(values, 1, fallback.y, variables),
            animationComponent(values, 2, fallback.z, variables)
         );
      }
      if (value.isJsonPrimitive()) {
         float uniform = MolangExpression.evaluate(value, variables);
         return new Vector3f(uniform, uniform, uniform);
      }
      JsonObject object = value.getAsJsonObject();
      if (object.has("vector")) {
         return animationVector(object.get("vector"), fallback, variables, time, tracks);
      }
      if (object.has("post")) {
         return animationVector(object.get("post"), fallback, variables, time, tracks);
      }
      if (object.has("pre")) {
         return animationVector(object.get("pre"), fallback, variables, time, tracks);
      }
      JsonElement before = null;
      JsonElement after = null;
      double beforeTime = Double.NEGATIVE_INFINITY;
      double afterTime = Double.POSITIVE_INFINITY;
      KeyframeTrack compiled = tracks.get(object);
      if (compiled != null && compiled.sorted != null && Float.isFinite(time)) {
         int next = compiled.ceiling(time);
         int previous = next < compiled.sorted.length && compiled.sorted[next].time == time ? next : next - 1;
         if (previous >= 0) { beforeTime = compiled.sorted[previous].time; before = compiled.sorted[previous].value; }
         if (next < compiled.sorted.length) { afterTime = compiled.sorted[next].time; after = compiled.sorted[next].value; }
      } else if (compiled != null) {
         for (Keyframe key : compiled.source) {
            double keyTime = key.time;
            if (keyTime <= time && keyTime > beforeTime) {
               beforeTime = keyTime; before = key.value;
            }
            if (keyTime >= time && keyTime < afterTime) {
               afterTime = keyTime; after = key.value;
            }
         }
      } else {
      for (Map.Entry<String, JsonElement> entry : object.entrySet()) {
         try {
            double keyTime = Double.parseDouble(entry.getKey());
            if (keyTime <= time && keyTime > beforeTime) {
               beforeTime = keyTime;
               before = entry.getValue();
            }
            if (keyTime >= time && keyTime < afterTime) {
               afterTime = keyTime;
               after = entry.getValue();
            }
         } catch (NumberFormatException ignored) {
         }
      }
      }
      if (before == null) {
         before = after;
         beforeTime = afterTime;
      }
      if (after == null) {
         after = before;
         afterTime = beforeTime;
      }
      if (before == null) {
         return new Vector3f(fallback);
      }
      Vector3f start = animationVector(keyframeValue(before, false),
         fallback, variables, time, tracks);
      if (after == before || afterTime <= beforeTime) {
         return start;
      }
      Vector3f end = animationVector(keyframeValue(after, true),
         fallback, variables, time, tracks);
      float progress = (float)((time - beforeTime) / (afterTime - beforeTime));
      progress = ease(before, Math.max(0.0F, Math.min(1.0F, progress)));
      return start.lerp(end, progress);
   }

   private static JsonElement keyframeValue(JsonElement value, boolean incoming) {
      if (value == null || !value.isJsonObject()) return value;
      JsonObject object = value.getAsJsonObject();
      String endpoint = incoming ? "pre" : "post";
      if (object.has(endpoint)) return object.get(endpoint);
      return value;
   }

   private static float ease(JsonElement keyframe, float progress) {
      if (keyframe == null || !keyframe.isJsonObject()) return progress;
      JsonObject object = keyframe.getAsJsonObject();
      if (!object.has("easing") || !object.get("easing").isJsonPrimitive()) {
         return progress;
      }
      String easing = object.get("easing").getAsString().toLowerCase();
      float t = progress;
      return switch (easing) {
         case "step" -> 0.0F;
         case "easeinquad" -> t * t;
         case "easeoutquad" -> 1.0F - (1.0F - t) * (1.0F - t);
         case "easeinoutquad" -> t < 0.5F ? 2.0F * t * t
            : 1.0F - (float)Math.pow(-2.0F * t + 2.0F, 2.0) / 2.0F;
         case "easeincubic" -> t * t * t;
         case "easeinoutcubic" -> t < 0.5F ? 4.0F * t * t * t
            : 1.0F - (float)Math.pow(-2.0F * t + 2.0F, 3.0) / 2.0F;
         case "easeinoutquart" -> t < 0.5F ? 8.0F * t * t * t * t
            : 1.0F - (float)Math.pow(-2.0F * t + 2.0F, 4.0) / 2.0F;
         case "easeinquint" -> t * t * t * t * t;
         case "easeinoutquint" -> t < 0.5F ? 16.0F * t * t * t * t * t
            : 1.0F - (float)Math.pow(-2.0F * t + 2.0F, 5.0) / 2.0F;
         case "easeinsine" -> 1.0F - (float)Math.cos(t * Math.PI / 2.0);
         case "easeoutsine" -> (float)Math.sin(t * Math.PI / 2.0);
         case "easeinoutsine" -> -((float)Math.cos(Math.PI * t) - 1.0F) / 2.0F;
         case "easeinexpo" -> t == 0.0F ? 0.0F
            : (float)Math.pow(2.0, 10.0F * t - 10.0F);
         case "easeoutexpo" -> t == 1.0F ? 1.0F
            : 1.0F - (float)Math.pow(2.0, -10.0F * t);
         case "easeinoutexpo" -> t == 0.0F ? 0.0F : t == 1.0F ? 1.0F
            : t < 0.5F ? (float)Math.pow(2.0, 20.0F * t - 10.0F) / 2.0F
            : (2.0F - (float)Math.pow(2.0, -20.0F * t + 10.0F)) / 2.0F;
         case "easeinback" -> 2.70158F * t * t * t - 1.70158F * t * t;
         case "easeoutback" -> 1.0F + 2.70158F
            * (float)Math.pow(t - 1.0F, 3.0) + 1.70158F
            * (float)Math.pow(t - 1.0F, 2.0);
         case "easeinoutback" -> t < 0.5F
            ? (float)(Math.pow(2.0F * t, 2.0)
               * ((2.5949095F + 1.0F) * 2.0F * t - 2.5949095F)) / 2.0F
            : (float)(Math.pow(2.0F * t - 2.0F, 2.0)
               * ((2.5949095F + 1.0F) * (t * 2.0F - 2.0F)
               + 2.5949095F) + 2.0F) / 2.0F;
         case "easeinoutcirc" -> t < 0.5F
            ? (1.0F - (float)Math.sqrt(1.0F - (float)Math.pow(2.0F * t, 2.0))) / 2.0F
            : ((float)Math.sqrt(1.0F - (float)Math.pow(-2.0F * t + 2.0F, 2.0))
               + 1.0F) / 2.0F;
         default -> t;
      };
   }

   private static float animationComponent(JsonArray values, int index, float fallback, Map<String, Double> variables) {
      return index < values.size() ? MolangExpression.evaluate(values.get(index), variables) : fallback;
   }

   private static void rotateAround(Matrix4f matrix, Vector3f pivot, Vector3f rotation) {
      if (rotation.lengthSquared() == 0.0F) {
         return;
      }
      pivot = lunarPosition(pivot);
      rotation = lunarRotation(rotation);
      matrix.translate(pivot.x, pivot.y, pivot.z)
         .rotateZ((float)Math.toRadians(rotation.z))
         .rotateY((float)Math.toRadians(rotation.y))
         .rotateX((float)Math.toRadians(rotation.x))
         .translate(-pivot.x, -pivot.y, -pivot.z);
   }

   private static Vector3f lunarPosition(Vector3f value) {
      return new Vector3f(-value.x, value.y, value.z);
   }

   private static Vector3f lunarRotation(Vector3f value) {
      return new Vector3f(-value.x, -value.y, value.z);
   }

   private static Vector3f vector(JsonArray values) {
      if (values == null) {
         return new Vector3f();
      }
      return new Vector3f(component(values, 0), component(values, 1), component(values, 2));
   }

   private static Vector3f vector2(JsonArray values) {
      return values == null ? new Vector3f() : new Vector3f(component(values, 0), component(values, 1), 0.0F);
   }

   private static float component(JsonArray values, int index) {
      return index < values.size() ? values.get(index).getAsFloat() : 0.0F;
   }

   private static float number(JsonObject object, String name, float fallback) {
      return object != null && object.has(name) ? object.get(name).getAsFloat() : fallback;
   }

   private static boolean booleanValue(JsonObject object, String name, boolean fallback) {
      return object != null && object.has(name) && !object.get(name).isJsonNull() ? object.get(name).getAsBoolean() : fallback;
   }

   private record AnimationTransform(Vector3f position, Vector3f rotation, Vector3f scale) {
      private static final AnimationTransform IDENTITY = new AnimationTransform(
         new Vector3f(), new Vector3f(), new Vector3f(1.0F, 1.0F, 1.0F)
      );
   }

   private static final class AnimationTransformBuilder {
      private Vector3f position = new Vector3f();
      private Vector3f rotation = new Vector3f();
      private Vector3f scale = new Vector3f(1.0F, 1.0F, 1.0F);

      private AnimationTransform build() {
         return new AnimationTransform(position, rotation, scale);
      }
   }

   private static final class PersistentAnimationVariables {
      private Map<String, Double> world = Map.of();
      private Map<String, Double> gui = Map.of();

      private Map<String, Double> forContext(boolean inGui) {
         return inGui ? gui : world;
      }

      private void set(boolean inGui, Map<String, Double> values) {
         if (inGui) {
            gui = values;
         } else {
            world = values;
         }
      }
   }
}
