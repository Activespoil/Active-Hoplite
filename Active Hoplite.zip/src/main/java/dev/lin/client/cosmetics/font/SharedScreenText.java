package dev.lin.client.cosmetics.font;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.renderer.texture.AbstractTexture;
import net.minecraft.resources.Identifier;
import java.lang.reflect.Method;
import java.util.*;

/** GPU glyph textures prepared at the native render boundary, never during GUI extraction. */
public final class SharedScreenText {
    private static Method measure;
    private static Method layoutVersion;
    private static String menuFont;
    private static long fontVersion;
    private static final long BUDGET = 64L * 1024 * 1024;
    private static long nextId, frame, bytes;
    private static final Map<Key, Line> CACHE = new LinkedHashMap<>(128,.75f,true);
    private static final List<Job> PENDING = new ArrayList<>();
    private record Key(String text,float size,float density,String font,long version) {}
    private static final class Line {
        final GlyphTexture texture; final Identifier id; final float advance; long used;
        Line(GlyphTexture texture, Identifier id,float advance){this.texture=texture;this.id=id;this.advance=advance;}
    }
    public record Job(GlyphTexture texture,String text,float size,int color,float density,String font) {}
    public static final class GlyphTexture extends AbstractTexture {
        GlyphTexture(int width,int height) {
            var device=RenderSystem.getDevice();
            texture=device.createTexture("Lin shared glyphs",GpuTexture.USAGE_TEXTURE_BINDING | GpuTexture.USAGE_RENDER_ATTACHMENT,
                    TextureFormat.RGBA8,width,height,1,1);
            textureView=device.createTextureView(texture);
            sampler=RenderSystem.getSamplerCache().getClampToEdge(FilterMode.LINEAR);
        }
    }
    static boolean active() {
        var screen=dev.lin.client.cosmetics.ui.SystemNavigation.activeScreen();
        return screen instanceof dev.lin.client.cosmetics.ui.CosmeticLockerScreen;
    }
    static float width(String text,float size) {
        try {
            bindSettingsFont();
            return ((Number)measure.invoke(null,text,size)).floatValue();
        }catch(ReflectiveOperationException e){throw new IllegalStateException("Shared screen font metrics",e);}
    }
    public static void beginFrame() {
        try {
            bindSettingsFont();
            fontVersion=((Number)layoutVersion.invoke(null)).longValue();
        }catch(ReflectiveOperationException e){throw new IllegalStateException("Shared settings font version",e);}
        frame++;
        SharedMenuText.beginFrame();
        // Evict only before extraction. Never destroy a texture referenced by this frame's GUI commands.
        var it=CACHE.entrySet().iterator();
        while((CACHE.size()>1024 || bytes>BUDGET) && it.hasNext()){
            Line line=it.next().getValue();it.remove();
            bytes-=(long)line.texture.getTexture().getWidth(0)*line.texture.getTexture().getHeight(0)*4;
            PENDING.removeIf(job->job.texture()==line.texture);
            Minecraft.getInstance().getTextureManager().release(line.id);
        }
    }
    static float draw(GuiGraphics graphics,String text,float x,float y,float size,int color) {
        try {bindSettingsFont();}
        catch(ReflectiveOperationException e){throw new IllegalStateException("Shared settings font",e);}
        float advance=width(text,size);
        SharedMenuText.add(graphics,text,x,y,size,color);
        return advance;
    }
    private static void bindSettingsFont() throws ReflectiveOperationException {
        if(measure!=null)return;
        Class<?> renderer=Class.forName("com.linclient.client.render.font.FontRenderer");
        menuFont=(String)renderer.getField("DEFAULT").get(null);
        layoutVersion=renderer.getMethod("layoutVersion");
        measure=renderer.getMethod("measureTextWidth",String.class,float.class);
    }
    /** Baseline-based HUD text joins the same deferred queue as native item icons. */
    public static float drawHud(GuiGraphics graphics,String text,float x,float baseline,float size,
                                int color,String font,float advance) {
        return draw(graphics,text,x,baseline-size,size,color,font,advance);
    }
    private static float draw(GuiGraphics graphics,String text,float x,float y,float size,int color,
                              String font,float advance) {
        if(text==null || text.isEmpty() || color>>>24==0)return advance;
        var pose=graphics.pose();
        // Opening/hover scale animation shares a bounded set of density variants.
        float density=dev.lin.client.cosmetics.render.SkijaUiRaster.rasterDensity(graphics);
        float padding=Math.max(size*.5f,3/density);
        Key key=new Key(text,size,density,font,fontVersion);
        Line line=CACHE.get(key);
        if(line==null){
            if(Float.isNaN(advance))advance=width(text,size);
            int w=Math.max(1,(int)Math.ceil((advance+padding*2)*density));
            int h=Math.max(1,(int)Math.ceil((size*1.7f+padding*2)*density));
            var texture=new GlyphTexture(w,h);
            var id=Identifier.fromNamespaceAndPath("lin_client","shared_glyph/"+nextId++);
            Minecraft.getInstance().getTextureManager().register(id,texture);
            line=new Line(texture,id,advance);CACHE.put(key,line);
            bytes+=(long)w*h*4;
            PENDING.add(new Job(texture,text,size,0xffffffff,density,font));
        }
        line.used=frame;
        int w=line.texture.getTexture().getWidth(0),h=line.texture.getTexture().getHeight(0);
        pose.pushMatrix();
        try{
            pose.translate(x-padding,y-padding);pose.scale(1/density,1/density);
            graphics.blit(RenderPipelines.GUI_TEXTURED_PREMULTIPLIED_ALPHA,line.id,0,0,0,0,w,h,w,h,premultiply(color));
        }finally{pose.popMatrix();}
        return line.advance;
    }
    public static List<Job> takePending(){var jobs=List.copyOf(PENDING);PENDING.clear();return jobs;}
    private static int premultiply(int color) {
        int a=color>>>24;
        return a<<24 | (((color>>>16)&255)*a+127)/255<<16
                | (((color>>>8)&255)*a+127)/255<<8 | ((color&255)*a+127)/255;
    }
    static void close(){
        PENDING.clear();
        for(Line line:CACHE.values())Minecraft.getInstance().getTextureManager().release(line.id);
        CACHE.clear();bytes=0;
    }
    private SharedScreenText(){}
}
