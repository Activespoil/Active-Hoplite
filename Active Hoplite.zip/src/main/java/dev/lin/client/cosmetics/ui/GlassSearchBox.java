package dev.lin.client.cosmetics.ui;

import dev.lin.client.cosmetics.font.FontManager;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import java.util.function.Consumer;

public final class GlassSearchBox extends EditBox {
   private float uiScale = 1.0F;
   private float contentLeft;
   private float contentWidth = 1.0F;
   private float visualFontSize = 10.0F;
   private int displayStart;

   public GlassSearchBox(Font font, int x, int y, int width, int height, Component narration) {
      super(font, x, y, width, height, narration);
      this.setBordered(false);
      this.setTextShadow(false);
   }

   public void setVisualMetrics(float uiScale, float contentLeft, float contentWidth, float fontSize) {
      this.uiScale = Math.max(0.01F, uiScale);
      this.contentLeft = Math.max(0.0F, contentLeft);
      this.contentWidth = Math.max(1.0F, contentWidth);
      this.visualFontSize = fontSize;
   }

   public void setChangeListener(Consumer<String> listener) {
      // A typed call is remapped by Loom; literal reflection names are not.
      this.setResponder(listener);
   }

   public GlassSearchBox.VisibleText visibleText() {
      String value = this.getValue();
      int cursor = clampToBoundary(value, this.getCursorPosition());
      this.displayStart = clampToBoundary(value, Math.min(this.displayStart, value.length()));
      if (cursor < this.displayStart) {
         this.displayStart = cursor;
      }

      while (this.displayStart < cursor && FontManager.widthRegular(value.substring(this.displayStart, cursor), this.visualFontSize) > this.contentWidth) {
         this.displayStart = nextBoundary(value, this.displayStart);
      }

      while (this.displayStart > 0) {
         int previous = previousBoundary(value, this.displayStart);
         if (FontManager.widthRegular(value.substring(previous, cursor), this.visualFontSize) > this.contentWidth) {
            break;
         }

         this.displayStart = previous;
      }

      int displayEnd = this.displayStart;

      while (displayEnd < value.length()) {
         int next = nextBoundary(value, displayEnd);
         if (FontManager.widthRegular(value.substring(this.displayStart, next), this.visualFontSize) > this.contentWidth) {
            break;
         }

         displayEnd = next;
      }

      return new GlassSearchBox.VisibleText(this.displayStart, displayEnd, value.substring(this.displayStart, displayEnd));
   }

   public GlassSearchBox.SelectionRange selectionRange() {
      String value = this.getValue();
      String selected = this.getHighlighted();
      int cursor = clampToBoundary(value, this.getCursorPosition());
      if (selected.isEmpty()) {
         return new GlassSearchBox.SelectionRange(cursor, cursor);
      }

      int before = cursor - selected.length();
      if (before >= 0 && value.regionMatches(before, selected, 0, selected.length())) {
         return new GlassSearchBox.SelectionRange(before, cursor);
      }

      int after = cursor + selected.length();
      if (after <= value.length() && value.regionMatches(cursor, selected, 0, selected.length())) {
         return new GlassSearchBox.SelectionRange(cursor, after);
      }

      int fallback = value.indexOf(selected);
      return fallback < 0 ? new GlassSearchBox.SelectionRange(cursor, cursor) : new GlassSearchBox.SelectionRange(fallback, fallback + selected.length());
   }

   @Override
   public void onClick(MouseButtonEvent click, boolean doubled) {
      int position = this.cursorAt(click.x());
      if (doubled) {
         this.selectWordAt(position);
      } else {
         this.moveCursorTo(position, click.hasShiftDown());
      }
   }

   @Override
   protected void onDrag(MouseButtonEvent click, double dragX, double dragY) {
      this.moveCursorTo(this.cursorAt(click.x()), true);
   }

   @Override
   public void renderWidget(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
   }

   private int cursorAt(double screenX) {
      GlassSearchBox.VisibleText visible = this.visibleText();
      float localX = (float)((screenX - this.getX()) / this.uiScale) - this.contentLeft;
      if (localX <= 0.0F) {
         return visible.start();
      }

      String value = this.getValue();
      float cursorX = 0.0F;
      int index = visible.start();

      while (index < visible.end()) {
         int next = nextBoundary(value, index);
         float advance = FontManager.widthRegular(value.substring(index, next), this.visualFontSize);
         if (localX < cursorX + advance * 0.5F) {
            return index;
         }

         cursorX += advance;
         index = next;
      }

      return visible.end();
   }

   private void selectWordAt(int position) {
      String value = this.getValue();
      if (value.isEmpty()) {
         this.moveCursorTo(0, false);
      } else {
         int pivot = Math.min(position, value.length() - 1);
         if (Character.isWhitespace(value.charAt(pivot)) && pivot > 0) {
            pivot--;
         }

         int start = pivot;
         int end = pivot + 1;

         while (start > 0 && !Character.isWhitespace(value.charAt(start - 1))) {
            start--;
         }

         while (end < value.length() && !Character.isWhitespace(value.charAt(end))) {
            end++;
         }

         this.setCursorPosition(end);
         this.setHighlightPos(start);
      }
   }

   private static int clampToBoundary(String value, int index) {
      int clamped = Math.max(0, Math.min(value.length(), index));
      return clamped > 0 && clamped < value.length() && Character.isLowSurrogate(value.charAt(clamped)) && Character.isHighSurrogate(value.charAt(clamped - 1))
         ? clamped - 1
         : clamped;
   }

   private static int nextBoundary(String value, int index) {
      return index >= value.length() ? value.length() : value.offsetByCodePoints(index, 1);
   }

   private static int previousBoundary(String value, int index) {
      return index <= 0 ? 0 : value.offsetByCodePoints(index, -1);
   }

   public record SelectionRange(int start, int end) {
      public boolean isEmpty() {
         return this.start == this.end;
      }
   }

   public record VisibleText(int start, int end, String text) {
   }
}
