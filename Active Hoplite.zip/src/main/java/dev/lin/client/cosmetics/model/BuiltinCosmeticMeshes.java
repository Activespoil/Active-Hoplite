package dev.lin.client.cosmetics.model;

import org.joml.Matrix4f;
import org.joml.Vector4f;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Meshes used by Lunar's texture-only legacy formats. */
public final class BuiltinCosmeticMeshes {
    private static final int WING_TEXTURE_SIZE = 256;
    private static final int WING_ANIMATION_FRAMES = 120;
    private static final CosmeticMesh[] WING_FRAMES =
            new CosmeticMesh[WING_ANIMATION_FRAMES];
    private static final int DYNAMIC_WING_PHASES = 48;
    private static final Map<Integer, CosmeticMesh> DYNAMIC_WING_FRAMES =
            new LinkedHashMap<>(256, 0.75F, true) {
                @Override
                protected boolean removeEldestEntry(Map.Entry<Integer, CosmeticMesh> eldest) {
                    return size() > 384;
                }
            };
    private static long dynamicWingLastMillis;
    private static float dynamicWingPhase;
    private static float dynamicWingMovement;

    private BuiltinCosmeticMeshes() {
    }

    public static CosmeticMesh capePreview() {
        List<CosmeticVertex> vertices = new ArrayList<>();
        quad(vertices, -0.3125F, -1.45F, 0.18F, 0.3125F, -0.45F, 0.18F,
                0, 0, 1, 1, 0, 0, 1);
        return CosmeticMesh.of(vertices.toArray(CosmeticVertex[]::new), 1, 1);
    }

    /** Neutral frame used as the stable bounds/reference mesh. */
    public static CosmeticMesh wings() {
        return wingFrame(0L);
    }

    /** Lunar's native four-part legacy wing model and two-second joint cycle. */
    public static CosmeticMesh wingFrame(long timeMillis) {
        int frame = Math.floorMod((int) (timeMillis % 2000L)
                        * WING_ANIMATION_FRAMES / 2000,
                WING_ANIMATION_FRAMES);
        CosmeticMesh cached = WING_FRAMES[frame];
        if (cached != null) return cached;
        synchronized (WING_FRAMES) {
            cached = WING_FRAMES[frame];
            if (cached == null) {
                float phase = frame / (float) WING_ANIMATION_FRAMES
                        * (float) (Math.PI * 2.0);
                cached = createWingFrame(phase, 0.0F, false, false);
                WING_FRAMES[frame] = cached;
            }
        }
        return cached;
    }

    public static synchronized CosmeticMesh wingFrame(long timeMillis,
                                                       float movement,
                                                       boolean flying,
                                                       boolean crouching) {
        float targetMovement = Math.max(0.0F, Math.min(1.0F, movement));
        if (dynamicWingLastMillis == 0L || timeMillis < dynamicWingLastMillis
                || timeMillis - dynamicWingLastMillis > 500L) {
            dynamicWingLastMillis = timeMillis;
            dynamicWingMovement = targetMovement;
        } else {
            float elapsed = Math.min(0.1F,
                    (timeMillis - dynamicWingLastMillis) / 1000.0F);
            dynamicWingLastMillis = timeMillis;
            float smoothing = 1.0F - (float) Math.exp(-8.0F * elapsed);
            dynamicWingMovement += (targetMovement - dynamicWingMovement)
                    * smoothing;
            float cyclesPerSecond = flying ? 1.38F
                    : 0.50F + dynamicWingMovement * 0.30F;
            dynamicWingPhase = (dynamicWingPhase + elapsed * cyclesPerSecond
                    * (float) (Math.PI * 2.0))
                    % (float) (Math.PI * 2.0);
        }
        int phaseFrame = Math.floorMod(Math.round(dynamicWingPhase
                        / (float) (Math.PI * 2.0) * DYNAMIC_WING_PHASES),
                DYNAMIC_WING_PHASES);
        int movementFrame = Math.round(dynamicWingMovement * 8.0F);
        int key = phaseFrame | movementFrame << 6
                | (flying ? 1 << 10 : 0) | (crouching ? 1 << 11 : 0);
        CosmeticMesh cached = DYNAMIC_WING_FRAMES.get(key);
        if (cached != null) return cached;
        float quantizedPhase = phaseFrame / (float) DYNAMIC_WING_PHASES
                * (float) (Math.PI * 2.0);
        float quantizedMovement = movementFrame / 8.0F;
        CosmeticMesh created = createWingFrame(quantizedPhase,
                quantizedMovement, flying, crouching);
        DYNAMIC_WING_FRAMES.put(key, created);
        return created;
    }

    private static CosmeticMesh createWingFrame(float phase, float movement,
                                                 boolean flying,
                                                 boolean crouching) {
        List<CosmeticVertex> vertices = new ArrayList<>(128);
        float wave = (float) Math.sin(phase);
        float lift = (float) Math.cos(phase);
        float intensity = flying ? 1.0F : 0.26F + movement * 0.42F;
        float xRotation = (float) Math.toRadians(-60.0F
                - (crouching ? 8.0F : 0.0F)) - lift * 0.12F * intensity;
        float yRotation = (float) Math.toRadians(16.0F)
                + wave * 0.30F * intensity;
        float zRotation = (float) Math.toRadians(7.0F
                + (crouching ? 8.0F : 0.0F));
        float tipRotation = -((wave + 0.5F) * 0.42F) * intensity;
        appendWing(vertices, true, xRotation, -yRotation,
                -zRotation, tipRotation);
        appendWing(vertices, false, xRotation, yRotation,
                zRotation, -tipRotation);
        return CosmeticMesh.of(vertices.toArray(CosmeticVertex[]::new),
                WING_TEXTURE_SIZE, WING_TEXTURE_SIZE);
    }

    private static void appendWing(List<CosmeticVertex> out, boolean mirrored,
                                   float xRotation, float yRotation,
                                   float zRotation, float tipRotation) {
        float rootX = mirrored ? 4.0F : -4.0F;
        float cubeX = mirrored ? 0.0F : -56.0F;
        float tipX = mirrored ? 56.0F : -56.0F;

        Matrix4f root = new Matrix4f()
                .scale(0.13F)
                .translate(0.0F, 0.75F, 1.0F)
                .rotateX(xRotation)
                .rotateY(yRotation)
                .rotateZ(zRotation)
                .translate(rootX / 16.0F, 5.0F / 16.0F, 2.0F / 16.0F)
                ;

        addBox(out, root, mirrored, 112, 88,
                cubeX, -4, -4, cubeX + 56, 4, 4);
        addMembrane(out, root, mirrored ? 0 : 58, 88,
                cubeX, 2, cubeX + 56, 58, mirrored);

        Matrix4f tip = new Matrix4f(root)
                .translate(tipX / 16.0F, 0.0F, 0.0F)
                .rotateZ(tipRotation);
        addBox(out, tip, mirrored, 112, 136,
                cubeX, -2, -2, cubeX + 56, 2, 2);
        addMembrane(out, tip, mirrored ? 0 : 58, 144,
                cubeX, 2, cubeX + 56, 58, mirrored);
    }

    private static void addMembrane(List<CosmeticVertex> out, Matrix4f transform,
                                    float u, float v,
                                    float x0, float z0, float x1, float z1,
                                    boolean mirror) {
        Vector4f[] points = {
                transform.transform(new Vector4f(x0 / 16.0F, 0, z0 / 16.0F, 1)),
                transform.transform(new Vector4f(x1 / 16.0F, 0, z0 / 16.0F, 1)),
                transform.transform(new Vector4f(x1 / 16.0F, 0, z1 / 16.0F, 1)),
                transform.transform(new Vector4f(x0 / 16.0F, 0, z1 / 16.0F, 1))
        };
        float u0 = u / WING_TEXTURE_SIZE;
        float u1 = (u + 56.0F) / WING_TEXTURE_SIZE;
        float v0 = v / WING_TEXTURE_SIZE;
        float v1 = (v + 56.0F) / WING_TEXTURE_SIZE;
        if (mirror) {
            float swap = u0;
            u0 = u1;
            u1 = swap;
        }
        float ax = points[1].x - points[0].x;
        float ay = points[1].y - points[0].y;
        float az = points[1].z - points[0].z;
        float bx = points[2].x - points[0].x;
        float by = points[2].y - points[0].y;
        float bz = points[2].z - points[0].z;
        float nx = ay * bz - az * by;
        float ny = az * bx - ax * bz;
        float nz = ax * by - ay * bx;
        float length = Math.max(0.0001F,
                (float) Math.sqrt(nx * nx + ny * ny + nz * nz));
        nx /= length;
        ny /= length;
        nz /= length;
        float[] us = {u0, u1, u1, u0};
        float[] vs = {v0, v0, v1, v1};
        for (int index = 0; index < 4; index++) {
            Vector4f point = points[index];
            out.add(new CosmeticVertex(point.x, point.y, point.z,
                    us[index], vs[index], nx, ny, nz));
        }
    }

    private static void addBox(List<CosmeticVertex> out, Matrix4f transform,
                               boolean mirror, float u, float v,
                               float x0, float y0, float z0,
                               float x1, float y1, float z1) {
        float width = x1 - x0;
        float height = y1 - y0;
        float depth = z1 - z0;
        face(out, transform, mirror, u + depth + width, v + depth,
                depth, height,
                x0, y1, z1, x0, y1, z0, x0, y0, z0, x0, y0, z1);
        face(out, transform, mirror, u, v + depth, depth, height,
                x1, y1, z0, x1, y1, z1, x1, y0, z1, x1, y0, z0);
        face(out, transform, mirror, u + depth, v + depth, width, height,
                x0, y1, z0, x1, y1, z0, x1, y0, z0, x0, y0, z0);
        face(out, transform, mirror, u + depth * 2 + width, v + depth,
                width, height,
                x1, y1, z1, x0, y1, z1, x0, y0, z1, x1, y0, z1);
        face(out, transform, mirror, u + depth, v, width, depth,
                x0, y1, z1, x1, y1, z1, x1, y1, z0, x0, y1, z0);
        face(out, transform, mirror, u + depth + width, v + depth,
                width, -depth,
                x0, y0, z0, x1, y0, z0, x1, y0, z1, x0, y0, z1);
    }

    private static void face(List<CosmeticVertex> out, Matrix4f transform,
                             boolean mirror, float u, float v,
                             float width, float height, float... positions) {
        Vector4f[] points = new Vector4f[4];
        for (int index = 0; index < 4; index++) {
            points[index] = transform.transform(new Vector4f(
                    positions[index * 3] / 16.0F,
                    positions[index * 3 + 1] / 16.0F,
                    positions[index * 3 + 2] / 16.0F, 1.0F));
        }
        float ax = points[1].x - points[0].x;
        float ay = points[1].y - points[0].y;
        float az = points[1].z - points[0].z;
        float bx = points[2].x - points[0].x;
        float by = points[2].y - points[0].y;
        float bz = points[2].z - points[0].z;
        float nx = ay * bz - az * by;
        float ny = az * bx - ax * bz;
        float nz = ax * by - ay * bx;
        float normalLength = (float) Math.sqrt(nx * nx + ny * ny + nz * nz);
        if (normalLength < 0.000001F) return;
        nx /= normalLength;
        ny /= normalLength;
        nz /= normalLength;

        float u0 = u / WING_TEXTURE_SIZE;
        float u1 = (u + width) / WING_TEXTURE_SIZE;
        float v0 = v / WING_TEXTURE_SIZE;
        float v1 = (v + height) / WING_TEXTURE_SIZE;
        if (mirror) {
            float swap = u0;
            u0 = u1;
            u1 = swap;
        }
        float[] us = mirror
                ? new float[]{u0, u1, u1, u0}
                : new float[]{u1, u0, u0, u1};
        float[] vs = {v0, v0, v1, v1};
        for (int index = 0; index < 4; index++) {
            Vector4f point = points[index];
            out.add(new CosmeticVertex(point.x, point.y, point.z,
                    us[index], vs[index], nx, ny, nz));
        }
    }

    private static float radians(float degrees) {
        return (float) Math.toRadians(degrees);
    }

    private static void quad(List<CosmeticVertex> out,
                             float x0, float y0, float z0,
                             float x1, float y1, float z1,
                             float u0, float v0, float u1, float v1,
                             float nx, float ny, float nz) {
        plane(out, x0, y0, z0, x0, y1, z1, x1, y1, z1, x1, y0, z0,
                u0, v0, u1, v1);
    }

    private static void plane(List<CosmeticVertex> out,
                              float x0, float y0, float z0,
                              float x1, float y1, float z1,
                              float x2, float y2, float z2,
                              float x3, float y3, float z3,
                              float u0, float v0, float u1, float v1) {
        float ax = x1 - x0;
        float ay = y1 - y0;
        float az = z1 - z0;
        float bx = x2 - x0;
        float by = y2 - y0;
        float bz = z2 - z0;
        float nx = ay * bz - az * by;
        float ny = az * bx - ax * bz;
        float nz = ax * by - ay * bx;
        float length = Math.max(0.0001F,
                (float) Math.sqrt(nx * nx + ny * ny + nz * nz));
        nx /= length;
        ny /= length;
        nz /= length;
        out.add(new CosmeticVertex(x0, y0, z0, u0, v0, nx, ny, nz));
        out.add(new CosmeticVertex(x1, y1, z1, u0, v1, nx, ny, nz));
        out.add(new CosmeticVertex(x2, y2, z2, u1, v1, nx, ny, nz));
        out.add(new CosmeticVertex(x3, y3, z3, u1, v0, nx, ny, nz));
    }
}
