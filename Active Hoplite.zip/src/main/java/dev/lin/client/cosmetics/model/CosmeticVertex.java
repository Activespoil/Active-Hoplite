package dev.lin.client.cosmetics.model;

/** One textured, lit vertex in the standalone cosmetic coordinate system. */
public record CosmeticVertex(
        float x, float y, float z,
        float u, float v,
        float nx, float ny, float nz) {
}
