package dev.lin.client.cosmetics.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import dev.lin.client.cosmetics.LinClient;
import dev.lin.client.cosmetics.catalog.CosmeticCategory;
import dev.lin.client.cosmetics.catalog.CosmeticDefinition;
import dev.lin.client.cosmetics.catalog.LunarCatalog;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public final class CosmeticConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir()
            .resolve("lin-client.json");
    private static Data data = new Data();
    /** Immutable hot-path views. Rendering and animation read these every
     * frame/tick, while mutations are rare and rebuild them under the config
     * lock. */
    private static volatile List<CosmeticDefinition> equippedSnapshot = List.of();
    private static volatile Set<Integer> equippedIds = Set.of();
    private static volatile Set<Integer> favoriteSnapshot = Set.of();
    private static boolean lastSaveSucceeded = true;
    private static long lastSaveMillis = Long.MIN_VALUE;

    private CosmeticConfig() {
    }

    public static synchronized void load() {
        if (Files.isRegularFile(FILE)) {
            try {
                Data loaded = GSON.fromJson(Files.readString(FILE, StandardCharsets.UTF_8),
                        Data.class);
                if (loaded != null) {
                    data = loaded;
                }
            } catch (Exception exception) {
                LinClient.LOGGER.error("Unable to read {}", FILE, exception);
            }
        }
        normalize();
    }

    public static synchronized boolean save() {
        normalize();
        Path staging = FILE.resolveSibling(FILE.getFileName() + ".tmp");
        try {
            Files.createDirectories(FILE.getParent());
            Files.writeString(staging, GSON.toJson(data), StandardCharsets.UTF_8);
            try {
                Files.move(staging, FILE, StandardCopyOption.ATOMIC_MOVE,
                        StandardCopyOption.REPLACE_EXISTING);
            } catch (AtomicMoveNotSupportedException ignored) {
                Files.move(staging, FILE, StandardCopyOption.REPLACE_EXISTING);
            }
            lastSaveSucceeded = true;
            lastSaveMillis = System.currentTimeMillis();
            return true;
        } catch (Exception exception) {
            lastSaveSucceeded = false;
            lastSaveMillis = System.currentTimeMillis();
            LinClient.LOGGER.error("Unable to save {}", FILE, exception);
            try {
                Files.deleteIfExists(staging);
            } catch (Exception ignored) {
            }
            return false;
        }
    }

    public static synchronized boolean equip(CosmeticDefinition definition) {
        if (!definition.category().isLockerEnabled()) {
            return false;
        }
        String category = definition.category().id();
        Integer current = data.equipped.get(category);
        if (current != null && current == definition.id()) {
            return true;
        }
        data.equipped.put(category, definition.id());
        data.activeFitId = null;
        return save();
    }

    public static synchronized boolean unequip(CosmeticDefinition definition) {
        String category = definition.category().id();
        Integer current = data.equipped.get(category);
        if (current == null || current != definition.id()) {
            return true;
        }
        data.equipped.remove(category);
        data.activeFitId = null;
        return save();
    }

    public static synchronized boolean toggleEquip(CosmeticDefinition definition) {
        String category = definition.category().id();
        Integer current = data.equipped.get(category);
        if (current != null && current == definition.id()) {
            unequip(definition);
            return false;
        }
        equip(definition);
        return true;
    }

    public static synchronized void clearCategory(CosmeticCategory category) {
        data.equipped.remove(category.id());
        data.activeFitId = null;
        save();
    }

    public static synchronized void clearAll() {
        data.equipped.clear();
        data.activeFitId = null;
        save();
    }

    public static boolean isEquipped(int id) {
        return equippedIds.contains(id);
    }

    public static String vipIcon() { return data.vipIcon == null ? "none" : data.vipIcon; }
    public static boolean vipLobbyOnly() { return data.vipLobbyOnly; }
    public static synchronized boolean setVipLobbyOnly(boolean value) {
        boolean previous = data.vipLobbyOnly;
        data.vipLobbyOnly = value;
        if (save()) return true;
        data.vipLobbyOnly = previous;
        return false;
    }

    public static synchronized boolean setVipIcon(String id) {
        String previous = data.vipIcon;
        data.vipIcon = id;
        if (save()) return true;
        data.vipIcon = previous;
        return false;
    }

    public static String arrowTrail() { return data.arrowTrail == null ? "none" : data.arrowTrail; }

    public static synchronized boolean setArrowTrail(String id) {
        String previous = data.arrowTrail;
        data.arrowTrail = id;
        if (save()) return true;
        data.arrowTrail = previous;
        return false;
    }

    public static CosmeticDefinition equipped(CosmeticCategory category) {
        if (!category.isLockerEnabled()) {
            return null;
        }
        for (CosmeticDefinition definition : equippedSnapshot) {
            if (definition.category() == category) return definition;
        }
        return null;
    }

    public static List<CosmeticDefinition> equipped() {
        return equippedSnapshot;
    }

    public static boolean shareCosmetics() { return data.shareCosmetics; }
    public static boolean receiveCosmetics() { return data.receiveCosmetics; }
    public static int multiplayerQuality() { return Math.max(0,Math.min(2,data.multiplayerQuality)); }
    public static void setShareCosmetics(boolean value) { data.shareCosmetics=value;save(); }
    public static void setReceiveCosmetics(boolean value) { data.receiveCosmetics=value;save(); }
    public static void cycleMultiplayerQuality() { data.multiplayerQuality=(multiplayerQuality()+1)%3;save(); }
    public static boolean showTabBadge() { return data.showTabBadge; }
    public static boolean showNametagBadge() { return data.showNametagBadge; }
    public static boolean thirdPersonNametag() { return data.thirdPersonNametag; }
    public static void setShowTabBadge(boolean value) { data.showTabBadge=value;save(); }
    public static void setShowNametagBadge(boolean value) { data.showNametagBadge=value;save(); }
    public static void setThirdPersonNametag(boolean value) { data.thirdPersonNametag=value;save(); }

    private static void rebuildEquippedSnapshot() {
        List<CosmeticDefinition> result = new ArrayList<>();
        Set<Integer> ids = new LinkedHashSet<>();
        for (Integer id : data.equipped.values()) {
            CosmeticDefinition definition = LunarCatalog.byId(id);
            if (definition != null && definition.category().isLockerEnabled()) {
                result.add(definition);
                ids.add(id);
            }
        }
        equippedSnapshot = List.copyOf(result);
        equippedIds = Set.copyOf(ids);
    }

    public static synchronized SavedFit saveCurrentFit() {
        normalize();
        int id = Math.max(1, data.nextFitId);
        while (findFit(id) != null) id++;
        data.nextFitId = id + 1;
        OutfitData outfit = new OutfitData(id, "Fit " + id,
                new LinkedHashMap<>(data.equipped));
        data.fits.add(outfit);
        data.activeFitId = id;
        save();
        return savedFit(outfit);
    }

    public static synchronized boolean applyFit(int id) {
        OutfitData outfit = findFit(id);
        if (outfit == null) return false;
        data.equipped = new LinkedHashMap<>(outfit.equipped);
        data.activeFitId = id;
        return save();
    }

    public static synchronized boolean deleteFit(int id) {
        boolean removed = data.fits.removeIf(outfit -> outfit != null
                && outfit.id == id);
        if (!removed) return false;
        if (data.activeFitId != null && data.activeFitId == id) {
            data.activeFitId = null;
        }
        return save();
    }

    public static synchronized boolean renameFit(int id, String name) {
        OutfitData outfit = findFit(id);
        if (outfit == null || name == null) return false;
        String normalized = name.strip();
        if (normalized.isEmpty()) return false;
        if (normalized.length() > 48) {
            normalized = normalized.substring(0, 48).stripTrailing();
        }
        if (normalized.equals(outfit.name)) return true;
        outfit.name = normalized;
        return save();
    }

    public static synchronized List<SavedFit> fits() {
        List<SavedFit> result = new ArrayList<>();
        for (OutfitData outfit : data.fits) {
            result.add(savedFit(outfit));
        }
        return List.copyOf(result);
    }

    public static synchronized boolean isActiveFit(int id) {
        return data.activeFitId != null && data.activeFitId == id;
    }

    public static synchronized Integer activeFitId() {
        return data.activeFitId;
    }

    public static synchronized boolean toggleFavorite(int id) {
        boolean favorite;
        if (data.favorites.remove(id)) {
            favorite = false;
        } else {
            data.favorites.add(id);
            favorite = true;
        }
        save();
        return favorite;
    }

    public static synchronized boolean isFavorite(int id) {
        return data.favorites.contains(id);
    }

    public static Set<Integer> favoritesSnapshot() { return favoriteSnapshot; }

    public static synchronized boolean sortAscending() {
        return data.sortAscending;
    }

    public static synchronized void setSortAscending(boolean value) {
        data.sortAscending = value;
        save();
    }

    public static synchronized boolean favoritesOnly() {
        return data.favoritesOnly;
    }

    public static synchronized void setFavoritesOnly(boolean value) {
        data.favoritesOnly = value;
        save();
    }

    public static Path file() {
        return FILE;
    }

    public static synchronized boolean lastSaveSucceeded() {
        return lastSaveSucceeded;
    }

    public static synchronized long lastSaveMillis() {
        return lastSaveMillis;
    }

    private static void normalize() {
        if (data.equipped == null) {
            data.equipped = new LinkedHashMap<>();
        }
        if (data.favorites == null) {
            data.favorites = new LinkedHashSet<>();
        }
        if (data.fits == null) {
            data.fits = new ArrayList<>();
        }
        migrateHopliteCompanion(data.equipped);
        data.equipped.entrySet().removeIf(entry -> {
            CosmeticDefinition definition = LunarCatalog.byId(entry.getValue());
            return definition == null || !definition.category().isLockerEnabled();
        });
        data.favorites.removeIf(id -> {
            CosmeticDefinition definition = LunarCatalog.byId(id);
            return definition == null || !definition.category().isLockerEnabled();
        });
        data.fits.removeIf(outfit -> outfit == null);
        int maxId = 0;
        for (OutfitData outfit : data.fits) {
            maxId = Math.max(maxId, outfit.id);
            if (outfit.name == null || outfit.name.isBlank()) {
                outfit.name = "Fit " + outfit.id;
            }
            if (outfit.equipped == null) {
                outfit.equipped = new LinkedHashMap<>();
            }
            migrateHopliteCompanion(outfit.equipped);
            outfit.equipped.entrySet().removeIf(entry -> {
                CosmeticDefinition definition = LunarCatalog.byId(entry.getValue());
                return definition == null || !definition.category().isLockerEnabled();
            });
        }
        data.nextFitId = Math.max(Math.max(1, data.nextFitId), maxId + 1);
        if (data.activeFitId != null && findFit(data.activeFitId) == null) {
            data.activeFitId = null;
        }
        rebuildEquippedSnapshot();
        favoriteSnapshot = Set.copyOf(data.favorites);
    }

    private static void migrateHopliteCompanion(Map<String, Integer> equipped) {
        Integer old = equipped.get("pet");
        CosmeticDefinition definition = old == null ? null : LunarCatalog.byId(old);
        if (definition != null && "HOPLITE_PET".equals(definition.indexType())) {
            equipped.remove("pet");
            // Preserve an explicitly equipped companion if the old outfit had both.
            equipped.putIfAbsent("companion", old);
        }
    }

    private static OutfitData findFit(int id) {
        for (OutfitData outfit : data.fits) {
            if (outfit.id == id) return outfit;
        }
        return null;
    }

    private static SavedFit savedFit(OutfitData outfit) {
        return new SavedFit(outfit.id, outfit.name,
                Map.copyOf(outfit.equipped));
    }

    public record SavedFit(int id, String name,
                           Map<String, Integer> equipped) {
    }

    private static final class Data {
        boolean shareCosmetics = true;
        boolean receiveCosmetics = true;
        int multiplayerQuality = 1;
        boolean showTabBadge = true;
        boolean showNametagBadge = true;
        boolean thirdPersonNametag = true;
        String arrowTrail = "none";
        String vipIcon = "none";
        boolean vipLobbyOnly = true;
        Map<String, Integer> equipped = new LinkedHashMap<>();
        Set<Integer> favorites = new LinkedHashSet<>();
        List<OutfitData> fits = new ArrayList<>();
        int nextFitId = 1;
        Integer activeFitId;
        boolean sortAscending = true;
        boolean favoritesOnly;
    }

    private static final class OutfitData {
        int id;
        String name;
        Map<String, Integer> equipped = new LinkedHashMap<>();

        private OutfitData(int id, String name, Map<String, Integer> equipped) {
            this.id = id;
            this.name = name;
            this.equipped = equipped;
        }
    }
}
