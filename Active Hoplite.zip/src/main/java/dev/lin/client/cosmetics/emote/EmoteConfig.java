package dev.lin.client.cosmetics.emote;

import com.google.gson.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import net.fabricmc.loader.api.FabricLoader;

public final class EmoteConfig {
    public static final int SLOTS = 8, MAX_PAGES = 8;
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("lin-client/emotes.json");
    private static final List<String[]> PAGES = new ArrayList<>();
    private static boolean loaded;
    private static int activePage;
    private static boolean defaultCapeInitialized;
    private EmoteConfig() {}
    public static void load() {
        if (loaded) return;
        loaded = true;
        if (Files.isRegularFile(FILE)) {
            try {
                JsonObject data = JsonParser.parseString(Files.readString(FILE, StandardCharsets.UTF_8)).getAsJsonObject();
                for (JsonElement row : data.getAsJsonArray("pages")) {
                    if (PAGES.size() >= MAX_PAGES) break;
                    String[] page = new String[SLOTS];
                    Arrays.fill(page, "");
                    JsonArray values = row.getAsJsonArray();
                    for (int i = 0; i < Math.min(SLOTS, values.size()); i++) page[i] = values.get(i).getAsString();
                    PAGES.add(page);
                }
                activePage = data.has("activePage") ? data.get("activePage").getAsInt() : 0;
                defaultCapeInitialized = data.has("defaultCapeInitialized") && data.get("defaultCapeInitialized").getAsBoolean();
            } catch (IOException | RuntimeException e) {
                dev.lin.client.cosmetics.LinClient.LOGGER.warn("Cannot read emote settings; preserving invalid file", e);
                try { Files.copy(FILE, FILE.resolveSibling("emotes.invalid-" + System.currentTimeMillis() + ".json")); }
                catch (IOException copyError) { dev.lin.client.cosmetics.LinClient.LOGGER.warn("Cannot preserve invalid settings", copyError); }
                PAGES.clear();
            }
        }
        if (PAGES.isEmpty()) {
            PAGES.add(new String[]{"wave", "clapping", "yes", "no", "bow", "salute", "dab", "shrug"});
            PAGES.add(new String[]{"floss", "orange_justice", "gangnam_style", "t_pose", "thinking", "laughing", "fist", "hype"});
        }
        activePage = Math.max(0, Math.min(PAGES.size()-1, activePage));
    }
    public static int pageCount() { load(); return PAGES.size(); }
    public static int page() { load(); return activePage; }
    public static void page(int page) { load(); activePage = Math.floorMod(page, PAGES.size()); save(); }
    public static String slot(int page, int slot) { load(); return PAGES.get(page)[slot]; }
    public static void assign(int page, int slot, String id) {
        load();
        if (!id.isEmpty() && EmoteCatalog.get(id) == null) return;
        PAGES.get(page)[slot] = id;
        save();
    }
    public static void addPage() {
        load();
        if (PAGES.size() >= MAX_PAGES) return;
        String[] page = new String[SLOTS]; Arrays.fill(page, "");
        PAGES.add(page); activePage = PAGES.size()-1; save();
    }
    public static void removePage() {
        load();
        if (PAGES.size() <= 1) return;
        PAGES.remove(activePage); activePage = Math.min(activePage, PAGES.size()-1); save();
    }
    public static boolean defaultCapeInitialized() { load(); return defaultCapeInitialized; }
    public static void markDefaultCapeInitialized() { defaultCapeInitialized = true; save(); }
    public static void save() {
        load();
        JsonObject data = new JsonObject();
        data.addProperty("version", 1);
        data.addProperty("activePage", activePage);
        data.addProperty("defaultCapeInitialized", defaultCapeInitialized);
        JsonArray pages = new JsonArray();
        for (String[] page : PAGES) {
            JsonArray row = new JsonArray(); for (String value : page) row.add(value); pages.add(row);
        }
        data.add("pages", pages);
        Path temp = FILE.resolveSibling("emotes.json.tmp");
        try {
            Files.createDirectories(FILE.getParent());
            Files.writeString(temp, new GsonBuilder().setPrettyPrinting().create().toJson(data), StandardCharsets.UTF_8);
            try { Files.move(temp, FILE, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING); }
            catch (AtomicMoveNotSupportedException e) { Files.move(temp, FILE, StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException e) { dev.lin.client.cosmetics.LinClient.LOGGER.warn("Cannot save emote settings", e); }
    }
}
