package dev.lin.client.cosmetics.ui;

import dev.lin.client.cosmetics.font.FontManager;
import dev.lin.client.cosmetics.render.OpenGlUiRenderer;
import net.minecraft.client.gui.GuiGraphics;

/** Shared visual tokens for the approved sidebar layout and quick wheel. */
public final class CosmeticsUiStyle {
    public static final int PANEL = 0xD018232C, CARD = 0x80212C35, HOVER = 0xB02C414D;
    public static final int ACCENT = 0xFF52D7EE, SELECTED = 0x703299AF, LINE = 0x405D7889;
    public static final int TEXT = 0xFFF0F4F7, MUTED = 0xFFA2B3BD, ERROR = 0xFFFFA58B;
    private CosmeticsUiStyle() {}
    public static void panel(GuiGraphics g, float x, float y, float w, float h) {
        OpenGlUiRenderer.roundedPanel(g, x, y, w, h, 10, PANEL, LINE, 1);
    }
    public static void card(GuiGraphics g, float x, float y, float w, float h, boolean selected, boolean hover) {
        OpenGlUiRenderer.roundedPanel(g, x, y, w, h, 7,
                selected ? SELECTED : hover ? HOVER : CARD, selected ? ACCENT : LINE, selected ? 1.5f : 1);
    }
    public static void text(GuiGraphics g, String value, float x, float y, float size, int color) {
        OpenGlUiRenderer.textRegular(g, value, x, y, size, color);
    }
    public static void centered(GuiGraphics g, String value, float cx, float y, float size, int color) {
        text(g, value, cx - FontManager.widthRegular(value, size) / 2, y, size, color);
    }
    public static void button(GuiGraphics g, String label, float x, float y, float w,
                              boolean primary, boolean hover) {
        OpenGlUiRenderer.roundedPanel(g, x, y, w, 34, 6,
                primary ? (hover ? 0xFF42CEE7 : 0xE028AFCB) : hover ? HOVER : CARD,
                primary ? ACCENT : LINE, 1);
        centered(g, label, x + w/2, y + 10, 12, TEXT);
    }
    public static String fit(String value, float size, float width) {
        if (FontManager.widthRegular(value, size) <= width) return value;
        while (!value.isEmpty() && FontManager.widthRegular(value + "…", size) > width)
            value = value.substring(0, value.offsetByCodePoints(value.length(), -1));
        return value + "…";
    }
    public static boolean inside(double mx, double my, float x, float y, float w, float h) {
        return mx >= x && my >= y && mx < x+w && my < y+h;
    }
}
