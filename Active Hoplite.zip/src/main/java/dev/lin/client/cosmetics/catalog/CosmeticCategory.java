package dev.lin.client.cosmetics.catalog;

import java.util.Arrays;

public enum CosmeticCategory {
    ALL("all", "全部饰品", "cosmetic"),
    CLOAK("cloak", "披风", "cloak"),
    HAT("hat", "头饰", "hat"),
    BANDANNA("bandanna", "头巾", "bandana"),
    PET("pet", "宠物", "pet"),
    COMPANION("companion", "伙伴", "companion"),
    BODYWEAR("bodywear", "身体饰品", "bodywear"),
    SUITS("suits", "套装", "suits"),
    AURAS("auras", "光环", "auras"),
    DRAGON_WINGS("dragon_wings", "翅膀", "wings"),
    BACKPACK("backpack", "背饰", "backpack"),
    SHOES("shoes", "鞋子", "shoes"),
    MASK("mask", "面具", "mask"),
    NECKWEAR("neckwear", "颈饰", "necklace"),
    GLASSES("glasses", "眼镜", "glasses"),
    BELTS("belts", "腰带", "belts"),
    SHIELDS("shields", "盾牌", "shields"),
    WRISTWEAR("wristwear", "腕饰", "wristwear"),
    ITEMS("items", "手持物品", "item");

    private final String id;
    private final String displayName;
    private final String icon;

    CosmeticCategory(String id, String displayName, String icon) {
        this.id = id;
        this.displayName = displayName;
        this.icon = icon;
    }

    public String id() {
        return id;
    }

    public String displayName() {
        return displayName;
    }

    public String icon() {
        return icon;
    }

    /** Categories retained by the standalone Lunar Locker. */
    public boolean isLockerEnabled() {
        return switch (this) {
            case CLOAK, HAT, PET, COMPANION, AURAS, DRAGON_WINGS -> true;
            default -> false;
        };
    }

    public static CosmeticCategory fromCatalog(String value) {
        if (value == null) {
            return ALL;
        }
        if (value.equals("hand") || value.equals("sword") || value.equals("shovel")) {
            return ITEMS;
        }
        return Arrays.stream(values())
                .filter(category -> category.id.equals(value))
                .findFirst()
                .orElse(ALL);
    }
}
