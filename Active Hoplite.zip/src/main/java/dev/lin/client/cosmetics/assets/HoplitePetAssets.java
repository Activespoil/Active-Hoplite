package dev.lin.client.cosmetics.assets;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.lin.client.cosmetics.model.CosmeticMesh;
import dev.lin.client.cosmetics.model.HoplitePetAnimation;
import dev.lin.client.cosmetics.model.CosmeticVertex;
import org.joml.Vector3f;

import javax.imageio.ImageIO;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Complete resource-pack item geometry, shared by the existing pet UI and world renderer. */
public final class HoplitePetAssets {
    private static final String ROOT = "/assets/lin_client/hoplite_pets/";

    private HoplitePetAssets() {}

    public record Loaded(CosmeticMesh mesh, BufferedImage sheet, int width, int height,
                         int frames, int frameTime) {}
    private record Texture(BufferedImage image, int width, int height, List<Integer> timeline, int x) {}

    private static InputStream open(String path) throws IOException {
        if (path.contains("..") || path.startsWith("/")) throw new IOException("Unsafe pet path");
        InputStream stream = HoplitePetAssets.class.getResourceAsStream(ROOT + path);
        if (stream == null) throw new IOException("Missing Hoplite pet asset: " + path);
        return stream;
    }

    private static JsonObject json(String path) throws IOException {
        try (var reader = new InputStreamReader(open(path), StandardCharsets.UTF_8)) {
            return JsonParser.parseReader(reader).getAsJsonObject();
        }
    }

    public static Loaded load(String name) throws IOException {
        JsonObject model = json("models/" + name + ".json");
        JsonObject refs = model.getAsJsonObject("textures");
        Map<String, Texture> textures = new LinkedHashMap<>();
        int width = 0, height = 1, duration = 1, frameStep = 0;
        for (var entry : refs.entrySet()) {
            String ref = resolve(refs, entry.getValue().getAsString());
            if (textures.containsKey(ref)) continue;
            String path = "textures/" + ref.replace(':', '/') + ".png";
            BufferedImage image;
            try (InputStream stream = open(path)) { image = ImageIO.read(stream); }
            if (image == null) throw new IOException("Invalid pet texture: " + path);
            JsonObject animation = null;
            try (InputStream metadata = HoplitePetAssets.class.getResourceAsStream(ROOT + path + ".mcmeta")) {
                if (metadata != null) {
                    animation = JsonParser.parseReader(new InputStreamReader(metadata, StandardCharsets.UTF_8))
                            .getAsJsonObject().getAsJsonObject("animation");
                }
            }
            int tw = image.getWidth(), th = image.getHeight();
            List<Integer> timeline = new ArrayList<>();
            if (animation != null) {
                tw = integer(animation, "width", Math.min(tw, th));
                th = integer(animation, "height", tw);
                int count = image.getWidth() / tw * (image.getHeight() / th);
                int time = integer(animation, "frametime", 1);
                if (animation.has("frames")) {
                    for (JsonElement frame : animation.getAsJsonArray("frames")) {
                        int index = frame.isJsonObject() ? frame.getAsJsonObject().get("index").getAsInt() : frame.getAsInt();
                        int ticks = frame.isJsonObject() ? integer(frame.getAsJsonObject(), "time", time) : time;
                        if (index < 0 || index >= count || ticks < 1) throw new IOException("Invalid animation frame");
                        frameStep = gcd(frameStep, ticks);
                        for (int i = 0; i < ticks; i++) timeline.add(index);
                    }
                } else {
                    frameStep = gcd(frameStep, time);
                    for (int frame = 0; frame < count; frame++)
                        for (int i = 0; i < time; i++) timeline.add(frame);
                }
            } else timeline.add(0);
            if (timeline.isEmpty()) throw new IOException("Empty animation");
            duration = Math.multiplyExact(duration / gcd(duration, timeline.size()), timeline.size());
            if (duration > 2400) throw new IOException("Pet texture animation cycle too large");
            textures.put(ref, new Texture(image, tw, th, timeline, width));
            width += tw;
            height = Math.max(height, th);
        }
        frameStep = Math.max(1, frameStep);
        int frameCount = duration / frameStep;
        BufferedImage sheet = new BufferedImage(width, height * frameCount, BufferedImage.TYPE_INT_ARGB);
        Graphics2D graphics = sheet.createGraphics();
        try {
            for (int tick = 0; tick < frameCount; tick++) {
                for (Texture texture : textures.values()) {
                    int frame = texture.timeline.get(tick * frameStep % texture.timeline.size());
                    int columns = texture.image.getWidth() / texture.width;
                    int sx = frame % columns * texture.width, sy = frame / columns * texture.height;
                    graphics.drawImage(texture.image, texture.x, tick * height,
                            texture.x + texture.width, tick * height + texture.height,
                            sx, sy, sx + texture.width, sy + texture.height, null);
                }
            }
        } finally { graphics.dispose(); }

        List<CosmeticVertex> vertices = new ArrayList<>();
        List<Integer> elementEnds = new ArrayList<>();
        for (JsonElement value : model.getAsJsonArray("elements")) {
            JsonObject element = value.getAsJsonObject();
            float[] from = vector(element.getAsJsonArray("from")), to = vector(element.getAsJsonArray("to"));
            // Separate authored front/back faces of paper-thin pet parts.
            for (int axis = 0; axis < 3; axis++) {
                if (Math.abs(to[axis] - from[axis]) < 1.0E-6F) {
                    from[axis] -= 0.005F; to[axis] += 0.005F;
                }
            }
            for (var faceEntry : element.getAsJsonObject("faces").entrySet()) {
                JsonObject face = faceEntry.getValue().getAsJsonObject();
                Texture texture = textures.get(resolve(refs, face.get("texture").getAsString()));
                float[] uv = vector(face.getAsJsonArray("uv"));
                int rotation = integer(face, "rotation", 0) / 90;
                Vector3f[] points = corners(faceEntry.getKey(), from, to);
                for (Vector3f point : points) rotate(point, element);
                Vector3f normal = new Vector3f(points[1]).sub(points[0]).cross(new Vector3f(points[2]).sub(points[0]));
                if (normal.lengthSquared() < 1E-10F) normal.set(0, 1, 0); else normal.normalize();
                float[][] coords = {{uv[0], uv[1]}, {uv[0], uv[3]}, {uv[2], uv[3]}, {uv[2], uv[1]}};
                for (int i = 0; i < 4; i++) {
                    float[] tex = coords[(i + rotation) % 4];
                    Vector3f point = points[i];
                    vertices.add(new CosmeticVertex(point.x, -point.y, point.z,
                            (texture.x + tex[0] / 16 * texture.width) / width,
                            tex[1] / 16 * texture.height / height, normal.x, -normal.y, normal.z));
                }
            }
            elementEnds.add(vertices.size());
        }
        CosmeticMesh raw = CosmeticMesh.of(vertices.toArray(CosmeticVertex[]::new), width, height);
        if (raw.vertexCount() == 0) throw new IOException("Pet has no model geometry");
        // Preserve the pack's authored size (16 model units = one block).
        // The shared companion renderer applies Lunar's height ceiling; do not
        // squeeze every model to the old 0.52-block shoulder-pet bounding box.
        float scale = 1.0F / 16.0F;
        CosmeticVertex[] normalized = vertices.stream().map(v -> new CosmeticVertex(
                (v.x() - raw.centerX()) * scale, (v.y() - raw.maxY()) * scale,
                (v.z() - raw.centerZ()) * scale, v.u(), v.v(), v.nx(), v.ny(), v.nz()))
                .toArray(CosmeticVertex[]::new);
        CosmeticMesh mesh = CosmeticMesh.of(normalized, width, height);
        HoplitePetAnimation.register(name, mesh, elementEnds.stream().mapToInt(Integer::intValue).toArray(),
                raw.centerX(), raw.maxY(), raw.centerZ());
        return new Loaded(mesh, sheet, width, height, frameCount, frameStep);
    }

    private static String resolve(JsonObject refs, String value) throws IOException {
        for (int i = 0; value.startsWith("#"); i++) {
            if (i >= refs.size() || !refs.has(value.substring(1))) throw new IOException("Invalid texture reference");
            value = refs.get(value.substring(1)).getAsString();
        }
        return value;
    }
    private static int integer(JsonObject object, String key, int fallback) {
        return object.has(key) ? object.get(key).getAsInt() : fallback;
    }
    private static int gcd(int a, int b) { return b == 0 ? a : gcd(b, a % b); }
    private static float[] vector(JsonArray values) {
        float[] result = new float[values.size()];
        for (int i = 0; i < result.length; i++) result[i] = values.get(i).getAsFloat();
        return result;
    }
    private static void rotate(Vector3f point, JsonObject element) {
        if (!element.has("rotation")) return;
        JsonObject rotation = element.getAsJsonObject("rotation");
        float[] origin = vector(rotation.getAsJsonArray("origin"));
        if (!rotation.has("angle")) {
            // Modern resource-pack models also support XYZ Euler rotations.
            point.sub(origin[0], origin[1], origin[2]);
            point.rotateZ((float) Math.toRadians(rotation.get("z").getAsFloat()));
            point.rotateY((float) Math.toRadians(rotation.get("y").getAsFloat()));
            point.rotateX((float) Math.toRadians(rotation.get("x").getAsFloat()));
            point.add(origin[0], origin[1], origin[2]);
            return;
        }
        float angle = (float) Math.toRadians(rotation.get("angle").getAsFloat());
        String axis = rotation.get("axis").getAsString();
        point.sub(origin[0], origin[1], origin[2]);
        if (rotation.has("rescale") && rotation.get("rescale").getAsBoolean()) {
            float scale = 1 / (float) Math.cos(angle);
            point.mul(axis.equals("x") ? 1 : scale, axis.equals("y") ? 1 : scale, axis.equals("z") ? 1 : scale);
        }
        switch (axis) {
            case "x" -> point.rotateX(angle);
            case "y" -> point.rotateY(angle);
            case "z" -> point.rotateZ(angle);
            default -> throw new IllegalArgumentException("Invalid rotation axis");
        }
        point.add(origin[0], origin[1], origin[2]);
    }
    private static Vector3f[] corners(String face, float[] f, float[] t) {
        int[][] indices = switch (face) {
            case "down" -> new int[][]{{0,0,1},{0,0,0},{1,0,0},{1,0,1}};
            case "up" -> new int[][]{{0,1,0},{0,1,1},{1,1,1},{1,1,0}};
            case "north" -> new int[][]{{1,1,0},{1,0,0},{0,0,0},{0,1,0}};
            case "south" -> new int[][]{{0,1,1},{0,0,1},{1,0,1},{1,1,1}};
            case "west" -> new int[][]{{0,1,0},{0,0,0},{0,0,1},{0,1,1}};
            case "east" -> new int[][]{{1,1,1},{1,0,1},{1,0,0},{1,1,0}};
            default -> throw new IllegalArgumentException("Unknown model face: " + face);
        };
        Vector3f[] result = new Vector3f[4];
        for (int i = 0; i < 4; i++) result[i] = new Vector3f(
                indices[i][0] == 0 ? f[0] : t[0], indices[i][1] == 0 ? f[1] : t[1], indices[i][2] == 0 ? f[2] : t[2]);
        return result;
    }
}
