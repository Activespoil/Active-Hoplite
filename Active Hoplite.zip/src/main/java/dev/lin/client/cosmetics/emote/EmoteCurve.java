package dev.lin.client.cosmetics.emote;

/** Original BOBJ scalar curve, including time handles (not just value easing). */
public final class EmoteCurve {
    private final float[][] keys;
    public EmoteCurve(float[][] keys) { this.keys = keys; }
    public float sample(float time) {
        if (keys.length == 0) return 0;
        if (time <= keys[0][0]) return keys[0][1];
        int last = keys.length - 1;
        if (time >= keys[last][0]) return keys[last][1];
        int low = 0, high = last;
        while (high - low > 1) {
            int mid = (low + high) >>> 1;
            if (keys[mid][0] <= time) low = mid; else high = mid;
        }
        float[] a = keys[low], b = keys[high];
        if ((int)a[2] == 0) return a[1];
        float span = b[0] - a[0], linear = (time - a[0]) / span;
        if ((int)a[2] != 2) return a[1] + (b[1] - a[1]) * linear;
        // Blender clamps overlapping handle lengths, preserving their slopes.
        float ax = Math.max(a[0], a[5]), bx = Math.min(b[0], b[3]);
        float ay = a[6], by = b[4];
        float handles = ax - a[0] + b[0] - bx;
        if (handles > span) {
            float factor = span / handles;
            ax = a[0] + (ax - a[0]) * factor;
            ay = a[1] + (ay - a[1]) * factor;
            bx = b[0] + (bx - b[0]) * factor;
            by = b[1] + (by - b[1]) * factor;
        }
        float left = 0, right = 1;
        for (int i = 0; i < 16; i++) {
            float mid = (left + right) * .5f;
            if (bezier(a[0], ax, bx, b[0], mid) < time) left = mid; else right = mid;
        }
        return bezier(a[1], ay, by, b[1], (left + right) * .5f);
    }
    private static float bezier(float a, float b, float c, float d, float t) {
        float s = 1 - t;
        return s*s*s*a + 3*s*s*t*b + 3*s*t*t*c + t*t*t*d;
    }
}
