package dev.lin.client.cosmetics.emote;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.*;
import net.minecraft.resources.Identifier;

public final class EmoteRuntime {
    public record Sample(EmoteCatalog.Action action, float frame, float weight) {}
    private static EmoteCatalog.Action playing;
    private static long started, stopped;
    private static java.util.UUID playerId;
    private static Object level;
    private static int initialHurtTime;
    private EmoteRuntime() {}
    public static void initialize() { /* Emote playback has no global wheel key binding. */ }
    public static void tick(Minecraft client) {
        if (playing == null) return;
        if (client.player == null || client.level != level || !client.player.getUUID().equals(playerId)
                || !client.player.isAlive() || client.player.isSpectator()) { clear(); return; }
        long now = System.nanoTime();
        if (stopped != 0) { if (now - stopped > 180_000_000L) clear(); return; }
        if (client.options.keyUp.isDown() || client.options.keyDown.isDown()
                || client.options.keyLeft.isDown() || client.options.keyRight.isDown()
                || client.options.keyJump.isDown() || client.options.keyAttack.isDown()
                || client.options.keyUse.isDown() || client.player.swinging
                || client.player.isUsingItem() || client.player.hurtTime > initialHurtTime
                || client.player.isFallFlying() || client.player.isPassenger()
                || client.player.isInWater() || client.player.isSleeping()
                || client.player.getDeltaMovement().horizontalDistanceSqr() > .0025
                || (!playing.looping() && frame(now) >= playing.duration())) stop();
        initialHurtTime = client.player.hurtTime;
    }
    public static boolean play(String id) {
        Minecraft client = Minecraft.getInstance();
        EmoteCatalog.Action action = EmoteCatalog.get(id);
        if (action == null || client.player == null || !client.player.isAlive()
                || client.player.isSpectator() || client.player.isPassenger()
                || client.player.isSleeping() || client.player.isFallFlying()) return false;
        playing = action; started = System.nanoTime(); stopped = 0;
        playerId = client.player.getUUID(); level = client.level;
        initialHurtTime = client.player.hurtTime;
        return true;
    }
    public static void stop() { if (playing != null && stopped == 0) stopped = System.nanoTime(); }
    public static void clear() { playing = null; level = null; playerId = null; stopped = 0; }
    private static float frame(long now) { return (now - started) / 50_000_000f; }
    public static Sample current(int entityId) {
        Minecraft client = Minecraft.getInstance();
        if (playing == null || client.player == null || entityId != client.player.getId()
                || client.level != level || !client.player.getUUID().equals(playerId)) return null;
        long now = System.nanoTime();
        float frames = frame(stopped == 0 ? now : stopped);
        float weight = Math.min(1, (now - started) / 180_000_000f);
        if (stopped != 0) weight *= Math.max(0, 1 - (now - stopped) / 180_000_000f);
        float time = playing.looping() ? frames % playing.duration() : Math.min(frames, playing.duration());
        return new Sample(playing, time, weight);
    }
}
