package dev.lin.client.cosmetics.ui;

import java.util.IdentityHashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.CharacterEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

/** Owns page lifetime: navigation changes content, not the Minecraft screen. */
public final class ClientPageHost extends Screen {
    private final Screen parent;
    private final Map<Integer,Screen> pages=new LinkedHashMap<>();
    private final Map<Screen,Long> initialized=new IdentityHashMap<>();
    private Screen active;
    private boolean disposed;
    public ClientPageHost(Screen parent,Screen existing){
        super(Component.literal("Lin Client"));this.parent=parent;
        if(existing!=null){pages.put(SystemNavigation.pageId(existing),existing);active=existing;
            initialized.put(existing,size(existing.width,existing.height));}
    }
    private static long size(int w,int h){return ((long)w<<32)|(h&0xffffffffL);}
    public Screen activePage(){return active;}
    Screen returnTarget(){return parent;}
    public boolean contains(Screen page){return pages.containsValue(page);}
    public boolean hasCosmetics(){return pages.containsKey(SystemNavigation.COSMETICS)&&!disposed;}
    Screen page(int id){return pages.get(id);}
    void show(int id,Screen page){
        if(active==page)return;
        Screen previous=active;
        // Initialization failure leaves the previous page usable.
        if(width>0&&height>0)initialize(page);
        if(previous!=null){previous.clearFocus();
            if(previous instanceof CosmeticLockerScreen locker)locker.suspendPage();}
        pages.put(id,page);active=page;
    }
    private void initialize(Screen page){
        long target=size(width,height);
        if(!Long.valueOf(target).equals(initialized.get(page))){page.init(width,height);initialized.put(page,target);}
    }
    @Override protected void init(){disposed=false;if(active!=null)initialize(active);}
    @Override public void renderBackground(GuiGraphics g,int x,int y,float delta){}
    @Override public void render(GuiGraphics g,int x,int y,float delta){if(active!=null)active.render(g,x,y,delta);}
    @Override public void tick(){if(active!=null)active.tick();}
    public void renderFrameEnd(){}
    @Override public boolean mouseClicked(MouseButtonEvent e,boolean doubled){return active!=null&&active.mouseClicked(e,doubled);}
    @Override public boolean mouseReleased(MouseButtonEvent e){return active!=null&&active.mouseReleased(e);}
    @Override public boolean mouseDragged(MouseButtonEvent e,double x,double y){return active!=null&&active.mouseDragged(e,x,y);}
    @Override public boolean mouseScrolled(double x,double y,double h,double v){return active!=null&&active.mouseScrolled(x,y,h,v);}
    @Override public void mouseMoved(double x,double y){if(active!=null)active.mouseMoved(x,y);}
    @Override public boolean keyPressed(KeyEvent e){return active!=null&&active.keyPressed(e);}
    @Override public boolean keyReleased(KeyEvent e){return active!=null&&active.keyReleased(e);}
    @Override public boolean charTyped(CharacterEvent e){return active!=null&&active.charTyped(e);}
    @Override public void onFilesDrop(java.util.List<java.nio.file.Path> paths){if(active!=null)active.onFilesDrop(paths);}
    @Override public void onClose(){if(active!=null)active.onClose();else minecraft.setScreen(parent);}
    @Override public boolean isPauseScreen(){return false;}
    @Override public void removed(){
        if(disposed)return;
        disposed=true;
        for(Screen page:pages.values())page.removed();
        initialized.clear();
    }
}
