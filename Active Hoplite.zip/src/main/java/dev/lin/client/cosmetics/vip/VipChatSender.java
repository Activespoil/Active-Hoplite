/*
 * Decompiled with CFR 0.152.
 */
package dev.lin.client.cosmetics.vip;

public final class VipChatSender {
    private VipChatSender() {
    }

    public static boolean matches(String text, String name) {
        if (text == null || name == null || name.isEmpty()) {
            return false;
        }
        int from = 0;
        while (from < text.length()) {
            String tail;
            String prefix;
            int end;
            int start = text.indexOf(name, from);
            if (start < 0 || start > 96) {
                return false;
            }
            from = end = start + name.length();
            if (start > 0 && VipChatSender.username(text.charAt(start - 1)) || end < text.length() && VipChatSender.username(text.charAt(end)) || (prefix = text.substring(0, start).trim()).indexOf(10) >= 0 || prefix.indexOf(13) >= 0 || !(tail = text.substring(end).stripLeading()).startsWith(":") && !tail.startsWith("\uff1a") && !tail.startsWith(">") && !tail.startsWith("\u00bb") && !tail.startsWith("\u226b") && !tail.startsWith("\u2192") && !tail.startsWith("\u279c") && !tail.startsWith("\u27a4") && !tail.startsWith(" ]") && !tail.startsWith("]") && !tail.startsWith("\u3011")) continue;
            return true;
        }
        return false;
    }

    private static boolean username(char ch) {
        return ch == '_' || Character.isLetterOrDigit(ch);
    }
}

