package dev.lin.client.cosmetics.font;

import dev.lin.client.cosmetics.ui.ClientShell;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.navigation.ScreenRectangle;
import java.util.ArrayList;
import java.util.List;

/** Menu-only native text commands. HUD glyph textures retain their ordered GUI path. */
public final class SharedMenuText {
    public record Line(String text,float x,float baseline,float size,int color,ScreenRectangle clip) {}
    public record Cover(int beforeLine,float x,float y,float width,float height,float radius) {}
    public record Frame(ClientShell.Layout shell,List<Line> lines,List<Cover> covers) {}
    private static final List<Line> LINES=new ArrayList<>();
    private static final List<Cover> COVERS=new ArrayList<>();
    private static ClientShell.Layout shell;
    private SharedMenuText() {}

    public static void beginFrame(){LINES.clear();COVERS.clear();shell=null;}
    static void add(GuiGraphics g,String text,float x,float y,float size,int color){
        if(text==null || text.isEmpty() || color>>>24==0)return;
        if(shell==null){
            var window=Minecraft.getInstance().getWindow();
            shell=ClientShell.layout(window.getGuiScaledWidth(),window.getGuiScaledHeight());
        }
        var p=g.pose();
        float guiX=p.m00()*x+p.m10()*y+p.m20();
        float guiBaseline=p.m01()*x+p.m11()*(y+size)+p.m21();
        // Normalize the legacy music/wardrobe coordinate systems before creating the font.
        // 13 shell units now creates exactly the same Skija Font as a function-card label.
        float fontSize=Math.round(size*p.m11()/shell.scale()*1000)/1000f;
        LINES.add(new Line(text,(guiX-shell.x())/shell.scale(),
                (guiBaseline-shell.y())/shell.scale(),fontSize,color,g.scissorStack.peek()));
    }
    /** Later popup surfaces mask older text, while their own labels remain on top. */
    public static void occlude(GuiGraphics g,float x,float y,float w,float h,float radius){
        if(LINES.isEmpty() || w<=0 || h<=0)return;
        var p=g.pose();
        float left=p.m00()*x+p.m10()*y+p.m20(),top=p.m01()*x+p.m11()*y+p.m21();
        float right=left+w*p.m00(),bottom=top+h*p.m11();
        var clip=g.scissorStack.peek();
        if(clip!=null){left=Math.max(left,clip.left());top=Math.max(top,clip.top());
            right=Math.min(right,clip.right());bottom=Math.min(bottom,clip.bottom());}
        if(right>left && bottom>top)COVERS.add(new Cover(LINES.size(),left,top,right-left,bottom-top,radius*p.m00()));
    }
    public static Frame takeFrame(){
        Frame frame=new Frame(shell,List.copyOf(LINES),List.copyOf(COVERS));
        beginFrame();return frame;
    }
}
