package dev.lin.client.cosmetics.ui;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import net.minecraft.client.Minecraft;
import net.minecraft.core.component.DataComponents;
import net.minecraft.resources.Identifier;
import net.minecraft.world.item.ItemStack;

/** Prove the active resource chain is static; unknown schemas fail closed. */
public final class StaticPortraitModels {
    private static final Identifier HEAD = Identifier.fromNamespaceAndPath("lin_client", "headwear");
    private static final Map<Float, Boolean> CHECKED = new HashMap<>();
    private static long generation;
    private static Object activeModel;
    private StaticPortraitModels() {}
    public static long generation() {
        // The baked item-model identity changes on resource reload, even when
        // Minecraft retains the same resource manager and GUI renderer objects.
        Object model = Minecraft.getInstance().getModelManager().getItemModel(HEAD);
        if (model != activeModel) { activeModel = model; invalidate(); }
        return generation;
    }
    public static void invalidate() { generation++; CHECKED.clear(); }

    public static boolean isStatic(ItemStack stack) {
        generation();
        if (!HEAD.equals(stack.get(DataComponents.ITEM_MODEL))) return false;
        var data = stack.get(DataComponents.CUSTOM_MODEL_DATA);
        Float value = data == null ? null : data.getFloat(0);
        if (value == null || !Float.isFinite(value)) return false;
        return CHECKED.computeIfAbsent(value, StaticPortraitModels::check);
    }

    private static boolean check(float value) {
        try {
            JsonObject dispatch = read(Identifier.fromNamespaceAndPath("lin_client", "items/headwear.json"))
                    .getAsJsonObject("model");
            if (!"minecraft:range_dispatch".equals(dispatch.get("type").getAsString())
                    || !"minecraft:custom_model_data".equals(dispatch.get("property").getAsString())
                    || (dispatch.has("index") && dispatch.get("index").getAsInt() != 0)
                    || (dispatch.has("scale") && dispatch.get("scale").getAsFloat() != 1)) return false;
            JsonObject selected = dispatch.getAsJsonObject("fallback");
            float threshold = Float.NEGATIVE_INFINITY;
            for (var entry : dispatch.getAsJsonArray("entries")) {
                var candidate = entry.getAsJsonObject();
                float lower = candidate.get("threshold").getAsFloat();
                if (lower <= value && lower >= threshold) {
                    threshold = lower; selected = candidate.getAsJsonObject("model");
                }
            }
            // Only plain baked models, never special/entity/conditional renderers.
            if (!"minecraft:model".equals(selected.get("type").getAsString())
                    || selected.has("tints")) return false;
            Map<String, String> textures = new HashMap<>();
            if (!model(Identifier.parse(selected.get("model").getAsString()), textures, new HashSet<>())) return false;
            if (textures.isEmpty()) return false;
            for (String texture : textures.values()) {
                Set<String> seen = new HashSet<>();
                while (texture.startsWith("#")) {
                    if (!seen.add(texture)) return false;
                    texture = textures.get(texture.substring(1));
                    if (texture == null) return false;
                }
                Identifier id = Identifier.parse(texture);
                Identifier png = Identifier.fromNamespaceAndPath(id.getNamespace(), "textures/" + id.getPath() + ".png");
                var manager = Minecraft.getInstance().getResourceManager();
                if (manager.getResource(png).isEmpty()) return false;
                Identifier meta = Identifier.fromNamespaceAndPath(png.getNamespace(), png.getPath() + ".mcmeta");
                if (manager.getResource(meta).isPresent() && read(meta).has("animation")) return false;
            }
            return true;
        } catch (Exception invalidOrUnknownResource) {
            return false;
        }
    }

    private static boolean model(Identifier id, Map<String, String> textures, Set<Identifier> seen) throws Exception {
        if (!seen.add(id) || seen.size() > 32 || id.getPath().startsWith("builtin/")) return false;
        JsonObject json = read(Identifier.fromNamespaceAndPath(id.getNamespace(), "models/" + id.getPath() + ".json"));
        if (json.has("overrides") || json.has("loader")) return false;
        if (json.has("parent") && !model(Identifier.parse(json.get("parent").getAsString()), textures, seen)) return false;
        if (json.has("textures")) for (var entry : json.getAsJsonObject("textures").entrySet())
            textures.put(entry.getKey(), entry.getValue().getAsString());
        return true;
    }

    private static JsonObject read(Identifier id) throws Exception {
        try (var reader = Minecraft.getInstance().getResourceManager().getResourceOrThrow(id).openAsReader()) {
            return JsonParser.parseReader(reader).getAsJsonObject();
        }
    }
}
