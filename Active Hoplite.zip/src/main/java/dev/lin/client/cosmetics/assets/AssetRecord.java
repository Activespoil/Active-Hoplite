package dev.lin.client.cosmetics.assets;

public record AssetRecord(String logicalPath, String sha1, long size) {
}
