package dev.lin.client.cosmetics.render;

import dev.lin.client.cosmetics.config.CosmeticConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.world.entity.projectile.arrow.AbstractArrow;
import net.minecraft.world.entity.projectile.arrow.Arrow;
import net.minecraft.world.entity.projectile.arrow.SpectralArrow;
import net.minecraft.world.phys.Vec3;

/** Client-authored themes. The resource pack provides menu icons, not server animation logic. */
public enum ArrowTrails {
    NONE("none", "原版 / 关闭自定义", 0xDDD6B8, 0xEEE9DC),
    SOUL("soul_harvester", "灵魂收割", 0x48D7DD, 0x183A58),
    CAMO("camo", "丛林迷彩", 0x63864D, 0xBBA678),
    DRAGON("dragon", "魔龙吐息", 0xBB49DD, 0xEE86F0),
    BEATS("bopping_beats", "跃动音符", 0xFFCC55, 0x66DDEE),
    EVERGREEN("evergreen_glitter", "常青闪光", 0x49D68C, 0xF9E69D);

    public final String id, label;
    public final int primary, secondary;
    private final DustParticleOptions dust, accent;
    private static int budgetTick = Integer.MIN_VALUE, used;

    ArrowTrails(String id, String label, int primary, int secondary) {
        this.id = id; this.label = label; this.primary = primary; this.secondary = secondary;
        dust = new DustParticleOptions(primary, 0.65F);
        accent = new DustParticleOptions(secondary, 0.5F);
    }

    public static ArrowTrails selected() {
        String id = CosmeticConfig.arrowTrail();
        for (ArrowTrails value : values()) if (value.id.equals(id)) return value;
        return NONE;
    }

    public static boolean replaces(AbstractArrow arrow) {
        return theme(arrow)!=NONE;
    }

    public static ArrowTrails theme(AbstractArrow arrow) {
        Minecraft client = Minecraft.getInstance();
        if(client.player==null || client.level!=arrow.level() || !(arrow instanceof Arrow || arrow instanceof SpectralArrow))return NONE;
        if(arrow.getOwner()==client.player)return selected();
        if(arrow.getOwner() instanceof net.minecraft.client.player.AbstractClientPlayer owner){
            var peer=dev.lin.client.cosmetics.sync.CosmeticSyncBridge.remote(owner.getUUID());
            if(peer!=null)for(var value:values())if(value.id.equals(peer.outfit().appearance().arrowTrail()))return value;
        }
        return NONE;
    }

    public static void emit(AbstractArrow arrow, Vec3 from) {
        if (!replaces(arrow) || from == null) return;
        Minecraft client = Minecraft.getInstance();
        if (client.isPaused() || arrow.position().distanceToSqr(client.player.position()) > 96 * 96) return;
        Vec3 delta = arrow.position().subtract(from);
        double length = delta.length();
        if (length < 0.025 || length > 12) return;
        if (budgetTick != client.player.tickCount) { budgetTick = client.player.tickCount; used = 0; }
        ArrowTrails theme = theme(arrow);
        int count = Math.min(16, Math.max(1, (int)Math.ceil(length / 0.16)));
        for (int i = 0; i < count && used < 128; i++) {
            Vec3 point = from.add(delta.scale((i + 0.5) / count));
            double wave = Math.sin((arrow.tickCount * 16 + i) * 0.7) * 0.035;
            ParticleOptions particle = (i & 1) == 0 ? theme.dust : theme.accent;
            double vx = 0, vy = 0.005, vz = 0;
            if (i % 4 == 0) {
                switch (theme) {
                    case SOUL -> { particle = ParticleTypes.SOUL; vy = 0.015; }
                    case DRAGON -> { particle = net.minecraft.core.particles.PowerParticleOption.create(ParticleTypes.DRAGON_BREATH, 0.4F); vx = wave; vz = -wave; }
                    case BEATS -> { particle = ParticleTypes.NOTE; vx = Math.floorMod(arrow.tickCount + i, 24) / 24.0; vy = 0; }
                    case EVERGREEN -> particle = ParticleTypes.HAPPY_VILLAGER;
                    default -> { }
                }
            }
            client.level.addParticle(particle, point.x, point.y, point.z, vx, vy, vz);
            used++;
        }
    }
}
