package dev.lin.client.cosmetics.ui;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;

/** Shared runtime boundary: Lunar leaves native menus alone, while retaining world tools. */
public final class ClientFeaturePolicy {
    public static final boolean NATIVE_MENUS = ClientFeaturePolicy.class.getResource("/lin-native-menus.marker") != null;
    private ClientFeaturePolicy() {}
    public static boolean inWorld() {
        Minecraft client=Minecraft.getInstance();
        return client!=null && client.level!=null && client.player!=null;
    }
    public static boolean canOpenFeatures() { return !NATIVE_MENUS || inWorld(); }
    public static boolean permits(Screen screen) {
        if (!NATIVE_MENUS || screen==null) return true;
        for (Class<?> type=screen.getClass(); type!=null; type=type.getSuperclass()) {
            String name=type.getName();
            if (name.startsWith("dev.lin.client.cosmetics.ui.")
                    || name.startsWith("dev.lin.client.features.ui."))
                return inWorld();
        }
        return true;
    }
    public static void tick(Minecraft client) {
        if (!NATIVE_MENUS || client==null) return;
        if (!inWorld() && !permits(client.screen)) {
            client.setScreen(null);
        }
    }
}
