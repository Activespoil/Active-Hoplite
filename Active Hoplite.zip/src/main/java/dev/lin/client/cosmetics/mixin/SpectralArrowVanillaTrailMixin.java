package dev.lin.client.cosmetics.mixin;

import dev.lin.client.cosmetics.render.ArrowTrails;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.world.entity.projectile.arrow.SpectralArrow;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

/** Suppresses the spectral-arrow glow particles while a custom trail is equipped. */
@Mixin(SpectralArrow.class)
public abstract class SpectralArrowVanillaTrailMixin {
    @Redirect(method = "tick", at = @At(value = "INVOKE", target =
            "Lnet/minecraft/world/level/Level;addParticle(Lnet/minecraft/core/particles/ParticleOptions;DDDDDD)V"))
    private void lin$replaceSpectralTrail(Level level, ParticleOptions particle, double x, double y, double z,
                                          double vx, double vy, double vz) {
        if (!ArrowTrails.replaces((SpectralArrow)(Object)this)) level.addParticle(particle, x, y, z, vx, vy, vz);
    }
}
