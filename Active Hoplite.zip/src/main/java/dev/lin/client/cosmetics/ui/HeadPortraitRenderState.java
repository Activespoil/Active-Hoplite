package dev.lin.client.cosmetics.ui;

import net.minecraft.client.renderer.entity.state.AvatarRenderState;
import net.minecraft.world.item.ItemStack;

/** Only the fixed, head-only HUD preview may reuse an entity raster. */
public final class HeadPortraitRenderState extends AvatarRenderState {
    public ItemStack portraitHead = ItemStack.EMPTY;
    public boolean staticHead;
    public boolean selfCard;
}
