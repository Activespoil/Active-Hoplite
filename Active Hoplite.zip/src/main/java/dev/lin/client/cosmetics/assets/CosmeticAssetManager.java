package dev.lin.client.cosmetics.assets;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mojang.blaze3d.platform.NativeImage;
import dev.lin.client.cosmetics.LinClient;
import dev.lin.client.cosmetics.catalog.CosmeticCategory;
import dev.lin.client.cosmetics.catalog.CosmeticDefinition;
import dev.lin.client.cosmetics.config.CosmeticConfig;
import dev.lin.client.cosmetics.model.BedrockModelLoader;
import dev.lin.client.cosmetics.model.BuiltinCosmeticMeshes;
import dev.lin.client.cosmetics.model.CosmeticAttachment;
import dev.lin.client.cosmetics.model.CosmeticMesh;
import dev.lin.client.cosmetics.model.CosmeticRenderData;
import dev.lin.client.cosmetics.model.CosmeticVertex;
import dev.lin.client.cosmetics.model.ObjModelLoader;
import dev.lin.client.cosmetics.ui.CosmeticLockerScreen;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.resources.Identifier;

import javax.imageio.ImageIO;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Loads both Lunar cosmetic generations without touching Lunar Client code.
 * GEK definitions, Bedrock geometry, legacy OBJ, WebP and cape atlases all go
 * through this one standalone cache.
 */
public final class CosmeticAssetManager {
    private static volatile boolean menuPreviewActive;
    private static volatile boolean closed;
    private static long nextCleanupNanos;
    private static final Map<Integer, FailedRequest> FAILURES = new ConcurrentHashMap<>();
    private record FailedRequest(int attempts, long retryAt,
            CompletableFuture<CosmeticRenderData> result) {}
    private static final int UI_CACHE_LIMIT = 144;
    private static final AnimationFrameCache FRAME_PIXELS = new AnimationFrameCache(16L * 1024 * 1024);
    // Bedrock animation evaluation rebuilds an entire immutable mesh. Five to
    // eight samples per second remain smooth because the renderer interpolates
    // between samples, while substantially reducing decoder CPU contention.
    private static final long MODEL_UPDATE_INTERVAL_NANOS = 160_000_000L;
    private static final long LARGE_MODEL_UPDATE_INTERVAL_NANOS = 260_000_000L;
    private static final long MIN_MODEL_TRANSITION_NANOS = 40_000_000L;
    private static final long MAX_MODEL_TRANSITION_NANOS = 250_000_000L;
    private static final long START_NANOS = System.nanoTime();
    private static final Object IMAGE_DECODER_LOCK = new Object();
    private static final ExecutorService EXECUTOR = Executors.newFixedThreadPool(4, task -> {
        Thread thread = new Thread(task, "Standalone Lunar Cosmetic Decoder");
        thread.setDaemon(true);
        return thread;
    });
    private static final ExecutorService MODEL_EXECUTOR = Executors.newSingleThreadExecutor(task -> {
        Thread thread = new Thread(task, "Lin Cosmetic Animator");
        thread.setDaemon(true);
        return thread;
    });
    private static final Map<Integer, CompletableFuture<CosmeticRenderData>> REQUESTS =
            new ConcurrentHashMap<>();
    private static final Map<Integer, ActiveData> ACTIVE = Collections.synchronizedMap(
            new LinkedHashMap<>(64, 0.75F, true));
    private static final Set<Integer> VISIBLE_PREVIEWS = ConcurrentHashMap.newKeySet();
    private static final Map<String, JsonObject> HATS = loadLegacyIndex("hats.json");
    private static final Map<String, JsonObject> BODYWEAR = loadLegacyIndex("bodywear.json");

    private static final Set<Integer> REMOTE_ORIGIN = ConcurrentHashMap.newKeySet();
    private static final Set<Integer> REMOTE_IDS = ConcurrentHashMap.newKeySet();
    private static final Set<Integer> REMOTE_ANIMATED_IDS = ConcurrentHashMap.newKeySet();
    private record RemoteKey(java.util.UUID owner, int id) {}
    private static final Map<RemoteKey, RemoteFrame> REMOTE_FRAMES = new LinkedHashMap<>();
    private static final long REMOTE_ASSET_BYTES = 64L * 1024 * 1024;
    private static final long REMOTE_MESH_BYTES = 16L * 1024 * 1024;
    private static final int REMOTE_CONCURRENCY = 4;
    private static final java.util.List<CompletableFuture<CosmeticRenderData>> remoteLoading = new java.util.ArrayList<>();
    private static long remoteGeneration;
    private static final Set<Integer> remoteTooLarge=new java.util.HashSet<>();
    private static Set<Integer> remoteCandidates=Set.of();
    private static int remoteJobs;
    private static final class RemoteFrame {
        volatile CosmeticRenderData data;
        final BedrockModelLoader.AnimationContext animation = new BedrockModelLoader.AnimationContext();
        boolean updating; long next, last;
        RemoteFrame(CosmeticRenderData neutral) { data=neutral;last=System.nanoTime(); }
    }
    public static void clearRemote() {
        releaseRemoteExcept(Set.of());
        remoteGeneration++;REMOTE_IDS.clear();REMOTE_ANIMATED_IDS.clear();REMOTE_FRAMES.clear();remoteTooLarge.clear();remoteCandidates=Set.of();
        // A previous task may still own the executor; it decrements the job count on completion.
    }
    private static void releaseRemoteExcept(Set<Integer> wanted) {
        synchronized(ACTIVE){
            for(int id:REMOTE_IDS)if(!wanted.contains(id) && !CosmeticConfig.isEquipped(id) && !VISIBLE_PREVIEWS.contains(id)){
                ActiveData asset=ACTIVE.remove(id);if(asset!=null)release(asset);
            }
        }
    }
    public static CosmeticRenderData remoteData(java.util.UUID owner, CosmeticDefinition definition) {
        if(definition==null || !REMOTE_IDS.contains(definition.id()))return null;
        ActiveData asset=ACTIVE.get(definition.id());if(asset==null)return null;
        RemoteFrame frame=REMOTE_FRAMES.get(new RemoteKey(owner,definition.id()));
        return frame==null?asset.neutralData:frame.data;
    }
    private static long assetBytes(ActiveData asset) {
        long texture=(long)asset.pixels.getWidth()*asset.pixels.getHeight()*8;
        if(asset.capePixels!=null)texture+=(long)asset.capePixels.getWidth()*asset.capePixels.getHeight()*8;
        if(asset.animation!=null)texture+=(long)asset.animation.sheet.getWidth()*asset.animation.sheet.getHeight()*4;
        return texture+(long)asset.neutralData.mesh().vertexCount()*96;
    }
    /** Tick only: bounded ownership, one outstanding remote load and at most two queued animation samples. */
    public static void remoteTick(java.util.Collection<dev.lin.client.cosmetics.sync.RemoteCosmetics.View> views,
            Map<java.util.UUID,BedrockModelLoader.AnimationContext> motion) {
        Set<Integer> candidates=new java.util.HashSet<>();
        for(var view:views)for(var definition:view.peer().definitions())candidates.add(definition.id());
        if(!candidates.equals(remoteCandidates)){remoteCandidates=Set.copyOf(candidates);remoteTooLarge.clear();}
        Set<Integer> ids=new java.util.LinkedHashSet<>();
        Set<Integer> animatedIds=new java.util.HashSet<>();
        Set<RemoteKey> frames=new java.util.HashSet<>();
        long assets=0,meshes=0,now=System.nanoTime();
        for(var view:views)for(var definition:view.peer().definitions()) {
            if(remoteTooLarge.contains(definition.id()))continue;
            ActiveData asset=ACTIVE.get(definition.id());
            if(!ids.contains(definition.id())) {
                long cost=asset==null?512*1024:assetBytes(asset);
                if(ids.size()>=96 || assets+cost>REMOTE_ASSET_BYTES)continue;
                ids.add(definition.id());assets+=cost;
            }
            if(view.animated())animatedIds.add(definition.id());
            if(asset==null || asset.modelAnimation==null || !view.animated())continue;
            long cost=(long)asset.neutralData.mesh().vertexCount()*128;
            if(meshes+cost>REMOTE_MESH_BYTES)continue;
            meshes+=cost;
            RemoteKey key=new RemoteKey(view.player().getUUID(),definition.id());frames.add(key);
            RemoteFrame frame=REMOTE_FRAMES.computeIfAbsent(key,k->new RemoteFrame(asset.neutralData));
            if(frame.updating || now<frame.next || remoteJobs>=2)continue;
            var input=motion.get(key.owner()).snapshot();
            // Motion is captured on the client thread; persistent variables stay with this avatar/asset.
            frame.updating=true;remoteJobs++;long generation=remoteGeneration;
            frame.next=now+300_000_000L;
            CompletableFuture.supplyAsync(()->{
                if(asset.released)return null;
                return BedrockModelLoader.loadForInstance(asset.modelAnimation.geometry,asset.modelAnimation.animation,
                    asset.modelAnimation.definition,(System.nanoTime()-START_NANOS)/1_000_000_000f,input,frame.animation);
            },MODEL_EXECUTOR).whenComplete((mesh,error)->Minecraft.getInstance().execute(()->{
                remoteJobs--;frame.updating=false;
                if(generation!=remoteGeneration || asset.released || REMOTE_FRAMES.get(key)!=frame)return;
                if(error==null && mesh!=null){long at=System.nanoTime();frame.data=transition(frame.data,mesh,at,300_000_000L);frame.last=at;}
                else frame.next=System.nanoTime()+5_000_000_000L;
            }));
        }
        releaseRemoteExcept(ids);
        REMOTE_IDS.clear();REMOTE_IDS.addAll(ids);REMOTE_ANIMATED_IDS.clear();REMOTE_ANIMATED_IDS.addAll(animatedIds);REMOTE_FRAMES.keySet().retainAll(frames);
        remoteLoading.removeIf(CompletableFuture::isDone);
        if(remoteLoading.size()<REMOTE_CONCURRENCY) {
            outer:
            for(var view:views){
                for(var definition:view.peer().definitions())if(ids.contains(definition.id()) && !ACTIVE.containsKey(definition.id()) && !REQUESTS.containsKey(definition.id())){
                    CompletableFuture<CosmeticRenderData> future=request(definition,true);
                    if(!future.isDone()){
                        remoteLoading.add(future);
                        if(remoteLoading.size()>=REMOTE_CONCURRENCY)break outer;
                    }
                }
            }
        }
    }

    private CosmeticAssetManager() {
    }

    public static CosmeticRenderData get(CosmeticDefinition definition) {
        if (definition == null) {
            return null;
        }
        ActiveData active = ACTIVE.get(definition.id());
        if (active != null) {
            return active.data;
        }
        request(definition);
        return null;
    }

    /** Returns the model evaluated with Lunar's GUI-only animation state. */
    public static CosmeticRenderData getPreview(CosmeticDefinition definition) {
        if (definition == null) {
            return null;
        }
        ActiveData active = ACTIVE.get(definition.id());
        if (active != null) {
            return active.previewData;
        }
        request(definition);
        return null;
    }

    public static CompletableFuture<CosmeticRenderData> request(CosmeticDefinition definition) {
        return request(definition,false);
    }
    private static CompletableFuture<CosmeticRenderData> request(CosmeticDefinition definition,boolean remote) {
        if (definition == null) {
            return CompletableFuture.failedFuture(new IllegalArgumentException("No cosmetic"));
        }
        if(!remote)REMOTE_ORIGIN.remove(definition.id());
        ActiveData active = ACTIVE.get(definition.id());
        if (active != null) {
            return CompletableFuture.completedFuture(active.data);
        }
        synchronized (REQUESTS) {
            if (closed) return CompletableFuture.failedFuture(
                    new IllegalStateException("Cosmetic manager closed"));
            CompletableFuture<CosmeticRenderData> pending = REQUESTS.get(definition.id());
            if (pending != null) return pending;
            FailedRequest previous = FAILURES.get(definition.id());
            if (previous != null && System.nanoTime() < previous.retryAt) return previous.result;
            // Publish the owner before scheduling: even immediate completion is safe.
            CompletableFuture<CosmeticRenderData> owner = new CompletableFuture<>();
            REQUESTS.put(definition.id(), owner);
            if(remote)REMOTE_ORIGIN.add(definition.id());
            CompletableFuture.supplyAsync(() -> {
                if (REQUESTS.get(definition.id()) != owner) throw new java.util.concurrent.CancellationException();
                try { return prepare(definition); }
                catch (Exception failure) { throw new java.util.concurrent.CompletionException(failure); }
            }, EXECUTOR).thenCompose(prepared -> register(prepared, owner))
                    .whenComplete((value, failure) -> {
                        synchronized (REQUESTS) {
                            if (!REQUESTS.remove(definition.id(), owner)) return;
                            REMOTE_ORIGIN.remove(definition.id());
                            if (failure == null) {
                                FAILURES.remove(definition.id());
                                owner.complete(value);
                            } else {
                                int attempts = previous == null ? 1 : Math.min(5, previous.attempts + 1);
                                long delay = Math.min(30L, 2L << (attempts - 1)) * 1_000_000_000L;
                                FAILURES.put(definition.id(), new FailedRequest(attempts,
                                        System.nanoTime() + delay, owner));
                                owner.completeExceptionally(failure);
                                LinClient.LOGGER.warn("Unable to load cosmetic {} ({})",
                                        definition.id(), definition.name(), failure);
                            }
                        }
                    });
            return owner;
        }
    }

    /** Explicit recovery after repairing assets; normal requests also retry with backoff. */
    public static void retryFailedLoads() { FAILURES.clear(); }

    public static boolean isLoading(int id) {
        return REQUESTS.containsKey(id);
    }

    public static void preload(List<CosmeticDefinition> visible) {
        VISIBLE_PREVIEWS.clear();
        if (visible == null) {
            return;
        }
        for (CosmeticDefinition definition : visible) {
            VISIBLE_PREVIEWS.add(definition.id());
            request(definition);
        }
    }

    public static void clearPreload() {
        VISIBLE_PREVIEWS.clear();
        cancelUnusedRequests();
    }

    public static void setMenuPreviewActive(boolean active) {
        menuPreviewActive = active;
    }

    private static PreparedData prepare(CosmeticDefinition definition) throws Exception {
        if ("HOPLITE_PET".equals(definition.indexType())) {
            HoplitePetAssets.Loaded pet = HoplitePetAssets.load(definition.logicalResource());
            FrameSequence sequence = new FrameSequence(pet.sheet(), pet.width(), pet.height(),
                    1, pet.frames(), pet.frameTime(), false);
            return new PreparedData(definition, pet.mesh(), pet.mesh(), sequence.frame(0),
                    null, CosmeticAttachment.COMPANION, true, false, sequence, null);
        }
        if (definition.gek()) {
            return prepareGek(definition);
        }
        if (definition.category() == CosmeticCategory.CLOAK) {
            return prepareCape(definition);
        }
        if (definition.category() == CosmeticCategory.DRAGON_WINGS) {
            return prepareLegacyWings(definition);
        }
        return prepareObj(definition);
    }

    private static PreparedData prepareGek(CosmeticDefinition definition) throws Exception {
        JsonObject gek = readJson(definition.logicalResource());
        String modelPath = requiredPath(gek, "model");
        String texturePath = requiredPath(gek, "texture");
        JsonObject geometry = readJson(modelPath);
        JsonObject animationRoot = gek.has("animation")
                ? readJson(LunarAssetIndex.normalize(gek.get("animation").getAsString())) : null;
        CosmeticMesh mesh = initialAnimatedMesh(geometry, animationRoot, gek, false);
        CosmeticMesh previewMesh = initialAnimatedMesh(
                geometry, animationRoot, gek, true);
        BufferedImage sheet = readImage(texturePath);
        FrameSequence textureAnimation = frameSequence(texturePath, sheet,
                mesh.textureWidth(), mesh.textureHeight(), false);
        BufferedImage frame = textureAnimation.frame(0);
        CosmeticAttachment attachment = attachment(definition, gek, null);
        return new PreparedData(definition, mesh, previewMesh, frame, null, attachment,
                true, definition.category() == CosmeticCategory.AURAS, textureAnimation,
                new ModelAnimation(BedrockModelLoader.compile(geometry, animationRoot), animationRoot, gek));
    }

    private static CosmeticMesh initialAnimatedMesh(JsonObject geometry,
                                                     JsonObject animationRoot,
                                                     JsonObject gek,
                                                     boolean inGui) {
        var compiled=BedrockModelLoader.compile(geometry,animationRoot);
        var context=new BedrockModelLoader.AnimationContext();
        if (animationRoot == null) {
            return BedrockModelLoader.load(compiled, null, gek,0f,inGui,context);
        }
        IllegalArgumentException lastFailure = null;
        // Some Lunar effects intentionally scale every visible bone to zero at
        // animation time 0. Sample nearby GUI frames before falling back to the
        // authored base geometry so those effects can enter the live cache.
        for (float time : new float[]{0.0F, 0.25F, 0.5F, 1.0F, 2.0F, 3.0F}) {
            try {
                return BedrockModelLoader.load(compiled, animationRoot, gek,
                        time, inGui,context);
            } catch (IllegalArgumentException failure) {
                lastFailure = failure;
            }
        }
        try {
            return BedrockModelLoader.load(geometry, null, null);
        } catch (IllegalArgumentException failure) {
            if (lastFailure != null) failure.addSuppressed(lastFailure);
            throw failure;
        }
    }

    private static PreparedData prepareObj(CosmeticDefinition definition) throws Exception {
        JsonObject legacy = legacyDefinition(definition.indexType());
        if (legacy == null) {
            throw new IOException("No legacy model definition for " + definition.indexType());
        }
        String family = HATS.containsKey(definition.indexType()) ? "hats" : "bodywear";
        String modelPath = "cosmetics/models/" + family + "/" + definition.indexType()
                + "/" + definition.indexType() + ".obj";
        Path model = LunarAssetStore.obtain(modelPath);
        CosmeticMesh mesh;
        try (var reader = Files.newBufferedReader(model, StandardCharsets.UTF_8)) {
            mesh = ObjModelLoader.load(reader, legacy, false);
        }
        BufferedImage sheet = readImage(definition.logicalResource());
        FrameSequence animation = frameSequence(definition.logicalResource(), sheet,
                sheet.getWidth(), legacyFrameHeight(sheet), false);
        BufferedImage frame = animation.frame(0);
        return new PreparedData(definition, mesh, mesh, frame, null,
                attachment(definition, null, legacy), true,
                definition.category() == CosmeticCategory.AURAS, animation, null);
    }

    private static PreparedData prepareCape(CosmeticDefinition definition) throws Exception {
        BufferedImage sheet = readImage(definition.logicalResource());
        CapeFrame cape = capeFrame(sheet, readOptionalJson(definition.logicalResource() + ".mcmeta"));
        FrameSequence animation = new FrameSequence(sheet, cape.width, cape.height,
                Math.max(1, sheet.getWidth() / cape.width), cape.frameCount,
                cape.frameTime, true);
        BufferedImage first = animation.frame(0);
        BufferedImage preview = cropCapeFace(first);
        BufferedImage atlas = capeAtlas(first);
        CosmeticMesh mesh = BuiltinCosmeticMeshes.capePreview();
        return new PreparedData(definition, mesh, mesh, preview,
                atlas, CosmeticAttachment.CAPE, true, false, animation, null);
    }

    private static PreparedData prepareLegacyWings(CosmeticDefinition definition) throws Exception {
        BufferedImage sheet = readImage(definition.logicalResource());
        FrameSequence animation = frameSequence(definition.logicalResource(), sheet,
                sheet.getWidth(), legacyFrameHeight(sheet), false);
        CosmeticMesh mesh = BuiltinCosmeticMeshes.wings();
        return new PreparedData(definition, mesh, mesh,
                animation.frame(0), null, CosmeticAttachment.WINGS, true, false,
                animation, null);
    }

    private static CompletableFuture<CosmeticRenderData> register(PreparedData prepared, CompletableFuture<CosmeticRenderData> owner) {
        CompletableFuture<CosmeticRenderData> result = new CompletableFuture<>();
        Minecraft.getInstance().execute(() -> {
            try {
                int id = prepared.definition.id();
                if (closed || REQUESTS.get(id) != owner) {
                    result.cancel(false);
                    return;
                }
                if(REMOTE_ORIGIN.contains(id) && !CosmeticConfig.isEquipped(id) && !VISIBLE_PREVIEWS.contains(id)) {
                    long cost=(long)prepared.image.getWidth()*prepared.image.getHeight()*8+(long)prepared.mesh.vertexCount()*96;
                    if(prepared.animation!=null)cost+=(long)prepared.animation.sheet.getWidth()*prepared.animation.sheet.getHeight()*4;
                    if(prepared.capeAtlas!=null)cost+=(long)prepared.capeAtlas.getWidth()*prepared.capeAtlas.getHeight()*8;
                    long resident=0;
                    synchronized(ACTIVE){for(var e:ACTIVE.entrySet())if(REMOTE_IDS.contains(e.getKey()))resident+=assetBytes(e.getValue());}
                    if(!REMOTE_IDS.contains(id) || resident+cost>REMOTE_ASSET_BYTES){
                        remoteTooLarge.add(id);result.completeExceptionally(new IllegalStateException("Remote cosmetic memory budget"));return;
                    }
                }
                Identifier textureId = Identifier.fromNamespaceAndPath(
                        LinClient.MOD_ID, "runtime/cosmetic_" + id);
                NativeImage pixels = toNativeImage(prepared.image);
                DynamicTexture texture = new DynamicTexture(
                        () -> "Standalone Lunar cosmetic " + id,
                        pixels);
                Minecraft.getInstance().getTextureManager().register(textureId, texture);

                Identifier capeId = null;
                DynamicTexture capeTexture = null;
                NativeImage capePixels = null;
                if (prepared.capeAtlas != null) {
                    capeId = Identifier.fromNamespaceAndPath(
                            LinClient.MOD_ID, "runtime/cape_" + id);
                    capePixels = toNativeImage(prepared.capeAtlas);
                    capeTexture = new DynamicTexture(
                            () -> "Standalone Lunar cape " + id,
                            capePixels);
                    Minecraft.getInstance().getTextureManager().register(capeId, capeTexture);
                }
                CosmeticRenderData data = new CosmeticRenderData(prepared.definition,
                        prepared.mesh, textureId, capeId, prepared.attachment,
                        prepared.doubleSided, prepared.translucent);
                CosmeticRenderData previewData = new CosmeticRenderData(
                        prepared.definition, prepared.previewMesh, textureId, capeId,
                        prepared.attachment, prepared.doubleSided, prepared.translucent,
                        prepared.previewMesh, prepared.previewMesh,
                        System.nanoTime(), 1L);
                ACTIVE.put(id, new ActiveData(data, previewData, texture, capeTexture,
                        pixels, capePixels, prepared.animation,
                        prepared.modelAnimation));
                trim();
                result.complete(data);
            } catch (Exception exception) {
                result.completeExceptionally(exception);
            }
        });
        return result;
    }

    private static void trim() {
        synchronized (ACTIVE) {
            Iterator<Map.Entry<Integer, ActiveData>> iterator = ACTIVE.entrySet().iterator();
            while (ACTIVE.size() > UI_CACHE_LIMIT && iterator.hasNext()) {
                Map.Entry<Integer, ActiveData> entry = iterator.next();
                if (CosmeticConfig.isEquipped(entry.getKey()) || REMOTE_IDS.contains(entry.getKey())) {
                    continue;
                }
                iterator.remove();
                release(entry.getValue());
            }
        }
    }

    private static CosmeticAttachment attachment(CosmeticDefinition definition,
                                                   JsonObject gek, JsonObject legacy) {
        if (definition.category() == CosmeticCategory.CLOAK) return CosmeticAttachment.CAPE;
        if (definition.category() == CosmeticCategory.DRAGON_WINGS) return CosmeticAttachment.WINGS;
        if (definition.category() == CosmeticCategory.AURAS) return CosmeticAttachment.AURA;
        if (definition.category() == CosmeticCategory.COMPANION) return CosmeticAttachment.COMPANION;
        if (definition.category() == CosmeticCategory.SHOES) return CosmeticAttachment.FEET;
        if (definition.category() == CosmeticCategory.ITEMS) return CosmeticAttachment.HAND;
        if (definition.category() == CosmeticCategory.BACKPACK
                || definition.category() == CosmeticCategory.SHIELDS) return CosmeticAttachment.BACK;
        String bone = gek == null ? "" : string(gek, "attached_bone", "").toUpperCase();
        String type = gek == null ? "" : string(gek, "type", "").toLowerCase();
        if (type.equals("companion")) return CosmeticAttachment.COMPANION;
        if (bone.contains("SHOULDER")) return CosmeticAttachment.LEFT_SHOULDER;
        if (bone.contains("HEAD")) return CosmeticAttachment.HEAD;
        if (bone.contains("BODY") || bone.contains("CHEST")) return CosmeticAttachment.BODY;
        if (type.equals("suits") || definition.category() == CosmeticCategory.SUITS) {
            return CosmeticAttachment.FULL_BODY;
        }
        String legacyBone = legacy == null ? "" : string(legacy, "bodyPart", "");
        if (legacyBone.equalsIgnoreCase("HEAD")) return CosmeticAttachment.HEAD;
        return definition.category() == CosmeticCategory.HAT
                || definition.category() == CosmeticCategory.BANDANNA
                || definition.category() == CosmeticCategory.MASK
                || definition.category() == CosmeticCategory.GLASSES
                ? CosmeticAttachment.HEAD : CosmeticAttachment.BODY;
    }

    private static JsonObject legacyDefinition(String indexType) {
        JsonObject value = HATS.get(indexType);
        return value != null ? value : BODYWEAR.get(indexType);
    }

    private static Map<String, JsonObject> loadLegacyIndex(String name) {
        String path = "/assets/lin_client/catalog/" + name;
        try (InputStream input = CosmeticAssetManager.class.getResourceAsStream(path)) {
            if (input == null) return Map.of();
            JsonObject root = JsonParser.parseReader(
                    new InputStreamReader(input, StandardCharsets.UTF_8)).getAsJsonObject();
            Map<String, JsonObject> result = new LinkedHashMap<>();
            for (Map.Entry<String, JsonElement> entry : root.entrySet()) {
                if (entry.getValue().isJsonObject()) {
                    result.put(entry.getKey(), entry.getValue().getAsJsonObject());
                }
            }
            return Map.copyOf(result);
        } catch (Exception exception) {
            throw new IllegalStateException("Unable to load " + name, exception);
        }
    }

    private static JsonObject readJson(String logicalPath) throws IOException {
        Path file = LunarAssetStore.obtain(logicalPath);
        return JsonParser.parseString(Files.readString(file, StandardCharsets.UTF_8))
                .getAsJsonObject();
    }

    private static JsonObject readOptionalJson(String logicalPath) {
        try {
            return readJson(logicalPath);
        } catch (Exception ignored) {
            return null;
        }
    }

    private static BufferedImage readImage(String logicalPath) throws IOException {
        Path file = LunarAssetStore.obtain(logicalPath);
        synchronized (IMAGE_DECODER_LOCK) {
            BufferedImage image = ImageIO.read(file.toFile());
            if (image == null) {
                throw new IOException("Image decoder rejected " + logicalPath);
            }
            return image;
        }
    }

    private static int legacyFrameHeight(BufferedImage image) {
        if (image.getHeight() > image.getWidth()
                && image.getHeight() % image.getWidth() == 0) {
            return image.getWidth();
        }
        return image.getHeight();
    }

    private static FrameSequence frameSequence(String logicalPath, BufferedImage image,
                                               int declaredWidth, int declaredHeight,
                                               boolean cape) {
        JsonObject metadata = LunarAssetIndex.get(logicalPath + ".mcmeta") == null
                ? null : readOptionalJson(logicalPath + ".mcmeta");
        JsonObject animation = metadata == null ? null : metadata.getAsJsonObject("animation");
        int frameWidth;
        int frameHeight;
        if (animation != null && animation.has("width")) {
            frameWidth = animation.get("width").getAsInt();
        } else {
            frameWidth = image.getWidth();
        }
        if (animation != null && animation.has("height")) {
            frameHeight = animation.get("height").getAsInt();
        } else if (declaredWidth > 0 && declaredHeight > 0) {
            float pixelScale = (float) frameWidth / declaredWidth;
            frameHeight = Math.max(1, Math.round(declaredHeight * pixelScale));
        } else {
            frameHeight = image.getHeight();
        }
        frameWidth = Math.max(1, Math.min(frameWidth, image.getWidth()));
        frameHeight = Math.max(1, Math.min(frameHeight, image.getHeight()));
        int columns = Math.max(1, image.getWidth() / frameWidth);
        int rows = Math.max(1, image.getHeight() / frameHeight);
        int count = animation == null ? 1 : columns * rows;
        if (animation == null && image.getHeight() > frameHeight
                && image.getHeight() % frameHeight == 0) {
            count = columns * rows;
        }
        int frameTime = animation != null && animation.has("frametime")
                ? Math.max(1, animation.get("frametime").getAsInt()) : 2;
        return new FrameSequence(image, frameWidth, frameHeight, columns,
                Math.max(1, count), frameTime, cape);
    }

    private static CapeFrame capeFrame(BufferedImage sheet, JsonObject metadata) {
        JsonObject animation = metadata == null ? null : metadata.getAsJsonObject("animation");
        int width = animation != null && animation.has("width")
                ? animation.get("width").getAsInt() : sheet.getWidth();
        width = Math.max(1, Math.min(width, sheet.getWidth()));
        int inferredHeight = width % 64 == 0 ? width / 2
                : Math.max(1, Math.round(width * 17.0F / 22.0F));
        int height = animation != null && animation.has("height")
                ? animation.get("height").getAsInt() : inferredHeight;
        height = Math.max(1, Math.min(height, sheet.getHeight()));
        int columns = Math.max(1, sheet.getWidth() / width);
        int rows = Math.max(1, sheet.getHeight() / height);
        int count = animation == null ? 1 : columns * rows;
        int frameTime = animation != null && animation.has("frametime")
                ? Math.max(1, animation.get("frametime").getAsInt()) : 2;
        return new CapeFrame(width, height, Math.max(1, count), frameTime);
    }

    private static BufferedImage cropCapeFace(BufferedImage frame) {
        boolean atlas = frame.getWidth() % 64 == 0 && frame.getHeight() * 2 == frame.getWidth();
        int scale = atlas ? Math.max(1, frame.getWidth() / 64)
                : Math.max(1, Math.round(frame.getWidth() / 22.0F));
        int x = Math.min(frame.getWidth() - 1, scale);
        int y = Math.min(frame.getHeight() - 1, scale);
        int width = Math.max(1, Math.min(scale * 10, frame.getWidth() - x));
        int height = Math.max(1, Math.min(scale * 16, frame.getHeight() - y));
        return frame.getSubimage(x, y, width, height);
    }

    private static BufferedImage capeAtlas(BufferedImage frame) {
        if (frame.getWidth() % 64 == 0 && frame.getHeight() * 2 == frame.getWidth()) {
            return frame;
        }
        BufferedImage face = cropCapeFace(frame);
        BufferedImage atlas = new BufferedImage(64, 32, BufferedImage.TYPE_INT_ARGB);
        Graphics2D graphics = atlas.createGraphics();
        try {
            graphics.setRenderingHint(RenderingHints.KEY_INTERPOLATION,
                    RenderingHints.VALUE_INTERPOLATION_BILINEAR);
            graphics.drawImage(face, 1, 1, 11, 17, null);
            graphics.drawImage(face, 12, 1, 22, 17, null);
        } finally {
            graphics.dispose();
        }
        return atlas;
    }

    private static NativeImage toNativeImage(BufferedImage image) {
        NativeImage result = new NativeImage(image.getWidth(), image.getHeight(), true);
        for (int y = 0; y < image.getHeight(); y++) {
            for (int x = 0; x < image.getWidth(); x++) {
                int argb = image.getRGB(x, y);
                int abgr = argb & 0xFF00FF00
                        | (argb & 0xFF0000) >>> 16 | (argb & 0xFF) << 16;
                result.setPixelABGR(x, y, abgr);
            }
        }
        return result;
    }

    private static String requiredPath(JsonObject object, String name) throws IOException {
        if (!object.has(name) || !object.get(name).isJsonPrimitive()) {
            throw new IOException("GEK definition is missing " + name);
        }
        return LunarAssetIndex.normalize(object.get(name).getAsString());
    }

    private static String string(JsonObject object, String name, String fallback) {
        return object != null && object.has(name) && object.get(name).isJsonPrimitive()
                ? object.get(name).getAsString() : fallback;
    }

    private static void release(ActiveData active) {
        active.released = true;
        FRAME_PIXELS.release(active.animation);
        Minecraft minecraft = Minecraft.getInstance();
        minecraft.getTextureManager().release(active.data.texture());
        if (active.data.capeTexture() != null) {
            minecraft.getTextureManager().release(active.data.capeTexture());
        }
    }

    private static void cancelUnusedRequests() {
        synchronized (REQUESTS) {
            for (var entry : REQUESTS.entrySet()) {
                if (!CosmeticConfig.isEquipped(entry.getKey())
                        && !VISIBLE_PREVIEWS.contains(entry.getKey())
                        && !REMOTE_IDS.contains(entry.getKey())
                        && REQUESTS.remove(entry.getKey(), entry.getValue())) {
                    REMOTE_ORIGIN.remove(entry.getKey());
                    entry.getValue().cancel(false);
                }
            }
        }
    }

    /** Client-thread cleanup; equipped and currently visible assets retain ownership. */
    public static void releaseUnused() {
        cancelUnusedRequests();
        synchronized (ACTIVE) {
            var iterator = ACTIVE.entrySet().iterator();
            while (iterator.hasNext()) {
                var entry = iterator.next();
                if (CosmeticConfig.isEquipped(entry.getKey())
                        || VISIBLE_PREVIEWS.contains(entry.getKey()) || REMOTE_IDS.contains(entry.getKey())) continue;
                iterator.remove();
                release(entry.getValue());
            }
        }
    }

    /** Advances animated WebP/PNG sheets using vanilla resource-pack timing. */
    public static void tick() {
        long tickNanos = System.nanoTime();
        Minecraft minecraft = Minecraft.getInstance();
        boolean thirdPerson = !minecraft.options.getCameraType().isFirstPerson();
        boolean lockerOpen = dev.lin.client.cosmetics.ui.SystemNavigation.activeScreen() instanceof CosmeticLockerScreen;
        if (!lockerOpen && !(minecraft.screen instanceof dev.lin.client.cosmetics.ui.ClientPageHost host && host.hasCosmetics()) && tickNanos >= nextCleanupNanos) {
            nextCleanupNanos = tickNanos + 5_000_000_000L;
            releaseUnused();
        }
        synchronized (ACTIVE) {
            // A completed future can invoke whenComplete inline. Its access-order
            // ACTIVE.get changes the live LinkedHashMap even under this reentrant lock.
            // Snapshot entries, retaining the LRU policy and the existing ownership lock.
            for (Map.Entry<Integer, ActiveData> entry : new ArrayList<>(ACTIVE.entrySet())) {
                ActiveData active = entry.getValue();
                int id = entry.getKey();
                CosmeticCategory category = active.data.definition().category();
                boolean menuUsesWorldMesh = menuPreviewActive
                        && (category == CosmeticCategory.AURAS
                        || category == CosmeticCategory.DRAGON_WINGS);
                boolean updatePreview = VISIBLE_PREVIEWS.contains(id)
                        && (!menuPreviewActive || !menuUsesWorldMesh);
                boolean updateWorld = CosmeticConfig.isEquipped(id)
                        && (thirdPerson || lockerOpen || menuUsesWorldMesh
                        || (minecraft.player != null
                        && active.data.attachment() == CosmeticAttachment.COMPANION));
                if (!updatePreview && !updateWorld && !REMOTE_ANIMATED_IDS.contains(id)) continue;

                if (active.animation != null && active.animation.count > 1) {
                    active.ticks++;
                    if (active.ticks >= active.animation.frameTime) {
                        active.ticks = 0;
                        active.frame = (active.frame + 1) % active.animation.count;
                        FrameSequence sequence = active.animation;
                        int frame = active.frame;
                        FRAME_PIXELS.get(sequence, frame, 0, () -> sequence.cape
                                ? cropCapeFace(sequence.frame(frame)) : sequence.frame(frame)).write(active.pixels);
                        if (sequence.cape && active.capePixels != null && active.capeTexture != null) {
                            FRAME_PIXELS.get(sequence, frame, 1, () -> capeAtlas(sequence.frame(frame))).write(active.capePixels);
                            active.capeTexture.upload();
                        }
                        active.texture.upload();
                    }
                }

                if ((!updatePreview && !updateWorld) || active.modelAnimation == null || active.modelUpdating
                        || tickNanos < active.nextModelUpdateNanos) continue;
                active.modelUpdating = true;
                active.nextModelUpdateNanos = tickNanos
                        + (active.data.mesh().vertexCount() > 3000
                        ? LARGE_MODEL_UPDATE_INTERVAL_NANOS
                        : MODEL_UPDATE_INTERVAL_NANOS);
                var capturedMotion = BedrockModelLoader.localSnapshot();
                CompletableFuture.supplyAsync(() -> {
                            if (active.released) return null;
                            float time = (System.nanoTime() - START_NANOS)
                                    / 1_000_000_000.0F;
                            CosmeticMesh worldMesh = updateWorld
                                    ? BedrockModelLoader.load(
                                            active.modelAnimation.geometry,
                                            active.modelAnimation.animation,
                                            active.modelAnimation.definition,
                                            time, false, capturedMotion)
                                    : null;
                            CosmeticMesh previewMesh = updatePreview
                                    ? BedrockModelLoader.load(
                                            active.modelAnimation.geometry,
                                            active.modelAnimation.animation,
                                            active.modelAnimation.definition,
                                            time, true)
                                    : null;
                            return new AnimatedMeshes(worldMesh, previewMesh);
                        }, MODEL_EXECUTOR)
                        .whenComplete((meshes, failure) -> {
                          synchronized (ACTIVE) {
                            if (active.released || ACTIVE.get(id) != active) return;
                            if (failure == null && meshes != null) {
                                long now = System.nanoTime();
                                long duration = Math.max(MIN_MODEL_TRANSITION_NANOS,
                                        Math.min(MAX_MODEL_TRANSITION_NANOS,
                                                now - active.lastModelNanos));
                                if (meshes.world != null) {
                                    active.data = transition(
                                            active.data, meshes.world, now, duration);
                                }
                                if (meshes.preview != null) {
                                    active.previewData = transitionPreview(
                                            active.previewData, meshes.preview, now, duration);
                                }
                                active.lastModelNanos = now;
                            }
                            active.modelUpdating = false;
                          }
                        });
            }
        }
    }

    private static CosmeticRenderData transition(CosmeticRenderData old,
                                                   CosmeticMesh mesh,
                                                   long now, long duration) {
        CosmeticMesh current = currentMesh(old);
        return new CosmeticRenderData(old.definition(), mesh,
                old.texture(), old.capeTexture(), old.attachment(),
                old.doubleSided(), old.translucent(), current,
                old.referenceMesh(), now, duration);
    }

    private static CosmeticRenderData transitionPreview(CosmeticRenderData old,
                                                          CosmeticMesh mesh,
                                                          long now, long duration) {
        CosmeticMesh current = currentMesh(old);
        return new CosmeticRenderData(old.definition(), mesh,
                old.texture(), old.capeTexture(), old.attachment(),
                old.doubleSided(), old.translucent(), current,
                mesh, now, duration);
    }

    private static CosmeticMesh currentMesh(CosmeticRenderData data) {
        CosmeticMesh target = data.mesh();
        CosmeticMesh previous = data.previousMesh();
        float progress = data.meshProgress();
        if (previous == null || progress >= 1.0F
                || previous.vertexCount() != target.vertexCount()) {
            return target;
        }
        CosmeticVertex[] from = previous.rawVertices();
        CosmeticVertex[] to = target.rawVertices();
        CosmeticVertex[] sampled = new CosmeticVertex[to.length];
        for (int index = 0; index < to.length; index++) {
            CosmeticVertex a = from[index];
            CosmeticVertex b = to[index];
            sampled[index] = new CosmeticVertex(
                    lerp(a.x(), b.x(), progress),
                    lerp(a.y(), b.y(), progress),
                    lerp(a.z(), b.z(), progress),
                    b.u(), b.v(), lerp(a.nx(), b.nx(), progress),
                    lerp(a.ny(), b.ny(), progress), lerp(a.nz(), b.nz(), progress));
        }
        return CosmeticMesh.of(sampled, target.textureWidth(),
                target.textureHeight());
    }

    private static float lerp(float from, float to, float progress) {
        return from + (to - from) * progress;
    }

    public static void close() {
        closed = true;
        clearRemote();
        synchronized (REQUESTS) {
            var pending = new ArrayList<>(REQUESTS.values());
            REQUESTS.clear();
            pending.forEach(future -> future.cancel(false));
            FAILURES.clear();
        }
        EXECUTOR.shutdownNow();
        MODEL_EXECUTOR.shutdownNow();
        synchronized (ACTIVE) {
            for (ActiveData active : new ArrayList<>(ACTIVE.values())) {
                release(active);
            }
            ACTIVE.clear();
            VISIBLE_PREVIEWS.clear();
        }
        REQUESTS.clear();
        REMOTE_ORIGIN.clear();
    }

    private record PreparedData(CosmeticDefinition definition, CosmeticMesh mesh,
                                CosmeticMesh previewMesh,
                                BufferedImage image, BufferedImage capeAtlas,
                                CosmeticAttachment attachment,
                                boolean doubleSided, boolean translucent,
                                FrameSequence animation,
                                ModelAnimation modelAnimation) {
    }

    private static final class ActiveData {
        private final CosmeticRenderData neutralData;
        private volatile CosmeticRenderData data;
        private volatile CosmeticRenderData previewData;
        private final DynamicTexture texture;
        private final DynamicTexture capeTexture;
        private final NativeImage pixels;
        private final NativeImage capePixels;
        private final FrameSequence animation;
        private final ModelAnimation modelAnimation;
        private int frame;
        private int ticks;
        private volatile long lastModelNanos = System.nanoTime();
        private volatile long nextModelUpdateNanos;
        private volatile boolean modelUpdating;
        private volatile boolean released;

        private ActiveData(CosmeticRenderData data,
                           CosmeticRenderData previewData,
                           DynamicTexture texture,
                           DynamicTexture capeTexture, NativeImage pixels,
                           NativeImage capePixels, FrameSequence animation,
                           ModelAnimation modelAnimation) {
            this.neutralData = data;
            this.data = data;
            this.previewData = previewData;
            this.texture = texture;
            this.capeTexture = capeTexture;
            this.pixels = pixels;
            this.capePixels = capePixels;
            this.animation = animation;
            this.modelAnimation = modelAnimation;
        }
    }

    private record CapeFrame(int width, int height, int frameCount, int frameTime) {
    }

    private record ModelAnimation(BedrockModelLoader.CompiledGeometry geometry, JsonObject animation,
                                  JsonObject definition) {
    }

    private record AnimatedMeshes(CosmeticMesh world, CosmeticMesh preview) {
    }

    private static final class FrameSequence {
        private final BufferedImage sheet;
        private final int width;
        private final int height;
        private final int columns;
        private final int count;
        private final int frameTime;
        private final boolean cape;

        private FrameSequence(BufferedImage sheet, int width, int height,
                              int columns, int count, int frameTime, boolean cape) {
            this.sheet = sheet;
            this.width = width;
            this.height = height;
            this.columns = columns;
            this.count = count;
            this.frameTime = frameTime;
            this.cape = cape;
        }

        private BufferedImage frame(int index) {
            int safe = Math.floorMod(index, count);
            int x = safe % columns * width;
            int y = safe / columns * height;
            return sheet.getSubimage(x, y, Math.min(width, sheet.getWidth() - x),
                    Math.min(height, sheet.getHeight() - y));
        }
    }
}
