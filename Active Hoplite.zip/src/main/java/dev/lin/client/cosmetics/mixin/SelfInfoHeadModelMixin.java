package dev.lin.client.cosmetics.mixin;

import dev.lin.client.cosmetics.ui.SelfInfoHeadPortrait;
import net.minecraft.client.model.player.PlayerModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.renderer.entity.state.AvatarRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import java.util.ArrayList;
import java.util.List;

@Mixin(PlayerModel.class)
public abstract class SelfInfoHeadModelMixin implements dev.lin.client.cosmetics.ui.PortraitModelState {
    @Unique private final List<ModelPart> lin$portraitHidden = new ArrayList<>();
    @Unique private final List<ModelPart> lin$portraitBody = new ArrayList<>();
    @Unique private ModelPart lin$portraitRoot,lin$portraitHead;

    // A baked PlayerModel's hierarchy is fixed. Visibility still changes each render.
    @Unique private void lin$preparePortraitParts(PlayerModel model) {
        if(lin$portraitRoot==model.root() && lin$portraitHead==model.head)return;
        lin$portraitBody.clear();
        var headParts=java.util.Collections.newSetFromMap(new java.util.IdentityHashMap<ModelPart,Boolean>());
        headParts.addAll(model.head.getAllParts());
        for(ModelPart part:model.root().getAllParts())if(!headParts.contains(part))lin$portraitBody.add(part);
        lin$portraitRoot=model.root();lin$portraitHead=model.head;
    }

    @Inject(method = "method_62110(Lnet/minecraft/class_10055;)V", at = @At("HEAD"))
    private void lin$restorePortraitParts(AvatarRenderState state, CallbackInfo ci) {
        lin$restorePortraitVisibility();
    }

    @Unique private void lin$restorePortraitModel() { lin$restorePortraitVisibility(); }

    @Override public void lin$restorePortraitVisibility() {
        for (ModelPart part : lin$portraitHidden) part.skipDraw = false;
        lin$portraitHidden.clear();
    }

    @Inject(method = "method_62110(Lnet/minecraft/class_10055;)V", at = @At("TAIL"))
    private void lin$headOnly(AvatarRenderState state, CallbackInfo ci) {
        if (state.id != SelfInfoHeadPortrait.PREVIEW_ID) return;
        PlayerModel model = (PlayerModel)(Object)this;
        model.head.resetPose();
        model.hat.resetPose();
        lin$preparePortraitParts(model);
        for (ModelPart part : lin$portraitBody) {
            if (!part.skipDraw) {
                part.skipDraw = true;
                lin$portraitHidden.add(part);
            }
        }
    }
}

