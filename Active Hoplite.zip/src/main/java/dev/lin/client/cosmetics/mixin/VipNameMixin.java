/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.llamalad7.mixinextras.injector.ModifyReturnValue
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 */
package dev.lin.client.cosmetics.mixin;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import dev.lin.client.cosmetics.vip.VipIcons;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(value={Player.class})
public abstract class VipNameMixin {
    @ModifyReturnValue(method={"method_5476"}, at={@At(value="RETURN")})
    private Component lin$vip(Component original) {
        return VipIcons.decorate(original, ((Player)((Object)this)).getUUID());
    }
}

