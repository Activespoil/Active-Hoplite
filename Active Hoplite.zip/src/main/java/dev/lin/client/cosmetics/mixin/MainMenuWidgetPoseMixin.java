package dev.lin.client.cosmetics.mixin;

import dev.lin.client.cosmetics.ui.MainMenuPlayerPreview;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.renderer.entity.state.AvatarRenderState;
import net.minecraft.client.renderer.entity.state.HumanoidRenderState;
import net.minecraft.util.Mth;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Applies the approved hero pose only to the small Hoplite title-screen card. */
@Mixin(HumanoidModel.class)
public abstract class MainMenuWidgetPoseMixin {
    // This project is packaged with the manual TinyRemapper fallback when the
    // local Gradle loopback transport is unavailable. Use the stable
    // intermediary target explicitly so the annotation remains valid after
    // that remap as well as in the shipped Fabric environment.
    @Inject(method = "method_17087(Lnet/minecraft/class_10034;)V",
            at = @At("TAIL"), remap = false)
    private void linClient$applyHopliteWidgetPose(HumanoidRenderState state,
                                                  CallbackInfo callback) {
        if (!(state instanceof AvatarRenderState avatar)
                || !MainMenuPlayerPreview.isHopliteWidgetPreview(avatar.id)) return;

        HumanoidModel<?> model = (HumanoidModel<?>)(Object)this;

        // Player's right arm (viewer's left): raised beside the head, with a
        // restrained idle wave so the silhouette remains readable.
        float wave = Mth.sin(state.ageInTicks * 0.16F) * 0.12F;
        model.rightArm.xRot = -2.42F;
        model.rightArm.yRot = -0.18F;
        model.rightArm.zRot = 0.34F + wave;

        // Player's left arm (viewer's right): lowered across the torso so the
        // off-hand katana projects cleanly toward the right side of the card.
        model.leftArm.xRot = -0.92F;
        model.leftArm.yRot = 0.28F;
        model.leftArm.zRot = -0.18F;
    }
}
