package dev.lin.client.cosmetics.ui;

import java.util.Properties;
/** Shared source of truth: workspace shared-ui/assets/lin_client/ui/glass.properties. */
public final class GlassStyle {
 private static final Properties P = new Properties();
 static { try(var in=GlassStyle.class.getResourceAsStream("/assets/lin_client/ui/glass.properties")) { if(in!=null)P.load(in); } catch(java.io.IOException e) { throw new ExceptionInInitializerError(e); } }
 static { var file=net.fabricmc.loader.api.FabricLoader.getInstance().getConfigDir().resolve("lin-client/glass-theme.properties");
  if(java.nio.file.Files.isRegularFile(file)) try(var in=java.nio.file.Files.newInputStream(file)){P.load(in);}catch(java.io.IOException ignored){} }
 // Migrate only the former shipped opacity, leaving deliberate custom opacity intact.
 static {
  if (!"2".equals(P.getProperty("lens.shell.version"))) {
   if (number("panel.alpha",122f)==122f) P.setProperty("panel.alpha","210");
   P.setProperty("lens.shell.version","2");
  }
 }
 public static void set(String key,float value) { P.setProperty(key,Float.toString(value));
  var file=net.fabricmc.loader.api.FabricLoader.getInstance().getConfigDir().resolve("lin-client/glass-theme.properties");
  try {java.nio.file.Files.createDirectories(file.getParent());try(var out=java.nio.file.Files.newOutputStream(file)){P.store(out,"Shared Lin glass theme");}}catch(java.io.IOException e){throw new IllegalStateException("Cannot save shared glass theme",e);} }
 private static int hex(String k,String d){return (int)Long.parseLong(P.getProperty(k,d),16);}
 public static float number(String k,float d){return Float.parseFloat(P.getProperty(k,Float.toString(d)));}
 private static int rgb(String key,int fallback){return Math.round(number(key,fallback))&0xFFFFFF;}
 public static int backgroundRgb(){return rgb("theme.background.rgb",hex("panel.rgb","807E78"));}
 public static int accentRgb(){return rgb("theme.accent.rgb",0xFFFFFF);}
 public static int panel(){return ((int)number("panel.alpha",122)<<24)|backgroundRgb();}
 public static int control(){return 0x20000000|backgroundRgb();}
 public static int hover(){return 0x30000000|accentRgb();}
 public static int selected(){return 0x50000000|accentRgb();}
 public static int border(){int base=hex("border.argb","30FFFFFF");return ((int)number("border.alpha",base>>>24)<<24)|accentRgb();}
 public static float borderWidth(){return number("border.width",1f);}
 public static int blur(){return (int)number("panel.blur.radius",number("blur.radius",10));}
 public static float scale(float w,float h){return Math.max(.01f,Math.min(w*number("width.fraction",.88f)/1000f,h*number("height.fraction",.80f)/620f));}
 private GlassStyle(){}
}
