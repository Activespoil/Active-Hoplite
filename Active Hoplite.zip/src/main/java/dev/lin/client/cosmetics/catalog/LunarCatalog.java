package dev.lin.client.cosmetics.catalog;

import com.google.gson.Gson;
import dev.lin.client.cosmetics.LinClient;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public final class LunarCatalog {
    private static final String RESOURCE =
            "/assets/lin_client/catalog/cosmetics.json";
    private static final Gson GSON = new Gson();
    private static final Map<Integer, CosmeticDefinition> BY_ID = new HashMap<>();
    private static final Map<CosmeticCategory, List<CosmeticDefinition>> BY_CATEGORY =
            new EnumMap<>(CosmeticCategory.class);
    private static List<CosmeticDefinition> all = List.of();

    private LunarCatalog() {
    }

    public static synchronized void load() {
        if (!all.isEmpty()) {
            return;
        }
        try (InputStream input = LunarCatalog.class.getResourceAsStream(RESOURCE)) {
            if (input == null) {
                throw new IllegalStateException("Missing full Lunar cosmetic catalog");
            }
            CatalogEntry[] entries = GSON.fromJson(
                    new InputStreamReader(input, StandardCharsets.UTF_8), CatalogEntry[].class);
            try (InputStream pets = LunarCatalog.class.getResourceAsStream(
                    "/assets/lin_client/hoplite_pets/catalog.json")) {
                if (pets != null) {
                    CatalogEntry[] extra = GSON.fromJson(new InputStreamReader(
                            pets, StandardCharsets.UTF_8), CatalogEntry[].class);
                    int count = entries.length;
                    entries = java.util.Arrays.copyOf(entries, count + extra.length);
                    System.arraycopy(extra, 0, entries, count, extra.length);
                }
            }
            List<CosmeticDefinition> loaded = new ArrayList<>(entries.length);
            for (CatalogEntry entry : entries) {
                // v94 imported these as shoulder pets; keep their stable IDs and assets.
                if ("HOPLITE_PET".equals(entry.indexType)) entry.category = "companion";
                CosmeticDefinition definition = new CosmeticDefinition(
                        entry.id,
                        entry.name == null ? "Cosmetic " + entry.id : entry.name,
                        entry.resource == null ? "" : entry.resource,
                        entry.category == null ? "" : entry.category,
                        CosmeticCategory.fromCatalog(entry.category),
                        entry.indexType == null ? "NONE" : entry.indexType,
                        entry.geckolibCosmetic,
                        entry.animated,
                        entry.special,
                        entry.colors == null ? List.of() : List.copyOf(entry.colors),
                        entry.tags == null ? List.of() : List.copyOf(entry.tags),
                        entry.releasedAt == null ? "" : entry.releasedAt);
                loaded.add(definition);
                if (BY_ID.putIfAbsent(definition.id(), definition) != null) {
                    throw new IllegalStateException("Duplicate cosmetic ID: " + definition.id());
                }
                BY_CATEGORY.computeIfAbsent(definition.category(), ignored -> new ArrayList<>())
                        .add(definition);
            }
            loaded.sort(Comparator.comparingInt(CosmeticDefinition::id).reversed());
            all = List.copyOf(loaded);
            BY_CATEGORY.replaceAll((category, values) -> List.copyOf(values));
            LinClient.LOGGER.info(
                    "Loaded {} cosmetics across {} standalone Locker categories",
                    all.size(), BY_CATEGORY.size());
        } catch (Exception exception) {
            throw new IllegalStateException("Unable to load the Lunar cosmetic catalog", exception);
        }
    }

    public static List<CosmeticDefinition> all() {
        return all;
    }

    public static List<CosmeticDefinition> category(CosmeticCategory category) {
        return category == CosmeticCategory.ALL
                ? all : BY_CATEGORY.getOrDefault(category, List.of());
    }

    public static CosmeticDefinition byId(int id) {
        return BY_ID.get(id);
    }

    public static List<CosmeticDefinition> search(CosmeticCategory category,
                                                  String query,
                                                  boolean ascending,
                                                  boolean favoritesOnly) {
        String normalized = query == null ? "" : query.toLowerCase(Locale.ROOT)
                .replace('_', ' ').replace('-', ' ').trim();
        String[] terms = normalized.isEmpty() ? new String[0] : normalized.split("\\s+");
        Comparator<CosmeticDefinition> comparator = Comparator
                .comparing(CosmeticDefinition::name, String.CASE_INSENSITIVE_ORDER)
                .thenComparingInt(CosmeticDefinition::id);
        if (!ascending) {
            comparator = comparator.reversed();
        }
        return category(category).stream()
                .filter(definition -> !favoritesOnly
                        || dev.lin.client.cosmetics.config.CosmeticConfig.isFavorite(
                                definition.id()))
                .filter(definition -> matches(definition.searchText(), terms))
                .sorted(comparator)
                .toList();
    }

    private static boolean matches(String text, String[] terms) {
        for (String term : terms) {
            if (!term.isEmpty() && !text.contains(term)) {
                return false;
            }
        }
        return true;
    }

    @SuppressWarnings("unused")
    private static final class CatalogEntry {
        int id;
        String name;
        String resource;
        String category;
        String indexType;
        boolean geckolibCosmetic;
        boolean animated;
        boolean special;
        List<String> colors;
        List<String> tags;
        String releasedAt;
    }
}
