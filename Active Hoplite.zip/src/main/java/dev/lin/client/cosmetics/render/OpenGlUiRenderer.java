package dev.lin.client.cosmetics.render;

import dev.lin.client.shared.render.UnitCircle;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.vertex.VertexConsumer;
import dev.lin.client.cosmetics.font.FontManager;
import dev.lin.client.cosmetics.model.CosmeticMesh;
import dev.lin.client.cosmetics.model.CosmeticRenderData;
import dev.lin.client.cosmetics.model.CosmeticVertex;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.navigation.ScreenRectangle;
import net.minecraft.client.gui.render.TextureSetup;
import net.minecraft.client.gui.render.state.GuiElementRenderState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.renderer.texture.AbstractTexture;
import net.minecraft.resources.Identifier;
import org.joml.Matrix3x2f;
import org.joml.Matrix3x2fc;

public final class OpenGlUiRenderer {
   private static final float G2_EXPONENT = 4.0F;
   private static final int SHADOW_STEPS = 7;
   private static final Map<ProjectionKey, ProjectedCosmeticMesh> PROJECTED_MODELS =
      new LinkedHashMap<>(256, 0.75F, true) {
         @Override
         protected boolean removeEldestEntry(
            Map.Entry<ProjectionKey, ProjectedCosmeticMesh> eldest) {
            return size() > 512;
         }
      };

   private OpenGlUiRenderer() {
   }

   public static void panel(GuiGraphics graphics, int x, int y, int width, int height, int color, int border) {
      float radius = Math.min(10.0F, Math.max(4.0F, height * 0.22F));
      roundedPanel(graphics, x, y, width, height, radius, color, border, 1.0F);
   }

   public static void roundedPanel(GuiGraphics graphics, float x, float y, float width, float height, float radius, int color, int border, float borderWidth) {
      if (color >>> 24 != 0) dev.lin.client.cosmetics.font.SharedMenuText.occlude(graphics,x,y,width,height,radius);
      roundedRect(graphics, x, y, width, height, radius, color);
      roundedOutline(graphics, x, y, width, height, radius, border, borderWidth);
   }

   public static void glassPanel(GuiGraphics graphics, float x, float y, float width, float height, float radius, int color, int border, int shadow) {
      softShadow(graphics, x, y, width, height, radius, shadow);
      roundedPanel(graphics, x, y, width, height, radius, color, border, 1.0F);
      roundedPanel(graphics, x + 1.0F, y + 1.0F, width - 2.0F, height - 2.0F, Math.max(0.0F, radius - 1.0F), 16777215, 822083583, 0.7F);
   }

   public static void roundedRect(GuiGraphics graphics, float x, float y, float width, float height, float radius, int color) {
      if (SkijaUiRaster.round(graphics, x, y, width, height, radius, color, 0)) return;
      if (!(width <= 0.0F) && !(height <= 0.0F) && color >>> 24 != 0) {
         float clampedRadius = Math.max(0.0F, Math.min(radius, Math.min(width, height) * 0.5F));
         int alpha = color >>> 24;
         if (clampedRadius > 0.0F && alpha > 8) {
            int fringe = color & 16777215 | Math.max(1, Math.round(alpha * 0.24F)) << 24;
            submitRoundedRect(graphics, x - 0.45F, y - 0.45F, width + 0.9F, height + 0.9F, clampedRadius + 0.45F, fringe);
         }

         submitRoundedRect(graphics, x, y, width, height, clampedRadius, color);
      }
   }

   public static void roundedOutline(GuiGraphics graphics, float x, float y, float width, float height, float radius, int color, float thickness) {
      if (thickness > 0 && SkijaUiRaster.round(graphics, x, y, width, height, radius, color, thickness)) return;
      if (!(width <= 0.0F) && !(height <= 0.0F) && !(thickness <= 0.0F) && color >>> 24 != 0) {
         float clampedRadius = Math.max(0.0F, Math.min(radius, Math.min(width, height) * 0.5F));
         float clampedThickness = Math.min(thickness, Math.min(width, height) * 0.5F);
         submitRoundedRing(graphics, x, y, width, height, clampedRadius, clampedThickness, color);
      }
   }

   public static void softShadow(GuiGraphics graphics, float x, float y, float width, float height, float radius, int color) {
      int baseAlpha = color >>> 24;
      if (baseAlpha != 0) {
         for (int step = 7; step >= 1; step--) {
            float normalized = step / 7.0F;
            float expansion = step * 1.7F;
            float gaussian = (float)Math.exp(-2.35F * normalized * normalized);
            int alpha = Math.max(1, Math.round(baseAlpha * gaussian * 0.2F));
            int layerColor = color & 16777215 | alpha << 24;
            roundedOutline(
               graphics, x - expansion, y - expansion + 2.0F, width + expansion * 2.0F, height + expansion * 2.0F, radius + expansion, layerColor, 1.8F
            );
         }
      }
   }

   public static void searchIcon(GuiGraphics graphics, float centerX, float centerY, float size, int color) {
      submitIcon(graphics, centerX, centerY, size, color, OpenGlUiRenderer.UiIcon.SEARCH);
   }

   public static void closeIcon(GuiGraphics graphics, float centerX, float centerY, float size, int color) {
      submitIcon(graphics, centerX, centerY, size, color, OpenGlUiRenderer.UiIcon.CLOSE);
   }

   public static void checkIcon(GuiGraphics graphics, float centerX, float centerY, float size, int color) {
      submitIcon(graphics, centerX, centerY, size, color, OpenGlUiRenderer.UiIcon.CHECK);
   }

   public static void icon(GuiGraphics graphics, float centerX, float centerY, float size, int color, OpenGlUiRenderer.UiIcon icon) {
      if (icon != null) {
         submitIcon(graphics, centerX, centerY, size, color, icon);
      }
   }

   public static void text(GuiGraphics graphics, String value, float x, float y, float size, int color) {
      FontManager.draw(graphics, value, x, y, size, color);
   }

   public static void textRegular(GuiGraphics graphics, String value, float x, float y, float size, int color) {
      FontManager.drawRegular(graphics, value, x, y, size, color);
   }

   public static void angledTexture(
      GuiGraphics graphics, Identifier texture, float centerX, float centerY, float width, float height, int color
   ) {
      float halfWidth = width * 0.5F;
      float halfHeight = height * 0.5F;
      float horizontalShift = 3.0F;
      float left = centerX - halfWidth * 0.68F + horizontalShift;
      float right = centerX + halfWidth * 0.68F + horizontalShift;
      float top = centerY - halfHeight;
      float bottom = centerY + halfHeight;
      float x0 = left;
      float y0 = top + 3.0F;
      float x1 = left;
      float y1 = bottom - 3.0F;
      float x2 = right;
      float y2 = bottom;
      float x3 = right;
      float y3 = top;
      Matrix3x2f pose = new Matrix3x2f(graphics.pose());
      ScreenRectangle scissor = graphics.scissorStack.peek();
      float minX = Math.min(Math.min(x0, x1), Math.min(x2, x3));
      float minY = Math.min(Math.min(y0, y1), Math.min(y2, y3));
      float maxX = Math.max(Math.max(x0, x1), Math.max(x2, x3));
      float maxY = Math.max(Math.max(y0, y1), Math.max(y2, y3));
      ScreenRectangle textureBounds = bounds(minX, minY, maxX - minX, maxY - minY, pose, scissor);
      if (textureBounds != null) {
         AbstractTexture loaded = Minecraft.getInstance().getTextureManager().getTexture(texture);
         TextureSetup setup = TextureSetup.singleTexture(loaded.getTextureView(), loaded.getSampler());
         graphics.guiRenderState.submitGuiElement(
            new OpenGlUiRenderer.TexturedQuadRenderState(pose, setup, x0, y0, x1, y1, x2, y2, x3, y3, color, scissor, textureBounds)
         );
      }
   }

   public static void cosmeticModel(
      GuiGraphics graphics, CosmeticRenderData data, float centerX, float centerY, float size
   ) {
      cosmeticModel(graphics, data, centerX, centerY, size, 146.0F, 14.0F);
   }

   public static void cosmeticModel(
      GuiGraphics graphics, CosmeticRenderData data, float centerX, float centerY,
      float size, float yawDegrees, float pitchDegrees
   ) {
      CosmeticMesh mesh = data.mesh();
      CosmeticMesh previousMesh = data.previousMesh();
      CosmeticMesh referenceMesh = data.referenceMesh() == null ? mesh : data.referenceMesh();
      float progress = data.meshProgress();
      if (previousMesh == null || previousMesh.vertexCount() != mesh.vertexCount()) {
         previousMesh = mesh;
         progress = 1.0F;
      }
      ProjectedCosmeticMesh projected;
      ProjectedCosmeticMesh previousProjected;
      synchronized (PROJECTED_MODELS) {
         CosmeticMesh stableReference = referenceMesh;
         ProjectionKey currentKey = new ProjectionKey(mesh, stableReference,
            Float.floatToIntBits(yawDegrees), Float.floatToIntBits(pitchDegrees));
         ProjectionKey previousKey = new ProjectionKey(previousMesh, stableReference,
            Float.floatToIntBits(yawDegrees), Float.floatToIntBits(pitchDegrees));
         projected = PROJECTED_MODELS.computeIfAbsent(currentKey,
            value -> projectCosmeticMesh(value.mesh(), value.referenceMesh(),
               yawDegrees, pitchDegrees));
         previousProjected = PROJECTED_MODELS.computeIfAbsent(previousKey,
            value -> projectCosmeticMesh(value.mesh(), value.referenceMesh(),
               yawDegrees, pitchDegrees));
      }
      Matrix3x2f pose = new Matrix3x2f(graphics.pose());
      ScreenRectangle scissor = graphics.scissorStack.peek();
      ScreenRectangle modelBounds = bounds(centerX - size * 0.55F, centerY - size * 0.55F,
         size * 1.1F, size * 1.1F, pose, scissor);
      if (modelBounds != null) {
         AbstractTexture loaded = Minecraft.getInstance().getTextureManager().getTexture(data.texture());
         TextureSetup setup = TextureSetup.singleTexture(loaded.getTextureView(), loaded.getSampler());
         graphics.guiRenderState.submitGuiElement(
            new OpenGlUiRenderer.CosmeticModelRenderState(pose, setup,
               previousProjected, projected, progress, centerX, centerY, size,
               scissor, modelBounds)
         );
      }
   }

   private static ProjectedCosmeticMesh projectCosmeticMesh(CosmeticMesh mesh,
                                                             CosmeticMesh referenceMesh,
                                                             float yawDegrees,
                                                             float pitchDegrees) {
      CosmeticVertex[] vertices = mesh.rawVertices();
      List<ProjectedCosmeticFace> faces = new ArrayList<>(vertices.length / 4);
      ProjectedCosmeticFace[] sourceFaces = new ProjectedCosmeticFace[vertices.length / 4];
      float yaw = (float)Math.toRadians(yawDegrees);
      float pitch = (float)Math.toRadians(pitchDegrees);
      float yawSin = (float)Math.sin(yaw);
      float yawCos = (float)Math.cos(yaw);
      float pitchSin = (float)Math.sin(pitch);
      float pitchCos = (float)Math.cos(pitch);
      float normalize = 0.82F / referenceMesh.extent();
      float centerX = referenceMesh.centerX();
      float centerY = referenceMesh.centerY();
      float centerZ = referenceMesh.centerZ();
      for (int index = 0; index + 3 < vertices.length; index += 4) {
         CosmeticVertex[] corners = {vertices[index], vertices[index + 1], vertices[index + 2], vertices[index + 3]};
         float[] values = new float[20];
         float depth = 0.0F;
         for (int corner = 0; corner < corners.length; corner++) {
            CosmeticVertex vertex = corners[corner];
            float localX = (vertex.x() - centerX) * normalize;
            float localY = (vertex.y() - centerY) * normalize;
            float localZ = (vertex.z() - centerZ) * normalize;
            float rotatedX = localX * yawCos + localZ * yawSin;
            float rotatedZ = -localX * yawSin + localZ * yawCos;
            float rotatedY = localY * pitchCos - rotatedZ * pitchSin;
            float finalZ = localY * pitchSin + rotatedZ * pitchCos;
            int offset = corner * 5;
            values[offset] = rotatedX;
            values[offset + 1] = rotatedY;
            values[offset + 2] = vertex.u();
            values[offset + 3] = vertex.v();
            values[offset + 4] = finalZ;
            depth += finalZ;
         }
         CosmeticVertex normal = corners[0];
         float normalX = normal.nx() * yawCos + normal.nz() * yawSin;
         float normalZ = -normal.nx() * yawSin + normal.nz() * yawCos;
         float normalY = normal.ny() * pitchCos - normalZ * pitchSin;
         float finalNormalZ = normal.ny() * pitchSin + normalZ * pitchCos;
         float light = Math.max(0.0F, normalX * -0.35F + normalY * -0.45F + finalNormalZ * 0.82F);
         int shade = Math.max(145, Math.min(255, Math.round(165.0F + light * 90.0F)));
         int color = 0xFF000000 | shade << 16 | shade << 8 | shade;
         int sourceIndex = index / 4;
         ProjectedCosmeticFace face = new ProjectedCosmeticFace(
            values, depth * 0.25F, color, sourceIndex);
         faces.add(face);
         sourceFaces[sourceIndex] = face;
      }
      faces.sort(Comparator.comparingDouble(ProjectedCosmeticFace::depth));
      return new ProjectedCosmeticMesh(
         faces.toArray(ProjectedCosmeticFace[]::new), sourceFaces);
   }

   public static boolean inside(double mouseX, double mouseY, int x, int y, int width, int height) {
      return mouseX >= x && mouseX < x + width && mouseY >= y && mouseY < y + height;
   }

   private static void submitRoundedRect(GuiGraphics graphics, float x, float y, float width, float height, float radius, int color) {
      Matrix3x2f pose = new Matrix3x2f(graphics.pose());
      ScreenRectangle scissor = graphics.scissorStack.peek();
      ScreenRectangle bounds = bounds(x, y, width, height, pose, scissor);
      if (bounds != null) {
         graphics.guiRenderState
            .submitGuiElement(new OpenGlUiRenderer.G2RoundedRectangleRenderState(pose, x, y, width, height, radius, color, scissor, bounds));
      }
   }

   private static void submitRoundedRing(GuiGraphics graphics, float x, float y, float width, float height, float radius, float thickness, int color) {
      Matrix3x2f pose = new Matrix3x2f(graphics.pose());
      ScreenRectangle scissor = graphics.scissorStack.peek();
      ScreenRectangle bounds = bounds(x, y, width, height, pose, scissor);
      if (bounds != null) {
         graphics.guiRenderState
            .submitGuiElement(new OpenGlUiRenderer.G2RoundedRingRenderState(pose, x, y, width, height, radius, thickness, color, scissor, bounds));
      }
   }

   private static void submitIcon(GuiGraphics graphics, float centerX, float centerY, float size, int color, OpenGlUiRenderer.UiIcon type) {
      Matrix3x2f pose = new Matrix3x2f(graphics.pose());
      ScreenRectangle scissor = graphics.scissorStack.peek();
      float padding = size * 0.2F;
      ScreenRectangle bounds = bounds(
         centerX - size * 0.5F - padding, centerY - size * 0.5F - padding, size + padding * 2.0F, size + padding * 2.0F, pose, scissor
      );
      if (bounds != null) {
         graphics.guiRenderState.submitGuiElement(new OpenGlUiRenderer.StrokeIconRenderState(pose, centerX, centerY, size, color, type, scissor, bounds));
      }
   }

   private static ScreenRectangle bounds(float x, float y, float width, float height, Matrix3x2fc pose, ScreenRectangle scissor) {
      int left = (int)Math.floor(x);
      int top = (int)Math.floor(y);
      int right = (int)Math.ceil(x + width);
      int bottom = (int)Math.ceil(y + height);
      ScreenRectangle transformed = new ScreenRectangle(left, top, Math.max(0, right - left), Math.max(0, bottom - top)).transformMaxBounds(pose);
      return scissor == null ? transformed : scissor.intersection(transformed);
   }

   private static void quad(
      VertexConsumer consumer, Matrix3x2fc pose, float x0, float y0, float x1, float y1, float x2, float y2, float x3, float y3, int color
   ) {
      consumer.addVertexWith2DPose(pose, x0, y0).setColor(color);
      consumer.addVertexWith2DPose(pose, x1, y1).setColor(color);
      consumer.addVertexWith2DPose(pose, x2, y2).setColor(color);
      consumer.addVertexWith2DPose(pose, x3, y3).setColor(color);
   }

   private record TexturedQuadRenderState(
      Matrix3x2fc pose,
      TextureSetup textureSetup,
      float x0,
      float y0,
      float x1,
      float y1,
      float x2,
      float y2,
      float x3,
      float y3,
      int color,
      ScreenRectangle scissorArea,
      ScreenRectangle bounds
   ) implements GuiElementRenderState {
      @Override
      public void buildVertices(VertexConsumer consumer) {
         consumer.addVertexWith2DPose(this.pose, this.x0, this.y0).setUv(0.0F, 0.0F).setColor(this.color);
         consumer.addVertexWith2DPose(this.pose, this.x1, this.y1).setUv(0.0F, 1.0F).setColor(this.color);
         consumer.addVertexWith2DPose(this.pose, this.x2, this.y2).setUv(1.0F, 1.0F).setColor(this.color);
         consumer.addVertexWith2DPose(this.pose, this.x3, this.y3).setUv(1.0F, 0.0F).setColor(this.color);
      }

      @Override
      public RenderPipeline pipeline() {
         return RenderPipelines.GUI_TEXTURED;
      }
   }

   private record CosmeticModelRenderState(
      Matrix3x2fc pose,
      TextureSetup textureSetup,
      ProjectedCosmeticMesh previousMesh,
      ProjectedCosmeticMesh mesh,
      float progress,
      float centerX,
      float centerY,
      float size,
      ScreenRectangle scissorArea,
      ScreenRectangle bounds
   ) implements GuiElementRenderState {
      @Override
      public void buildVertices(VertexConsumer consumer) {
         for (ProjectedCosmeticFace face : this.mesh.faces()) {
            float[] values = face.values();
            ProjectedCosmeticFace previousFace =
               this.previousMesh.sourceFaces()[face.sourceIndex()];
            float[] previousValues = previousFace == null
               ? values : previousFace.values();
            for (int corner = 0; corner < 4; corner++) {
               int offset = corner * 5;
               consumer.addVertexWith2DPose(
                     this.pose,
                     this.centerX + lerp(previousValues[offset], values[offset],
                        this.progress) * this.size,
                     this.centerY + lerp(previousValues[offset + 1],
                        values[offset + 1], this.progress) * this.size
                  )
                  .setUv(values[offset + 2], values[offset + 3])
                  .setColor(face.color());
            }
         }
      }

      private static float lerp(float from, float to, float progress) {
         return from + (to - from) * progress;
      }

      @Override
      public RenderPipeline pipeline() {
         return RenderPipelines.GUI_TEXTURED;
      }
   }

   private record ProjectedCosmeticMesh(ProjectedCosmeticFace[] faces,
                                        ProjectedCosmeticFace[] sourceFaces) {
   }

   private record ProjectedCosmeticFace(float[] values, float depth, int color,
                                        int sourceIndex) {
   }

   private record ProjectionKey(CosmeticMesh mesh, CosmeticMesh referenceMesh,
                                int yawBits, int pitchBits) {
   }

   private record G2RoundedRectangleRenderState(
      Matrix3x2fc pose, float x, float y, float width, float height, float radius, int color, ScreenRectangle scissorArea, ScreenRectangle bounds
   ) implements GuiElementRenderState {
      @Override
      public void buildVertices(VertexConsumer consumer) {
         if (this.radius <= 0.0F) {
            OpenGlUiRenderer.quad(
               consumer,
               this.pose,
               this.x,
               this.y,
               this.x,
               this.y + this.height,
               this.x + this.width,
               this.y + this.height,
               this.x + this.width,
               this.y,
               this.color
            );
         } else {
            int segments = Math.max(6, Math.min(48, (int)Math.ceil(this.radius * 1.5F)));
            float right = this.x + this.width;

            for (int segment = 0; segment < segments; segment++) {
               float offset0 = this.radius * segment / segments;
               float offset1 = this.radius * (segment + 1) / segments;
               float inset0 = cornerInset(offset0, this.radius);
               float inset1 = cornerInset(offset1, this.radius);
               OpenGlUiRenderer.quad(
                  consumer,
                  this.pose,
                  this.x + inset0,
                  this.y + offset0,
                  this.x + inset1,
                  this.y + offset1,
                  right - inset1,
                  this.y + offset1,
                  right - inset0,
                  this.y + offset0,
                  this.color
               );
               float bottom0 = this.y + this.height - offset1;
               float bottom1 = this.y + this.height - offset0;
               OpenGlUiRenderer.quad(
                  consumer, this.pose, this.x + inset1, bottom0, this.x + inset0, bottom1, right - inset0, bottom1, right - inset1, bottom0, this.color
               );
            }

            if (this.height > this.radius * 2.0F) {
               OpenGlUiRenderer.quad(
                  consumer,
                  this.pose,
                  this.x,
                  this.y + this.radius,
                  this.x,
                  this.y + this.height - this.radius,
                  right,
                  this.y + this.height - this.radius,
                  right,
                  this.y + this.radius,
                  this.color
               );
            }
         }
      }

      @Override
      public RenderPipeline pipeline() {
         return RenderPipelines.GUI;
      }

      @Override
      public TextureSetup textureSetup() {
         return TextureSetup.noTexture();
      }

      private static float cornerInset(float offset, float radius) {
         float normalized = Math.max(0.0F, Math.min(1.0F, (radius - offset) / radius));
         float horizontal = (float)Math.pow(1.0 - Math.pow(normalized, 4.0), 0.25);
         return radius * (1.0F - horizontal);
      }
   }

   private record G2RoundedRingRenderState(
      Matrix3x2fc pose,
      float x,
      float y,
      float width,
      float height,
      float radius,
      float thickness,
      int color,
      ScreenRectangle scissorArea,
      ScreenRectangle bounds
   ) implements GuiElementRenderState {
      @Override
      public void buildVertices(VertexConsumer consumer) {
         int segments = Math.max(6, Math.min(48, (int)Math.ceil(this.radius * 1.5F)));
         float[] outer = contour(this.x, this.y, this.width, this.height, this.radius, segments);
         float innerWidth = Math.max(0.0F, this.width - this.thickness * 2.0F);
         float innerHeight = Math.max(0.0F, this.height - this.thickness * 2.0F);
         float innerRadius = Math.max(0.0F, this.radius - this.thickness);
         float[] inner = contour(this.x + this.thickness, this.y + this.thickness, innerWidth, innerHeight, innerRadius, segments);
         int pointCount = outer.length / 2;

         for (int point = 0; point < pointCount; point++) {
            int next = (point + 1) % pointCount;
            OpenGlUiRenderer.quad(
               consumer,
               this.pose,
               outer[point * 2],
               outer[point * 2 + 1],
               inner[point * 2],
               inner[point * 2 + 1],
               inner[next * 2],
               inner[next * 2 + 1],
               outer[next * 2],
               outer[next * 2 + 1],
               this.color
            );
         }
      }

      @Override
      public RenderPipeline pipeline() {
         return RenderPipelines.GUI;
      }

      @Override
      public TextureSetup textureSetup() {
         return TextureSetup.noTexture();
      }

      private static float[] contour(float x, float y, float width, float height, float radius, int segments) {
         float[] points = new float[(segments * 4 + 4) * 2];
         float right = x + width;
         float bottom = y + height;
         int cursor = 0;
         cursor = point(points, cursor, x + radius, y);
         cursor = point(points, cursor, right - radius, y);

         for (int i = 1; i <= segments; i++) {
            float offset = radius * i / segments;
            cursor = point(points, cursor, right - inset(offset, radius), y + offset);
         }

         cursor = point(points, cursor, right, bottom - radius);

         for (int i = 1; i <= segments; i++) {
            float offset = radius * i / segments;
            cursor = point(points, cursor, right - inset(radius - offset, radius), bottom - radius + offset);
         }

         cursor = point(points, cursor, x + radius, bottom);

         for (int i = 1; i <= segments; i++) {
            float offset = radius * i / segments;
            cursor = point(points, cursor, x + inset(offset, radius), bottom - offset);
         }

         cursor = point(points, cursor, x, y + radius);

         for (int i = 1; i < segments; i++) {
            float offset = radius * i / segments;
            cursor = point(points, cursor, x + inset(radius - offset, radius), y + radius - offset);
         }

         return points;
      }

      private static int point(float[] points, int cursor, float x, float y) {
         points[cursor++] = x;
         points[cursor++] = y;
         return cursor;
      }

      private static float inset(float offset, float radius) {
         return radius <= 0.0F ? 0.0F : OpenGlUiRenderer.G2RoundedRectangleRenderState.cornerInset(offset, radius);
      }
   }

   private record StrokeIconRenderState(
      Matrix3x2fc pose, float centerX, float centerY, float size, int color, OpenGlUiRenderer.UiIcon type, ScreenRectangle scissorArea, ScreenRectangle bounds
   ) implements GuiElementRenderState {
      @Override
      public void buildVertices(VertexConsumer consumer) {
         switch (this.type) {
            case SEARCH:
               this.drawSearch(consumer);
               break;
            case CLOSE:
               this.drawClose(consumer);
               break;
            case CHECK:
               this.drawCheck(consumer);
               break;
            case USER:
               this.drawUser(consumer);
               break;
            case LINK:
               this.drawLink(consumer);
               break;
            case FOLDER:
               this.drawFolder(consumer);
               break;
            case HEADWEAR:
               this.drawHeadwear(consumer);
               break;
            case WINGS:
               this.drawWings(consumer);
               break;
            case SHIRT:
               this.drawShirt(consumer);
               break;
             case SWORD:
                this.drawSword(consumer);
                break;
             case COSMETICS:
                this.drawCosmetics(consumer);
                break;
             case CAPE:
                this.drawCape(consumer);
                break;
             case PET:
                this.drawPet(consumer);
                break;
             case ARROW_LEFT:
                this.drawArrowLeft(consumer);
                break;
             case ARROW_RIGHT:
                this.drawArrowRight(consumer);
                break;
             case ARROW_UP:
                this.drawArrowUp(consumer);
                break;
             case ARROW_DOWN:
                this.drawArrowDown(consumer);
                break;
             case RESET:
                this.drawReset(consumer);
                break;
             case ROTATE_HORIZONTAL:
                this.drawRotateHorizontal(consumer);
                break;
             case BACK:
                this.drawBack(consumer);
                break;
            case GRID:
               this.drawGrid(consumer);
               break;
            case PALETTE:
               this.drawPalette(consumer);
               break;
            case HANGER:
               this.drawHanger(consumer);
               break;
            case CIRCLE:
               this.drawCircle(consumer);
               break;
            case CUBE:
               this.drawCube(consumer);
               break;
            case MORE_VERTICAL:
               this.drawMoreVertical(consumer);
               break;
            case HELP:
               this.drawHelp(consumer);
               break;
            case EXPAND:
               this.drawExpand(consumer);
               break;
            case FILTER:
               this.drawFilter(consumer);
               break;
            case SWAP:
               this.drawSwap(consumer);
               break;
            case ADD:
               this.drawAdd(consumer);
         }
      }

      private void drawSearch(VertexConsumer consumer) {
         int segments = 24;
         float outer = this.size * 0.31F;
         float inner = Math.max(0.0F, outer - Math.max(1.15F, this.size * 0.085F));
         float ringX = this.centerX - this.size * 0.08F;
         float ringY = this.centerY - this.size * 0.08F;

         if (segments <= 0) return;
         UnitCircle circle = UnitCircle.of(segments);
         for (int segment = 0; segment < segments; segment++) {
            OpenGlUiRenderer.quad(
               consumer,
               this.pose,
               ringX + circle.cos(segment) * outer,
               ringY + circle.sin(segment) * outer,
               ringX + circle.cos(segment) * inner,
               ringY + circle.sin(segment) * inner,
               ringX + circle.cos(segment + 1) * inner,
               ringY + circle.sin(segment + 1) * inner,
               ringX + circle.cos(segment + 1) * outer,
               ringY + circle.sin(segment + 1) * outer,
               this.color
            );
         }

         this.line(
            consumer,
            ringX + outer * 0.68F,
            ringY + outer * 0.68F,
            this.centerX + this.size * 0.34F,
            this.centerY + this.size * 0.34F,
            Math.max(1.2F, this.size * 0.09F)
         );
      }

      private void drawClose(VertexConsumer consumer) {
         float half = this.size * 0.28F;
         float thickness = Math.max(1.15F, this.size * 0.09F);
         this.line(consumer, this.centerX - half, this.centerY - half, this.centerX + half, this.centerY + half, thickness);
         this.line(consumer, this.centerX + half, this.centerY - half, this.centerX - half, this.centerY + half, thickness);
      }

      private void drawCheck(VertexConsumer consumer) {
         float stroke = Math.max(1.15F, this.size * 0.11F);
         this.line(
            consumer,
            this.centerX - this.size * 0.34F,
            this.centerY,
            this.centerX - this.size * 0.08F,
            this.centerY + this.size * 0.25F,
            stroke
         );
         this.line(
            consumer,
            this.centerX - this.size * 0.08F,
            this.centerY + this.size * 0.25F,
            this.centerX + this.size * 0.36F,
            this.centerY - this.size * 0.29F,
            stroke
         );
      }

      private void drawUser(VertexConsumer consumer) {
         float stroke = this.stroke();
         this.ring(consumer, this.centerX, this.centerY - this.size * 0.19F, this.size * 0.14F, stroke, 18);
         this.arc(consumer, this.centerX, this.centerY + this.size * 0.24F, this.size * 0.3F, 3.5185838F, 5.906194F, stroke, 14);
         this.line(
            consumer,
            this.centerX - this.size * 0.3F,
            this.centerY + this.size * 0.24F,
            this.centerX - this.size * 0.3F,
            this.centerY + this.size * 0.31F,
            stroke
         );
         this.line(
            consumer,
            this.centerX + this.size * 0.3F,
            this.centerY + this.size * 0.24F,
            this.centerX + this.size * 0.3F,
            this.centerY + this.size * 0.31F,
            stroke
         );
      }

      private void drawLink(VertexConsumer consumer) {
         float stroke = this.stroke();
         this.ring(consumer, this.centerX - this.size * 0.16F, this.centerY + this.size * 0.1F, this.size * 0.19F, stroke, 16);
         this.ring(consumer, this.centerX + this.size * 0.16F, this.centerY - this.size * 0.1F, this.size * 0.19F, stroke, 16);
         this.line(
            consumer,
            this.centerX - this.size * 0.1F,
            this.centerY - this.size * 0.19F,
            this.centerX + this.size * 0.1F,
            this.centerY + this.size * 0.19F,
            stroke
         );
      }

      private void drawFolder(VertexConsumer consumer) {
         float stroke = this.stroke();
         float left = this.centerX - this.size * 0.34F;
         float right = this.centerX + this.size * 0.34F;
         float top = this.centerY - this.size * 0.2F;
         float bottom = this.centerY + this.size * 0.27F;
         this.path(
            consumer,
            stroke,
            true,
            left,
            top,
            left + this.size * 0.16F,
            top,
            left + this.size * 0.23F,
            top - this.size * 0.12F,
            this.centerX + this.size * 0.08F,
            top - this.size * 0.12F,
            this.centerX + this.size * 0.17F,
            top,
            right,
            top,
            right,
            bottom,
            left,
            bottom
         );
      }

      private void drawHeadwear(VertexConsumer consumer) {
         float stroke = this.stroke();
         float left = this.centerX - this.size * 0.23F;
         float right = this.centerX + this.size * 0.23F;
         float crownTop = this.centerY - this.size * 0.30F;
         float crownBottom = this.centerY + this.size * 0.14F;
         this.path(
            consumer,
            stroke,
            false,
            left,
            crownBottom,
            left + this.size * 0.04F,
            this.centerY - this.size * 0.18F,
            this.centerX - this.size * 0.08F,
            crownTop,
            this.centerX + this.size * 0.12F,
            crownTop + this.size * 0.04F,
            right,
            crownBottom
         );
         this.line(consumer, left, this.centerY + this.size * 0.02F, right, this.centerY + this.size * 0.02F, stroke);
         this.line(
            consumer,
            this.centerX - this.size * 0.37F,
            this.centerY + this.size * 0.20F,
            this.centerX + this.size * 0.37F,
            this.centerY + this.size * 0.20F,
            stroke
         );
      }

      private void drawWings(VertexConsumer consumer) {
         float stroke = this.stroke();
         float left = this.centerX - this.size * 0.04F;
         float right = this.centerX + this.size * 0.04F;
         this.path(
            consumer,
            stroke,
            false,
            left,
            this.centerY - this.size * 0.08F,
            this.centerX - this.size * 0.18F,
            this.centerY - this.size * 0.31F,
            this.centerX - this.size * 0.37F,
            this.centerY - this.size * 0.2F,
            this.centerX - this.size * 0.29F,
            this.centerY + this.size * 0.1F,
            this.centerX - this.size * 0.17F,
            this.centerY + this.size * 0.3F,
            left,
            this.centerY + this.size * 0.18F
         );
         this.path(
            consumer,
            stroke,
            false,
            right,
            this.centerY - this.size * 0.08F,
            this.centerX + this.size * 0.18F,
            this.centerY - this.size * 0.31F,
            this.centerX + this.size * 0.37F,
            this.centerY - this.size * 0.2F,
            this.centerX + this.size * 0.29F,
            this.centerY + this.size * 0.1F,
            this.centerX + this.size * 0.17F,
            this.centerY + this.size * 0.3F,
            right,
            this.centerY + this.size * 0.18F
         );
         this.line(consumer, left, this.centerY - this.size * 0.08F, right, this.centerY - this.size * 0.08F, stroke);
      }

      private void drawShirt(VertexConsumer consumer) {
         float stroke = this.stroke();
         this.path(
            consumer,
            stroke,
            true,
            this.centerX - this.size * 0.13F,
            this.centerY - this.size * 0.34F,
            this.centerX - this.size * 0.35F,
            this.centerY - this.size * 0.17F,
            this.centerX - this.size * 0.25F,
            this.centerY + this.size * 0.03F,
            this.centerX - this.size * 0.14F,
            this.centerY - this.size * 0.04F,
            this.centerX - this.size * 0.14F,
            this.centerY + this.size * 0.33F,
            this.centerX + this.size * 0.14F,
            this.centerY + this.size * 0.33F,
            this.centerX + this.size * 0.14F,
            this.centerY - this.size * 0.04F,
            this.centerX + this.size * 0.25F,
            this.centerY + this.size * 0.03F,
            this.centerX + this.size * 0.35F,
            this.centerY - this.size * 0.17F,
            this.centerX + this.size * 0.13F,
            this.centerY - this.size * 0.34F,
            this.centerX + this.size * 0.07F,
            this.centerY - this.size * 0.21F,
            this.centerX - this.size * 0.07F,
            this.centerY - this.size * 0.21F
         );
      }

       private void drawSword(VertexConsumer consumer) {
          float stroke = this.stroke();
          float x = this.centerX;
          float y = this.centerY;
          float s = this.size;
          this.path(
             consumer,
             stroke,
             true,
             x + s * 0.18F,
             y - s * 0.42F,
             x + s * 0.44F,
             y - s * 0.42F,
             x + s * 0.44F,
             y - s * 0.20F,
             x + s * 0.36F,
             y - s * 0.20F,
             x + s * 0.36F,
             y - s * 0.12F,
             x + s * 0.28F,
             y - s * 0.12F,
             x + s * 0.28F,
             y - s * 0.04F,
             x + s * 0.20F,
             y - s * 0.04F,
             x + s * 0.20F,
             y + s * 0.04F,
             x + s * 0.12F,
             y + s * 0.04F,
             x + s * 0.12F,
             y + s * 0.12F,
             x + s * 0.04F,
             y + s * 0.12F,
             x + s * 0.19F,
             y + s * 0.27F,
             x + s * 0.19F,
             y + s * 0.39F,
             x + s * 0.07F,
             y + s * 0.39F,
             x - s * 0.05F,
             y + s * 0.27F,
             x - s * 0.27F,
             y + s * 0.49F,
             x - s * 0.47F,
             y + s * 0.49F,
             x - s * 0.47F,
             y + s * 0.31F,
             x - s * 0.25F,
             y + s * 0.09F,
             x - s * 0.39F,
             y - s * 0.05F,
             x - s * 0.39F,
             y - s * 0.18F,
             x - s * 0.26F,
             y - s * 0.18F,
             x - s * 0.11F,
             y - s * 0.03F,
             x - s * 0.03F,
             y - s * 0.03F,
             x - s * 0.03F,
             y - s * 0.11F,
             x + s * 0.05F,
             y - s * 0.11F,
             x + s * 0.05F,
             y - s * 0.19F,
             x + s * 0.13F,
             y - s * 0.19F,
             x + s * 0.13F,
             y - s * 0.27F,
             x + s * 0.18F,
             y - s * 0.27F
          );
       }

       private void drawCosmetics(VertexConsumer consumer) {
          float stroke = this.stroke();
          float x = this.centerX;
          float y = this.centerY;
          float s = this.size;
          this.path(
             consumer,
             stroke,
             true,
             x - s * 0.08F,
             y - s * 0.39F,
             x + s * 0.01F,
             y - s * 0.10F,
             x + s * 0.30F,
             y - s * 0.01F,
             x + s * 0.01F,
             y + s * 0.08F,
             x - s * 0.08F,
             y + s * 0.37F,
             x - s * 0.17F,
             y + s * 0.08F,
             x - s * 0.46F,
             y - s * 0.01F,
             x - s * 0.17F,
             y - s * 0.10F
          );
          this.path(
             consumer,
             stroke,
             true,
             x + s * 0.31F,
             y - s * 0.37F,
             x + s * 0.35F,
             y - s * 0.25F,
             x + s * 0.47F,
             y - s * 0.21F,
             x + s * 0.35F,
             y - s * 0.17F,
             x + s * 0.31F,
             y - s * 0.05F,
             x + s * 0.27F,
             y - s * 0.17F,
             x + s * 0.15F,
             y - s * 0.21F,
             x + s * 0.27F,
             y - s * 0.25F
          );
       }

       private void drawCape(VertexConsumer consumer) {
          float stroke = this.stroke();
          float x = this.centerX;
          float y = this.centerY;
          float s = this.size;
          this.path(
             consumer,
             stroke,
             true,
             x - s * 0.14F,
             y - s * 0.37F,
             x + s * 0.14F,
             y - s * 0.37F,
             x + s * 0.30F,
             y - s * 0.24F,
             x + s * 0.38F,
             y + s * 0.39F,
             x,
             y + s * 0.29F,
             x - s * 0.38F,
             y + s * 0.39F,
             x - s * 0.30F,
             y - s * 0.24F
          );
          this.line(consumer, x - s * 0.14F, y - s * 0.37F, x - s * 0.08F, y + s * 0.31F, stroke);
          this.line(consumer, x + s * 0.14F, y - s * 0.37F, x + s * 0.08F, y + s * 0.31F, stroke);
       }

       private void drawPet(VertexConsumer consumer) {
          float stroke = this.stroke();
          float x = this.centerX;
          float y = this.centerY;
          float s = this.size;
          this.path(
             consumer,
             stroke,
             true,
             x - s * 0.34F,
             y - s * 0.12F,
             x - s * 0.35F,
             y - s * 0.40F,
             x - s * 0.12F,
             y - s * 0.28F,
             x + s * 0.12F,
             y - s * 0.28F,
             x + s * 0.35F,
             y - s * 0.40F,
             x + s * 0.34F,
             y - s * 0.12F,
             x + s * 0.24F,
             y + s * 0.28F,
             x,
             y + s * 0.39F,
             x - s * 0.24F,
             y + s * 0.28F
          );
          this.line(consumer, x - s * 0.16F, y, x - s * 0.08F, y, stroke);
          this.line(consumer, x + s * 0.08F, y, x + s * 0.16F, y, stroke);
          this.path(consumer, stroke, false, x + s * 0.26F, y + s * 0.18F, x + s * 0.46F, y + s * 0.29F, x + s * 0.40F, y + s * 0.44F);
       }

      private void drawArrowLeft(VertexConsumer consumer) {
         float stroke = this.stroke();
         float half = this.size * 0.30F;
         this.line(consumer, this.centerX + half, this.centerY, this.centerX - half, this.centerY, stroke);
         this.line(consumer, this.centerX - half, this.centerY, this.centerX - this.size * 0.08F, this.centerY - this.size * 0.21F, stroke);
         this.line(consumer, this.centerX - half, this.centerY, this.centerX - this.size * 0.08F, this.centerY + this.size * 0.21F, stroke);
      }

      private void drawArrowRight(VertexConsumer consumer) {
         float stroke = this.stroke();
         float half = this.size * 0.30F;
         this.line(consumer, this.centerX - half, this.centerY, this.centerX + half, this.centerY, stroke);
         this.line(consumer, this.centerX + half, this.centerY, this.centerX + this.size * 0.08F, this.centerY - this.size * 0.21F, stroke);
         this.line(consumer, this.centerX + half, this.centerY, this.centerX + this.size * 0.08F, this.centerY + this.size * 0.21F, stroke);
      }

      private void drawArrowUp(VertexConsumer consumer) {
         float stroke = this.stroke();
         float half = this.size * 0.30F;
         this.line(consumer, this.centerX, this.centerY + half, this.centerX, this.centerY - half, stroke);
         this.line(consumer, this.centerX, this.centerY - half, this.centerX - this.size * 0.21F, this.centerY - this.size * 0.08F, stroke);
         this.line(consumer, this.centerX, this.centerY - half, this.centerX + this.size * 0.21F, this.centerY - this.size * 0.08F, stroke);
      }

      private void drawArrowDown(VertexConsumer consumer) {
         float stroke = this.stroke();
         float half = this.size * 0.30F;
         this.line(consumer, this.centerX, this.centerY - half, this.centerX, this.centerY + half, stroke);
         this.line(consumer, this.centerX, this.centerY + half, this.centerX - this.size * 0.21F, this.centerY + this.size * 0.08F, stroke);
         this.line(consumer, this.centerX, this.centerY + half, this.centerX + this.size * 0.21F, this.centerY + this.size * 0.08F, stroke);
      }

      private void drawReset(VertexConsumer consumer) {
         float stroke = this.stroke();
         float radius = this.size * 0.29F;
         this.arc(consumer, this.centerX, this.centerY, radius, -2.75F, 2.30F, stroke, 22);
         float endX = this.centerX + (float)Math.cos(2.30F) * radius;
         float endY = this.centerY + (float)Math.sin(2.30F) * radius;
         this.line(consumer, endX, endY, endX + this.size * 0.02F, endY - this.size * 0.22F, stroke);
         this.line(consumer, endX, endY, endX + this.size * 0.22F, endY - this.size * 0.02F, stroke);
      }

      private void drawRotateHorizontal(VertexConsumer consumer) {
         float stroke = Math.max(1.15F, this.size * 0.045F);
         float radiusX = this.size * 0.42F;
         float radiusY = this.size * 0.115F;
         this.ellipseArc(consumer, this.centerX, this.centerY, radiusX, radiusY, 0.0F, (float)(Math.PI * 2.0), stroke, 36);

         float arrowWidth = this.size * 0.12F;
         float arrowHeight = this.size * 0.09F;
         float left = this.centerX - radiusX;
         float right = this.centerX + radiusX;
         this.line(consumer, left, this.centerY, left + arrowWidth, this.centerY - arrowHeight, stroke);
         this.line(consumer, left, this.centerY, left + arrowWidth, this.centerY + arrowHeight, stroke);
         this.line(consumer, right, this.centerY, right - arrowWidth, this.centerY - arrowHeight, stroke);
         this.line(consumer, right, this.centerY, right - arrowWidth, this.centerY + arrowHeight, stroke);
      }

      private void drawBack(VertexConsumer consumer) {
         float stroke = this.stroke();
         this.line(consumer, this.centerX + this.size * 0.31F, this.centerY, this.centerX - this.size * 0.22F, this.centerY, stroke);
         this.line(consumer, this.centerX - this.size * 0.22F, this.centerY, this.centerX - this.size * 0.02F, this.centerY - this.size * 0.2F, stroke);
         this.line(consumer, this.centerX - this.size * 0.22F, this.centerY, this.centerX - this.size * 0.02F, this.centerY + this.size * 0.2F, stroke);
      }

      private void drawGrid(VertexConsumer consumer) {
         float stroke = this.stroke();
         float gap = this.size * 0.08F;
         float half = this.size * 0.3F;
         float tile = this.size * 0.2F;

         for (int row = 0; row < 2; row++) {
            for (int column = 0; column < 2; column++) {
               float x = this.centerX - half + column * (tile + gap);
               float y = this.centerY - half + row * (tile + gap);
               this.path(consumer, stroke, true, x, y, x + tile, y, x + tile, y + tile, x, y + tile);
            }
         }
      }

      private void drawPalette(VertexConsumer consumer) {
         float stroke = this.stroke();
         this.arc(consumer, this.centerX, this.centerY, this.size * 0.31F, (float) (Math.PI / 5), 5.906194F, stroke, 20);
         this.filledCircle(consumer, this.centerX - this.size * 0.12F, this.centerY - this.size * 0.11F, this.size * 0.045F, stroke, 10);
         this.filledCircle(consumer, this.centerX + this.size * 0.04F, this.centerY - this.size * 0.2F, this.size * 0.045F, stroke, 10);
         this.filledCircle(consumer, this.centerX + this.size * 0.19F, this.centerY - this.size * 0.1F, this.size * 0.045F, stroke, 10);
         this.filledCircle(consumer, this.centerX + this.size * 0.18F, this.centerY + this.size * 0.08F, this.size * 0.045F, stroke, 10);
         this.arc(consumer, this.centerX + this.size * 0.1F, this.centerY + this.size * 0.2F, this.size * 0.12F, 0.47123894F, 3.6128316F, stroke, 8);
      }

      private void drawHanger(VertexConsumer consumer) {
         float stroke = this.stroke();
         this.arc(consumer, this.centerX, this.centerY - this.size * 0.22F, this.size * 0.1F, (float) Math.PI, (float) (Math.PI * 2), stroke, 10);
         this.line(consumer, this.centerX, this.centerY - this.size * 0.12F, this.centerX - this.size * 0.35F, this.centerY + this.size * 0.17F, stroke);
         this.line(consumer, this.centerX, this.centerY - this.size * 0.12F, this.centerX + this.size * 0.35F, this.centerY + this.size * 0.17F, stroke);
         this.line(
            consumer,
            this.centerX - this.size * 0.35F,
            this.centerY + this.size * 0.17F,
            this.centerX + this.size * 0.35F,
            this.centerY + this.size * 0.17F,
            stroke
         );
      }

      private void drawCircle(VertexConsumer consumer) {
         this.ring(consumer, this.centerX, this.centerY, this.size * 0.29F, this.stroke(), 22);
      }

      private void drawCube(VertexConsumer consumer) {
         float stroke = this.stroke();
         float top = this.centerY - this.size * 0.3F;
         float mid = this.centerY - this.size * 0.06F;
         float bottom = this.centerY + this.size * 0.3F;
         float left = this.centerX - this.size * 0.3F;
         float right = this.centerX + this.size * 0.3F;
         float apex = this.centerX;
         this.path(consumer, stroke, true, apex, top, right, mid, apex, this.centerY + this.size * 0.05F, left, mid);
         this.line(consumer, apex, this.centerY + this.size * 0.05F, apex, bottom, stroke);
         this.line(consumer, left, mid, left, this.centerY + this.size * 0.05F, stroke);
         this.line(consumer, right, mid, right, this.centerY + this.size * 0.05F, stroke);
         this.line(consumer, left, this.centerY + this.size * 0.05F, apex, bottom, stroke);
         this.line(consumer, right, this.centerY + this.size * 0.05F, apex, bottom, stroke);
      }

      private void drawMoreVertical(VertexConsumer consumer) {
         float radius = Math.max(0.8F, this.size * 0.065F);
         this.filledCircle(consumer, this.centerX,
                 this.centerY - this.size * 0.23F, radius, 0, 12);
         this.filledCircle(consumer, this.centerX, this.centerY,
                 radius, 0, 12);
         this.filledCircle(consumer, this.centerX,
                 this.centerY + this.size * 0.23F, radius, 0, 12);
      }

      private void drawHelp(VertexConsumer consumer) {
         float stroke = Math.max(1.0F, this.size * 0.075F);
         this.ring(consumer, this.centerX, this.centerY,
                 this.size * 0.35F, stroke, 24);
         this.arc(consumer, this.centerX - this.size * 0.02F,
                 this.centerY - this.size * 0.08F, this.size * 0.15F,
                 3.55F, 6.8F, stroke, 12);
         this.line(consumer, this.centerX + this.size * 0.08F,
                 this.centerY + this.size * 0.03F,
                 this.centerX + this.size * 0.02F,
                 this.centerY + this.size * 0.17F, stroke);
         this.filledCircle(consumer, this.centerX,
                 this.centerY + this.size * 0.26F,
                 this.size * 0.045F, 0, 10);
      }

      private void drawExpand(VertexConsumer consumer) {
         float stroke = this.stroke();
         float outer = this.size * 0.34F;
         float inner = this.size * 0.09F;
         this.line(consumer, this.centerX - inner, this.centerY - inner,
                 this.centerX - outer, this.centerY - outer, stroke);
         this.line(consumer, this.centerX - outer, this.centerY - outer,
                 this.centerX - outer, this.centerY - this.size * 0.10F, stroke);
         this.line(consumer, this.centerX - outer, this.centerY - outer,
                 this.centerX - this.size * 0.10F, this.centerY - outer, stroke);
         this.line(consumer, this.centerX + inner, this.centerY + inner,
                 this.centerX + outer, this.centerY + outer, stroke);
         this.line(consumer, this.centerX + outer, this.centerY + outer,
                 this.centerX + outer, this.centerY + this.size * 0.10F, stroke);
         this.line(consumer, this.centerX + outer, this.centerY + outer,
                 this.centerX + this.size * 0.10F, this.centerY + outer, stroke);
      }

      private void drawFilter(VertexConsumer consumer) {
         float stroke = this.stroke();
         this.path(consumer, stroke, false,
                 this.centerX - this.size * 0.35F,
                 this.centerY - this.size * 0.28F,
                 this.centerX + this.size * 0.35F,
                 this.centerY - this.size * 0.28F,
                 this.centerX + this.size * 0.11F,
                 this.centerY + this.size * 0.02F,
                 this.centerX + this.size * 0.11F,
                 this.centerY + this.size * 0.29F,
                 this.centerX - this.size * 0.08F,
                 this.centerY + this.size * 0.20F,
                 this.centerX - this.size * 0.08F,
                 this.centerY + this.size * 0.02F,
                 this.centerX - this.size * 0.35F,
                 this.centerY - this.size * 0.28F);
      }

      private void drawSwap(VertexConsumer consumer) {
         float stroke = this.stroke();
         float left = this.centerX - this.size * 0.34F;
         float right = this.centerX + this.size * 0.34F;
         float top = this.centerY - this.size * 0.16F;
         float bottom = this.centerY + this.size * 0.16F;
         this.line(consumer, left, top, right, top, stroke);
         this.line(consumer, right, top, right - this.size * 0.15F,
                 top - this.size * 0.14F, stroke);
         this.line(consumer, right, top, right - this.size * 0.15F,
                 top + this.size * 0.14F, stroke);
         this.line(consumer, right, bottom, left, bottom, stroke);
         this.line(consumer, left, bottom, left + this.size * 0.15F,
                 bottom - this.size * 0.14F, stroke);
         this.line(consumer, left, bottom, left + this.size * 0.15F,
                 bottom + this.size * 0.14F, stroke);
      }

      private void drawAdd(VertexConsumer consumer) {
         float stroke = this.stroke();
         float half = this.size * 0.27F;
         this.line(consumer, this.centerX - half, this.centerY,
                 this.centerX + half, this.centerY, stroke);
         this.line(consumer, this.centerX, this.centerY - half,
                 this.centerX, this.centerY + half, stroke);
      }

      private float stroke() {
         return Math.max(1.0F, this.size * 0.075F);
      }

      private void ring(VertexConsumer consumer, float x, float y, float radius, float thickness, int segments) {
         float outer = radius + thickness * 0.5F;
         float inner = Math.max(0.0F, radius - thickness * 0.5F);

         if (segments <= 0) return;
         UnitCircle circle = UnitCircle.of(segments);
         for (int segment = 0; segment < segments; segment++) {
            OpenGlUiRenderer.quad(
               consumer,
               this.pose,
               x + circle.cos(segment) * outer,
               y + circle.sin(segment) * outer,
               x + circle.cos(segment) * inner,
               y + circle.sin(segment) * inner,
               x + circle.cos(segment + 1) * inner,
               y + circle.sin(segment + 1) * inner,
               x + circle.cos(segment + 1) * outer,
               y + circle.sin(segment + 1) * outer,
               this.color
            );
         }
      }

      private void filledCircle(VertexConsumer consumer, float x, float y, float radius, float thickness, int segments) {
         float outer = radius + thickness * 0.5F;

         if (segments <= 0) return;
         UnitCircle circle = UnitCircle.of(segments);
         for (int segment = 0; segment < segments; segment++) {
            OpenGlUiRenderer.quad(
               consumer,
               this.pose,
               x + circle.cos(segment) * outer,
               y + circle.sin(segment) * outer,
               x,
               y,
               x,
               y,
               x + circle.cos(segment + 1) * outer,
               y + circle.sin(segment + 1) * outer,
               this.color
            );
         }
      }

      private void arc(VertexConsumer consumer, float x, float y, float radius, float start, float end, float thickness, int segments) {
         for (int segment = 0; segment < segments; segment++) {
            float t0 = (float)segment / segments;
            float t1 = (float)(segment + 1) / segments;
            this.line(
               consumer,
               x + (float)Math.cos(start + (end - start) * t0) * radius,
               y + (float)Math.sin(start + (end - start) * t0) * radius,
               x + (float)Math.cos(start + (end - start) * t1) * radius,
               y + (float)Math.sin(start + (end - start) * t1) * radius,
               thickness
            );
         }
      }

      private void ellipseArc(
         VertexConsumer consumer, float x, float y, float radiusX, float radiusY, float start, float end, float thickness, int segments
      ) {
         for (int segment = 0; segment < segments; segment++) {
            float t0 = (float)segment / segments;
            float t1 = (float)(segment + 1) / segments;
            this.line(
               consumer,
               x + (float)Math.cos(start + (end - start) * t0) * radiusX,
               y + (float)Math.sin(start + (end - start) * t0) * radiusY,
               x + (float)Math.cos(start + (end - start) * t1) * radiusX,
               y + (float)Math.sin(start + (end - start) * t1) * radiusY,
               thickness
            );
         }
      }

      private void path(VertexConsumer consumer, float thickness, boolean closed, float... points) {
         int pointCount = points.length / 2;
         if (pointCount >= 2) {
            for (int point = 0; point < pointCount - 1; point++) {
               this.line(consumer, points[point * 2], points[point * 2 + 1], points[(point + 1) * 2], points[(point + 1) * 2 + 1], thickness);
            }

            if (closed) {
               this.line(consumer, points[(pointCount - 1) * 2], points[(pointCount - 1) * 2 + 1], points[0], points[1], thickness);
            }
         }
      }

      private void line(VertexConsumer consumer, float startX, float startY, float endX, float endY, float thickness) {
         float dx = endX - startX;
         float dy = endY - startY;
         float length = (float)Math.sqrt(dx * dx + dy * dy);
         if (!(length <= 0.0F)) {
            float normalX = -dy / length * thickness * 0.5F;
            float normalY = dx / length * thickness * 0.5F;
            OpenGlUiRenderer.quad(
               consumer,
               this.pose,
               startX - normalX,
               startY - normalY,
               startX + normalX,
               startY + normalY,
               endX + normalX,
               endY + normalY,
               endX - normalX,
               endY - normalY,
               this.color
            );
         }
      }

      @Override
      public RenderPipeline pipeline() {
         return RenderPipelines.GUI;
      }

      @Override
      public TextureSetup textureSetup() {
         return TextureSetup.noTexture();
      }
   }

   public enum UiIcon {
      SEARCH,
      CLOSE,
      CHECK,
      USER,
      LINK,
      FOLDER,
      HEADWEAR,
      WINGS,
       SHIRT,
       SWORD,
       COSMETICS,
       CAPE,
       PET,
       ARROW_LEFT,
       ARROW_RIGHT,
       ARROW_UP,
       ARROW_DOWN,
       RESET,
       ROTATE_HORIZONTAL,
       BACK,
      GRID,
      PALETTE,
      HANGER,
      CIRCLE,
      CUBE,
      MORE_VERTICAL,
      HELP,
      EXPAND,
      FILTER,
      SWAP,
      ADD;
   }
}
