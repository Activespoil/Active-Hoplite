package dev.lin.client.cosmetics.ui;
public interface PortraitModelState {
    void lin$restorePortraitVisibility();
}
