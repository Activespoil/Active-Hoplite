package dev.lin.client.cosmetics.model;

/**
 * Immutable quad mesh. Coordinates are Minecraft renderer units: one block is
 * one unit, positive Y points down, and the entity origin is at its feet.
 */
public record CosmeticMesh(
        CosmeticVertex[] vertices,
        int textureWidth,
        int textureHeight,
        float minX,
        float minY,
        float minZ,
        float maxX,
        float maxY,
        float maxZ) {

    public CosmeticMesh {
        vertices = vertices == null ? new CosmeticVertex[0] : vertices.clone();
        textureWidth = Math.max(1, textureWidth);
        textureHeight = Math.max(1, textureHeight);
    }

    @Override
    public CosmeticVertex[] vertices() {
        return vertices.clone();
    }

    /** Read-only hot-path view used by the renderers. */
    public CosmeticVertex[] rawVertices() {
        return vertices;
    }

    public float extent() {
        return Math.max(0.001F,
                Math.max(maxX - minX, Math.max(maxY - minY, maxZ - minZ)));
    }

    public int vertexCount() {
        return vertices.length;
    }

    public float centerX() {
        return (minX + maxX) * 0.5F;
    }

    public float centerY() {
        return (minY + maxY) * 0.5F;
    }

    public float centerZ() {
        return (minZ + maxZ) * 0.5F;
    }

    public static CosmeticMesh of(CosmeticVertex[] vertices, int textureWidth, int textureHeight) {
        if (vertices == null || vertices.length == 0) {
            return new CosmeticMesh(new CosmeticVertex[0], textureWidth, textureHeight,
                    0, 0, 0, 0, 0, 0);
        }
        float minX = Float.POSITIVE_INFINITY;
        float minY = Float.POSITIVE_INFINITY;
        float minZ = Float.POSITIVE_INFINITY;
        float maxX = Float.NEGATIVE_INFINITY;
        float maxY = Float.NEGATIVE_INFINITY;
        float maxZ = Float.NEGATIVE_INFINITY;
        for (CosmeticVertex vertex : vertices) {
            minX = Math.min(minX, vertex.x());
            minY = Math.min(minY, vertex.y());
            minZ = Math.min(minZ, vertex.z());
            maxX = Math.max(maxX, vertex.x());
            maxY = Math.max(maxY, vertex.y());
            maxZ = Math.max(maxZ, vertex.z());
        }
        return new CosmeticMesh(vertices, textureWidth, textureHeight,
                minX, minY, minZ, maxX, maxY, maxZ);
    }
}
