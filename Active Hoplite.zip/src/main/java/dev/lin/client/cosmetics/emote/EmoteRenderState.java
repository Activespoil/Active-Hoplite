package dev.lin.client.cosmetics.emote;

/** Preview data travels with the deferred 1.21.11 render state. */
public interface EmoteRenderState {
    EmoteRuntime.Sample linEmoteSample();
    void linEmoteSample(EmoteRuntime.Sample sample);
}
