package dev.lin.client.cosmetics.ui;
import dev.lin.client.cosmetics.font.FontManager;
import dev.lin.client.cosmetics.font.PageTypography;
import dev.lin.client.cosmetics.render.OpenGlUiRenderer;
import dev.lin.client.cosmetics.sync.CosmeticSyncBridge;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.resources.Identifier;
import java.util.function.Consumer;
/** Standalone Cosmetics Wardrobe shell, navigation geometry, and glass palette. */
public final class ClientShell {
 private static final Identifier BRAND_LOGO=Identifier.fromNamespaceAndPath("lin_client","textures/ui/brand_logo.png");
 public static final float WIDTH=760, HEIGHT=614, SIDE=174, RAIL_GAP=0, RAIL_WIDTH=260;
 private static final float SCALE_REFERENCE_HEIGHT=720;
 public static final String[] KEYS={"cloaks","headwear","wings","pets","artifacts","trims","misc","settings"};
 public static final String[] LABELS={"披风","头饰","翅膀","宠物","神器皮肤","盔甲纹饰","杂项","设置"};
 public static final String[] LABELS_EN={"Capes","Headwear","Wings","Pets","Artifacts","Armor Trim","Misc","Settings"};
 private static boolean english=false;
 private static final float NAV_TOP=90, NAV_STEP=44;
 private static long motionTime;
 private static float indicator=-1;
 private static final dev.lin.client.shared.LensMotion.Spring navigationSpring=new dev.lin.client.shared.LensMotion.Spring(90);
 private static final float[] hover=new float[KEYS.length];
 private static float langHover=0;
 public static boolean isEnglish(){return english;}
 public static void toggleLanguage(){english=!english;}
 public static String tr(String zh,String en){return english?en:zh;}
 public record Layout(float x,float y,float scale){
  public float localX(double value){return (float)(value-x)/scale;}
  public float localY(double value){return (float)(value-y)/scale;}
 }
 public interface Painter {
  void box(float x,float y,float w,float h,float r,int color);
  void outline(float x,float y,float w,float h,float r,int color);
  void text(String text,float x,float y,float size,int color);
  void line(float x,float y,float x2,float y2,int color);
 }
 private ClientShell(){}
 public static float totalWidth(){return WIDTH+RAIL_GAP+RAIL_WIDTH;}
 public static float scale(int w,int h){
  float requested=GlassStyle.number("width.fraction",.88f)/.88f;
  if(!Float.isFinite(requested))requested=1f;
  requested=Math.max(.60f,Math.min(1.50f,requested));
  float fit=Math.min(w*.96f/totalWidth(),h*.88f/SCALE_REFERENCE_HEIGHT);
  return Math.max(.01f,fit*Math.min(1f,.90f*requested));
 }
 public static Layout layout(int w,int h){float s=scale(w,h);return new Layout((w-(WIDTH+RAIL_GAP+RAIL_WIDTH)*s)/2,(h-HEIGHT*s)/2,s);}
 public static Layout content(int width,int height,float virtualLeft,float virtualWidth,float virtualHeight,float top){
  return contentArea(width,height,SIDE+14,top,WIDTH-SIDE-28,HEIGHT-top-12,virtualLeft,virtualWidth,virtualHeight);
 }
 public static Layout contentArea(int width,int height,float left,float top,float areaWidth,float areaHeight,float virtualLeft,float virtualWidth,float virtualHeight){
  Layout shell=layout(width,height);
  float s=shell.scale()*Math.min(areaWidth/virtualWidth,areaHeight/virtualHeight);
  return new Layout(shell.x()+left*shell.scale()-virtualLeft*s,shell.y()+top*shell.scale(),s);
 }
 public static boolean railPage(String key){return true;}
 public static boolean inRail(double x,double y,int w,int h){
  Layout l=layout(w,h);return inside(l.localX(x),l.localY(y),WIDTH+RAIL_GAP,0,RAIL_WIDTH,HEIGHT);
 }
 public static Layout railContent(int w,int h,float virtualLeft,float virtualWidth,float virtualHeight){
  Layout l=layout(w,h);float fit=Math.min((RAIL_WIDTH-14)/virtualWidth,(HEIGHT-98)/virtualHeight);
  float s=l.scale()*fit;
  return new Layout(l.x()+(WIDTH+4)*l.scale()-virtualLeft*s,l.y()+82*l.scale(),s);
 }
 public static int color(String method,int fallback){
  return switch(method){
   case "primaryText"->0xFFF2F5F4;
   case "secondaryText"->0xFFA5B0AD;
   case "mutedText"->0xFF6E7875;
   case "accent"->0xFF76E02A;
   case "panel"->0xFF141817;
   case "control"->0xFF1C2220;
   case "accentText"->0xFF0E150B;
   default->fallback;
  };
 }
 public static int text(){return 0xFFF2F5F4;}
 public static int muted(){return 0xFF6E7875;}
 public static int accent(){return 0xFF76E02A;}
 public static int surface(){return 0xFF141817;}
 public static int control(){return 0xFF1C2220;}
 public static int tile(){return 0xFF1B211F;}
 public static int glassTile(){return 0xD21B211F;}
 public static int glassHover(){return 0xE6222A27;}
 public static int inset(){return 0xCC101413;}
 public static int hoverSurface(){return 0xFF242C2A;}
 public static int selected(){return 0xFF1F2F1C;}
 public static int border(){return 0xFF2A3230;}
 public static int accentText(){return 0xFF0E150B;}
 private static int blend(int a,int b,float t){
  int r=Math.round(((a>>16)&255)*(1-t)+((b>>16)&255)*t);
  int g=Math.round(((a>>8)&255)*(1-t)+((b>>8)&255)*t);
  int blue=Math.round((a&255)*(1-t)+(b&255)*t);
  return 0xFF000000|(r<<16)|(g<<8)|blue;
 }
 public static boolean inside(float x,float y,float left,float top,float w,float h){return x>=left&&y>=top&&x<left+w&&y<top+h;}
 public static void draw(Painter p,String selected,String name,float mx,float my){draw(p,selected,name,mx,my,false);}
 public static void draw(Painter p,String selected,String name,float mx,float my,boolean searchPlaceholder){
  int tint=0xDC131817;
  p.box(0,0,totalWidth(),HEIGHT,20,tint);
  p.outline(0.5f,0.5f,totalWidth()-1,HEIGHT-1,19.5f,0xFF2B3431);
  p.box(24,0.8f,totalWidth()*0.38f,1.2f,0.6f,0x1CFFFFFF);
  p.box(8,8,SIDE-16,HEIGHT-16,14,0x88101413);
  p.text("Active",50,29,14.5f,text());
  p.text("Hoplite",50+FontManager.widthRegular("Active ",14.5f),29,14.5f,0xFF7B8582);

  long now=System.nanoTime();double dt=motionTime==0?0:Math.min(.05,(now-motionTime)/1e9);motionTime=now;
  int selectedIndex=java.util.Arrays.asList(KEYS).indexOf(selected);
  float target=NAV_TOP+Math.max(0,selectedIndex)*NAV_STEP;
  if(indicator<0){indicator=target;navigationSpring.snap(target);}else indicator=navigationSpring.update(target,dt);
  if(selectedIndex>=0){
   p.box(12,indicator,SIDE-24,38,8,0xCC1E2624);
   p.box(12,indicator+5,3.5f,28,1.75f,accent());
  }
  String[] labels=english?LABELS_EN:LABELS;
  for(int i=0;i<KEYS.length;i++){
   float y=NAV_TOP+i*NAV_STEP;boolean active=KEYS[i].equals(selected);
   hover[i]=dev.lin.client.shared.UiMotion.follow(hover[i],!active&&inside(mx,my,12,y,SIDE-24,38)?1:0,dt);
   if(hover[i]>.01f)p.box(12,y,SIDE-24,38,8,(Math.round(18*hover[i])<<24)|0xFFFFFF);
   icon(p,i,26,y+11,active?accent():muted());
   p.text(labels[i],54,y+11,PageTypography.BODY,active?text():0xFF8E9895);
  }
  float langY=HEIGHT-50;
  langHover=dev.lin.client.shared.UiMotion.follow(langHover,inside(mx,my,12,langY,SIDE-24,34)?1:0,dt);
  if(langHover>.01f)p.box(12,langY,SIDE-24,34,8,(Math.round(18*langHover)<<24)|0xFFFFFF);
  icon(p,99,24,langY+9,langHover>.2f?text():muted());
  p.text("Language/"+(english?"EN":"CN"),50,langY+10,12f,langHover>.2f?text():0xFFA5B0AD);
 }
 private static String trimToWidth(String text,float size,float maxWidth){
  if(text==null)return "";
  String out=text;
  while(!out.isEmpty()&&FontManager.widthRegular(out,size)>maxWidth)out=out.substring(0,out.length()-1);
  return out;
 }
 public static void render(GuiGraphics g,int w,int h,String selected,double mx,double my){
  render(g,w,h,selected,mx,my,false);
 }
 public static void render(GuiGraphics g,int w,int h,String selected,double mx,double my,boolean placeholder){
  render(g,w,h,selected,mx,my,placeholder,true);
 }
 public static void render(GuiGraphics g,int w,int h,String selected,double mx,double my,boolean placeholder,boolean showLogo){
  Layout l=layout(w,h);var pose=g.pose();pose.pushMatrix();
  try{
   pose.translate(l.x(),l.y());pose.scale(l.scale(),l.scale());
   draw(painter(g),selected,Minecraft.getInstance().getGameProfile().name(),l.localX(mx),l.localY(my),placeholder);
   if(showLogo)g.blit(RenderPipelines.GUI_TEXTURED,BRAND_LOGO,17,22,0,0,26,26,128,128,128,128);
  }finally{pose.popMatrix();}
 }
 public static boolean click(double gx,double gy,int w,int h,String selected,Runnable close){
  return click(gx,gy,w,h,selected,key->{});
 }
 public static boolean click(double gx,double gy,int w,int h,String selected,Consumer<String> onSelect){
  Layout l=layout(w,h);float x=l.localX(gx),y=l.localY(gy);
  for(int i=0;i<KEYS.length;i++)if(inside(x,y,12,NAV_TOP+i*NAV_STEP,SIDE-24,38)){
   onSelect.accept(KEYS[i]);
   return true;
  }
  if(inside(x,y,12,HEIGHT-50,SIDE-24,34)){
   toggleLanguage();
   return true;
  }
  return inside(x,y,0,0,SIDE,HEIGHT);
 }
 private static void icon(Painter p,int id,float x,float y,int color) {
  switch(id) {
   case 0 -> { // Capes: shield/cloak
    p.outline(x+2,y+1,12,15,3,color);
    p.line(x+5,y+5,x+11,y+5,color);
   }
   case 1 -> { // Headwear: cube/helmet
    p.outline(x+1,y+2,14,13,3,color);
    p.line(x+1,y+7,x+15,y+7,color);
   }
   case 2 -> { // Wings
    p.line(x+1,y+4,x+7,y+9,color);p.line(x+7,y+9,x+1,y+14,color);
    p.line(x+15,y+4,x+9,y+9,color);p.line(x+9,y+9,x+15,y+14,color);
   }
   case 3 -> { // Pets: paw
    p.outline(x+4,y+8,8,7,3,color);
    p.box(x+2,y+4,3,3,1.5f,color);p.box(x+6.5f,y+2,3,3,1.5f,color);p.box(x+11,y+4,3,3,1.5f,color);
   }
   case 4 -> { // Artifacts: sword
    p.line(x+2,y+14,x+14,y+2,color);
    p.line(x+4,y+9,x+8,y+13,color);
   }
   case 5 -> { // Armor Trim: 2x2 grid
    for(int row=0;row<2;row++)for(int col=0;col<2;col++)
     p.outline(x+1+col*8,y+1+row*8,6,6,1.5f,color);
   }
   case 6 -> { // Misc: star/sparkle
    p.line(x+8,y+1,x+8,y+15,color);p.line(x+1,y+8,x+15,y+8,color);
    p.outline(x+5,y+5,6,6,3,color);
   }
   case 7 -> { // Settings: sliders
    p.line(x+1,y+4,x+15,y+4,color);p.box(x+4,y+2,4,4,2,color);
    p.line(x+1,y+12,x+15,y+12,color);p.box(x+9,y+10,4,4,2,color);
   }
   default -> { // Gear / Language
    p.outline(x+1,y+1,14,14,7,color);
    p.outline(x+5,y+5,6,6,3,color);
   }
  }
 }
 public static Painter painter(GuiGraphics g) {
  return new Painter() {
   public void box(float x,float y,float w,float h,float r,int color) { OpenGlUiRenderer.roundedRect(g,x,y,w,h,r,color); }
   public void outline(float x,float y,float w,float h,float r,int color) { OpenGlUiRenderer.roundedOutline(g,x,y,w,h,r,color,1); }
   public void text(String text,float x,float y,float size,int color) { OpenGlUiRenderer.textRegular(g,text,x,y,size,color); }
   public void line(float x,float y,float x2,float y2,int color) {
    if(x==x2 || y==y2) {
     OpenGlUiRenderer.roundedRect(g,Math.min(x,x2),Math.min(y,y2),
       Math.max(1,Math.abs(x2-x)),Math.max(1,Math.abs(y2-y)),0,color);
     return;
    }
    var pose=g.pose();pose.pushMatrix();
    try {
     pose.translate(x,y);pose.rotate((float)Math.atan2(y2-y,x2-x));
     OpenGlUiRenderer.roundedRect(g,0,-.5f,(float)Math.hypot(x2-x,y2-y),1,0,color);
    } finally { pose.popMatrix(); }
   }
  };
 }
}
