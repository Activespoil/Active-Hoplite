package dev.lin.client.cosmetics.render;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import dev.lin.client.cosmetics.assets.CosmeticAssetManager;
import dev.lin.client.cosmetics.catalog.CosmeticCategory;
import dev.lin.client.cosmetics.catalog.CosmeticDefinition;
import dev.lin.client.cosmetics.config.CosmeticConfig;
import dev.lin.client.cosmetics.model.CosmeticAttachment;
import dev.lin.client.cosmetics.model.CosmeticMesh;
import dev.lin.client.cosmetics.model.HoplitePetAnimation;
import org.joml.Vector3f;
import dev.lin.client.cosmetics.model.CosmeticRenderData;
import dev.lin.client.cosmetics.model.CosmeticVertex;
import dev.lin.client.cosmetics.model.BedrockModelLoader;
import dev.lin.client.cosmetics.model.BuiltinCosmeticMeshes;
import dev.lin.client.features.cape.LunarCapeRegistry;
import dev.lin.client.features.cape.LunarCapeTextureManager;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Camera;
import net.minecraft.client.player.AbstractClientPlayer;
import dev.lin.client.cosmetics.sync.RemoteCosmetics;
import net.minecraft.client.model.player.PlayerModel;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.entity.state.AvatarRenderState;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.core.ClientAsset;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.PlayerSkin;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.joml.Quaternionf;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;

/** Submits standalone cosmetic geometry into the normal avatar render graph. */
public final class CosmeticWorldRenderer {
    private static final float PLAYER_FEET_Y = 1.5F;
    private static final float COMPANION_HEIGHT = 0.80F;
    private static final Map<java.util.UUID, CompanionFollower> FOLLOWERS = new java.util.HashMap<>();
    private static Object followerWorld;
    private static final long PET_PREVIEW_START = System.nanoTime();
    private static final Map<AvatarRenderState, List<CosmeticDefinition>> PREVIEW_OUTFITS =
            Collections.synchronizedMap(new WeakHashMap<>());
    private static final Map<AvatarRenderState, Identifier> PREVIEW_CAPES =
            Collections.synchronizedMap(new WeakHashMap<>());

    private CosmeticWorldRenderer() {
    }
    public static void clearFollowers() { FOLLOWERS.clear();followerWorld=null; }

    public static void setPreviewOutfit(AvatarRenderState state,
                                        List<CosmeticDefinition> outfit) {
        PREVIEW_OUTFITS.put(state, List.copyOf(outfit));
    }

    public static void setPreviewCape(AvatarRenderState state,
                                      Identifier texture) {
        if (texture != null) PREVIEW_CAPES.put(state, texture);
    }

    public static void applyCape(AvatarRenderState state) {
        if (!isLocalAvatar(state) && RemoteCosmetics.view(state)==null) return;
        Identifier textureId = PREVIEW_CAPES.remove(state);
        CosmeticDefinition cape = null;
        if (textureId == null) {
            for (CosmeticDefinition definition : equippedFor(state)) {
                if (definition.category() == CosmeticCategory.CLOAK) {
                    cape = definition;
                    break;
                }
            }
            CosmeticRenderData data = dataFor(state,cape);
            if (data != null) textureId = data.capeTexture();
        }
        if (textureId == null && isLocalAvatar(state) && LunarCapeRegistry.selected() != null) {
            textureId = LunarCapeTextureManager.selectedTexture();
        }
        if (textureId == null && !isLocalAvatar(state)) {
            var outfit=RemoteCosmetics.outfit(state);
            if(outfit!=null)textureId=LunarCapeTextureManager.remoteTexture(outfit.accessories().get("cape"));
        }
        if (textureId == null) return;
        PlayerSkin skin = state.skin;
        ClientAsset.ResourceTexture texture = new ClientAsset.ResourceTexture(
                textureId, textureId);
        state.skin = new PlayerSkin(skin.body(), texture, texture,
                skin.model(), skin.secure());
        state.showCape = !state.chestEquipment.is(Items.ELYTRA);
    }

    public static boolean isCapeApplied(AvatarRenderState state) {
        if (!isLocalAvatar(state) && RemoteCosmetics.view(state)==null) return false;
        if (PREVIEW_CAPES.containsKey(state)) return true;
        for (CosmeticDefinition definition : equippedFor(state)) {
            if (definition.category() != CosmeticCategory.CLOAK) continue;
            CosmeticRenderData data = dataFor(state,definition);
            if (data != null && data.capeTexture() != null) return true;
        }
        if(!isLocalAvatar(state)) {
            var outfit=RemoteCosmetics.outfit(state);
            return outfit!=null && LunarCapeTextureManager.remoteTexture(outfit.accessories().get("cape"))!=null;
        }
        return LunarCapeRegistry.selected() != null
                && LunarCapeTextureManager.selectedTexture() != null;
    }

    public static void submit(PlayerModel model, AvatarRenderState state,
                              PoseStack matrices, SubmitNodeCollector collector) {
        if ((!isLocalAvatar(state) && RemoteCosmetics.view(state)==null) || state.isInvisible) return;
        List<CosmeticDefinition> previewOutfit = PREVIEW_OUTFITS.get(state);
        boolean preview = previewOutfit != null;
        List<CosmeticDefinition> outfit = equippedFor(state);
        try {
            for (CosmeticDefinition definition : outfit) {
                // Aura GUI animations are thumbnail compositions: some shift
                // the root off the player and halve the orbit radius. An aura
                // attached to the avatar must retain its worn animation space.
                CosmeticRenderData data = preview
                        && definition.category() != CosmeticCategory.AURAS
                        && definition.category() != CosmeticCategory.DRAGON_WINGS
                        ? CosmeticAssetManager.getPreview(definition)
                        : dataFor(state,definition);
                if (data == null || data.attachment() == CosmeticAttachment.CAPE) continue;
                if (!preview && data.attachment() == CosmeticAttachment.COMPANION) continue;
                matrices.pushPose();
                applyAttachment(model, state, data, matrices, preview);
                var owner=RemoteCosmetics.player(state);
                float speed=owner==null?0:(float)Math.hypot(owner.getX()-owner.xOld,owner.getZ()-owner.zOld)*20;
                var remoteView=RemoteCosmetics.view(state);
                CosmeticMesh wings=(remoteView==null || remoteView.animated()) && definition.category()==CosmeticCategory.DRAGON_WINGS && !definition.gek()
                    ? BuiltinCosmeticMeshes.wingFrame(System.currentTimeMillis(),Math.min(1f,speed/4.317f),
                        owner!=null && owner.isFallFlying(),owner!=null && owner.isCrouching()):null;
                int light=state.lightCoords;float ticks=state.ageInTicks;
                collector.submitCustomGeometry(matrices,
                        RenderTypes.entityCutoutNoCull(data.texture()),
                        (pose, consumer) -> render(data, pose, consumer,
                                light,ticks,0f,0f,0f,wings));
                matrices.popPose();
            }
        } finally {
            PREVIEW_OUTFITS.remove(state);
        }
    }

    public static void renderWorldCompanion(WorldRenderContext context) {
        Minecraft mc=Minecraft.getInstance();
        if(followerWorld!=mc.level){FOLLOWERS.clear();followerWorld=mc.level;}
        if(mc.player==null || mc.level==null || context.matrices()==null)return;
        java.util.Set<java.util.UUID> wanted=new java.util.HashSet<>();
        drawCompanion(context,mc.player,CosmeticConfig.equipped(CosmeticCategory.COMPANION),false,wanted);
        for(var view:RemoteCosmetics.views()){
            if(!view.animated() || view.player().isInvisible() || view.player().isSpectator()
                || dev.lin.client.cosmetics.sync.CosmeticSyncBridge.remote(view.player().getUUID())==null)continue;
            for(var definition:view.peer().definitions())if(definition.category()==CosmeticCategory.COMPANION)
                drawCompanion(context,view.player(),definition,true,wanted);
        }
        FOLLOWERS.keySet().retainAll(wanted);
    }
    private static void drawCompanion(WorldRenderContext context, AbstractClientPlayer player,
            CosmeticDefinition definition, boolean remote, java.util.Set<java.util.UUID> wanted){
        if(player.isInvisible() || player.isSpectator())return;
        CosmeticRenderData data=remote?CosmeticAssetManager.remoteData(player.getUUID(),definition):CosmeticAssetManager.get(definition);
        if(data==null || data.attachment()!=CosmeticAttachment.COMPANION)return;
        wanted.add(player.getUUID());
        FOLLOWERS.computeIfAbsent(player.getUUID(),id->new CompanionFollower()).draw(context,player,definition,data);
    }
    private static final class CompanionFollower {
    private int companionOwnerId = Integer.MIN_VALUE;
    private int companionDefinitionId = Integer.MIN_VALUE;
    private int companionLastTick = Integer.MIN_VALUE;
    private double companionX;
    private double companionY;
    private double companionZ;
    private double companionPreviousX;
    private double companionPreviousY;
    private double companionPreviousZ;
    private double companionTargetX;
    private double companionTargetZ;
    private float companionMoveYaw;
    private float companionPreviousYaw;
    private float companionMoveSpeed;
    private double companionVelocityY;
    private java.lang.ref.WeakReference<Object> companionWorld = new java.lang.ref.WeakReference<>(null);
    private boolean companionIsHoplite;
    private int companionNextTargetTick;
    private float companionStride;
    private float companionPreviousStride;
    private float companionActivity;
    private float companionPreviousActivity;
        void draw(WorldRenderContext context, AbstractClientPlayer player,
                  CosmeticDefinition definition, CosmeticRenderData data) {
        Minecraft minecraft = Minecraft.getInstance();
        int seed = definition.id();
        updateCompanionFollower(player, seed, "HOPLITE_PET".equals(data.definition().indexType()));
        RemoteCosmetics.companionSpeed(player,companionMoveSpeed*20f);
        Camera camera = context.gameRenderer().getMainCamera();
        float partialTick = Mth.clamp(camera.getPartialTickTime(), 0.0F, 1.0F);
        double worldX = Mth.lerp(partialTick, companionPreviousX, companionX);
        double worldY = Mth.lerp(partialTick, companionPreviousY, companionY);
        double worldZ = Mth.lerp(partialTick, companionPreviousZ, companionZ);
        Vec3 cameraPosition = camera.position();
        float ticks = player.tickCount + partialTick;
        float stride = Mth.lerp(partialTick, companionPreviousStride, companionStride);
        float activity = Mth.lerp(partialTick, companionPreviousActivity, companionActivity);
        HoplitePetAnimation.Body body = companionIsHoplite
                ? HoplitePetAnimation.body(definition.logicalResource(), ticks, stride, activity) : null;
        float bob = body != null ? body.lift() : companionMoveSpeed > 0.008F
                ? (float) Math.sin(ticks * 0.62F + seed * 0.37F) * 0.018F : 0.0F;
        float ownerAngle = (float) Math.atan2(player.getX() - worldX, player.getZ() - worldZ);
        float lookYaw = -(float) Math.toRadians(Mth.clamp(
                Mth.wrapDegrees((float) Math.toDegrees(ownerAngle - companionYaw(partialTick))), -35f, 35f));

        PoseStack matrices = context.matrices();
        matrices.pushPose();
        matrices.translate(worldX - cameraPosition.x,
                worldY - cameraPosition.y + bob,
                worldZ - cameraPosition.z);
        matrices.mulPose(new Quaternionf().rotateY(
                companionYaw(partialTick) + (float) Math.PI));
        if (body != null) {
            matrices.mulPose(new Quaternionf().rotateX(body.pitch()).rotateZ(body.roll()));
            matrices.scale(1f + body.breath() * .35f, 1f + body.breath(), 1f + body.breath() * .35f);
        }
        matrices.scale(-1.0F, -1.0F, 1.0F);
        matrices.translate(0.0F, -PLAYER_FEET_Y, 0.0F);
        int light = LevelRenderer.getLightColor(minecraft.level,
                BlockPos.containing(worldX, worldY + 0.5, worldZ));
        render(data, matrices.last(), context.consumers().getBuffer(
                RenderTypes.entityCutoutNoCull(data.texture())), light, ticks, stride, activity, lookYaw);
        matrices.popPose();
    }

    private void updateCompanionFollower(AbstractClientPlayer player, int seed, boolean hoplite) {
        companionIsHoplite = hoplite;
        int tick = player.tickCount;
        if (companionOwnerId != player.getId()
                || companionWorld.get() != player.level()
                || companionDefinitionId != seed
                || companionLastTick == Integer.MIN_VALUE
                || tick < companionLastTick
                || tick - companionLastTick > 40) {
            resetCompanionFollower(player, seed, tick);
            return;
        }
        if (tick == companionLastTick) return;

        int steps = Math.min(4, tick - companionLastTick);
        for (int stepIndex = 0; stepIndex < steps; stepIndex++) {
            companionPreviousX = companionX;
            companionPreviousY = companionY;
            companionPreviousZ = companionZ;
            companionPreviousYaw = companionMoveYaw;
            companionPreviousStride = companionStride;
            companionPreviousActivity = companionActivity;
            int simulatedTick = companionLastTick + 1;
            chooseCompanionTarget(player, seed, simulatedTick);

            double toTargetX = companionTargetX - companionX;
            double toTargetZ = companionTargetZ - companionZ;
            double distance = Math.sqrt(toTargetX * toTargetX + toTargetZ * toTargetZ);
            double toPlayerX = player.getX() - companionX;
            double toPlayerZ = player.getZ() - companionZ;
            double playerDistance = Math.sqrt(toPlayerX * toPlayerX + toPlayerZ * toPlayerZ);
            if (playerDistance > 16.0) {
                resetCompanionFollower(player, seed, tick);
                return;
            }

            double playerSpeed = Math.hypot(player.getX() - player.xOld,
                    player.getZ() - player.zOld);
            double speed = 0.05 + Math.min(0.10, playerSpeed * 0.3);
            if (playerDistance > 7.0) speed = 0.40;
            else if (playerDistance > 4.5) speed = 0.28;
            else if (playerDistance > 2.5) speed = 0.18;
            if (companionIsHoplite) {
                // Ease into a short walk, then settle instead of endlessly orbiting.
                double wanted = Math.min(speed, Math.max(0.0, (distance - 0.12) * 0.18));
                if (distance < 0.16) wanted = 0.0;
                speed = companionMoveSpeed + (wanted - companionMoveSpeed) * (wanted > companionMoveSpeed ? .35 : .5);
                if (speed < .002) speed = 0.0;
            }
            double movement = Math.min(distance, speed);
            float desiredYaw = companionIsHoplite && distance < .2 ? companionMoveYaw
                    : (float) Math.atan2(toTargetX, toTargetZ);
            float turn = Mth.wrapDegrees((float) Math.toDegrees(desiredYaw - companionMoveYaw));
            float heading = companionMoveYaw + (float) Math.toRadians(
                    Mth.clamp(turn, -18.0F, 18.0F));
            double groundY = companionGroundY(player, companionX, companionZ, companionY);
            double nextX = companionX, nextZ = companionZ;
            float nextYaw = heading;
            boolean found = false;
            // Short local steering, not entity AI: try either side of a blocked path.
            for (float offset : new float[]{0, 0.45F, -0.45F, 0.9F, -0.9F}) {
                float direction = heading + offset;
                double x = companionX + Math.sin(direction) * movement;
                double z = companionZ + Math.cos(direction) * movement;
                double floor = companionGroundY(player, x, z, companionY);
                if (!Double.isFinite(floor) || floor - companionY > 1.05
                        || companionY - floor > 3.0) continue;
                if (!companionClear(player, x, Math.max(companionY, floor), z)) continue;
                nextX = x;
                nextZ = z;
                nextYaw = direction;
                groundY = floor;
                found = true;
                break;
            }
            double nextY = companionY;
            if (Double.isFinite(groundY)) {
                if (groundY > companionY + 0.03) {
                    // Rise before moving across a step face, instead of sliding through it.
                    companionVelocityY = Math.min(0.30, Math.max(0.18, companionVelocityY + 0.06));
                    nextY = Math.min(groundY, companionY + companionVelocityY);
                } else if (groundY < companionY - 0.03) {
                    companionVelocityY = Math.max(-0.65, Math.min(0.0, companionVelocityY) - 0.055);
                    nextY = Math.max(groundY, companionY + companionVelocityY);
                } else {
                    nextY = groundY;
                    companionVelocityY = 0.0;
                }
            }
            if (found && companionClear(player, nextX, nextY, nextZ)) {
                companionX = nextX;
                companionZ = nextZ;
                companionY = nextY;
                companionMoveYaw = nextYaw;
            } else {
                movement = 0.0;
                // A blocked upward step can still lift the companion on the near side.
                if (companionClear(player, companionX, nextY, companionZ)) companionY = nextY;
                companionMoveYaw = heading;
            }
            // Use actual travel: a blocked pet must not keep walking in place.
            companionMoveSpeed = (float) Math.hypot(companionX - companionPreviousX,
                    companionZ - companionPreviousZ);
            companionStride += companionMoveSpeed * 8.0F;
            float targetActivity = Mth.clamp(companionMoveSpeed / .12F, 0.0F, 1.0F);
            companionActivity += (targetActivity - companionActivity) * .3F;

            companionLastTick = simulatedTick;
        }
        companionLastTick = tick;
    }

    private void resetCompanionFollower(AbstractClientPlayer player, int seed, int tick) {
        companionOwnerId = player.getId();
        companionWorld = new java.lang.ref.WeakReference<>(player.level());
        companionDefinitionId = seed;
        companionLastTick = tick;
        double yaw = Math.toRadians(player.getYRot());
        double rightX = Math.cos(yaw);
        double rightZ = Math.sin(yaw);
        companionX = player.getX() + rightX * 1.35;
        companionZ = player.getZ() + rightZ * 1.35;
        companionY = companionGroundY(player, companionX, companionZ, player.getY());
        if (!Double.isFinite(companionY)) companionY = player.getY();
        companionPreviousX = companionX;
        companionPreviousY = companionY;
        companionPreviousZ = companionZ;
        companionMoveYaw = (float) (yaw + Math.PI);
        companionPreviousYaw = companionMoveYaw;
        companionMoveSpeed = 0.0F;
        companionVelocityY = 0.0;
        companionStride = companionPreviousStride = 0.0F;
        companionActivity = companionPreviousActivity = 0.0F;
        companionTargetX = companionX;
        companionTargetZ = companionZ;
        companionNextTargetTick = tick + 35;

        chooseCompanionTarget(player, seed, tick);
    }

    private void chooseCompanionTarget(AbstractClientPlayer player, int seed, int tick) {
        if (companionIsHoplite) {
            double distance = Math.hypot(companionX - player.getX(), companionZ - player.getZ());
            double speed = Math.hypot(player.getX() - player.xOld, player.getZ() - player.zOld);
            if (speed > .025 || distance > 2.8) {
                double yaw = Math.toRadians(player.getYRot());
                companionTargetX = player.getX() + Math.sin(yaw) * 1.5 + Math.cos(yaw) * .85;
                companionTargetZ = player.getZ() - Math.cos(yaw) * 1.5 + Math.sin(yaw) * .85;
                companionNextTargetTick = tick + 65;
            } else if (tick >= companionNextTargetTick) {
                int segment = tick / 80;
                double angle = Math.atan2(companionZ - player.getZ(), companionX - player.getX())
                        + companionRandom(seed, segment, 0) * .75;
                double radius = 1.35 + (companionRandom(seed, segment, 1) + 1.0) * .3;
                companionTargetX = player.getX() + Math.cos(angle) * radius;
                companionTargetZ = player.getZ() + Math.sin(angle) * radius;
                companionNextTargetTick = tick + 90 + Math.floorMod(seed + segment * 37, 70);
            }
            return;
        }
        // Advance around the player's current position, rather than drawing straight
        // chords between random points anchored to where the player used to stand.
        double angle = Math.atan2(companionZ - player.getZ(), companionX - player.getX());
        double direction = (seed & 1) == 0 ? 1.0 : -1.0;
        double lead = angle + direction * 0.60;
        double radius = 1.75 + Math.sin(tick * 0.025 + seed) * 0.15;
        companionTargetX = player.getX() + Math.cos(lead) * radius;
        companionTargetZ = player.getZ() + Math.sin(lead) * radius;
    }

    private boolean companionClear(AbstractClientPlayer player, double x, double y, double z) {
        return player.level().noCollision(new AABB(
                x - 0.20, y + 0.015, z - 0.20, x + 0.20, y + 0.78, z + 0.20));
    }

    private float companionYaw(float partialTick) {
        float delta = Mth.wrapDegrees((float) Math.toDegrees(companionMoveYaw - companionPreviousYaw));
        return companionPreviousYaw + (float) Math.toRadians(delta) * partialTick;
    }

    private double companionGroundY(AbstractClientPlayer player, double x, double z, double referenceY) {
        // Local collision surfaces include slabs/stairs and floors below roofs.
        // A heightmap reports the roof/topmost block and cannot represent those.
        double best = Double.NEGATIVE_INFINITY;
        for (int bx = Mth.floor(x - 0.20); bx <= Mth.floor(x + 0.20); bx++) {
        for (int bz = Mth.floor(z - 0.20); bz <= Mth.floor(z + 0.20); bz++) {
        for (int y = Mth.floor(referenceY + 1.05); y >= Mth.floor(referenceY - 4.0); y--) {
            BlockPos pos = new BlockPos(bx, y, bz);
            if (!player.level().hasChunkAt(pos)) continue;
            for (AABB box : player.level().getBlockState(pos)
                    .getCollisionShape(player.level(), pos).toAabbs()) {
                double top = y + box.maxY;
                if (x + 0.20 > bx + box.minX && x - 0.20 < bx + box.maxX
                        && z + 0.20 > bz + box.minZ && z - 0.20 < bz + box.maxZ
                        && top <= referenceY + 1.05 && top > best
                        && companionClear(player, x, top, z)) best = top;
            }
        }
        }
        }
        return best == Double.NEGATIVE_INFINITY ? Double.NaN : best;
    }

    }

    private static List<CosmeticDefinition> equippedFor(AvatarRenderState state) {
        List<CosmeticDefinition> preview = PREVIEW_OUTFITS.get(state);
        if(preview!=null)return preview;
        if(isLocalAvatar(state))return CosmeticConfig.equipped();
        var view=RemoteCosmetics.view(state);
        return view==null?List.of():view.peer().definitions();
    }

    private static CosmeticRenderData dataFor(AvatarRenderState state,CosmeticDefinition definition){
        if(isLocalAvatar(state))return CosmeticAssetManager.get(definition);
        var view=RemoteCosmetics.view(state);
        return view==null?null:CosmeticAssetManager.remoteData(view.player().getUUID(),definition);
    }

    private static void applyAttachment(PlayerModel model, AvatarRenderState state,
                                        CosmeticRenderData data,
                                        PoseStack matrices, boolean preview) {
        CosmeticAttachment attachment = data.attachment();
        if (data.definition().gek()) {
            switch (attachment) {
                case LEFT_SHOULDER -> {
                    float bob = (float) Math.sin(state.ageInTicks * 0.08F) * 0.006F;
                    matrices.translate(0.0F, bob, 0.0F);
                }
                case COMPANION -> {
                    applyCompanionMotion(state, data, matrices, preview);
                }
                default -> {
                    // GEK bones are authored in the complete Lunar biped space.
                    // Applying a vanilla body-part transform here would offset the
                    // already absolute head/body/leg pivots a second time.
                }
            }
            return;
        }
        switch (attachment) {
            case HEAD -> model.head.translateAndRotate(matrices);
            case BODY, BACK -> model.body.translateAndRotate(matrices);
            case HAND -> model.rightArm.translateAndRotate(matrices);
            case LEFT_SHOULDER -> {
                model.body.translateAndRotate(matrices);
                float bob = (float) Math.sin(state.ageInTicks * 0.08F) * 0.025F;
                matrices.translate(-0.72F, -0.50F + bob, 0.02F);
                matrices.mulPose(new Quaternionf().rotateY((float) Math.toRadians(-18)));
            }
            case COMPANION -> {
                applyCompanionMotion(state, data, matrices, preview);
            }
            case FEET, WINGS, AURA, FULL_BODY, CAPE -> {
            }
        }
    }

    private static void applyCompanionMotion(AvatarRenderState state,
                                             CosmeticRenderData data,
                                             PoseStack matrices,
                                             boolean preview) {
        int seed = data.definition().id();
        if (preview) {
            float ticks = state.ageInTicks;
            float x = 0.82F + companionCoordinate(ticks, seed, 0) * 0.10F;
            float z = 0.34F + companionCoordinate(ticks, seed, 1) * 0.08F;
            float bob = (float) Math.sin(ticks * 0.10F + seed * 0.37F) * 0.018F;
            matrices.translate(x, bob, z);
            matrices.mulPose(new Quaternionf().rotateY((float) Math.toRadians(-25)));
            return;
        }

    }

    private static float companionCoordinate(float ticks, int seed, int axis) {
        float phase = ticks / 64.0F;
        int segment = (int) Math.floor(phase);
        float progress = phase - segment;
        progress = progress * progress * (3.0F - 2.0F * progress);
        float from = companionRandom(seed, segment, axis);
        float to = companionRandom(seed, segment + 1, axis);
        return lerp(from, to, progress);
    }

    private static float companionRandom(int seed, int segment, int axis) {
        int value = seed * 0x45D9F3B + segment * 0x27D4EB2D
                + axis * 0x165667B1;
        value ^= value >>> 16;
        value *= 0x7FEB352D;
        value ^= value >>> 15;
        value *= 0x846CA68B;
        value ^= value >>> 16;
        return ((value >>> 8) & 0x00FFFFFF) / 8388607.5F - 1.0F;
    }

    private static void render(CosmeticRenderData data, PoseStack.Pose pose,
                               VertexConsumer consumer, int light) {
        float ticks = (System.nanoTime() - PET_PREVIEW_START) / 50_000_000.0F;
        render(data, pose, consumer, light, ticks, 0f, 0f, 0f);
    }

    private static void render(CosmeticRenderData data, PoseStack.Pose pose,
                               VertexConsumer consumer, int light, float ticks,
                               float stride, float activity, float lookYaw) {
        render(data,pose,consumer,light,ticks,stride,activity,lookYaw,null);
    }
    private static void render(CosmeticRenderData data, PoseStack.Pose pose,
                               VertexConsumer consumer, int light, float ticks,
                               float stride,float activity,float lookYaw,CosmeticMesh wingMesh) {
        boolean legacyWings = data.definition().category()
                == CosmeticCategory.DRAGON_WINGS && !data.definition().gek();
        CosmeticMesh mesh = legacyWings && wingMesh!=null ? wingMesh : data.mesh();
        CosmeticMesh previousMesh = data.previousMesh();
        float progress = data.meshProgress();
        if (legacyWings) {
            previousMesh = mesh;
            progress = 1.0F;
        }
        CosmeticVertex[] vertices = mesh.rawVertices();
        CosmeticVertex[] previousVertices = previousMesh == null
                ? vertices : previousMesh.rawVertices();
        boolean interpolate = progress < 1.0F
                && previousVertices.length == vertices.length;
        if (!interpolate) {
            previousMesh = mesh;
            previousVertices = vertices;
            progress = 1.0F;
        }
        boolean gek = data.definition().gek();
        float scale = 1.0F;
        float centerX = 0;
        float centerZ = 0;
        float anchorY = 0;
        boolean normalize = false;
        float minY = lerp(previousMesh.minY(), mesh.minY(), progress);
        float maxY = lerp(previousMesh.maxY(), mesh.maxY(), progress);
        if (data.attachment() == CosmeticAttachment.COMPANION) {
            float height = Math.max(0.001F, maxY - minY);
            scale = "HOPLITE_PET".equals(data.definition().indexType())
                    ? 0.86F / height : Math.min(1.0F, COMPANION_HEIGHT / height);
            centerX = lerp(previousMesh.centerX(), mesh.centerX(), progress);
            centerZ = lerp(previousMesh.centerZ(), mesh.centerZ(), progress);
            // This render hook still uses the biped model origin (upper body),
            // while companion geometry is authored with its feet at Y = 0.
            // Move that foot plane to the same Y as the vanilla player's feet.
            anchorY = PLAYER_FEET_Y;
            normalize = true;
        }
        HoplitePetAnimation.Pose petPose = "HOPLITE_PET".equals(data.definition().indexType())
                ? HoplitePetAnimation.pose(mesh, ticks, stride, activity, lookYaw) : null;
        Vector3f petPosition = petPose == null ? null : new Vector3f();
        Vector3f petNormal = petPose == null ? null : new Vector3f();
        for (int index = 0; index < vertices.length; index++) {
            CosmeticVertex vertex = vertices[index];
            CosmeticVertex previous = previousVertices[index];
            float vertexX = lerp(previous.x(), vertex.x(), progress);
            float vertexY = lerp(previous.y(), vertex.y(), progress);
            float vertexZ = lerp(previous.z(), vertex.z(), progress);
            float nx = lerp(previous.nx(), vertex.nx(), progress);
            float ny = lerp(previous.ny(), vertex.ny(), progress);
            float nz = lerp(previous.nz(), vertex.nz(), progress);
            if (interpolate) {
                float lengthSquared = nx * nx + ny * ny + nz * nz;
                if (lengthSquared > 1.0E-8F) {
                    float inverseLength = (float) (1.0 / Math.sqrt(lengthSquared));
                    nx *= inverseLength; ny *= inverseLength; nz *= inverseLength;
                } else { nx = vertex.nx(); ny = vertex.ny(); nz = vertex.nz(); }
            }
            if (petPose != null) {
                petPosition.set(vertexX, vertexY, vertexZ);
                petNormal.set(nx, ny, nz);
                petPose.transform(index, petPosition, petNormal);
                vertexX = petPosition.x; vertexY = petPosition.y; vertexZ = petPosition.z;
                nx = petNormal.x; ny = petNormal.y; nz = petNormal.z;
            }
            float x;
            float y;
            float z;
            if (normalize) {
                x = (vertexX - centerX) * scale;
                y = anchorY + (vertexY - maxY) * scale;
                z = (vertexZ - centerZ) * scale;
            } else if (gek) {
                x = vertexX;
                y = vertexY + PLAYER_FEET_Y;
                z = vertexZ;
            } else {
                x = vertexX;
                y = vertexY;
                z = vertexZ;
            }
            // Lighting follows the interpolated pose instead of snapping to the
            // next animation sample while positions are still transitioning.
            consumer.addVertex(pose, x, y, z)
                    .setColor(-1)
                    .setUv(vertex.u(), vertex.v())
                    .setOverlay(OverlayTexture.NO_OVERLAY)
                    .setLight(light)
                    .setNormal(pose, nx, ny, nz);
        }
    }

    private static float lerp(float from, float to, float progress) {
        return from + (to - from) * progress;
    }

    private static boolean isLocalAvatar(AvatarRenderState state) {
        if (PREVIEW_OUTFITS.containsKey(state)) return true;
        Minecraft minecraft = Minecraft.getInstance();
        return minecraft.player != null && state.id == minecraft.player.getId();
    }
}
