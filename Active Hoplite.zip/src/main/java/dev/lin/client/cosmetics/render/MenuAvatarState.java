package dev.lin.client.cosmetics.render;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.entity.state.AvatarRenderState;
import net.minecraft.client.resources.DefaultPlayerSkin;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.player.PlayerSkin;
import java.util.function.Supplier;
/** World-independent render state shared by the locker and start menu. No fake client world. */
public final class MenuAvatarState {
 private static Supplier<PlayerSkin> lookup; private static String profile="";
 private MenuAvatarState(){}
 /** ItemModelResolver.updateForLiving requires a real entity, absent on the title screen. */
 public static void resolveItem(net.minecraft.client.renderer.item.ItemStackRenderState state,
                                net.minecraft.world.item.ItemStack stack,
                                net.minecraft.world.item.ItemDisplayContext context,
                                net.minecraft.world.entity.LivingEntity entity, int previewId) {
  var resolver = Minecraft.getInstance().getItemModelResolver();
  if (entity != null) resolver.updateForLiving(state, stack, context, entity);
  else resolver.updateForTopItem(state, stack, context, null, null, previewId + context.ordinal());
 }
 public static PlayerSkin skin(){
  var mc=Minecraft.getInstance();String current=mc.getGameProfile().toString();
  if(lookup==null||!profile.equals(current)){profile=current;lookup=mc.getSkinManager().createLookup(mc.getGameProfile(),false);}
  var skin=lookup.get();return skin==null?DefaultPlayerSkin.get(mc.getGameProfile()):skin;
 }
 public static AvatarRenderState create(){
  var s=new AvatarRenderState();s.skin=skin();s.entityType=EntityType.PLAYER;
  s.boundingBoxWidth=.6f;s.boundingBoxHeight=1.8f;s.eyeHeight=1.62f;s.id=Integer.MIN_VALUE+1207;
  s.ageInTicks=(System.nanoTime()%120_000_000_000L)/50_000_000f;s.lightCoords=15728880;
  s.mainArm=HumanoidArm.RIGHT;s.showHat=s.showJacket=s.showLeftPants=s.showRightPants=s.showLeftSleeve=s.showRightSleeve=s.showCape=true;
  return s;
 }
}
