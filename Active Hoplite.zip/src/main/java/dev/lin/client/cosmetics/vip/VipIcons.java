package dev.lin.client.cosmetics.vip;

import dev.lin.client.cosmetics.config.CosmeticConfig;
import dev.lin.client.features.artifact.HopliteServerContext;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.TreeMap;
import java.util.UUID;
import java.util.regex.Pattern;
import net.minecraft.network.chat.FontDescription;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;
import net.minecraft.network.chat.contents.TranslatableContents;
import net.minecraft.world.scores.Objective;
import net.minecraft.world.scores.PlayerTeam;
import net.minecraft.world.scores.Scoreboard;
import net.minecraft.world.scores.Team;
import net.minecraft.resources.Identifier;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.network.chat.ComponentContents;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.scores.DisplaySlot;
import net.minecraft.network.chat.contents.PlainTextContents;
import net.minecraft.world.scores.PlayerScoreEntry;

public final class VipIcons {
    private static final FontDescription FONT = new FontDescription.Resource(Identifier.fromNamespaceAndPath((String)"lin_client", (String)"vip"));
    public static final Icon NONE = new Icon("none", "\u4e0d\u663e\u793a", -1);
    public static final List<Icon> ALL;
    private static Object lobbyLevel;
    private static int lobbyTick;
    private static boolean lobby;

    public static Icon selected() {
        String id = CosmeticConfig.vipIcon();
        return byId(id);
    }

    public static Component decorate(Component original, UUID owner) {
        return decorate(original, owner, false);
    }

    public static Component decorateChat(Component original, UUID owner) {
        return decorate(original, owner, true);
    }

    private static Component decorate(Component original, UUID owner, boolean chat) {
        LocalPlayer player = Minecraft.getInstance().player;
        if (original == null || player == null || owner==null) return original;
        Icon icon=selected();String name=player.getGameProfile().name();boolean lobbyOnly=CosmeticConfig.vipLobbyOnly();
        if(!player.getUUID().equals(owner)){
            var peer=dev.lin.client.cosmetics.sync.CosmeticSyncBridge.remote(owner);
            if(peer==null)return original;
            var appearance=peer.outfit().appearance();
            icon=byId(appearance.vipIcon());lobbyOnly=appearance.vipLobbyOnly();
            var info=Minecraft.getInstance().getConnection()==null?null:Minecraft.getInstance().getConnection().getPlayerInfo(owner);
            if(info!=null){
                name=info.getProfile().name();
            }else{
                var lvl=Minecraft.getInstance().level;
                var remotePlayer=lvl==null?null:lvl.getPlayerByUUID(owner);
                if(remotePlayer==null)return original;
                name=remotePlayer.getGameProfile().name();
            }
        }
        if(icon==NONE || (lobbyOnly && !HopliteServerContext.isLobbyWithoutTabHealth())){
            return original;
        }
        Component colored = VipIcons.colorName(original, name, icon.id());
        if (original.visit((style, text) -> FONT.equals((Object)style.getFont()) ? Optional.of(true) : Optional.empty(), Style.EMPTY).isPresent()) {
            return colored;
        }
        var glyph=icon.component().copy();glyph.setStyle(glyph.getStyle().withInsertion("lin-vip:"+owner));
        return Component.empty().append(glyph).append(" ").append(colored);
    }

    private static final class Index {static final Map<String,Icon> VALUES=ALL.stream().collect(java.util.stream.Collectors.toUnmodifiableMap(Icon::id,icon->icon));}
    public static Icon byId(String id){return id==null?NONE:Index.VALUES.getOrDefault(id,NONE);}

    public static boolean visible() {
        return !CosmeticConfig.vipLobbyOnly() || HopliteServerContext.isLobbyWithoutTabHealth();
    }

    static boolean lobbyText(List<String> rows) {
        String text = String.join((CharSequence)"\n", rows).replaceAll("(?i)\u00a7[0-9a-fk-orx]", "").toLowerCase(Locale.ROOT);
        if (Pattern.compile("pvp\\s*(enabled|in)|border\\s*(shrinking|in)|deathmatch|game\\s*time|\u5269\u4f59\u73a9\u5bb6|\u6e38\u620f\u65f6\u95f4|\u5bf9\u5c40\u8fdb\u884c").matcher(text).find()) {
            return false;
        }
        return Pattern.compile("\\blobby\\b|\\bhub\\b|waiting for players|starting in|\u5927\u5385|\u7b49\u5f85\u73a9\u5bb6|\u5373\u5c06\u5f00\u59cb").matcher(text).find();
    }

    public static FormattedCharSequence filterChat(FormattedCharSequence text) {
        if (text.accept((index, style, cp) -> !FONT.equals((Object)style.getFont()))) {
            return text;
        }
        return sink -> {
            boolean[] gap = new boolean[]{false};
            return text.accept((index, style, cp) -> {
                if (FONT.equals((Object)style.getFont()) && !chatIconVisible(style)) {
                    gap[0] = true;
                    return true;
                }
                if (gap[0]) {
                    gap[0] = false;
                    if (cp == 32) {
                        return true;
                    }
                }
                return sink.accept(index, style, cp);
            });
        };
    }

    private static boolean chatIconVisible(Style style){
        String marker=style.getInsertion();
        if(marker==null || !marker.startsWith("lin-vip:"))return visible();
        try{
            UUID id=UUID.fromString(marker.substring(8));
            var player=Minecraft.getInstance().player;
            if(player!=null && player.getUUID().equals(id))return selected()!=NONE && visible();
            var peer=dev.lin.client.cosmetics.sync.CosmeticSyncBridge.remote(id);
            return peer!=null && byId(peer.outfit().appearance().vipIcon())!=NONE
                && (!peer.outfit().appearance().vipLobbyOnly() || HopliteServerContext.isLobbyWithoutTabHealth());
        }catch(IllegalArgumentException ignored){return false;}
    }

    static int[] palette(String id) {
        int[] nArray;
        switch (id.replace("plus/", "")) {
            case "roles/owner": 
            case "roles/admin": 
            case "roles/youtube": {
                int[] nArray2 = new int[1];
                nArray = nArray2;
                nArray2[0] = 0xFF5555;
                break;
            }
            case "roles/mod": 
            case "roles/helper": {
                int[] nArray3 = new int[1];
                nArray = nArray3;
                nArray3[0] = 0x55FF55;
                break;
            }
            case "roles/production": 
            case "roles/partner": 
            case "roles/media": 
            case "roles/twitch": {
                int[] nArray4 = new int[1];
                nArray = nArray4;
                nArray4[0] = 0xAA77FF;
                break;
            }
            case "roles/tester": {
                int[] nArray5 = new int[1];
                nArray = nArray5;
                nArray5[0] = 0x55FFFF;
                break;
            }
            case "roles/bot": 
            case "roles/minion": {
                int[] nArray6 = new int[1];
                nArray = nArray6;
                nArray6[0] = 0xAAAAAA;
                break;
            }
            case "aqua": {
                int[] nArray7 = new int[1];
                nArray = nArray7;
                nArray7[0] = 0x55FFFF;
                break;
            }
            case "black": {
                int[] nArray8 = new int[1];
                nArray = nArray8;
                nArray8[0] = 0x555555;
                break;
            }
            case "blue_green_yellow": {
                int[] nArray9 = new int[3];
                nArray9[0] = 0x5599FF;
                nArray9[1] = 0x55FF55;
                nArray = nArray9;
                nArray9[2] = 0xFFFF55;
                break;
            }
            case "cyan": {
                int[] nArray10 = new int[1];
                nArray = nArray10;
                nArray10[0] = 43690;
                break;
            }
            case "dark_green": {
                int[] nArray11 = new int[1];
                nArray = nArray11;
                nArray11[0] = 43520;
                break;
            }
            case "dark_purple": {
                int[] nArray12 = new int[1];
                nArray = nArray12;
                nArray12[0] = 0xAA00AA;
                break;
            }
            case "dark_red": {
                int[] nArray13 = new int[1];
                nArray = nArray13;
                nArray13[0] = 0xAA0000;
                break;
            }
            case "gray": {
                int[] nArray14 = new int[1];
                nArray = nArray14;
                nArray14[0] = 0xAAAAAA;
                break;
            }
            case "green_to_blue": {
                int[] nArray15 = new int[2];
                nArray15[0] = 0x55FF55;
                nArray = nArray15;
                nArray15[1] = 0x5599FF;
                break;
            }
            case "green_to_yellow": {
                int[] nArray16 = new int[2];
                nArray16[0] = 0x55FF55;
                nArray = nArray16;
                nArray16[1] = 0xFFFF55;
                break;
            }
            case "light_red": {
                int[] nArray17 = new int[1];
                nArray = nArray17;
                nArray17[0] = 0xFF5555;
                break;
            }
            case "lime_green": {
                int[] nArray18 = new int[1];
                nArray = nArray18;
                nArray18[0] = 0x55FF55;
                break;
            }
            case "orange_purple": {
                int[] nArray19 = new int[2];
                nArray19[0] = 0xFFAA00;
                nArray = nArray19;
                nArray19[1] = 0xAA55FF;
                break;
            }
            case "pink": {
                int[] nArray20 = new int[1];
                nArray = nArray20;
                nArray20[0] = 0xFF55FF;
                break;
            }
            case "purple": {
                int[] nArray21 = new int[1];
                nArray = nArray21;
                nArray21[0] = 0xAA77FF;
                break;
            }
            case "rainbow": {
                int[] nArray22 = new int[7];
                nArray22[0] = 0xFF5555;
                nArray22[1] = 0xFFAA00;
                nArray22[2] = 0xFFFF55;
                nArray22[3] = 0x55FF55;
                nArray22[4] = 0x55FFFF;
                nArray22[5] = 0xAA77FF;
                nArray = nArray22;
                nArray22[6] = 0xFF55FF;
                break;
            }
            case "sunset": {
                int[] nArray23 = new int[3];
                nArray23[0] = 0xFFAA55;
                nArray23[1] = 0xFF5588;
                nArray = nArray23;
                nArray23[2] = 0xAA55FF;
                break;
            }
            default: {
                int[] nArray24 = new int[1];
                nArray = nArray24;
                nArray24[0] = 0xFFAA00;
            }
        }
        return nArray;
    }

    static int nameColor(String id, int index, int length) {
        int[] colors = VipIcons.palette(id);
        float position = Math.max(0.0f, Math.min(1.0f, (float)index / (float)Math.max(1, length - 1))) * (float)(colors.length - 1);
        int low = (int)position;
        int high = Math.min(low + 1, colors.length - 1);
        float fraction = position - (float)low;
        int color = 0;
        for (int shift : new int[]{16, 8, 0}) {
            int a = colors[low] >> shift & 0xFF;
            int b = colors[high] >> shift & 0xFF;
            color |= Math.round((float)a + (float)(b - a) * fraction) << shift;
        }
        return color;
    }

    static Component colorName(Component original, String name, String id) {
        if (name.isEmpty() || id.equals("none")) {
            return original;
        }
        String text = original.getString();
        int start = text.indexOf(name);
        if (start < 0) {
            return original;
        }
        int end = start + name.length();
        if (start > 0 && VipIcons.usernameChar(text.charAt(start - 1)) || end < text.length() && VipIcons.usernameChar(text.charAt(end))) {
            return original;
        }
        return VipIcons.recolor(original, new int[]{0}, start, end, id, name);
    }

    private static boolean usernameChar(char c) {
        return Character.isLetterOrDigit(c) || c == '_';
    }

    private static Component recolor(Component source, int[] cursor, int start, int end, String id, String name) {
        MutableComponent result;
        ComponentContents contents = source.getContents();
        if (contents instanceof PlainTextContents) {
            int last;
            PlainTextContents literal = (PlainTextContents)contents;
            String text = literal.text();
            int offset = cursor[0];
            result = Component.empty().setStyle(source.getStyle());
            int first = Math.max(0, start - offset);
            if (first < (last = Math.min(text.length(), end - offset))) {
                if (first > 0) {
                    result.append((Component)Component.literal((String)text.substring(0, first)));
                }
                for (int i = first; i < last; ++i) {
                    result.append((Component)Component.literal((String)text.substring(i, i + 1)).setStyle(Style.EMPTY.withColor(VipIcons.nameColor(id, offset + i - start, end - start))));
                }
                if (last < text.length()) {
                    result.append((Component)Component.literal((String)text.substring(last)));
                }
            } else if (!text.isEmpty()) {
                result.append((Component)Component.literal((String)text));
            }
            cursor[0] = cursor[0] + text.length();
        } else if (contents instanceof TranslatableContents) {
            TranslatableContents translated = (TranslatableContents)contents;
            Object[] args = (Object[])translated.getArgs().clone();
            boolean changed = false;
            for (int i = 0; i < args.length; ++i) {
                Component argument;
                Object object = args[i];
                if (object instanceof Component) {
                    Component c;
                    argument = c = (Component)object;
                } else {
                    object = args[i];
                    if (object instanceof String) {
                        String s = (String)object;
                        argument = Component.literal((String)s);
                    } else {
                        argument = null;
                    }
                }
                if (cursor[0] > start || start >= cursor[0] + source.plainCopy().getString().length() || changed || argument == null || !argument.getString().contains(name)) continue;
                args[i] = VipIcons.colorName(argument, name, id);
                changed = args[i] != argument;
            }
            result = MutableComponent.create((ComponentContents)new TranslatableContents(translated.getKey(), translated.getFallback(), args)).setStyle(source.getStyle());
            cursor[0] = cursor[0] + source.plainCopy().getString().length();
        } else {
            result = source.plainCopy();
            cursor[0] = cursor[0] + result.getString().length();
        }
        for (Component sibling : source.getSiblings()) {
            result.append(VipIcons.recolor(sibling, cursor, start, end, id, name));
        }
        return result;
    }

    public static Component detectedChat(Component original) {
        LocalPlayer player = Minecraft.getInstance().player;
        if (player == null || original == null) {
            return original;
        }
        String name = player.getGameProfile().name();
        if(VipIcons.isSender(original.getString(), name))return VipIcons.decorateChat(original, player.getUUID());
        var connection=Minecraft.getInstance().getConnection();
        if(connection!=null)for(var info:connection.getOnlinePlayers()){
            if(dev.lin.client.cosmetics.sync.CosmeticSyncBridge.remote(info.getProfile().id())!=null
                    && VipIcons.isSender(original.getString(),info.getProfile().name()))return decorateChat(original,info.getProfile().id());
        }
        return original;
    }

    static boolean isSender(String text, String name) {
        int i = text.indexOf(name);
        if (i < 0 || i > 64 || i > 0 && (Character.isLetterOrDigit(text.charAt(i - 1)) || text.charAt(i - 1) == '_')) {
            return false;
        }
        String prefix = text.substring(0, i);
        if (prefix.indexOf(58) >= 0 || prefix.indexOf(65306) >= 0 || prefix.indexOf(187) >= 0 || prefix.indexOf(62) >= 0) {
            return false;
        }
        String tail = text.substring(i + name.length()).stripLeading();
        return tail.startsWith(":") || tail.startsWith("\uff1a") || tail.startsWith(">") || tail.startsWith("\u00bb") || tail.startsWith("\u226b");
    }

    static {
        String[] colors = new String[]{"aqua", "base", "black", "blue_green_yellow", "cyan", "dark_green", "dark_purple", "dark_red", "gray", "green_to_blue", "green_to_yellow", "light_red", "lime_green", "orange_purple", "pink", "purple", "rainbow", "sunset"};
        String[] labels = new String[]{"\u6c34\u84dd", "\u7ecf\u5178", "\u9ed1\u8272", "\u84dd\u7eff\u9ec4", "\u9752\u8272", "\u6df1\u7eff", "\u6df1\u7d2b", "\u6df1\u7ea2", "\u7070\u8272", "\u7eff\u84dd\u6e10\u53d8", "\u7eff\u9ec4\u6e10\u53d8", "\u6d45\u7ea2", "\u9752\u67e0", "\u6a59\u7d2b\u6e10\u53d8", "\u7c89\u8272", "\u7d2b\u8272", "\u5f69\u8679", "\u65e5\u843d"};
        TreeMap<String, String> names = new TreeMap<>();
        for (int i = 0; i < colors.length; ++i) {
            names.put(colors[i], "VIP \u00b7 " + labels[i]);
            names.put("plus/" + colors[i], "VIP+ \u00b7 " + labels[i]);
        }
        ArrayList<Icon> result = new ArrayList<Icon>();
        result.add(NONE);
        int glyph = 57344;
        for (Map.Entry<String, String> entry : names.entrySet()) {
            result.add(new Icon(entry.getKey(), entry.getValue(), glyph++));
        }
        String[] roles = new String[]{"owner", "admin", "mod", "helper", "production", "tester", "partner", "media", "minion", "youtube", "twitch", "bot"};
        String[] roleLabels = new String[]{"Owner \u00b7 \u670d\u4e3b", "Admin \u00b7 \u7ba1\u7406\u5458", "Mod \u00b7 \u7ba1\u7406\u5458", "Helper \u00b7 \u52a9\u624b", "Production \u00b7 \u5236\u4f5c\u7ec4", "Tester \u00b7 \u6d4b\u8bd5\u5458", "Partner \u00b7 \u5408\u4f5c\u4f19\u4f34", "Media \u00b7 \u5a92\u4f53", "Minion", "YouTube \u00b7 YouTuber", "Twitch \u00b7 \u4e3b\u64ad", "Bot \u00b7 \u673a\u5668\u4eba"};
        for (int i = 0; i < roles.length; ++i) {
            result.add(new Icon("roles/" + roles[i], roleLabels[i], glyph++));
        }
        ALL = List.copyOf(result);
        lobbyTick = Integer.MIN_VALUE;
    }

    public record Icon(String id, String label, int glyph) {
        public Component component() {
            return this.glyph < 0 ? Component.empty() : Component.literal((String)String.valueOf((char)this.glyph)).setStyle(Style.EMPTY.withFont(FONT).withColor(0xFFFFFF).withBold(Boolean.valueOf(false)).withItalic(Boolean.valueOf(false)).withObfuscated(Boolean.valueOf(false)).withUnderlined(Boolean.valueOf(false)).withStrikethrough(Boolean.valueOf(false)));
        }
    }
}
