package dev.lin.client.cosmetics.ui;

import com.google.gson.JsonParser;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.core.component.DataComponents;
import net.minecraft.resources.Identifier;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/** Resource-backed previews: model parts are never mistaken for animation frames. */
public final class KillEffectPreview {
    private static final KillEffectPreview[] VALUES = load();
    public static final KillEffectPreview BOMB = VALUES[0];
    public final String id, label, kind;
    private final ItemStack[] frames;
    private final boolean sequence;
    private int part;

    private KillEffectPreview(com.google.gson.JsonObject json) {
        id = json.get("id").getAsString();
        label = json.get("label").getAsString();
        kind = json.get("kind").getAsString();
        sequence = json.get("sequence").getAsBoolean();
        var paths = json.getAsJsonArray("frames");
        frames = new ItemStack[paths.size()];
        for (int i = 0; i < frames.length; i++) {
            frames[i] = new ItemStack(Items.PAPER);
            frames[i].set(DataComponents.ITEM_MODEL,
                    Identifier.fromNamespaceAndPath("lin_kill_effects", paths.get(i).getAsString()));
        }
    }

    private static KillEffectPreview[] load() {
        try (var input = KillEffectPreview.class.getResourceAsStream("/assets/lin_kill_effects/catalog.json")) {
            if (input == null) throw new IllegalStateException("Kill-effect catalog missing");
            var entries = JsonParser.parseReader(new InputStreamReader(input, StandardCharsets.UTF_8)).getAsJsonArray();
            var result = new ArrayList<KillEffectPreview>();
            for (var entry : entries) result.add(new KillEffectPreview(entry.getAsJsonObject()));
            if (result.isEmpty()) throw new IllegalStateException("Empty kill-effect catalog");
            return result.toArray(KillEffectPreview[]::new);
        } catch (java.io.IOException exception) {
            throw new IllegalStateException("Cannot read kill-effect catalog", exception);
        }
    }

    public static KillEffectPreview[] values() { return VALUES.clone(); }
    public void nextPart() { if (!sequence) part = (part + 1) % frames.length; }
    public String actionLabel() { return sequence ? "重新播放预览" : "切换部件 " + (part + 1) + "/" + frames.length; }

    public void render(GuiGraphics graphics, int x, int y, int size, long start) {
        int frame = part;
        if (sequence) {
            long elapsed = Math.max(0, (System.nanoTime() - start) / 1_000_000L);
            frame = (int)((elapsed % (frames.length * 100L + 600L)) / 100L);
            if (frame >= frames.length) return;
        }
        graphics.enableScissor(x, y, x + size, y + size);
        graphics.pose().pushMatrix();
        try {
            graphics.pose().translate(x, y);
            graphics.pose().scale(size / 16f, size / 16f);
            graphics.renderItem(frames[frame], 0, 0);
        } finally {
            graphics.pose().popMatrix();
            graphics.disableScissor();
        }
    }
}
