package dev.lin.client.cosmetics.mixin;
import dev.lin.client.cosmetics.pods.PodSkins;
import net.minecraft.client.renderer.item.ItemModelResolver;
import net.minecraft.client.renderer.item.ItemStackRenderState;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
@Mixin(ItemModelResolver.class)
public class PodSkinModelMixin {
    @ModifyVariable(method="updateForNonLiving",at=@At("HEAD"),argsOnly=true,ordinal=0)
    private ItemStack lin$podDisplay(ItemStack value,ItemStackRenderState state,ItemStack stack,ItemDisplayContext context,Entity entity){return PodSkins.replace(value,entity);}
    @ModifyVariable(method="updateForLiving",at=@At("HEAD"),argsOnly=true,ordinal=0)
    private ItemStack lin$podStand(ItemStack value,ItemStackRenderState state,ItemStack stack,ItemDisplayContext context,LivingEntity entity){return PodSkins.replace(value,entity);}
}
