package com.linclient.client.auth;

import java.net.URI;
import java.util.Properties;

/** Endpoint configuration for standalone cosmetics presence and outfit sync. */
public final class SpringAuthorization {
    private static final URI ENDPOINT = endpoint();

    private SpringAuthorization() {}

    public static String endpointBinding() {
        return ENDPOINT.toString();
    }

    private static URI endpoint() {
        Properties properties = new Properties();
        try (var in = SpringAuthorization.class.getResourceAsStream("/lin-server-auth.properties")) {
            if (in == null) throw new IllegalStateException("缺少在线同步配置");
            properties.load(in);
        } catch (Exception e) {
            throw new IllegalStateException("无法读取在线同步配置", e);
        }
        URI uri = URI.create(properties.getProperty("endpoint", ""));
        if (!"https".equalsIgnoreCase(uri.getScheme()) || uri.getHost() == null || uri.getUserInfo() != null
                || uri.getQuery() != null || uri.getFragment() != null
                || !(uri.getPath().isEmpty() || uri.getPath().equals("/"))) {
            throw new IllegalStateException("同步地址必须是 HTTPS 根地址");
        }
        return uri;
    }
}
