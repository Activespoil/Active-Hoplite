package com.linclient.client.auth;

import javax.net.ssl.*;
import java.net.*;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

/** TLS transport recovery; both attempts retain platform trust and HTTPS hostname verification. */
public final class VerifiedHttps {
    private static final ConcurrentHashMap<String,Long> RECOVERED=new ConcurrentHashMap<>();
    private static final java.util.concurrent.ScheduledExecutorService DEADLINES=java.util.concurrent.Executors.newSingleThreadScheduledExecutor(r->{var t=new Thread(r,"Lin HTTPS deadlines");t.setDaemon(true);return t;});
    private VerifiedHttps() {}

    public static HttpsURLConnection connect(URI uri,String method,String bearer,int length,int timeout)throws IOException {
        if(!"https".equalsIgnoreCase(uri.getScheme()) || uri.getHost()==null || uri.getUserInfo()!=null)
            throw new IOException("HTTPS origin required");
        String origin=uri.getHost()+":"+(uri.getPort()<0?443:uri.getPort());
        boolean recovered=System.nanoTime()<RECOVERED.getOrDefault(origin,0L);
        var c=create(uri,method,bearer,length,timeout,recovered);
        try { c.connect();return c; }
        catch(IOException first){
            c.disconnect();
            if(recovered || first instanceof SSLHandshakeException && hasCertificateFailure(first))throw first;
            c=create(uri,method,bearer,length,timeout,true);
            try{
                // Connect before opening/writing the body: failed login/enroll requests are never replayed.
                c.connect();
                if(RECOVERED.size()>=16)RECOVERED.clear();
                RECOVERED.put(origin,System.nanoTime()+600_000_000_000L);
                return c;
            }catch(IOException second){c.disconnect();second.addSuppressed(first);throw second;}
        }
    }

    private static boolean hasCertificateFailure(Throwable e){
        for(int i=0;e!=null && i<16;i++,e=e.getCause())
            if(e instanceof java.security.cert.CertificateException || e instanceof java.security.cert.CertPathValidatorException)return true;
        return false;
    }

    public static byte[] readBody(HttpsURLConnection c,int limit,int timeoutMillis)throws IOException {
        try(var input=c.getInputStream()){
            var deadline=DEADLINES.schedule(()->{try{input.close();}catch(IOException ignored){}c.disconnect();},timeoutMillis,java.util.concurrent.TimeUnit.MILLISECONDS);
            try{
                byte[] result=input.readNBytes(limit+1);
                if(result.length>limit)throw new IOException("HTTPS response outside byte budget");
                return result;
            }finally{deadline.cancel(false);}
        }
    }

    private static HttpsURLConnection create(URI uri,String method,String bearer,int length,int timeout,boolean recovered)throws IOException {
        var c=(HttpsURLConnection)uri.toURL().openConnection();
        c.setUseCaches(false);c.setConnectTimeout(timeout);c.setReadTimeout(12000);c.setInstanceFollowRedirects(false);
        c.setRequestMethod(method);c.setDoOutput(length>=0);
        c.setRequestProperty("Content-Type","application/json; charset=UTF-8");
        if(bearer!=null && !bearer.isEmpty())c.setRequestProperty("Authorization","Bearer "+bearer);
        if(length>=0)c.setFixedLengthStreamingMode(length);
        if(recovered)c.setSSLSocketFactory(new VerifiedSocketFactory(c.getSSLSocketFactory()));
        return c;
    }

    /** Disables only the optional SNI extension; HTTPS identity and trust-chain checks stay enabled. */
    private static final class VerifiedSocketFactory extends SSLSocketFactory {
        private final SSLSocketFactory delegate;
        VerifiedSocketFactory(SSLSocketFactory delegate){this.delegate=delegate;}
        private java.net.Socket configure(java.net.Socket socket)throws IOException{
            if(socket instanceof SSLSocket ssl){
                var parameters=ssl.getSSLParameters();
                parameters.setEndpointIdentificationAlgorithm("HTTPS");
                parameters.setServerNames(List.of());
                ssl.setSSLParameters(parameters);
                // Finish the verified handshake on the layered socket before HttpsClient
                // has a chance to infer and reinsert SNI from its URL host.
                ssl.setSoTimeout(12000);
                if(ssl.isConnected())try{ssl.startHandshake();}catch(IOException e){try{ssl.close();}catch(IOException ignored){}throw e;}
            }
            return socket;
        }
        public String[] getDefaultCipherSuites(){return delegate.getDefaultCipherSuites();}
        public String[] getSupportedCipherSuites(){return delegate.getSupportedCipherSuites();}
        public java.net.Socket createSocket()throws IOException{
            var unsupported=new java.net.SocketException("Use a layered TLS socket");
            unsupported.initCause(new UnsupportedOperationException());
            throw unsupported;
        }
        public java.net.Socket createSocket(java.net.Socket s,String host,int port,boolean close)throws IOException{return configure(delegate.createSocket(s,host,port,close));}
        public java.net.Socket createSocket(String host,int port)throws IOException{return configure(delegate.createSocket(host,port));}
        public java.net.Socket createSocket(String host,int port,java.net.InetAddress local,int localPort)throws IOException{return configure(delegate.createSocket(host,port,local,localPort));}
        public java.net.Socket createSocket(java.net.InetAddress host,int port)throws IOException{return configure(delegate.createSocket(host,port));}
        public java.net.Socket createSocket(java.net.InetAddress host,int port,java.net.InetAddress local,int localPort)throws IOException{return configure(delegate.createSocket(host,port,local,localPort));}
    }
}
