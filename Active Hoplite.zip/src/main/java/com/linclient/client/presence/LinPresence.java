package com.linclient.client.presence;

import com.google.gson.*;
import com.linclient.client.auth.SpringAuthorization;
import net.minecraft.client.Minecraft;
import net.minecraft.client.User;
import net.minecraft.client.multiplayer.ClientPacketListener;
import com.mojang.authlib.minecraft.MinecraftSessionService;
import javax.net.ssl.HttpsURLConnection;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;

/** Lin's own HTTPS presence, independent of Apollo, Curse IRC and cached license renewal. */
public final class LinPresence {
    private static final ExecutorService IO = Executors.newSingleThreadExecutor(r -> {
        Thread thread = new Thread(r, "Lin-presence"); thread.setDaemon(true); return thread;
    });
    private static PresenceSnapshot snapshot = PresenceSnapshot.EMPTY;
    private static ClientPacketListener connection;
    private static UUID self;
    private static volatile long generation;
    private static long nextRequest, earliestRefresh, readyAt;
    private static Set<UUID> lastQueried = Set.of();
    private static String token = "";
    private static int failures;
    private static boolean busy, initialized;
    private LinPresence() {}
    record Session(String token,long generation) {}
    static Session cosmeticSession(){return token.isEmpty()?null:new Session(token,generation);}
    static void invalidateSession(Session session){
        if(session!=null && session.generation()==generation && session.token().equals(token)){
            generation++;token="";busy=false;nextRequest=0;snapshot=PresenceSnapshot.EMPTY;
        }
    }
    public static void initialize() {
        if (initialized) return;
        initialized = true;
        net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> reset());
    }
    private static void reset() {
        generation++; snapshot = PresenceSnapshot.EMPTY; connection = null; self = null;
        nextRequest = 0; earliestRefresh = 0; lastQueried = Set.of(); failures = 0; busy = false;
        String old = token; token = "";
        if (!old.isEmpty() && !IO.isShutdown()) IO.execute(() -> leave(old));
    }
    public static void close() { reset(); IO.shutdown(); }
    public static boolean visible(UUID uuid) {
        Minecraft mc = Minecraft.getInstance();
        if (uuid == null || mc.player == null) return false;
        // Self is known locally; remote identities require a live, verified server response.
        return uuid.equals(mc.player.getUUID()) || snapshot.contains(uuid, System.nanoTime());
    }
    public static void tick(Minecraft mc) {
        if (mc.player == null || mc.getConnection() == null) {
            if (connection != null) reset();
            return;
        }
        UUID uuid = mc.player.getUUID();
        if (connection != mc.getConnection() || !uuid.equals(self)) {
            reset(); connection = mc.getConnection(); self = uuid;
            readyAt = System.nanoTime() + TimeUnit.MILLISECONDS.toNanos(300);
        }
        long now = System.nanoTime();
        if (mc.isLocalServer() || uuid.version() != 4 || !uuid.equals(mc.getUser().getProfileId())
                || busy || now < readyAt || IO.isShutdown()) return;
        LinkedHashSet<UUID> requested = new LinkedHashSet<>();
        requested.add(uuid);
        // Nearby names first, then TAB, with a strict request cap.
        for (var player : mc.level.players()) if (player.getUUID().version() == 4 && requested.size() < 512) requested.add(player.getUUID());
        for (var info : connection.getListedOnlinePlayers()) if (info.getProfile().id().version() == 4 && requested.size() < 512) requested.add(info.getProfile().id());
        boolean hasNewPlayer = !token.isEmpty() && now >= earliestRefresh && !lastQueried.containsAll(requested);
        if (now < nextRequest && !hasNewPlayer) return;
        var players = List.copyOf(requested);
        User user = mc.getUser(); MinecraftSessionService sessions = mc.services().sessionService();
        long epoch = generation;
        String previousToken = token;
        busy = true;
        IO.execute(() -> {
            String active = previousToken;
            try {
                if (active.isEmpty()) {
                    JsonObject body = new JsonObject(); body.addProperty("uuid", uuid.toString()); body.addProperty("name", user.getName());
                    String challenge = request("challenge", body, "").get("challenge").getAsString();
                    if (!challenge.matches("[0-9a-f]{40}")) throw new IllegalStateException("Invalid challenge");
                    if (epoch != generation) return;
                    // The account access token goes ONLY to Mojang's existing authlib service.
                    sessions.joinServer(uuid, user.getAccessToken(), challenge);
                    if (epoch != generation) return;
                    JsonObject proof = new JsonObject(); proof.addProperty("challenge", challenge);
                    active = request("verify", proof, "").get("token").getAsString();
                    if (!active.matches("[0-9a-f]{48}")) throw new IllegalStateException("Invalid session");
                }
                JsonObject body = new JsonObject(); JsonArray list = new JsonArray();
                for (UUID id : players) list.add(id.toString()); body.add("players", list);
                long started = System.nanoTime();
                JsonArray found = request("heartbeat", body, active).getAsJsonArray("players");
                if (found.size() > 512) throw new IllegalStateException("Oversized snapshot");
                Map<UUID, Long> deadlines = new HashMap<>();
                for (var entry : found) {
                    var item = entry.getAsJsonObject(); UUID id = UUID.fromString(item.get("uuid").getAsString());
                    long ttl = item.get("ttlMillis").getAsLong();
                    if (requested.contains(id) && ttl > 0 && ttl <= 45_000) deadlines.put(id, started + TimeUnit.MILLISECONDS.toNanos(ttl));
                }
                String accepted = active;
                mc.execute(() -> {
                    if (epoch != generation) { if (!IO.isShutdown()) IO.execute(() -> leave(accepted)); return; }
                    token = accepted; snapshot = new PresenceSnapshot(deadlines); lastQueried = Set.copyOf(players); busy = false; failures = 0;
                    long done = System.nanoTime();
                    earliestRefresh = done + TimeUnit.MILLISECONDS.toNanos(2300);
                    nextRequest = done + TimeUnit.SECONDS.toNanos(12);
                });
            } catch (Exception failure) {
                String attempted = active;
                mc.execute(() -> {
                    if (epoch != generation) { if (!attempted.isEmpty() && !IO.isShutdown()) IO.execute(() -> leave(attempted)); return; }
                    // Expired sessions reauthenticate on the next attempt. Network outages keep their bounded TTL.
                    token = failure instanceof HttpFailure h && h.status == 401 ? "" : attempted;
                    busy = false;
                    if (failure instanceof HttpFailure h && h.status == 429) {
                        long done = System.nanoTime();
                        earliestRefresh = done + TimeUnit.SECONDS.toNanos(5);
                        nextRequest = done + TimeUnit.SECONDS.toNanos(5);
                        return;
                    }
                    failures = Math.min(5, failures + 1);
                    nextRequest = System.nanoTime() + TimeUnit.SECONDS.toNanos(Math.min(60, 2L << failures));
                    if (failures == 1) System.getLogger("LinPresence").log(System.Logger.Level.INFO,
                            "Online badges unavailable; retrying in background. Game login is unaffected.");
                });
            }
        });
    }
    private static void leave(String token) { try { request("leave", new JsonObject(), token); } catch (Exception ignored) {} }
    private static final class HttpFailure extends Exception {
        final int status; HttpFailure(int status) { super("Presence HTTP " + status); this.status = status; }
    }
    private static JsonObject request(String path, JsonObject body, String bearer) throws Exception {
        URI endpoint = URI.create(SpringAuthorization.endpointBinding()).resolve("/api/client/presence/" + path);
        byte[] bytes = body.toString().getBytes(StandardCharsets.UTF_8);
        HttpsURLConnection c = com.linclient.client.auth.VerifiedHttps.connect(endpoint,"POST",bearer,bytes.length,5000);
        try {
            try (var out = c.getOutputStream()) { out.write(bytes); }
            int status = c.getResponseCode();
            if (status != 200) throw new HttpFailure(status);
            try (var in = c.getInputStream()) {
                byte[] result = in.readNBytes(65537);
                if (result.length > 65536) throw new IllegalStateException("Oversized response");
                return JsonParser.parseString(new String(result, StandardCharsets.UTF_8)).getAsJsonObject();
            }
        } finally { c.disconnect(); }
    }
}
