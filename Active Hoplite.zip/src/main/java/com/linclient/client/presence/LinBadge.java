package com.linclient.client.presence;

import net.minecraft.network.chat.*;
import net.minecraft.resources.Identifier;
import java.util.Optional;
import java.util.UUID;

/** One namespaced symbol; never changes a player's profile, team, score key or server-owned component. */
public final class LinBadge {
    // A small bitmap glyph has explicit ascent/height and survives GUI minification.
    // Keep the full-size menu logo independent from this optical badge variant.
    public static final FontDescription FONT = new FontDescription.Resource(Identifier.fromNamespaceAndPath("linclient", "peer_badge"));
    private static final FontDescription SPACE_FONT = FONT;
    private static final Style STYLE = Style.EMPTY.withFont(FONT).withColor(0xFFFFFF)
            .withShadowColor(0)
            .withBold(false).withItalic(false).withUnderlined(false).withStrikethrough(false).withObfuscated(false);
    private LinBadge() {}
    public static Component icon() { return Component.literal("\uFFFC").setStyle(STYLE); }
    public static Component prefix() { return Component.empty().append(icon()).append(Component.literal(" ").setStyle(STYLE.withFont(SPACE_FONT))); }
    public static boolean isBadge(Style style) { return FONT.equals(style.getFont()) || SPACE_FONT.equals(style.getFont()); }
    public static boolean isIcon(int codePoint, Style style) { return codePoint == '\uFFFC' && isBadge(style); }
    public static Component strip(Component original) {
        var result = Component.empty();
        original.visit((style, text) -> {
            if (!isBadge(style)) result.append(Component.literal(text).setStyle(style));
            return Optional.empty();
        }, Style.EMPTY);
        return result;
    }
    public static Component decorate(Component original, UUID uuid) {
        if (original == null) return null;
        boolean marked = original.visit((style, text) -> isBadge(style) ? Optional.of(true) : Optional.empty(), Style.EMPTY).orElse(false);
        if (!LinPresence.visible(uuid)) return marked ? strip(original) : original;
        return Component.empty().append(prefix()).append(marked ? strip(original) : original);
    }
    public static Component tab(Component original, UUID uuid) {
        if (!dev.lin.client.cosmetics.config.CosmeticConfig.showTabBadge()) {
            if (original == null) return null;
            boolean marked = original.visit((style, text) -> isBadge(style) ? Optional.of(true) : Optional.empty(), Style.EMPTY).orElse(false);
            return marked ? strip(original) : original;
        }
        return decorate(original, uuid);
    }
    public static Component nametag(Component original, UUID uuid) {
        if (!dev.lin.client.cosmetics.config.CosmeticConfig.showNametagBadge()) {
            if (original == null) return null;
            boolean marked = original.visit((style, text) -> isBadge(style) ? Optional.of(true) : Optional.empty(), Style.EMPTY).orElse(false);
            return marked ? strip(original) : original;
        }
        return decorate(original, uuid);
    }
}
