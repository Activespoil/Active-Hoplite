package com.linclient.client.presence;

import java.util.Map;
import java.util.UUID;

/** Immutable render-thread view; server TTL is measured from request start, never receipt time. */
public record PresenceSnapshot(Map<UUID, Long> deadlines) {
    public static final PresenceSnapshot EMPTY = new PresenceSnapshot(Map.of());
    public PresenceSnapshot { deadlines = Map.copyOf(deadlines); }
    public boolean contains(UUID uuid, long now) {
        Long until = deadlines.get(uuid);
        return until != null && now < until;
    }
}
