package com.linclient.client.presence;

import com.google.gson.*;
import com.linclient.client.auth.SpringAuthorization;
import dev.lin.client.cosmetics.sync.CosmeticSyncBridge;
import dev.lin.client.cosmetics.config.CosmeticConfig;
import net.minecraft.client.Minecraft;
import java.net.URI;
import java.net.http.*;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.*;

/** Single in-flight metadata request; independent of presence heartbeats and asset downloads. */
public final class CosmeticSyncClient {
    private static final ExecutorService IO=Executors.newSingleThreadExecutor(r->{var t=new Thread(r,"Lin cosmetic sync");t.setDaemon(true);return t;});
    private static final Gson JSON=new Gson();
    private static Object connection,world,player;
    private static LinPresence.Session session;
    private static long generation,acked=-1,rejected=-1,nextRequest,nextPoll,earliestPoll,nextUpload;
    private static Set<UUID> polledPeers=Set.of();
    private static int cursor,failures;
    private static boolean busy,capable,unsupported,trimCapable,appearanceCapable,receiving=true;
    private static long capabilityRetry;
    private static Future<?> pending;
    private CosmeticSyncClient(){}
    private static void reset(){
        generation++;if(pending!=null)pending.cancel(true);pending=null;
        busy=false;capable=false;unsupported=false;trimCapable=appearanceCapable=false;capabilityRetry=0;acked=rejected=-1;cursor=failures=0;
        nextRequest=nextPoll=earliestPoll=nextUpload=0;polledPeers=Set.of();CosmeticSyncBridge.clear();
    }
    public static void close(){reset();IO.shutdownNow();}
    public static void tick(Minecraft client){
        LinPresence.Session active=LinPresence.cosmeticSession();
        if(connection!=client.getConnection() || world!=client.level || player!=client.player || !Objects.equals(session,active)){
            reset();connection=client.getConnection();world=client.level;player=client.player;session=active;
        }
        if(receiving!=CosmeticConfig.receiveCosmetics()){
            reset();receiving=CosmeticConfig.receiveCosmetics();
        }
        if(client.player==null || client.level==null || active==null || client.isLocalServer()){
            CosmeticSyncBridge.status("等待正版在线会话");return;
        }
        if(unsupported && System.nanoTime()>=capabilityRetry){unsupported=false;capable=false;}
        if(IO.isShutdown() || unsupported || busy || System.nanoTime()<nextRequest)return;
        var local=CosmeticSyncBridge.local();long now=System.nanoTime();
        String path,method;JsonObject body=null;List<UUID> requested=List.of();
        if(!capable){path="capabilities";method="GET";}
        else if(local.revision()!=acked && local.revision()!=rejected && now>=nextUpload && (acked<0 || now-local.changedAtNanos()>=120_000_000L)){
            path="outfit";method="PUT";body=new JsonObject();body.addProperty("clientSeq",local.revision());
            body.addProperty("catalogRevision",CosmeticSyncBridge.CATALOG_REVISION);body.addProperty("shared",local.shared());
            var outfit=local.shared()?local.outfit():CosmeticSyncBridge.Outfit.EMPTY;
            body.add("slots",JSON.toJsonTree(outfit.slots()));body.add("accessories",JSON.toJsonTree(outfit.accessories()));body.add("options",JSON.toJsonTree(outfit.options()));
            // Separate optional field: old v1 clients still accept the original bounded options map.
            if(trimCapable)body.add("trim",JSON.toJsonTree(outfit.trim()));
            if(appearanceCapable)body.add("appearance",JSON.toJsonTree(outfit.appearance()));
            CosmeticSyncBridge.status(local.shared()?"正在同步":"正在取消共享");
        }else{
            if(!receiving)return;
            var candidates=new ArrayList<>(client.level.players());
            candidates.removeIf(p->p==client.player || p.getUUID().version()!=4 || p.distanceToSqr(client.player)>64*64);
            boolean hasUnseen=false;
            for(var p:candidates)if(!polledPeers.contains(p.getUUID())){hasUnseen=true;break;}
            if(now<nextPoll && (!hasUnseen || now<earliestPoll))return;
            candidates.sort(Comparator.comparingInt((net.minecraft.world.entity.player.Player p)->polledPeers.contains(p.getUUID())?1:0)
                .thenComparingDouble(p->p.distanceToSqr(client.player)));
            if(candidates.isEmpty()){CosmeticSyncBridge.clear();polledPeers=Set.of();nextPoll=now+2_000_000_000L;return;}
            int count=Math.min(32,candidates.size());var ids=new ArrayList<UUID>(count);JsonArray peers=new JsonArray();
            int start=hasUnseen?0:cursor;
            for(int i=0;i<count;i++){
                UUID id=candidates.get((start+i)%candidates.size()).getUUID();ids.add(id);
                JsonObject query=new JsonObject();query.addProperty("uuid",id.toString());
                var known=CosmeticSyncBridge.remote(id);if(known!=null)query.addProperty("knownVersion",known.version());peers.add(query);
            }
            cursor=(start+count)%candidates.size();requested=List.copyOf(ids);
            path="resolve";method="POST";body=new JsonObject();body.add("players",peers);
            if(appearanceCapable)body.addProperty("appearanceVersion",1);
        }
        String endpoint=path,verb=method;JsonObject payload=body;List<UUID> ids=requested;
        long epoch=generation,started=System.nanoTime();busy=true;
        pending=IO.submit(()->{
            try{
                JsonObject response=request(endpoint,verb,payload,active.token());
                client.execute(()->{
                    if(epoch!=generation)return;busy=false;failures=0;nextRequest=0;
                    try{
                        if(endpoint.equals("capabilities")){
                            if(response.get("protocol").getAsInt()!=1){unsupported=true;capabilityRetry=System.nanoTime()+30_000_000_000L;CosmeticSyncBridge.status("服务端需要更新");return;}
                            trimCapable=response.has("trimVersion") && response.get("trimVersion").getAsInt()==1;
                            appearanceCapable=response.has("appearanceVersion") && response.get("appearanceVersion").getAsInt()==1;
                            capable=true;
                        }else if(endpoint.equals("outfit")){
                            if(response.get("acceptedSeq").getAsLong()!=local.revision())throw new IllegalArgumentException("Wrong acknowledgement");
                            acked=local.revision();nextUpload=System.nanoTime()+550_000_000L;nextPoll=0;
                            CosmeticSyncBridge.status(!local.shared()?"仅自己可见":
                                !appearanceCapable?"饰品已同步 · 完整互见需更新服务端":local.outfit().trim()!=null && !trimCapable?"饰品已同步 · 纹饰互见需更新服务端":"已同步");
                        }else{
                            apply(response,ids,started);
                            var nextPolled=new HashSet<>(polledPeers);nextPolled.addAll(ids);
                            if(nextPolled.size()>512)nextPolled=new HashSet<>(ids);
                            polledPeers=Set.copyOf(nextPolled);
                            long done=System.nanoTime();
                            earliestPoll=done+600_000_000L;
                            nextPoll=done+ThreadLocalRandom.current().nextLong(1_800_000_000L,2_500_000_001L);
                        }
                    }catch(RuntimeException invalid){backoff("同步响应无效");}
                });
            }catch(Exception failure){
                client.execute(()->{
                    if(epoch!=generation)return;busy=false;
                    if(failure instanceof HttpFailure h){
                        if(h.code==401){LinPresence.invalidateSession(active);return;}
                        if(h.code==404 || h.code==405){unsupported=true;capabilityRetry=System.nanoTime()+30_000_000_000L;CosmeticSyncBridge.status("互见接口暂不可用 · 30秒后重试");return;}
                        if((h.code==422 || h.code==413 || h.code==409) && endpoint.equals("outfit")){
                            // Do NOT lock out peer resolution when an older server rejects a newer accessory;
                            // stop retrying this rejected revision until outfit changes, while still seeing others.
                            rejected=local.revision();nextUpload=System.nanoTime()+15_000_000_000L;
                            CosmeticSyncBridge.status("部分新款饰品需更新服务端后才可共享");return;
                        }
                        if(h.code==429){nextRequest=System.nanoTime()+Math.max(2,h.retrySeconds)*1_000_000_000L;return;}
                    }
                    backoff(local.shared()?"暂时无法同步":"取消共享待同步");
                });
            }
        });
    }
    private static void backoff(String message){
        failures=Math.min(5,failures+1);nextRequest=System.nanoTime()+TimeUnit.SECONDS.toNanos(Math.min(60,2L<<failures));
        CosmeticSyncBridge.status(message);
    }
    private static void apply(JsonObject response,List<UUID> requested,long started){
        JsonArray list=response.getAsJsonArray("players");if(list==null || list.size()>128)throw new IllegalArgumentException("Oversized snapshot");
        Map<UUID,CosmeticSyncBridge.Peer> next=new LinkedHashMap<>(CosmeticSyncBridge.snapshot());long now=System.nanoTime();
        next.entrySet().removeIf(e->now>=e.getValue().deadline());Set<UUID> seen=new HashSet<>();
        for(var value:list){
            JsonObject item=value.getAsJsonObject();UUID id=UUID.fromString(item.get("uuid").getAsString());
            if(!requested.contains(id) || !seen.add(id))throw new IllegalArgumentException("Unexpected player");
            String state=item.get("status").getAsString();
            if(state.equals("unavailable")){next.remove(id);continue;}
            long ttl=item.get("ttlMillis").getAsLong();String version=item.get("version").getAsString();
            if(ttl<=0 || ttl>45000 || !version.matches("[0-9a-f]{32}"))throw new IllegalArgumentException("Invalid lifetime/version");
            long deadline=started+TimeUnit.MILLISECONDS.toNanos(ttl);
            if(deadline<=now){next.remove(id);continue;}
            if(state.equals("unchanged")){
                var previous=next.get(id);if(previous!=null && previous.version().equals(version))next.put(id,new CosmeticSyncBridge.Peer(previous.outfit(),version,deadline,previous.definitions()));
            }else if(state.equals("updated")){
                Map<String,Integer> slots=new LinkedHashMap<>();var input=item.getAsJsonObject("slots");
                if(input==null || input.size()>24)throw new IllegalArgumentException("Invalid slots");
                for(var e:input.entrySet())slots.put(e.getKey(),e.getValue().getAsInt());
                var accessories=strings(item,"accessories",5);var options=strings(item,"options",9);
                slots.entrySet().removeIf(e->!CosmeticSyncBridge.knownSlot(e.getKey(),e.getValue()));
                accessories.entrySet().removeIf(e->!CosmeticSyncBridge.knownAccessory(e.getKey(),e.getValue()));
                next.put(id,new CosmeticSyncBridge.Peer(new CosmeticSyncBridge.Outfit(slots,accessories,options,readTrim(item),readAppearance(item)),version,deadline));
            }else throw new IllegalArgumentException("Invalid status");
        }
        if(seen.size()!=requested.size())throw new IllegalArgumentException("Incomplete snapshot");
        while(next.size()>1024)next.remove(next.keySet().iterator().next());
        CosmeticSyncBridge.replace(next);
    }
    private static Map<String,String> strings(JsonObject object,String name,int limit){
        JsonObject source=object.getAsJsonObject(name);if(source==null || source.size()>limit)throw new IllegalArgumentException("Invalid "+name);
        Map<String,String> out=new LinkedHashMap<>();for(var e:source.entrySet()){
            String value=e.getValue().getAsString();if(e.getKey().length()>32 || value.length()>96)throw new IllegalArgumentException("Oversized field");out.put(e.getKey(),value);
        }return out;
    }
    private static CosmeticSyncBridge.Trim readTrim(JsonObject item){
        if(!item.has("trim") || item.get("trim").isJsonNull())return null;
        var trim=item.getAsJsonObject("trim");
        if(trim.size()!=2 || !trim.has("pattern") || !trim.has("material"))throw new IllegalArgumentException("Invalid trim");
        String pattern=trim.get("pattern").getAsString(),material=trim.get("material").getAsString();
        if(pattern.length()>96 || material.length()>32)throw new IllegalArgumentException("Oversized trim");
        // A newer server may know assets this client does not have. Keep its other cosmetics.
        return CosmeticSyncBridge.knownTrim(pattern,material)?new CosmeticSyncBridge.Trim(pattern,material):null;
    }
    private static CosmeticSyncBridge.Appearance readAppearance(JsonObject item){
        if(!item.has("appearance") || item.get("appearance").isJsonNull())return CosmeticSyncBridge.Appearance.EMPTY;
        var a=item.getAsJsonObject("appearance");
        if(a.size()>4)throw new IllegalArgumentException("Oversized appearance");
        String vip=a.has("vipIcon")?a.get("vipIcon").getAsString():"none";
        String trail=a.has("arrowTrail")?a.get("arrowTrail").getAsString():"none";
        if(vip.length()>96 || trail.length()>96)throw new IllegalArgumentException("Oversized appearance ID");
        var skins=a.has("skins")?strings(a,"skins",64):new LinkedHashMap<String,String>();
        skins.entrySet().removeIf(e->!CosmeticSyncBridge.knownSkin(e.getKey(),e.getValue()));
        return new CosmeticSyncBridge.Appearance(CosmeticSyncBridge.known("vipIcons",vip)?vip:"none",
            !a.has("vipLobbyOnly") || a.get("vipLobbyOnly").getAsBoolean(),CosmeticSyncBridge.known("arrowTrails",trail)?trail:"none",skins);
    }
    private static final class HttpFailure extends Exception {final int code,retrySeconds;HttpFailure(int c,int r){code=c;retrySeconds=r;}}
    private static JsonObject request(String path,String method,JsonObject body,String token)throws Exception{
        URI endpoint=URI.create(SpringAuthorization.endpointBinding()).resolve("/api/client/cosmetics/v1/"+path);
        byte[] bytes=body==null?null:body.toString().getBytes(StandardCharsets.UTF_8);
        var c=com.linclient.client.auth.VerifiedHttps.connect(endpoint,method,token,bytes==null?-1:bytes.length,5000);
        try{
            if(bytes!=null)try(var out=c.getOutputStream()){out.write(bytes);}
            int status=c.getResponseCode();
            if(status!=200){int retry=2;try{retry=Math.min(120,Integer.parseInt(c.getHeaderField("Retry-After")));}catch(RuntimeException ignored){}throw new HttpFailure(status,retry);}
            byte[] response=com.linclient.client.auth.VerifiedHttps.readBody(c,524288,8000);
            return JsonParser.parseString(new String(response,StandardCharsets.UTF_8)).getAsJsonObject();
        }finally{c.disconnect();}
    }
}
