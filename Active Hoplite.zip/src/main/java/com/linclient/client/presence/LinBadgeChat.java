package com.linclient.client.presence;

import java.util.Optional;
import java.util.UUID;
import java.util.function.Function;
import java.util.regex.Pattern;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Style;
import net.minecraft.network.chat.contents.PlainTextContents;
import net.minecraft.network.chat.contents.TranslatableContents;

/** Presentation only: signed contents, trust evaluation and server components remain untouched. */
public final class LinBadgeChat {
    private static final Pattern SENDER = Pattern.compile(
            "^(?:(?:\\[[^\\]\\r\\n]{1,24}\\]|[^\\p{L}\\p{N}\\s<>:：»≫\\[\\]]{1,4})\\s*){0,4}"
            + "[<《]?([A-Za-z0-9_]{1,16})(?=\\s*(?:[:：»≫]|[>》]\\s))");
    private LinBadgeChat() {}

    public static Component signed(Component message, Component sender, UUID uuid) {
        if (!LinPresence.visible(uuid) || marked(message)) return message;
        // ChatTypeDecoration keeps the bound sender as a Component argument.
        // Match its identity, so an equal name quoted in the body is never marked.
        return replaceSender(message, sender, uuid, new boolean[1]);
    }

    private static Component replaceSender(Component source, Component sender, UUID uuid, boolean[] done) {
        if (done[0]) return source;
        if (source == sender) {
            done[0] = true;
            return LinBadge.decorate(source, uuid);
        }
        MutableComponent result = source.plainCopy();
        if (source.getContents() instanceof TranslatableContents t) {
            Object[] args = t.getArgs().clone();
            for (int i = 0; i < args.length; i++)
                if (args[i] instanceof Component c) args[i] = replaceSender(c, sender, uuid, done);
            result = MutableComponent.create(new TranslatableContents(t.getKey(), t.getFallback(), args))
                    .setStyle(source.getStyle());
        }
        for (Component sibling : source.getSiblings()) result.append(replaceSender(sibling, sender, uuid, done));
        return done[0] ? result : source;
    }

    public static Component detected(Component message) {
        var connection = Minecraft.getInstance().getConnection();
        if (connection == null) return message;
        return detected(message, name -> {
            for (var info : connection.getOnlinePlayers())
                if (info.getProfile().name().equals(name)) return info.getProfile().id();
            return null;
        });
    }

    public static Component detected(Component message, Function<String, UUID> lookup) {
        if (marked(message) || !literalTree(message)) return message;
        var matcher = SENDER.matcher(message.getString());
        if (!matcher.find() || matcher.start(1) > 64) return message;
        UUID sender = lookup.apply(matcher.group(1));
        if (sender == null || !LinPresence.visible(sender)) return message;
        return insert(message, matcher.start(1), new int[1], new boolean[1]);
    }

    private static boolean marked(Component message) {
        return message.visit((style, text) -> LinBadge.isBadge(style) ? Optional.of(true) : Optional.empty(),
                Style.EMPTY).orElse(false);
    }

    private static boolean literalTree(Component source) {
        if (!(source.getContents() instanceof PlainTextContents)) return false;
        for (Component child : source.getSiblings()) if (!literalTree(child)) return false;
        return true;
    }

    private static Component insert(Component source, int at, int[] offset, boolean[] done) {
        String text = ((PlainTextContents) source.getContents()).text();
        int local = at - offset[0];
        MutableComponent result;
        if (!done[0] && local >= 0 && local < text.length()) {
            result = Component.empty().setStyle(source.getStyle())
                    .append(text.substring(0, local)).append(LinBadge.prefix()).append(text.substring(local));
            done[0] = true;
        } else result = source.plainCopy();
        offset[0] += text.length();
        for (Component child : source.getSiblings()) result.append(insert(child, at, offset, done));
        return result;
    }
}
