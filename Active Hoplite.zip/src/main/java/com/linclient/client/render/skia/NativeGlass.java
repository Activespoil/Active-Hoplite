package com.linclient.client.render.skia;

import java.nio.ByteBuffer;
import org.lwjgl.BufferUtils;
import static org.lwjgl.opengl.GL33.*;

/** Render-thread-only glass. One fresh scene per frame; shared Gaussian output
 * is cropped to predicted panel bounds, with immediate fallback for new regions. */
public final class NativeGlass implements AutoCloseable {
    private static final int MAX_GAUSSIAN_PAIRS=128;
    private static final long IDLE_RELEASE_NANOS=5_000_000_000L;
    private static final String VERTEX = """
        #version 330 core
        out vec2 uv;
        void main() {
            uv=vec2((gl_VertexID<<1)&2,gl_VertexID&2);
            gl_Position=vec4(uv*2.0-1.0,0,1);
        }
        """;
    private static final String BLUR = """
        #version 330 core
        uniform sampler2D scene;
        uniform vec2 stepSize;
        uniform vec2 taps[128];
        uniform int tapCount;
        uniform float centerWeight;
        in vec2 uv;
        out vec4 color;
        void main() {
            // Combine adjacent Gaussian taps; never skip the texels between them.
            // The sRGB capture decodes in hardware before bilinear filtering.
            vec3 c=texture(scene,uv).rgb*centerWeight;
            for(int i=0;i<tapCount;i++) {
                vec2 s=stepSize*taps[i].x;
                c+=taps[i].y*(texture(scene,uv+s).rgb+texture(scene,uv-s).rgb);
            }
            color=vec4(c,1);
        }
        """;
    private static final String PANEL = """
        #version 330 core
        uniform sampler2D scene;
        uniform vec2 screenSize;
        uniform vec4 bounds;
        uniform float radius;
        uniform float pixelScale;
        uniform float opacity;
        uniform int affine;
        uniform vec4 inverseBasis;
        uniform vec2 origin;
        out vec4 color;
        void main() {
            vec2 p=gl_FragCoord.xy-bounds.xy-bounds.zw*0.5;
            if(affine==1) {
                vec2 screen=vec2(gl_FragCoord.x,screenSize.y-gl_FragCoord.y)-origin;
                p=vec2(dot(inverseBasis.xy,screen),dot(inverseBasis.zw,screen))-bounds.xy-bounds.zw*0.5;
            }
            vec2 q=abs(p)-(bounds.zw*0.5-radius);
            float d=length(max(q,0.0))+min(max(q.x,q.y),0.0)-radius;
            // Convert local signed distance to physical pixels for affine labels.
            if(affine==1) d/=max(length(vec2(dFdx(d),dFdy(d))),0.0001);
            float coverage=1.0-smoothstep(-0.75,0.75,d);
            if(coverage<=0.0) discard;
            float edge=1.0-smoothstep(0.0,max(1.0,3.0*pixelScale),-d);
            vec2 normal=normalize(p+vec2(0.0001));
            if(affine==1) normal=normalize(vec2(inverseBasis.x*normal.x+inverseBasis.z*normal.y,
                -inverseBasis.y*normal.x-inverseBasis.w*normal.y)+vec2(0.0001));
            vec2 uv=(gl_FragCoord.xy-normal*edge*pixelScale)/screenSize;
            vec3 c=max(texture(scene,uv).rgb,vec3(0));
            c=mix(c*12.92,1.055*pow(c,vec3(1.0/2.4))-0.055,step(vec3(0.0031308),c));
            float rim=(1.0-smoothstep(0.0,max(0.8,pixelScale),-d))*0.16;
            c=mix(c,vec3(1),rim*(0.65+0.35*normal.y));
            color=vec4(c,coverage*opacity);
        }
        """;
    private final State state = new State();
    private final int[] textures = new int[3], fbos = new int[3];
    private int width,height,vao,blur,panel,blurStep,blurTaps,blurCount,blurCenter,panelScreen,panelBounds,panelRadius,panelScale,panelOpacity,panelAffine,panelInverse,panelOrigin;
    private boolean ready, blurred;
    private int requestedLeft,requestedBottom,requestedRight,requestedTop;
    private int wantedLeft=Integer.MAX_VALUE,wantedBottom=Integer.MAX_VALUE,wantedRight,wantedTop;
    private int previousLeft=Integer.MAX_VALUE,previousBottom=Integer.MAX_VALUE,previousRight,previousTop;
    private int computedLeft,computedBottom,computedRight,computedTop;
    private float blurScale;
    private float uploadedSigma=Float.NaN;
    public long kernelUploads, passStateSetups;
    private int fullFrames;
    private static final int STRIPS = 32, ALL_STRIPS = -1;
    private int requestedStrips, wantedStrips, previousStrips, computedStrips;
    private final int[] wantedLow=new int[STRIPS],wantedHigh=new int[STRIPS];
    private final int[] previousLow=new int[STRIPS],previousHigh=new int[STRIPS];
    private final int[] requestLow=new int[STRIPS],requestHigh=new int[STRIPS];
    private final int[] computedLow=new int[STRIPS],computedHigh=new int[STRIPS];
    // Count processed texels for regression/diagnostics, including any fallback.
    public long horizontalPixels,verticalPixels;
    private long lastCaptureNanos;
    private final Kernel horizontal=new Kernel(),vertical=new Kernel();
    // Diagnostic counters intentionally count actual GPU work, not requests.
    public long captures, blurPasses;

    public void capture(int sourceFbo,int w,int h) {
        // Previous geometry only predicts work; the scene is always captured anew.
        previousLeft=width==w&&height==h?wantedLeft:Integer.MAX_VALUE;
        previousBottom=width==w&&height==h?wantedBottom:Integer.MAX_VALUE;
        previousRight=width==w&&height==h?wantedRight:0;
        previousTop=width==w&&height==h?wantedTop:0;
        previousStrips=width==w&&height==h?wantedStrips:0;
        System.arraycopy(wantedLow,0,previousLow,0,STRIPS);
        System.arraycopy(wantedHigh,0,previousHigh,0,STRIPS);
        java.util.Arrays.fill(wantedLow,Integer.MAX_VALUE);
        java.util.Arrays.fill(wantedHigh,0);
        wantedStrips=0;
        wantedLeft=wantedBottom=Integer.MAX_VALUE;wantedRight=wantedTop=0;
        if(fullFrames>0)fullFrames--;
        ready=false; blurred=false;
        if(w<1||h<1)return;
        if(vao!=0 && width==w && height==h && textures[0]!=0 && fbos[0]!=0) {
            // Blits do not use shaders, VAOs, blend, viewport or texture bindings.
            int read=glGetInteger(GL_READ_FRAMEBUFFER_BINDING);
            int draw=glGetInteger(GL_DRAW_FRAMEBUFFER_BINDING);
            boolean scissor=glIsEnabled(GL_SCISSOR_TEST),srgb=glIsEnabled(GL_FRAMEBUFFER_SRGB);
            boolean discard=glIsEnabled(GL_RASTERIZER_DISCARD);
            try {
                glDisable(GL_SCISSOR_TEST);glDisable(GL_FRAMEBUFFER_SRGB);glDisable(GL_RASTERIZER_DISCARD);
                copyScene(sourceFbo,w,h);
            } finally {
                glBindFramebuffer(GL_READ_FRAMEBUFFER,read);glBindFramebuffer(GL_DRAW_FRAMEBUFFER,draw);
                if(scissor)glEnable(GL_SCISSOR_TEST);
                if(srgb)glEnable(GL_FRAMEBUFFER_SRGB);
                if(discard)glEnable(GL_RASTERIZER_DISCARD);
            }
            return;
        }
        state.push();
        try {
            initialize(); resize(w,h); setup();
            copyScene(sourceFbo,w,h);
        } finally {state.pop();}
    }

    private void copyScene(int sourceFbo,int w,int h) {
        glBindFramebuffer(GL_READ_FRAMEBUFFER,sourceFbo);
        glBindFramebuffer(GL_DRAW_FRAMEBUFFER,fbos[0]);
        glBlitFramebuffer(0,0,w,h,0,0,(w+1)/2,(h+1)/2,GL_COLOR_BUFFER_BIT,GL_LINEAR);
        ready=true;captures++;lastCaptureNanos=System.nanoTime();
    }

    public boolean draw(int targetFbo,float x,float y,float w,float h,float radius,float scale) {
        return draw(targetFbo,x,y,w,h,radius,scale,1f);
    }
    /** Adds the known animation envelope to this frame's first Gaussian plan, without GL work. */
    public void predictRegion(float x,float y,float w,float h) {
        if(!ready || w<=0 || h<=0)return;
        resetRequest();includeRequest(x,y,x+w,y+h);
        previousLeft=Math.min(previousLeft,requestedLeft);previousBottom=Math.min(previousBottom,requestedBottom);
        previousRight=Math.max(previousRight,requestedRight);previousTop=Math.max(previousTop,requestedTop);
        previousStrips|=requestedStrips;
        for(int i=0;i<STRIPS;i++)if((requestedStrips&(1<<i))!=0){
            previousLow[i]=Math.min(previousLow[i],requestLow[i]);previousHigh[i]=Math.max(previousHigh[i],requestHigh[i]);
        }
    }
    public boolean draw(int targetFbo,float x,float y,float w,float h,float radius,float scale,float opacity) {
        return draw(targetFbo,x,y,w,h,radius,scale,opacity,true);
    }
    public boolean draw(int targetFbo,float x,float y,float w,float h,float radius,float scale,float opacity,boolean holdFallback) {
        if(opacity<=0)return true;
        if(!ready||w<=0||h<=0)return false;
        resetRequest();includeRequest(x,y,x+w,y+h);
        if(requestedRight<=requestedLeft || requestedTop<=requestedBottom)return true;
        state.push();
        try {
            preparePanels(targetFbo,scale,opacity,holdFallback?30:0);
            panelRect(x,y,w,h,radius);
            return true;
        } finally {state.pop();}
    }
    /** Independent rounded panels reuse one GL state save/setup/restore, without filling gaps. */
    public boolean drawPanels(int targetFbo,float[] bounds,float sx,float sy,float scale) {
        return drawPanels(targetFbo,bounds,bounds.length/5,sx,sy,scale,false);
    }
    /** Reusable buffers: count is panels, stride is 5 or 11 (local rect plus affine basis/translation). */
    public boolean drawPanels(int targetFbo,float[] bounds,int count,float sx,float sy,float scale,boolean affine) {
        int stride=affine?11:5;
        if(count<0 || count>bounds.length/stride || (count==bounds.length/stride && bounds.length%stride!=0))
            throw new IllegalArgumentException("Invalid panel buffer/count");
        if(count==0)return true;
        if(!ready)return false;
        resetRequest();
        for(int i=0;i<count*stride;i+=stride) {
            if(bounds[i+2]<=0 || bounds[i+3]<=0)continue;
            if(!affine)includeRequest(bounds[i]*sx,bounds[i+1]*sy,(bounds[i]+bounds[i+2])*sx,(bounds[i+1]+bounds[i+3])*sy);
            else {
                float a=bounds[i+5]*sx,c=bounds[i+7]*sx,d=bounds[i+6]*sy,e=bounds[i+8]*sy;
                float det=a*e-c*d;
                if(!Float.isFinite(det) || Math.abs(det)<1e-6f)continue;
                float px=a*bounds[i]+c*bounds[i+1]+bounds[i+9]*sx;
                float py=d*bounds[i]+e*bounds[i+1]+bounds[i+10]*sy;
                includeRequest(px+Math.min(0,a*bounds[i+2])+Math.min(0,c*bounds[i+3]),
                    py+Math.min(0,d*bounds[i+2])+Math.min(0,e*bounds[i+3]),
                    px+Math.max(0,a*bounds[i+2])+Math.max(0,c*bounds[i+3]),
                    py+Math.max(0,d*bounds[i+2])+Math.max(0,e*bounds[i+3]));
            }
        }
        if(requestedRight<=requestedLeft || requestedTop<=requestedBottom)return true;
        state.push();
        try {
            preparePanels(targetFbo,scale,1f,30);
            for(int i=0;i<count*stride;i+=stride) {
                if(affine) panelAffine(bounds,i,sx,sy);
                else if(bounds[i+2]>0 && bounds[i+3]>0)
                    panelRect(bounds[i]*sx,bounds[i+1]*sy,bounds[i+2]*sx,bounds[i+3]*sy,bounds[i+4]*Math.min(sx,sy));
            }
            return true;
        } finally {state.pop();}
    }
    private void panelAffine(float[] b,int i,float sx,float sy) {
        for(int n=0;n<11;n++)if(!Float.isFinite(b[i+n]))return;
        float x=b[i],y=b[i+1],w=b[i+2],h=b[i+3];
        if(w<=0 || h<=0)return;
        float a=b[i+5]*sx,c=b[i+7]*sx,tx=b[i+9]*sx;
        float d=b[i+6]*sy,e=b[i+8]*sy,ty=b[i+10]*sy;
        float det=a*e-c*d;
        if(!Float.isFinite(det) || Math.abs(det)<1e-6f)return;
        float px=a*x+c*y+tx,py=d*x+e*y+ty;
        float loX=px+Math.min(0,a*w)+Math.min(0,c*h),hiX=px+Math.max(0,a*w)+Math.max(0,c*h);
        float loY=py+Math.min(0,d*w)+Math.min(0,e*h),hiY=py+Math.max(0,d*w)+Math.max(0,e*h);
        if(hiX<-1 || loX>width+1 || hiY<-1 || loY>height+1)return;
        int left=Math.max(0,(int)Math.floor(loX)-1),bottom=Math.max(0,(int)Math.floor(height-hiY)-1);
        glScissor(left,bottom,Math.max(0,Math.min(width,(int)Math.ceil(hiX)+1)-left),
            Math.max(0,Math.min(height,(int)Math.ceil(height-loY)+1)-bottom));
        glUniform1i(panelAffine,1);
        glUniform4f(panelInverse,e/det,-c/det,-d/det,a/det);
        glUniform2f(panelOrigin,tx,ty);
        glUniform4f(panelBounds,x,y,w,h);
        glUniform1f(panelRadius,Math.max(0,Math.min(b[i+4],Math.min(w,h)*.5f)));
        glDrawArrays(GL_TRIANGLES,0,3);
    }
    private void resetRequest() {
        java.util.Arrays.fill(requestLow,Integer.MAX_VALUE);
        java.util.Arrays.fill(requestHigh,0);
        requestedStrips=0;
        requestedLeft=requestedBottom=Integer.MAX_VALUE;requestedRight=requestedTop=0;
    }
    private void includeRequest(float left,float top,float right,float bottom) {
        if(!Float.isFinite(left)||!Float.isFinite(top)||!Float.isFinite(right)||!Float.isFinite(bottom))return;
        int x0=Math.max(0,(int)Math.floor(left)-1),x1=Math.min(width,(int)Math.ceil(right)+1);
        int y0=Math.max(0,(int)Math.floor(height-bottom)-1),y1=Math.min(height,(int)Math.ceil(height-top)+1);
        if(x1<=x0 || y1<=y0)return;
        int first=(int)((long)x0*STRIPS/width);
        int last=Math.min(STRIPS-1,(int)((long)(x1-1)*STRIPS/width));
        for(int strip=first;strip<=last;strip++) {
            requestedStrips|=1<<strip;
            requestLow[strip]=Math.min(requestLow[strip],y0);
            requestHigh[strip]=Math.max(requestHigh[strip],y1);
        }
        requestedLeft=Math.min(requestedLeft,x0);requestedBottom=Math.min(requestedBottom,y0);
        requestedRight=Math.max(requestedRight,x1);requestedTop=Math.max(requestedTop,y1);
    }
    private void preparePanels(int targetFbo,float scale,float opacity,int fallbackFrames) {
        setup();
        wantedLeft=Math.min(wantedLeft,requestedLeft);wantedBottom=Math.min(wantedBottom,requestedBottom);
        wantedRight=Math.max(wantedRight,requestedRight);wantedTop=Math.max(wantedTop,requestedTop);
        wantedStrips|=requestedStrips;
        for(int i=0;i<STRIPS;i++)if((requestedStrips&(1<<i))!=0) {
            wantedLow[i]=Math.min(wantedLow[i],requestLow[i]);
            wantedHigh[i]=Math.max(wantedHigh[i],requestHigh[i]);
        }
        int halfW=(width+1)/2,halfH=(height+1)/2;
        if(!blurred)blurScale=scale;
        float pad=Math.abs(scale)+2; // refraction and bilinear footprint in physical pixels
        int rx0=Math.max(0,(int)Math.floor((requestedLeft-pad)*halfW/width));
        int ry0=Math.max(0,(int)Math.floor((requestedBottom-pad)*halfH/height));
        int rx1=Math.min(halfW,(int)Math.ceil((requestedRight+pad)*halfW/width));
        int ry1=Math.min(halfH,(int)Math.ceil((requestedTop+pad)*halfH/height));
        // Expand by one strip for refraction, bilinear footprint and integer rounding.
        // Very small targets use the original contiguous path.
        int needed=expandedStrips(requestedStrips,pad);
        if(!blurred || (needed & ~computedStrips)!=0 || rx0<computedLeft || ry0<computedBottom || rx1>computedRight || ry1>computedTop || !coversRows(halfH,pad)) {
            // A newly exposed region gets a full, fresh result immediately. At most one fallback per frame.
            if(blurred) { computedLeft=computedBottom=0;computedRight=halfW;computedTop=halfH;fullFrames=Math.max(fullFrames,fallbackFrames);computedStrips=ALL_STRIPS; }
            else {
                computedStrips=expandedStrips(previousStrips|requestedStrips,pad);
                computedLeft=Math.max(0,(int)Math.floor((Math.min(requestedLeft,previousLeft)-pad)*halfW/width));
                computedBottom=Math.max(0,(int)Math.floor((Math.min(requestedBottom,previousBottom)-pad)*halfH/height));
                computedRight=Math.min(halfW,(int)Math.ceil((Math.max(requestedRight,previousRight)+pad)*halfW/width));
                computedTop=Math.min(halfH,(int)Math.ceil((Math.max(requestedTop,previousTop)+pad)*halfH/height));
                // Cold layouts and recently moving/expanding layouts use the predictable full path.
                if(previousLeft==Integer.MAX_VALUE || fullFrames>0 ||
                    (long)(computedRight-computedLeft)*(computedTop-computedBottom)>(long)halfW*halfH*3/4) {
                    computedLeft=computedBottom=0;computedRight=halfW;computedTop=halfH;
                    if(previousLeft==Integer.MAX_VALUE || fullFrames>0)computedStrips=ALL_STRIPS;
                }
            }
            planRows(halfH,pad);
            if(textures[1]==0) {
                glBindBuffer(GL_PIXEL_UNPACK_BUFFER,0);
                createTarget(1,halfW,halfH);
                createTarget(2,halfW,halfH);
            }
            glUseProgram(blur);
            // The old kernel's sigma is approximately 5.9 physical pixels per GUI
            // scale unit. Preserve that spread while sampling every source texel.
            float sigma=Math.max(0.5f,blurScale)*5.9f;
            horizontal.update(sigma*halfW/width);
            vertical.update(sigma*halfH/height);
            // The vertical pass reads horizontal output above/below the visible result.
            int support=Math.min(MAX_GAUSSIAN_PAIRS*2,(int)Math.ceil(vertical.sigma*3))+1;
            int hy0=Math.max(0,computedBottom-support),hy1=Math.min(halfH,computedTop+support);
            glEnable(GL_SCISSOR_TEST);
            uploadKernel(horizontal);
            horizontalPixels+=stripPass(0,1,halfW,halfH,hy0,hy1,1f/halfW,0,support);
            uploadKernel(vertical);
            verticalPixels+=stripPass(1,2,halfW,halfH,computedBottom,computedTop,0,1f/halfH,0);
            blurred=true;
        }
        glBindFramebuffer(GL_DRAW_FRAMEBUFFER,targetFbo);
        glViewport(0,0,width,height);
        glEnable(GL_SCISSOR_TEST);
        glEnable(GL_BLEND);
        glBlendEquationSeparate(GL_FUNC_ADD,GL_FUNC_ADD);
        glBlendFuncSeparate(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA,GL_ONE,GL_ONE_MINUS_SRC_ALPHA);
        glUseProgram(panel);glBindTexture(GL_TEXTURE_2D,textures[2]);
        glUniform2f(panelScreen,width,height);
        glUniform1f(panelScale,scale);
        glUniform1f(panelOpacity,Math.max(0f,Math.min(1f,opacity)));
    }
    private int expandedStrips(int mask,float pad) {
        if(width/STRIPS<=pad+2)return ALL_STRIPS;
        int expanded=mask|(mask<<1)|(mask>>>1);
        // Limit extra draw calls when many disconnected labels span the screen.
        int runs=Integer.bitCount(expanded & ~(expanded<<1));
        return runs>4?ALL_STRIPS:expanded;
    }
    private boolean coversRows(int h,float pad) {
        if(width/STRIPS<=pad+2)return true; // original full-width path
        for(int i=0;i<STRIPS;i++)if((requestedStrips&(1<<i))!=0) {
            int low=Math.max(0,(int)Math.floor((requestLow[i]-pad)*h/height));
            int high=Math.min(h,(int)Math.ceil((requestHigh[i]+pad)*h/height));
            for(int n=Math.max(0,i-1);n<=Math.min(STRIPS-1,i+1);n++)
                if(low<computedLow[n] || high>computedHigh[n])return false;
        }
        return true;
    }
    private void planRows(int h,float pad) {
        java.util.Arrays.fill(computedLow,computedBottom);
        java.util.Arrays.fill(computedHigh,computedTop);
        // Keep bounded submission cost for cold/moving or fragmented layouts.
        if(previousLeft==Integer.MAX_VALUE || fullFrames>0 || width/STRIPS<=pad+2)return;
        int mask=previousStrips|requestedStrips;
        if(expandedStrips(mask,pad)==ALL_STRIPS)return;
        for(int i=0;i<STRIPS;i++)if((computedStrips&(1<<i))!=0) {
            int low=Integer.MAX_VALUE,high=0;
            for(int n=Math.max(0,i-1);n<=Math.min(STRIPS-1,i+1);n++) {
                if((previousStrips&(1<<n))!=0){low=Math.min(low,previousLow[n]);high=Math.max(high,previousHigh[n]);}
                if((requestedStrips&(1<<n))!=0){low=Math.min(low,requestLow[n]);high=Math.max(high,requestHigh[n]);}
            }
            if(low!=Integer.MAX_VALUE) {
                computedLow[i]=Math.max(computedBottom,(int)Math.floor((low-pad)*h/height));
                computedHigh[i]=Math.min(computedTop,(int)Math.ceil((high+pad)*h/height));
            }
        }
        int runs=0;
        for(int i=0;i<STRIPS;i++)if((computedStrips&(1<<i))!=0 &&
            (i==0 || (computedStrips&(1<<(i-1)))==0 || computedLow[i]!=computedLow[i-1] || computedHigh[i]!=computedHigh[i-1]))runs++;
        if(runs>8){java.util.Arrays.fill(computedLow,computedBottom);java.util.Arrays.fill(computedHigh,computedTop);}
    }
    private long stripPass(int src,int dst,int w,int h,int bottom,int top,float dx,float dy,int support) {
        long pixels=0;
        boolean prepared=false;
        for(int i=0;i<STRIPS;){
            if((computedStrips & (1<<i))==0){i++;continue;}
            int low=Math.max(bottom,computedLow[i]-support),high=Math.min(top,computedHigh[i]+support);
            int start=i++;
            while(i<STRIPS && (computedStrips & (1<<i))!=0 &&
                Math.max(bottom,computedLow[i]-support)==low && Math.min(top,computedHigh[i]+support)==high)i++;
            int left=Math.max(computedLeft,(int)((long)start*w/STRIPS));
            int right=Math.min(computedRight,(int)(((long)i*w+STRIPS-1)/STRIPS));
            if(right<=left || high<=low)continue;
            glScissor(left,low,right-left,high-low);
            if(!prepared){preparePass(src,dst,w,h,dx,dy);prepared=true;}
            glDrawArrays(GL_TRIANGLES,0,3);blurPasses++;
            pixels+=(long)(right-left)*(high-low);
        }
        return pixels;
    }

    private void panelRect(float x,float y,float w,float h,float radius) {
        glUniform1i(panelAffine,0);
        int left=Math.max(0,(int)Math.floor(x)-1),bottom=Math.max(0,(int)Math.floor(height-y-h)-1);
        glScissor(left,bottom,Math.max(0,Math.min(width,(int)Math.ceil(x+w)+1)-left),
            Math.max(0,Math.min(height,(int)Math.ceil(height-y)+1)-bottom));
        glUniform4f(panelBounds,x,height-y-h,w,h);
        glUniform1f(panelRadius,Math.min(radius,Math.min(w,h)*0.5f));
        glDrawArrays(GL_TRIANGLES,0,3);
    }
    private void preparePass(int src,int dst,int w,int h,float dx,float dy) {
        glBindFramebuffer(GL_DRAW_FRAMEBUFFER,fbos[dst]);glViewport(0,0,w,h);
        glBindTexture(GL_TEXTURE_2D,textures[src]);glUniform2f(blurStep,dx,dy);
        passStateSetups++;
    }
    private void setup() {
        glDisable(GL_SCISSOR_TEST);glDisable(GL_DEPTH_TEST);glDisable(GL_STENCIL_TEST);
        glDisable(GL_CULL_FACE);glDisable(GL_BLEND);glDisable(GL_FRAMEBUFFER_SRGB);
        glDisable(GL_RASTERIZER_DISCARD);glDisable(GL_COLOR_LOGIC_OP);
        glPolygonMode(GL_FRONT_AND_BACK,GL_FILL);
        glColorMask(true,true,true,true);glBindVertexArray(vao);
        glActiveTexture(GL_TEXTURE0);glBindSampler(0,0);
    }
    private void initialize() {
        if(vao!=0)return;
        try {
            blur=program(BLUR);panel=program(PANEL);vao=glGenVertexArrays();
            blurStep=glGetUniformLocation(blur,"stepSize");blurTaps=glGetUniformLocation(blur,"taps");
            blurCount=glGetUniformLocation(blur,"tapCount");blurCenter=glGetUniformLocation(blur,"centerWeight");
            panelScreen=glGetUniformLocation(panel,"screenSize");panelBounds=glGetUniformLocation(panel,"bounds");
            panelRadius=glGetUniformLocation(panel,"radius");panelScale=glGetUniformLocation(panel,"pixelScale");
            panelOpacity=glGetUniformLocation(panel,"opacity");
            panelAffine=glGetUniformLocation(panel,"affine");panelInverse=glGetUniformLocation(panel,"inverseBasis");
            panelOrigin=glGetUniformLocation(panel,"origin");
        } catch(RuntimeException e) {close();throw e;}
    }
    private static int program(String fragment) {
        int vs=0,fs=0,p=0;
        try {
            vs=shader(GL_VERTEX_SHADER,VERTEX);fs=shader(GL_FRAGMENT_SHADER,fragment);
            p=glCreateProgram();glAttachShader(p,vs);glAttachShader(p,fs);glLinkProgram(p);
            if(glGetProgrami(p,GL_LINK_STATUS)==0)throw new IllegalStateException(glGetProgramInfoLog(p));
            return p;
        } catch(RuntimeException e) {if(p!=0)glDeleteProgram(p);throw e;}
        finally {if(vs!=0)glDeleteShader(vs);if(fs!=0)glDeleteShader(fs);}
    }
    private static int shader(int type,String text) {
        int s=glCreateShader(type);glShaderSource(s,text);glCompileShader(s);
        if(glGetShaderi(s,GL_COMPILE_STATUS)==0){String error=glGetShaderInfoLog(s);glDeleteShader(s);throw new IllegalStateException(error);}
        return s;
    }
    private void resize(int w,int h) {
        if(width==w&&height==h)return;
        releaseTargets();
        glActiveTexture(GL_TEXTURE0);glBindBuffer(GL_PIXEL_UNPACK_BUFFER,0);
        try {
            // Allocate only the scene; Gaussian scratch/output targets are lazy.
            createTarget(0,(w+1)/2,(h+1)/2);
            width=w;height=h;
        } catch(RuntimeException e) {releaseTargets();throw e;}
    }
    private void createTarget(int i,int w,int h) {
        textures[i]=glGenTextures();fbos[i]=glGenFramebuffers();
        glBindTexture(GL_TEXTURE_2D,textures[i]);
        glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP_TO_EDGE);
        glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP_TO_EDGE);
        // Capture stores the scene's gamma-encoded bytes unchanged (sRGB writes
        // are disabled in setup). Sampling decodes them without per-tap pow().
        glTexImage2D(GL_TEXTURE_2D,0,i==0?GL_SRGB8_ALPHA8:GL_RGBA16F,w,h,0,GL_RGBA,GL_FLOAT,0L);
        glBindFramebuffer(GL_DRAW_FRAMEBUFFER,fbos[i]);
        glFramebufferTexture2D(GL_DRAW_FRAMEBUFFER,GL_COLOR_ATTACHMENT0,GL_TEXTURE_2D,textures[i],0);
        if(glCheckFramebufferStatus(GL_DRAW_FRAMEBUFFER)!=GL_FRAMEBUFFER_COMPLETE)throw new IllegalStateException("Incomplete glass framebuffer");
    }
    private void releaseTargets() {
        ready=false;blurred=false;width=height=0;
        for(int i=0;i<textures.length;i++){if(fbos[i]!=0)glDeleteFramebuffers(fbos[i]);if(textures[i]!=0)glDeleteTextures(textures[i]);fbos[i]=textures[i]=0;}
    }
    public void invalidate(){ready=false;blurred=false;}
    /** Hidden frames do no GPU work; brief F1/content changes retain allocations. */
    public void idle() {
        invalidate();
        if(vao!=0 && System.nanoTime()-lastCaptureNanos>=IDLE_RELEASE_NANOS)close();
    }
    @Override public void close() {
        releaseTargets();if(vao!=0)glDeleteVertexArrays(vao);if(blur!=0)glDeleteProgram(blur);if(panel!=0)glDeleteProgram(panel);
        vao=blur=panel=0;
        uploadedSigma=Float.NaN;
    }
    // Uniforms belong to this private program and survive GL program switches.
    private void uploadKernel(Kernel kernel) {
        if(uploadedSigma==kernel.sigma)return;
        kernel.upload(blurTaps,blurCount,blurCenter);
        uploadedSigma=kernel.sigma;
        kernelUploads++;
    }
    private static final class Kernel {
        final float[] pairs=new float[MAX_GAUSSIAN_PAIRS*2];
        float sigma=Float.NaN,center;
        int count;
        void update(float value) {
            if(sigma==value)return;
            sigma=value;
            int radius=Math.min(MAX_GAUSSIAN_PAIRS*2,(int)Math.ceil(value*3));
            double variance=(double)value*value,sum=1;
            for(int i=1;i<=radius;i++)sum+=2*Math.exp(-.5*i*i/variance);
            center=(float)(1/sum);count=(radius+1)/2;
            for(int i=1,p=0;i<=radius;i+=2,p+=2) {
                double a=Math.exp(-.5*i*i/variance);
                double b=i+1<=radius?Math.exp(-.5*(i+1)*(i+1)/variance):0;
                pairs[p]=(float)(i+b/(a+b));pairs[p+1]=(float)((a+b)/sum);
            }
        }
        void upload(int taps,int size,int weight) {
            glUniform2fv(taps,pairs);glUniform1i(size,count);glUniform1f(weight,center);
        }
    }
    /** Only touched state; no 16-unit scan or pixel pack/unpack parameter scan. */
    private static final class State {
        final int[] viewport=new int[4],scissor=new int[4],polygon=new int[2];
        final ByteBuffer mask=BufferUtils.createByteBuffer(4);
        final int[] caps={GL_BLEND,GL_DEPTH_TEST,GL_STENCIL_TEST,GL_CULL_FACE,GL_SCISSOR_TEST,GL_FRAMEBUFFER_SRGB,GL_RASTERIZER_DISCARD,GL_COLOR_LOGIC_OP};
        final boolean[] enabled=new boolean[caps.length];
        int active,texture,sampler,program,vao,read,draw,unpack,srcRGB,dstRGB,srcAlpha,dstAlpha,eqRGB,eqAlpha;
        void push() {
            active=glGetInteger(GL_ACTIVE_TEXTURE);glActiveTexture(GL_TEXTURE0);
            texture=glGetInteger(GL_TEXTURE_BINDING_2D);sampler=glGetInteger(GL_SAMPLER_BINDING);
            program=glGetInteger(GL_CURRENT_PROGRAM);vao=glGetInteger(GL_VERTEX_ARRAY_BINDING);
            read=glGetInteger(GL_READ_FRAMEBUFFER_BINDING);draw=glGetInteger(GL_DRAW_FRAMEBUFFER_BINDING);
            unpack=glGetInteger(GL_PIXEL_UNPACK_BUFFER_BINDING);
            glGetIntegerv(GL_VIEWPORT,viewport);glGetIntegerv(GL_SCISSOR_BOX,scissor);glGetIntegerv(GL_POLYGON_MODE,polygon);glGetBooleanv(GL_COLOR_WRITEMASK,mask);
            srcRGB=glGetInteger(GL_BLEND_SRC_RGB);dstRGB=glGetInteger(GL_BLEND_DST_RGB);
            srcAlpha=glGetInteger(GL_BLEND_SRC_ALPHA);dstAlpha=glGetInteger(GL_BLEND_DST_ALPHA);
            eqRGB=glGetInteger(GL_BLEND_EQUATION_RGB);eqAlpha=glGetInteger(GL_BLEND_EQUATION_ALPHA);
            for(int i=0;i<caps.length;i++)enabled[i]=glIsEnabled(caps[i]);
        }
        void pop() {
            glBindFramebuffer(GL_READ_FRAMEBUFFER,read);glBindFramebuffer(GL_DRAW_FRAMEBUFFER,draw);
            glViewport(viewport[0],viewport[1],viewport[2],viewport[3]);glScissor(scissor[0],scissor[1],scissor[2],scissor[3]);
            glColorMask(mask.get(0)!=0,mask.get(1)!=0,mask.get(2)!=0,mask.get(3)!=0);
            glPolygonMode(GL_FRONT_AND_BACK,polygon[0]);
            glBlendFuncSeparate(srcRGB,dstRGB,srcAlpha,dstAlpha);glBlendEquationSeparate(eqRGB,eqAlpha);
            for(int i=0;i<caps.length;i++){if(enabled[i])glEnable(caps[i]);else glDisable(caps[i]);}
            glUseProgram(program);glBindVertexArray(vao);glBindBuffer(GL_PIXEL_UNPACK_BUFFER,unpack);
            glActiveTexture(GL_TEXTURE0);glBindTexture(GL_TEXTURE_2D,texture);glBindSampler(0,sampler);glActiveTexture(active);
        }
    }
}
