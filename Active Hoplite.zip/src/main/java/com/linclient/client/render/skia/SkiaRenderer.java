/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.platform.NativeImage$Format
 *  com.mojang.blaze3d.platform.Window
 *  com.mojang.blaze3d.systems.RenderSystem
 *  com.mojang.blaze3d.textures.GpuTexture
 *  io.github.humbleui.skija.Canvas
 *  io.github.humbleui.skija.ColorAlphaType
 *  io.github.humbleui.skija.ColorInfo
 *  io.github.humbleui.skija.ColorType
 *  io.github.humbleui.skija.ImageInfo
 *  io.github.humbleui.skija.PixelGeometry
 *  io.github.humbleui.skija.Pixmap
 *  io.github.humbleui.skija.Surface
 *  io.github.humbleui.skija.SurfaceProps
 *  io.github.humbleui.skija.impl.Library
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.gui.GuiGraphics
 *  net.minecraft.client.renderer.RenderPipelines
 *  net.minecraft.client.renderer.texture.AbstractTexture
 *  net.minecraft.client.renderer.texture.DynamicTexture
 *  net.minecraft.resources.Identifier
 *  org.lwjgl.system.MemoryUtil
 */
package com.linclient.client.render.skia;

import com.linclient.client.render.skia.SkiaBlurRenderer;
import com.linclient.client.render.skia.SkiaGlBackend;
import com.mojang.blaze3d.platform.NativeImage;
import com.mojang.blaze3d.platform.Window;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.GpuTexture;
import io.github.humbleui.skija.Canvas;
import io.github.humbleui.skija.ColorAlphaType;
import io.github.humbleui.skija.ColorInfo;
import io.github.humbleui.skija.ColorType;
import io.github.humbleui.skija.ImageInfo;
import io.github.humbleui.skija.PixelGeometry;
import io.github.humbleui.skija.Pixmap;
import io.github.humbleui.skija.Surface;
import io.github.humbleui.skija.SurfaceProps;
import io.github.humbleui.skija.impl.Library;
import java.nio.ByteBuffer;
import java.util.Locale;
import java.util.Objects;
import java.util.function.Consumer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.renderer.texture.AbstractTexture;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.resources.Identifier;
import org.lwjgl.system.MemoryUtil;

@Environment(value=EnvType.CLIENT)
public class SkiaRenderer {
    private static final Identifier TEXTURE_ID = Identifier.fromNamespaceAndPath((String)"linclient", (String)"skia_frame");
    private static final Identifier REGION_TEXTURE_ID = Identifier.fromNamespaceAndPath((String)"linclient", (String)"skia_region");
    private static final SurfaceProps SURFACE_PROPS = new SurfaceProps(false, PixelGeometry.RGB_H);
    private static final long FRAME_IDLE_TIMEOUT_MS = 10000L;
    private static final long REGION_IDLE_TIMEOUT_MS = 5000L;
    private static final SkiaGlBackend GL_BACKEND = new SkiaGlBackend();
    private static final boolean USE_GL_BACKEND_FOR_FRAME = true;
    private static Surface surface;
    private static Surface regionSurface;
    private static DynamicTexture dynamicTexture;
    private static DynamicTexture regionTexture;
    private static int lastPixelW;
    private static int lastPixelH;
    private static int regionPixelW;
    private static int regionPixelH;
    private static int regionCapacityPixelW;
    private static int regionCapacityPixelH;
    private static float currentScale;
    private static int regionX;
    private static int regionY;
    private static int regionW;
    private static int regionH;
    private static boolean nativeLoaded;
    private static boolean drawing;
    private static boolean frameBatch;
    private static boolean regionDrawing;
    private static boolean frameDirty;
    private static boolean regionDirty;
    private static long lastFrameUseMs;
    private static long lastRegionUseMs;
    private static long regionContentHash;
    private static long lastUploadedRegionHash;
    private static boolean regionCacheValid;
    private static boolean regionCacheAllowed;

    private static void ensureNativeLoaded() {
        if (nativeLoaded) {
            return;
        }
        try {
            Library.load();
            nativeLoaded = true;
        }
        catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public static Canvas begin() {
        SkiaRenderer.ensureNativeLoaded();
        drawing = true;
        return GL_BACKEND.begin(SkiaBlurRenderer.mainFramebufferId(Minecraft.getInstance()));
    }

    public static Canvas beginRegion(int x, int y, int w, int h) {
        return SkiaRenderer.beginRegion(x, y, w, h, false);
    }

    public static Canvas beginRegion(int x, int y, int w, int h, boolean allowContentCache) {
        if (regionDrawing) {
            return regionSurface != null ? regionSurface.getCanvas() : null;
        }
        SkiaRenderer.ensureNativeLoaded();
        SkiaRenderer.pruneIdleSurfaces();
        regionCacheAllowed = allowContentCache;
        Window window = Minecraft.getInstance().getWindow();
        currentScale = window.getGuiScale();
        regionX = x;
        regionY = y;
        regionW = Math.max(1, w);
        regionH = Math.max(1, h);
        regionPixelW = Math.max(1, (int)Math.ceil((float)regionW * currentScale));
        regionPixelH = Math.max(1, (int)Math.ceil((float)regionH * currentScale));
        if (regionSurface == null || regionTexture == null || regionPixelW > regionCapacityPixelW || regionPixelH > regionCapacityPixelH) {
            int newPixelW = Math.max(regionPixelW, regionCapacityPixelW);
            int newPixelH = Math.max(regionPixelH, regionCapacityPixelH);
            SkiaRenderer.destroyRegionSurface();
            regionSurface = Surface.makeRaster((ImageInfo)new ImageInfo(new ColorInfo(ColorType.RGBA_8888, ColorAlphaType.UNPREMUL, null), newPixelW, newPixelH), (long)0L, (SurfaceProps)SURFACE_PROPS);
            regionTexture = new DynamicTexture("linclient:skia_region", newPixelW, newPixelH, false);
            Minecraft.getInstance().getTextureManager().register(REGION_TEXTURE_ID, (AbstractTexture)regionTexture);
            regionCapacityPixelW = newPixelW;
            regionCapacityPixelH = newPixelH;
            regionDirty = true;
            regionCacheValid = false;
        }
        Canvas canvas = regionSurface.getCanvas();
        canvas.restoreToCount(1);
        canvas.resetMatrix();
        canvas.clear(0);
        canvas.save();
        canvas.scale(currentScale, currentScale);
        canvas.translate((float)(-regionX), (float)(-regionY));
        regionDrawing = true;
        regionDirty = true;
        regionContentHash = 1L;
        SkiaRenderer.mixRegionHash(Float.floatToIntBits(currentScale));
        SkiaRenderer.mixRegionHash(regionX);
        SkiaRenderer.mixRegionHash(regionY);
        SkiaRenderer.mixRegionHash(regionW);
        SkiaRenderer.mixRegionHash(regionH);
        lastRegionUseMs = System.currentTimeMillis();
        return canvas;
    }

    private static void mixRegionHash(long value) {
        regionContentHash = regionContentHash * 31L + value;
    }

    public static void feedRegionContent(String text, float x, float y, float size, int argb, String fontName) {
        if (!regionDrawing) {
            return;
        }
        SkiaRenderer.mixRegionHash(text == null ? 0L : (long)text.hashCode());
        SkiaRenderer.mixRegionHash(Float.floatToIntBits(x));
        SkiaRenderer.mixRegionHash(Float.floatToIntBits(y));
        SkiaRenderer.mixRegionHash(Float.floatToIntBits(size));
        SkiaRenderer.mixRegionHash(argb);
        SkiaRenderer.mixRegionHash(fontName == null ? 0L : (long)fontName.hashCode());
    }

    public static boolean isRegionDrawing() {
        return regionDrawing;
    }

    public static float getScale() {
        return currentScale;
    }

    public static void beginFrameBatch() {
        frameBatch = true;
    }

    /** Text-only callers may share an enclosing HUD batch without ending it. */
    public static boolean isFrameBatch() {
        return frameBatch;
    }

    /** Submit queued Skija commands before a native pass, retaining the enclosing batch. */
    public static void flushForNative(GuiGraphics graphics) {
        if (!isDrawing()) return;
        boolean batch = frameBatch;
        frameBatch = false;
        try { end(graphics, graphics.guiWidth(), graphics.guiHeight()); }
        finally { frameBatch = batch; }
    }

    /** Only for NativeGlass, whose passes save and restore every GL state they touch. */
    public static boolean beginGlassPass(GuiGraphics graphics) {
        if (frameBatch && !regionDrawing && GL_BACKEND.isDrawing()) {
            GL_BACKEND.flushPending();
            return true;
        }
        flushForNative(graphics);
        return false;
    }

    public static void endGlassPass(boolean retainedSession) {
        if (retainedSession) GL_BACKEND.resumeAfterGlass();
    }

    public static void endFrameBatch(GuiGraphics graphics, int guiWidth, int guiHeight) {
        if (!frameBatch) {
            return;
        }
        frameBatch = false;
        SkiaRenderer.end(graphics, guiWidth, guiHeight);
    }

    public static boolean isMobileArm64() {
        String os = System.getProperty("os.name", "").toLowerCase(Locale.ROOT);
        String arch = System.getProperty("os.arch", "").toLowerCase(Locale.ROOT);
        return os.contains("linux") && (arch.contains("aarch64") || arch.contains("arm64"));
    }

    public static void end(GuiGraphics graphics, int guiWidth, int guiHeight) {
        if (frameBatch) {
            return;
        }
        try {
            GL_BACKEND.end();
        }
        finally {
            drawing = false;
        }
    }

    public static void endRegion(GuiGraphics graphics) {
        if (!regionDrawing || regionSurface == null || regionTexture == null) {
            return;
        }
        regionDrawing = false;
        try {
            boolean contentUnchanged;
            regionSurface.getCanvas().restore();
            boolean bl = contentUnchanged = regionCacheAllowed && regionCacheValid && regionContentHash == lastUploadedRegionHash;
            if (!contentUnchanged) {
                if (!SkiaRenderer.uploadSurface(regionSurface, regionTexture, regionCapacityPixelW, regionCapacityPixelH)) {
                    return;
                }
                lastUploadedRegionHash = regionContentHash;
                regionCacheValid = true;
            }
            graphics.blit(RenderPipelines.GUI_TEXTURED, REGION_TEXTURE_ID, regionX, regionY, 0.0f, 0.0f, regionW, regionH, regionPixelW, regionPixelH, regionCapacityPixelW, regionCapacityPixelH);
            regionDirty = false;
            lastRegionUseMs = System.currentTimeMillis();
        }
        finally {
            regionDrawing = false;
        }
    }

    public static void drawCached(GuiGraphics graphics, int guiWidth, int guiHeight) {
    }

    public static void drawCachedRegion(GuiGraphics graphics) {
        SkiaRenderer.pruneIdleSurfaces();
        if (regionTexture == null || regionCapacityPixelW <= 0 || regionCapacityPixelH <= 0) {
            return;
        }
        graphics.blit(RenderPipelines.GUI_TEXTURED, REGION_TEXTURE_ID, regionX, regionY, 0.0f, 0.0f, regionW, regionH, regionPixelW, regionPixelH, regionCapacityPixelW, regionCapacityPixelH);
        lastRegionUseMs = System.currentTimeMillis();
    }

    public static boolean isDrawing() {
        return drawing || GL_BACKEND.isDrawing();
    }

    public static boolean hasFrameCache() {
        return GL_BACKEND.hasSurface();
    }

    public static boolean supportsFrameCache() {
        return false;
    }

    public static boolean hasRegionCache() {
        return regionSurface != null && regionTexture != null;
    }

    public static void markFrameDirty() {
        frameDirty = true;
    }

    public static void markRegionDirty() {
        regionDirty = true;
        regionCacheValid = false;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private static boolean uploadSurface(Surface sourceSurface, DynamicTexture targetTexture, int uploadW, int uploadH) {
        try (Pixmap pixmap = new Pixmap();){
            if (!sourceSurface.peekPixels(pixmap)) {
                boolean bl = false;
                return bl;
            }
            long addr = pixmap.getAddr();
            int byteSize = uploadH * pixmap.getRowBytes();
            ByteBuffer buf = MemoryUtil.memByteBuffer((long)addr, (int)byteSize);
            GpuTexture gpuTexture = targetTexture.getTexture();
            RenderSystem.getDevice().createCommandEncoder().writeToTexture(gpuTexture, buf, NativeImage.Format.RGBA, 0, 0, 0, 0, uploadW, uploadH);
            boolean bl = true;
            return bl;
        }
    }

    private static void pruneIdleSurfaces() {
        long now = System.currentTimeMillis();
        if (!drawing && surface != null && lastFrameUseMs > 0L && now - lastFrameUseMs > 10000L) {
            SkiaRenderer.destroySurface();
            lastPixelW = -1;
            lastPixelH = -1;
            frameDirty = true;
            lastFrameUseMs = 0L;
        }
        if (!regionDrawing && regionSurface != null && lastRegionUseMs > 0L && now - lastRegionUseMs > 5000L) {
            SkiaRenderer.destroyRegionSurface();
            regionPixelW = -1;
            regionPixelH = -1;
            regionCapacityPixelW = -1;
            regionCapacityPixelH = -1;
            regionDirty = true;
            lastRegionUseMs = 0L;
        }
    }

    private static void destroySurface() {
        if (surface != null) {
            surface.close();
            surface = null;
        }
        if (dynamicTexture != null) {
            Minecraft.getInstance().getTextureManager().release(TEXTURE_ID);
            dynamicTexture = null;
        }
    }

    private static void destroyRegionSurface() {
        if (regionSurface != null) {
            regionSurface.close();
            regionSurface = null;
        }
        if (regionTexture != null) {
            Minecraft.getInstance().getTextureManager().release(REGION_TEXTURE_ID);
            regionTexture = null;
        }
        regionCacheValid = false;
    }

    public static void destroy() {
        GL_BACKEND.destroy();
        SkiaRenderer.destroySurface();
        SkiaRenderer.destroyRegionSurface();
        lastPixelW = -1;
        lastPixelH = -1;
        regionPixelW = -1;
        regionPixelH = -1;
        regionCapacityPixelW = -1;
        regionCapacityPixelH = -1;
        drawing = false;
        frameBatch = false;
        regionDrawing = false;
        frameDirty = true;
        regionDirty = true;
        lastFrameUseMs = 0L;
        lastRegionUseMs = 0L;
    }

    public static void resetFrameState() {
        Canvas canvas;
        drawing = false;
        frameBatch = false;
        regionDrawing = false;
        GL_BACKEND.resetCanvasState();
        if (surface != null) {
            canvas = surface.getCanvas();
            canvas.restoreToCount(1);
            canvas.resetMatrix();
        }
        if (regionSurface != null) {
            canvas = regionSurface.getCanvas();
            canvas.restoreToCount(1);
            canvas.resetMatrix();
        }
    }

    static {
        lastPixelW = -1;
        lastPixelH = -1;
        regionPixelW = -1;
        regionPixelH = -1;
        regionCapacityPixelW = -1;
        regionCapacityPixelH = -1;
        currentScale = 1.0f;
        regionX = 0;
        regionY = 0;
        regionW = 0;
        regionH = 0;
        nativeLoaded = false;
        drawing = false;
        frameBatch = false;
        regionDrawing = false;
        frameDirty = true;
        regionDirty = true;
        lastFrameUseMs = 0L;
        lastRegionUseMs = 0L;
        regionContentHash = 1L;
        lastUploadedRegionHash = 0L;
        regionCacheValid = false;
        regionCacheAllowed = false;
    }

    @Environment(value=EnvType.CLIENT)
    public static final class CachedRegion
    implements AutoCloseable {
        private final Identifier textureId;
        private final String debugName;
        private Surface cachedSurface;
        private DynamicTexture cachedTexture;
        private int pixelWidth = -1;
        private int pixelHeight = -1;
        private int lastX = Integer.MIN_VALUE;
        private int lastY = Integer.MIN_VALUE;
        private int lastWidth = -1;
        private int lastHeight = -1;
        private float lastScale = Float.NaN;
        private String lastStateKey;

        public CachedRegion(String path) {
            String safePath = path == null || path.isBlank() ? "cached_region" : path.toLowerCase().replaceAll("[^a-z0-9_./-]", "_");
            this.textureId = Identifier.fromNamespaceAndPath((String)"linclient", (String)safePath);
            this.debugName = "linclient:" + safePath;
        }

        /*
         * WARNING - Removed try catching itself - possible behaviour change.
         */
        public void render(GuiGraphics graphics, int x, int y, int width, int height, String stateKey, Consumer<Canvas> drawer) {
            render(graphics,x,y,width,height,stateKey,drawer,0xFFFFFFFF);
        }

        /** Tint is applied on GPU submission; animation must never invalidate the cached pixels. */
        public void render(GuiGraphics graphics, int x, int y, int width, int height, String stateKey, Consumer<Canvas> drawer, int tint) {
            boolean geometryChanged;
            if (graphics == null || drawer == null || width <= 0 || height <= 0) {
                return;
            }
            SkiaRenderer.ensureNativeLoaded();
            float scale = Minecraft.getInstance().getWindow().getGuiScale();
            int requiredPixelWidth = Math.max(1, (int)Math.ceil((float)width * scale));
            int requiredPixelHeight = Math.max(1, (int)Math.ceil((float)height * scale));
            boolean bl = geometryChanged = this.cachedSurface == null || this.cachedTexture == null || requiredPixelWidth != this.pixelWidth || requiredPixelHeight != this.pixelHeight || x != this.lastX || y != this.lastY || width != this.lastWidth || height != this.lastHeight || Float.compare(scale, this.lastScale) != 0;
            if (geometryChanged) {
                this.releaseResources();
                this.cachedSurface = Surface.makeRaster((ImageInfo)new ImageInfo(new ColorInfo(ColorType.RGBA_8888, ColorAlphaType.UNPREMUL, null), requiredPixelWidth, requiredPixelHeight), (long)0L, (SurfaceProps)SURFACE_PROPS);
                this.cachedTexture = new DynamicTexture(this.debugName, requiredPixelWidth, requiredPixelHeight, false);
                Minecraft.getInstance().getTextureManager().register(this.textureId, (AbstractTexture)this.cachedTexture);
                this.pixelWidth = requiredPixelWidth;
                this.pixelHeight = requiredPixelHeight;
                this.lastX = x;
                this.lastY = y;
                this.lastWidth = width;
                this.lastHeight = height;
                this.lastScale = scale;
                this.lastStateKey = null;
            }
            if (!Objects.equals(this.lastStateKey, stateKey)) {
                Canvas canvas = this.cachedSurface.getCanvas();
                canvas.restoreToCount(1);
                canvas.resetMatrix();
                canvas.clear(0);
                canvas.save();
                canvas.scale(scale, scale);
                canvas.translate((float)(-x), (float)(-y));
                try {
                    drawer.accept(canvas);
                }
                finally {
                    canvas.restore();
                }
                if (SkiaRenderer.uploadSurface(this.cachedSurface, this.cachedTexture, this.pixelWidth, this.pixelHeight)) {
                    this.lastStateKey = stateKey;
                }
            }
            graphics.blit(RenderPipelines.GUI_TEXTURED, this.textureId, x, y, 0.0f, 0.0f, width, height, this.pixelWidth, this.pixelHeight, this.pixelWidth, this.pixelHeight, tint);
        }

        public void invalidate() {
            this.lastStateKey = null;
        }

        @Override
        public void close() {
            this.releaseResources();
            this.pixelWidth = -1;
            this.pixelHeight = -1;
            this.lastStateKey = null;
        }

        private void releaseResources() {
            if (this.cachedSurface != null) {
                this.cachedSurface.close();
                this.cachedSurface = null;
            }
            if (this.cachedTexture != null) {
                Minecraft.getInstance().getTextureManager().release(this.textureId);
                this.cachedTexture = null;
            }
        }
    }
}


