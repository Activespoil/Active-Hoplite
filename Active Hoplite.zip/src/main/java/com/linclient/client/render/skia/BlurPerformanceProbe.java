package com.linclient.client.render.skia;

/** Short CPU sampling window; never waits for GPU completion or changes draw state. */
public final class BlurPerformanceProbe {
    public static final int HUD_SUITE=15, HUD_TARGET=16, HUD_SELF=17, HUD_SEASON=18,
            HUD_EQUIPMENT=19, HUD_RECIPE=20, HUD_PARTY=21, HUD_COUNTER=22, HUD_KEYS=23,
            HUD_COMPASS=24, HUD_DIRECTION=25, HUD_TEAM=26, HUD_ISLAND=27,
            HUD_INVENTORY=28, HUD_SCOREBOARD=29, HUD_COORDINATES=30, HUD_CHAT=31,
            HUD_POTIONS=32, HUD_COOLDOWNS=33, HUD_INVENTORY_ITEMS=34,
            HUD_COOLDOWN_ITEMS=35, HUD_POTION_ICONS=36,
            NATIVE_GLASS_CAPTURE=37, NATIVE_GAUSSIAN_PANEL=38;
    private static final String[] NAMES = {"capture", "panel-inclusive", "regions-inclusive", "skija-submit", "gl-state-save", "surface-prepare", "skija-state-reset", "gl-state-restore", "equipment-model-submit", "equipment-data-rebuild", "native-gui-render-inclusive", "native-item-prepare-inclusive", "native-item-atlas-redraw", "native-pip-prepare-inclusive", "native-item-resolve-submit",
            "hud-suite-inclusive", "hud-target-inclusive", "hud-self-inclusive", "hud-season-inclusive",
            "hud-equipment-inclusive", "hud-recipe-inclusive", "hud-party-inclusive", "hud-counter-inclusive",
            "hud-keys-inclusive", "hud-compass-inclusive", "hud-direction-inclusive", "hud-team-inclusive",
            "hud-island-inclusive", "hud-inventory-content-submit", "hud-scoreboard-content-submit",
            "hud-coordinates-content-submit", "hud-chat-content-submit", "hud-potions-content-submit",
            "hud-cooldowns-content-submit", "hud-inventory-items-submit", "hud-cooldown-items-submit", "hud-potion-icons-submit",
            "native-glass-capture", "native-gaussian-panel-inclusive"};
    private static final long[] CALLS = new long[NAMES.length], SAMPLES = new long[NAMES.length], TOTAL = new long[NAMES.length], MAX = new long[NAMES.length];
    private static final String[] GPU_NAMES = {"capture-copy", "skija-batch", "deferred-tooltip-cursor", "native-gui-render-inclusive", "native-item-prepare-inclusive", "native-pip-prepare-inclusive", "native-glass-capture", "native-gaussian-panels-inclusive"};
    private static final long[] GPU_CALLS = new long[GPU_NAMES.length], GPU_SAMPLES = new long[GPU_NAMES.length], GPU_TOTAL = new long[GPU_NAMES.length], GPU_MAX = new long[GPU_NAMES.length];
    private static final int[] QUERY_START = new int[32], QUERY_END = new int[32], QUERY_STAGE = new int[32], QUERY_STATE = new int[32];
    private static int queryCursor;
    private static Boolean timerSupported;
    private static long deadline;
    private BlurPerformanceProbe() {}
    public static long begin(int stage) {
        if (net.minecraft.client.Minecraft.getInstance().player == null) { deadline = 0; return 0; }
        long calls = ++CALLS[stage];
        if ((calls & 63) != 1) return 0;
        long now = System.nanoTime();
        if (deadline == 0) {
            clear(); deadline = now + 10_000_000_000L;
            CALLS[stage] = 1;
        }
        if (now >= deadline) {
            report(); clear(); deadline = System.nanoTime() + 60_000_000_000L;
            CALLS[stage] = 1; return System.nanoTime();
        }
        return now;
    }
    public static void end(int stage, long started) {
        if (started == 0) return;
        long elapsed = System.nanoTime() - started;
        SAMPLES[stage]++;
        TOTAL[stage] += elapsed;
        MAX[stage] = Math.max(MAX[stage], elapsed);
    }
    /** Timestamp pairs have no GL binding state; unavailable results are never waited on. */
    public static int beginGpu(int stage) {
        if (net.minecraft.client.Minecraft.getInstance().player == null) return 0;
        if ((++GPU_CALLS[stage] & 63) != 1) return 0;
        if (timerSupported == null) {
            var caps = org.lwjgl.opengl.GL.getCapabilities();
            timerSupported = caps.OpenGL33 || caps.GL_ARB_timer_query;
        }
        if (!timerSupported) return 0;
        drainGpu();
        int slot = queryCursor;
        if (QUERY_STATE[slot] != 0) return 0; // A busy GPU must not stall the render thread.
        queryCursor = (slot + 1) % QUERY_STATE.length;
        if (QUERY_START[slot] == 0) {
            QUERY_START[slot] = org.lwjgl.opengl.GL15.glGenQueries();
            QUERY_END[slot] = org.lwjgl.opengl.GL15.glGenQueries();
        }
        QUERY_STAGE[slot] = stage;
        QUERY_STATE[slot] = 1;
        org.lwjgl.opengl.GL33.glQueryCounter(QUERY_START[slot], org.lwjgl.opengl.GL33.GL_TIMESTAMP);
        return slot + 1;
    }

    public static void endGpu(int token) {
        if (token == 0) return;
        int slot = token - 1;
        org.lwjgl.opengl.GL33.glQueryCounter(QUERY_END[slot], org.lwjgl.opengl.GL33.GL_TIMESTAMP);
        QUERY_STATE[slot] = 2;
    }

    private static void drainGpu() {
        for (int i = 0; i < QUERY_STATE.length; i++) {
            if (QUERY_STATE[i] != 2 || org.lwjgl.opengl.GL15.glGetQueryObjecti(
                    QUERY_END[i], org.lwjgl.opengl.GL15.GL_QUERY_RESULT_AVAILABLE) == 0) continue;
            long start = org.lwjgl.opengl.GL33.glGetQueryObjectui64(QUERY_START[i], org.lwjgl.opengl.GL15.GL_QUERY_RESULT);
            long end = org.lwjgl.opengl.GL33.glGetQueryObjectui64(QUERY_END[i], org.lwjgl.opengl.GL15.GL_QUERY_RESULT);
            int stage = QUERY_STAGE[i];
            long elapsed = Math.max(0, end - start);
            GPU_SAMPLES[stage]++;
            GPU_TOTAL[stage] += elapsed;
            GPU_MAX[stage] = Math.max(GPU_MAX[stage], elapsed);
            QUERY_STATE[i] = 0;
        }
    }

    private static void report() {
        StringBuilder out = new StringBuilder("Lin blur CPU samples (first window 10 seconds, then 60 seconds, 1/64 calls). Inclusive timings overlap; not GPU execution time.\n");
        for (int i = 0; i < NAMES.length; i++) {
            out.append(NAMES[i]).append(": calls=").append(CALLS[i]).append(", samples=").append(SAMPLES[i])
               .append(", average_us=").append(SAMPLES[i] == 0 ? 0 : TOTAL[i] / SAMPLES[i] / 1000)
               .append(", max_us=").append(MAX[i] / 1000).append('\n');
        }
        if (Boolean.TRUE.equals(timerSupported)) {
            drainGpu();
            out.append("GPU timestamp intervals (async, 1/64; includes submission gaps; native GUI includes all game/mod GUI, nested intervals overlap; tooltip/cursor is not item rendering):\n");
            for (int i = 0; i < GPU_NAMES.length; i++) {
                out.append(GPU_NAMES[i]).append(": calls=").append(GPU_CALLS[i]).append(", samples=").append(GPU_SAMPLES[i])
                   .append(", average_us=").append(GPU_SAMPLES[i] == 0 ? 0 : GPU_TOTAL[i] / GPU_SAMPLES[i] / 1000)
                   .append(", max_us=").append(GPU_MAX[i] / 1000).append('\n');
            }
        }
        System.out.println("[Lin Blur Performance] " + out);
    }
    private static void clear() {
        java.util.Arrays.fill(CALLS, 0); java.util.Arrays.fill(SAMPLES, 0);
        java.util.Arrays.fill(TOTAL, 0); java.util.Arrays.fill(MAX, 0);
        java.util.Arrays.fill(GPU_CALLS, 0); java.util.Arrays.fill(GPU_SAMPLES, 0);
        java.util.Arrays.fill(GPU_TOTAL, 0); java.util.Arrays.fill(GPU_MAX, 0);
    }
}
