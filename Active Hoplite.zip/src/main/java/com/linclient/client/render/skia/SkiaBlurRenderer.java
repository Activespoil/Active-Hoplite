package com.linclient.client.render.skia;

import com.mojang.blaze3d.opengl.GlDevice;
import com.mojang.blaze3d.opengl.GlTexture;
import com.mojang.blaze3d.systems.RenderSystem;
import io.github.humbleui.skija.Canvas;
import io.github.humbleui.skija.ClipMode;
import io.github.humbleui.skija.ColorFilter;
import io.github.humbleui.skija.ColorType;
import io.github.humbleui.skija.DirectContext;
import io.github.humbleui.skija.FilterTileMode;
import io.github.humbleui.skija.Image;
import io.github.humbleui.skija.ImageFilter;
import io.github.humbleui.skija.Paint;
import io.github.humbleui.skija.PaintMode;
import io.github.humbleui.skija.SamplingMode;
import io.github.humbleui.skija.SurfaceOrigin;
import io.github.humbleui.skija.Surface;
import io.github.humbleui.skija.ImageInfo;
import io.github.humbleui.skija.ColorAlphaType;
import io.github.humbleui.skija.ColorSpace;
import io.github.humbleui.skija.impl.Library;
import io.github.humbleui.types.RRect;
import io.github.humbleui.types.Rect;
import net.minecraft.client.Minecraft;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import static org.lwjgl.opengl.GL45.*;

public final class SkiaBlurRenderer {
    private static final SkiaBlurRenderer INSTANCE = new SkiaBlurRenderer();
    private static final float MIN_CAPTURE_MARGIN = 18f;
    private static final int MAX_FILTER_CACHE = 8;
    private static final int CAPTURE_DOWNSAMPLE = 2;
    private static final int MIN_MERGED_REGIONS = 4;
    private static final double MAX_MERGED_AREA_RATIO = 2.5d;
    private final Paint blurPaint = new Paint().setAntiAlias(true);
    private final Paint frostPaint = new Paint().setAntiAlias(true);
    private final Paint tintPaint = new Paint().setAntiAlias(true);
    private final Paint outlinePaint = new Paint().setAntiAlias(true).setMode(PaintMode.STROKE).setStrokeWidth(1f);
    private final SkiaGlBackend framebufferBackend = new SkiaGlBackend();
    private final List<CaptureTarget> captureTargets = new ArrayList<>();
    private final int[] oldTexture = new int[1];
    private final int[] oldActiveTexture = new int[1];
    private final int[] oldSampler = new int[1];
    private final int[] oldReadFramebuffer = new int[1];
    private final int[] oldDrawFramebuffer = new int[1];
    private final int[] oldReadBuffer = new int[1];
    private final int[] oldDrawBuffer = new int[1];
    private final int[] oldViewport = new int[4];
    private final int[] oldScissorBox = new int[4];
    private ImageFilter encodeFilter;
    private int selectedFilterKey;
    private final Map<Integer, FilterSet> filterCache = new LinkedHashMap<>(8, .75f, true);
    private boolean nativeLoaded = false;
    private DirectContext capturePoolContext;
    private int captureTargetCursor;
    // Menu scene storage is independent of the HUD capture slots.
    private CaptureTarget menuCaptureTarget;
    private DirectContext menuCaptureContext;
    private SkiaGlBackend sharedFrameBackend;
    private boolean sharedFrameBackendResolved;
    private boolean sharedFrameActive;
    private Capture hudFrameSource = Capture.EMPTY;
    private DirectContext hudFrameSourceContext;
    private int hudFrameSourceFramebufferId = -1;
    private int captureFramebufferWidth = -1;
    private int captureFramebufferHeight = -1;
    private int captureGuiWidth = -1;
    private int captureGuiHeight = -1;
    private double captureGuiScale = Double.NaN;
    // Two independently configurable strengths cover the common HUD case.
    // Surfaces survive frames; their images never survive a scene refresh.
    private final Map<Integer, FrameBlur> frameBlurs = new LinkedHashMap<>();

    private static final class FrameBlur {
        Surface surface;
        Image image;
        int uses, previousUses;
        boolean unavailable;
        void reset() {
            if (image != null) { image.close(); image = null; }
            previousUses = uses;
            uses = 0;
        }
        void close() { reset(); if (surface != null) { surface.close(); surface = null; } }
    }

    private Image sharedBlur(DirectContext context, Capture capture, float sigma, int panels) {
        if (capture != hudFrameSource || capture.image == null) return null;
        int key = Float.floatToIntBits(sigma);
        FrameBlur entry = frameBlurs.get(key);
        if (entry == null) {
            if (frameBlurs.size() >= 2) {
                var iterator = frameBlurs.entrySet().iterator();
                boolean removed = false;
                while (iterator.hasNext()) {
                    FrameBlur old = iterator.next().getValue();
                    if (old.uses == 0) { old.close(); iterator.remove(); removed = true; break; }
                }
                if (!removed) return null;
            }
            entry = new FrameBlur();
            frameBlurs.put(key, entry);
        }
        entry.uses += panels;
        // A lone small panel is cheaper locally. Promote repeated consumers;
        // remember demand for one frame so stable HUDs share from their first draw.
        int threshold = Math.max(4, (int)Math.ceil((double)captureFramebufferWidth * captureFramebufferHeight / (1920 * 1080) * 4));
        if (entry.unavailable) return null;
        if (entry.image == null && Math.max(entry.uses, entry.previousUses) < threshold) return null;
        try {
        if (entry.surface == null) {
            entry.surface = Surface.makeRenderTarget(context, false, new ImageInfo(
                    captureFramebufferWidth, captureFramebufferHeight, ColorType.RGBA_8888,
                    ColorAlphaType.PREMUL, ColorSpace.getSRGB()));
            if (entry.surface == null) return null;
        }
        if (entry.image == null) {
            Canvas target = entry.surface.getCanvas();
            target.clear(0);
            target.save();
            try {
                target.scale((float) captureGuiScale, (float) captureGuiScale);
                blurPaint.setImageFilter(encodeFilter);
                target.drawImageRect(capture.image, Rect.makeWH(capture.width, capture.height),
                        Rect.makeXYWH(capture.dstX, capture.dstY, capture.dstW, capture.dstH),
                        SamplingMode.LINEAR, blurPaint, true);
            } finally {
                blurPaint.setImageFilter(null);
                target.restore();
            }
            entry.image = entry.surface.makeImageSnapshot();
        }
        return entry.image;
        } catch (RuntimeException failure) {
            entry.close();
            entry.unavailable = true;
            System.err.println("[Lin HUD] Shared blur unavailable; using local blur: " + failure.getMessage());
            return null;
        }
    }

    private SkiaBlurRenderer() {}

    public static SkiaBlurRenderer getInstance() {
        return INSTANCE;
    }

    public static int currentDrawFramebufferId() {
        return glGetInteger(GL_DRAW_FRAMEBUFFER_BINDING);
    }

    public boolean render(Minecraft client, float x, float y, float width, float height, float radius, int tintColor, float strength) {
        if (client == null || client.getWindow() == null || client.getMainRenderTarget() == null) return false;
        int framebufferId = mainFramebufferId(client);
        Canvas canvas = framebufferBackend.begin(framebufferId);
        DirectContext context = framebufferBackend.getContext();
        if (canvas == null || context == null) {
            framebufferBackend.end();
            return false;
        }
        beginCaptureBatch(context);
        try {
            return render(canvas, context, client, framebufferId, x, y, width, height,
                    radius, tintColor, strength, true, true);
        } finally {
            framebufferBackend.end();
        }
    }

    /** Rounded glass panel used by HUD elements that also need an optional outline. */
    public boolean renderPanel(Minecraft client, float x, float y, float width, float height,
                               float radius, int tintColor, float strength, int borderColor) {
        return renderPanel(client,x,y,width,height,radius,tintColor,strength,borderColor,null);
    }

    /** One filtered panel draw, clipped to the occupied HUD shape in GUI coordinates. */
    public boolean renderPanel(Minecraft client, float x, float y, float width, float height,
                               float radius, int tintColor, float strength, int borderColor,
                               io.github.humbleui.skija.Path occupied) {
        if (client == null || client.getWindow() == null || client.getMainRenderTarget() == null
                || width <= 0f || height <= 0f) return false;
        int framebufferId = mainFramebufferId(client);
        SkiaGlBackend sharedBackend = sharedFrameBackend();
        if (sharedBackend != null) {
            Canvas canvas = SkiaRenderer.begin();
            DirectContext context = sharedBackend.getContext();
            if (canvas == null || context == null) return false;
            beginSharedFrame(context);
            return renderPanel(canvas, context, client, framebufferId,
                    x, y, width, height, radius, tintColor, strength, borderColor, false, occupied);
        }
        Canvas canvas = framebufferBackend.begin(framebufferId);
        DirectContext context = framebufferBackend.getContext();
        if (canvas == null || context == null) {
            framebufferBackend.end();
            return false;
        }
        beginCaptureBatch(context);
        try {
            return renderPanel(canvas, context, client, framebufferId,
                    x, y, width, height, radius, tintColor, strength, borderColor, true, occupied);
        } finally {
            framebufferBackend.end();
        }
    }

    public boolean renderRegions(Minecraft client, List<Region> regions, int tintColor, float strength) {
        if (client == null || client.getWindow() == null || client.getMainRenderTarget() == null || regions == null || regions.isEmpty()) {
            return false;
        }
        int framebufferId = mainFramebufferId(client);
        SkiaGlBackend sharedBackend = sharedFrameBackend();
        if (sharedBackend != null) {
            Canvas canvas = SkiaRenderer.begin();
            DirectContext context = sharedBackend.getContext();
            if (canvas == null || context == null) return false;
            beginSharedFrame(context);
            return renderRegions(canvas, context, client, framebufferId, regions, tintColor, strength, true, false);
        }
        Canvas canvas = framebufferBackend.begin(framebufferId);
        DirectContext context = framebufferBackend.getContext();
        if (canvas == null || context == null) {
            framebufferBackend.end();
            return false;
        }
        beginCaptureBatch(context);
        try {
            return renderRegions(canvas, context, client, framebufferId, regions, tintColor, strength, true, true);
        } finally {
            framebufferBackend.end();
        }
    }

    /** Called after the shared Skija canvas has submitted all HUD work for this frame. */
    public static void onFrameSubmitted() {
        INSTANCE.sharedFrameActive = false;
        // Keep slot zero reserved for the clean HUD frame until Gui#render
        // finishes. Late HUD renderers (NameTags equipment, Equipment HUD and
        // ItemESP) submit separate Skija batches but must sample the same frame.
        INSTANCE.captureTargetCursor = INSTANCE.hudFrameSource.image == null ? 0 : 1;
    }

    /** Ends the clean-frame lifetime after every HUD layer has rendered. */
    public static void finishHudFrame() {
        INSTANCE.sharedFrameActive = false;
        INSTANCE.captureTargetCursor = 0;
        INSTANCE.clearHudFrameSource();
        for (FrameBlur blur : INSTANCE.frameBlurs.values()) blur.close();
        INSTANCE.frameBlurs.clear();
    }

    /** Captures the game once before any Lin HUD is drawn; every HUD then samples this same clean frame. */
    public boolean beginHudFrame(Minecraft client) {
        return captureHudFrame(client, false);
    }

    /** Starts a new Gui render pass and replaces any snapshot left by the previous frame. */
    public boolean startHudFrame(Minecraft client) {
        return captureHudFrame(client, true);
    }

    private boolean captureHudFrame(Minecraft client, boolean force) {
        if (client == null || client.getWindow() == null || client.getMainRenderTarget() == null) return false;
        SkiaGlBackend sharedBackend = sharedFrameBackend();
        if (sharedBackend == null) return false;
        int framebufferId = mainFramebufferId(client);
        DirectContext existingContext = sharedBackend.getContext();
        if (!force && captureGeometryMatches(client) && hudFrameSource.image != null
                && hudFrameSourceContext == existingContext
                && hudFrameSourceFramebufferId == framebufferId) return true;
        // Copying a texture does not require starting a Skija canvas. The old
        // path created an otherwise empty batch at Gui HEAD on every frame.
        DirectContext context = sharedBackend.contextForCapture();
        if (context == null) return false;

        clearHudFrameSource();
        ensureCaptureGeometry(client);
        beginSharedFrame(context);
        hudFrameSource = captureRegion(context, client, framebufferId,
                0f, 0f, client.getWindow().getGuiScaledWidth(), client.getWindow().getGuiScaledHeight(),
                (float) client.getWindow().getGuiScale(), 0f, true, true);
        hudFrameSourceContext = context;
        hudFrameSourceFramebufferId = framebufferId;
        return hudFrameSource.image != null;
    }

    private boolean renderPanel(Canvas canvas, DirectContext context, Minecraft client, int framebufferId,
                                float x, float y, float width, float height, float radius,
                                int tintColor, float strength, int borderColor, boolean flushCapture,
                                io.github.humbleui.skija.Path occupied) {
        canvas.save();
        try {
        if (occupied != null) canvas.clipPath(occupied, true);
        RRect panel = RRect.makeXYWH(x, y, width, height,
                Math.max(0f, Math.min(radius, Math.min(width, height) * .5f)));
        boolean drawn;
        if (strength > .01f) {
            drawn = render(canvas, context, client, framebufferId,
                    x, y, width, height, radius, tintColor, strength, true, flushCapture);
        } else {
            tintPaint.setColor(tintColor);
            canvas.drawRRect(panel, tintPaint);
            drawn = true;
        }
        if ((borderColor >>> 24) != 0) {
            outlinePaint.setColor(borderColor);
            canvas.drawRRect(panel, outlinePaint);
        }
        return drawn;
        } finally { canvas.restore(); }
    }

    private void beginSharedFrame(DirectContext context) {
        if (sharedFrameActive && capturePoolContext == context) return;
        beginCaptureBatch(context);
        if (hudFrameSource.image != null && hudFrameSourceContext == context) {
            captureTargetCursor = 1;
        }
        sharedFrameActive = true;
    }

    private SkiaGlBackend sharedFrameBackend() {
        if (sharedFrameBackendResolved) return sharedFrameBackend;
        sharedFrameBackendResolved = true;
        try {
            Field field = SkiaRenderer.class.getDeclaredField("GL_BACKEND");
            field.setAccessible(true);
            sharedFrameBackend = (SkiaGlBackend) field.get(null);
        } catch (ReflectiveOperationException | RuntimeException ignored) {
            sharedFrameBackend = null;
        }
        return sharedFrameBackend;
    }

    public boolean renderRegions(Canvas canvas, DirectContext context, Minecraft client, int sourceFramebufferId,
                                 List<Region> regions, int tintColor, float strength) {
        if (canvas == null || context == null || client == null || client.getWindow() == null
                || regions == null || regions.isEmpty()) return false;
        return renderRegions(canvas, context, client, sourceFramebufferId, regions, tintColor, strength, false, true);
    }

    /**
     * Draws glass over a rectangular area while leaving the supplied rounded
     * regions untouched. This is used by ClickGUI to style the game scene
     * around the menu without blurring or tinting the menu itself.
     */
    public boolean renderOutside(Canvas canvas, DirectContext context, Minecraft client, int sourceFramebufferId,
                                 float x, float y, float width, float height, List<Region> excludedRegions,
                                 int tintColor, float strength) {
        if (canvas == null || context == null || client == null || client.getWindow() == null
                || width <= 0f || height <= 0f) return false;

        float clampedStrength = Math.max(0f, Math.min(2f, strength));
        Capture capture = Capture.EMPTY;
        if (clampedStrength > .01f) {
            ensureNativeLoaded();
            float scale = (float) client.getWindow().getGuiScale();
            float blurSigma = blurSigma(clampedStrength);
            capture = captureRegion(context, client, sourceFramebufferId, x, y, width, height, scale,
                    Math.max(MIN_CAPTURE_MARGIN, blurSigma * 2f));
            if (capture.image == null) return false;
            ensureFilters(blurSigma);
        }

        canvas.save();
        try {
            canvas.clipRect(Rect.makeXYWH(x, y, width, height), true);
            if (excludedRegions != null) {
                for (Region region : excludedRegions) {
                    if (region == null || region.width() <= 0f || region.height() <= 0f) continue;
                    float radius = Math.max(0f, Math.min(region.radius(),
                            Math.min(region.width(), region.height()) * .5f));
                    canvas.clipRRect(RRect.makeXYWH(region.x(), region.y(), region.width(), region.height(), radius),
                            ClipMode.DIFFERENCE, true);
                }
            }

            Rect area = Rect.makeXYWH(x, y, width, height);
            if (capture.image != null) {
                blurPaint.setImageFilter(encodeFilter);
                canvas.drawImageRect(capture.image,
                        Rect.makeXYWH(0f, 0f, capture.width, capture.height),
                        Rect.makeXYWH(capture.dstX, capture.dstY, capture.dstW, capture.dstH),
                        SamplingMode.LINEAR,
                        blurPaint,
                        true);
                frostPaint.setColor(0x10000000);
                canvas.drawRect(area, frostPaint);
            }
            if ((tintColor >>> 24) != 0) {
                tintPaint.setColor(tintColor);
                canvas.drawRect(area, tintPaint);
            }
            return capture.image != null || (tintColor >>> 24) != 0;
        } finally {
            blurPaint.setImageFilter(null);
            canvas.restore();
            capture.close();
        }
    }

    public boolean render(Canvas canvas, DirectContext context, Minecraft client, int sourceFramebufferId,
                          float x, float y, float width, float height, float radius, int tintColor, float strength) {
        return render(canvas, context, client, sourceFramebufferId,
                x, y, width, height, radius, tintColor, strength, false, true);
    }

    /** ClickGUI compatibility entry: reading-surface color is owned by ClientShell. */
    public boolean renderLens(Canvas canvas, DirectContext context, Minecraft client, int sourceFramebufferId,
                              float x, float y, float width, float height, float radius,
                              int tintColor, float strength, float scale, float refraction, float dispersion) {
        if (client == null || client.getWindow() == null) return false;
        return renderMenu(canvas, context, client, sourceFramebufferId,
                client.getWindow().getGuiScaledWidth(), client.getWindow().getGuiScaledHeight(),
                new Region(x,y,width,height,radius), 0, 0, strength, scale, refraction, dispersion);
    }

    /** One fresh, reusable scene copy supplies outside blur and the lens material. */
    public boolean renderMenu(Canvas canvas, DirectContext context, Minecraft client, int framebufferId,
                              int screenWidth, int screenHeight, Region panel, int outsideTint,
                              float outsideStrength, float panelStrength, float scale,
                              float refraction, float dispersion) {
        if (canvas == null || context == null || client == null || client.getWindow() == null
                || panel == null || panel.width <= 0 || panel.height <= 0) return false;
        ensureNativeLoaded();
        float guiScale=(float)client.getWindow().getGuiScale();
        Capture capture=captureRegionUnprofiled(context,client,framebufferId,0,0,
                screenWidth,screenHeight,guiScale,0,false,true,true);
        if(capture.image==null)return false;
        RRect shape=RRect.makeXYWH(panel.x,panel.y,panel.width,panel.height,
                Math.max(0,Math.min(panel.radius,Math.min(panel.width,panel.height)*.5f)));
        canvas.save();
        try {
            if(outsideStrength>.01f || outsideTint>>>24!=0){
                canvas.save();
                try {
                    canvas.clipRect(Rect.makeWH(screenWidth,screenHeight),true);
                    canvas.clipRRect(shape,ClipMode.DIFFERENCE,true);
                    drawMenuScene(canvas,capture,outsideStrength);
                    if(outsideTint>>>24!=0){tintPaint.setColor(outsideTint);canvas.drawRect(Rect.makeWH(screenWidth,screenHeight),tintPaint);}
                }finally{canvas.restore();}
            }
            canvas.save();
            try{canvas.clipRRect(shape,true);drawMenuScene(canvas,capture,panelStrength);}
            finally{canvas.restore();}
            // No black frost or second body tint: the shell owns its single white reading surface.
            LensOptics.draw(canvas,capture.image,capture.dstX,capture.dstY,capture.dstW,capture.dstH,
                    panel.x,panel.y,panel.width,panel.height,panel.radius,scale,refraction,dispersion);
            return true;
        }finally{blurPaint.setImageFilter(null);canvas.restore();}
    }

    private void drawMenuScene(Canvas canvas,Capture capture,float strength){
        if(strength>.01f)ensureFilters(blurSigma(strength));
        blurPaint.setImageFilter(strength>.01f?encodeFilter:null);
        try{canvas.drawImageRect(capture.image,Rect.makeWH(capture.width,capture.height),
                Rect.makeXYWH(capture.dstX,capture.dstY,capture.dstW,capture.dstH),SamplingMode.LINEAR,blurPaint,true);}
        finally{blurPaint.setImageFilter(null);}
    }

    public boolean hasMenuCapture(){return menuCaptureTarget!=null;}
    /** Render boundary only, after the preceding menu frame was submitted. */
    public void releaseMenuCapture(){
        if(menuCaptureTarget!=null)destroyCaptureTarget(menuCaptureTarget);
        menuCaptureTarget=null;menuCaptureContext=null;
    }

    private CaptureTarget acquireMenuCapture(DirectContext context,int width,int height){
        if(menuCaptureTarget!=null && menuCaptureContext==context
                && menuCaptureTarget.width==width && menuCaptureTarget.height==height)return menuCaptureTarget;
        releaseMenuCapture();
        menuCaptureTarget=createCaptureTarget(context,width,height);
        menuCaptureContext=context;
        return menuCaptureTarget;
    }

    private boolean render(Canvas canvas, DirectContext context, Minecraft client, int sourceFramebufferId,
                           float x, float y, float width, float height, float radius, int tintColor, float strength,
                           boolean pooledCapture, boolean flushCapture) {
        long started = BlurPerformanceProbe.begin(1);
        try { return renderUnprofiled(canvas, context, client, sourceFramebufferId, x, y, width, height, radius, tintColor, strength, pooledCapture, flushCapture); }
        finally { BlurPerformanceProbe.end(1, started); }
    }

    private boolean renderUnprofiled(Canvas canvas, DirectContext context, Minecraft client, int sourceFramebufferId,
                           float x, float y, float width, float height, float radius, int tintColor, float strength,
                           boolean pooledCapture, boolean flushCapture) {
        if (canvas == null || context == null || client == null || client.getWindow() == null) return false;
        ensureNativeLoaded();

        Capture cleanFrame = cleanHudFrame(context, sourceFramebufferId, client);
        float scale = (float) client.getWindow().getGuiScale();
        float blurSigma = blurSigma(strength);
        Capture capture = cleanFrame.image != null ? cleanFrame
                : captureRegion(context, client, sourceFramebufferId, x, y, width, height, scale,
                Math.max(MIN_CAPTURE_MARGIN, blurSigma * 2f), pooledCapture, flushCapture);
        if (capture.image == null) return false;

        ensureFilters(blurSigma);
        Image shared = sharedBlur(context, capture, blurSigma, 1);
        RRect shape = RRect.makeXYWH(x, y, width, height, radius);
        canvas.save();
        try {
            canvas.clipRRect(shape, true);
            blurPaint.setImageFilter(shared == null ? encodeFilter : null);
            canvas.drawImageRect(shared == null ? capture.image : shared,
                    Rect.makeWH(shared == null ? capture.width : shared.getWidth(), shared == null ? capture.height : shared.getHeight()),
                    Rect.makeXYWH(capture.dstX, capture.dstY, capture.dstW, capture.dstH),
                    SamplingMode.LINEAR,
                    blurPaint,
                    true);

            frostPaint.setColor(0x10000000);
            canvas.drawRRect(shape, frostPaint);

            tintPaint.setColor(tintColor);
            if ((tintColor >>> 24) != 0) canvas.drawRRect(shape, tintPaint);
            return true;
        } finally {
            blurPaint.setImageFilter(null);
            canvas.restore();
            if (capture != cleanFrame) capture.close();
        }
    }

    private boolean renderRegions(Canvas canvas, DirectContext context, Minecraft client, int sourceFramebufferId,
                                  List<Region> regions, int tintColor, float strength, boolean pooledCapture,
                                  boolean flushCaptureBatch) {
        long started = BlurPerformanceProbe.begin(2);
        try { return renderRegionsUnprofiled(canvas, context, client, sourceFramebufferId, regions, tintColor, strength, pooledCapture, flushCaptureBatch); }
        finally { BlurPerformanceProbe.end(2, started); }
    }

    private boolean renderRegionsUnprofiled(Canvas canvas, DirectContext context, Minecraft client, int sourceFramebufferId,
                                  List<Region> regions, int tintColor, float strength, boolean pooledCapture,
                                  boolean flushCaptureBatch) {
        ensureNativeLoaded();
        Capture cleanFrame = cleanHudFrame(context, sourceFramebufferId, client);
        float scale = (float) client.getWindow().getGuiScale();
        float blurSigma = blurSigma(strength);
        // The scene has already been copied and submitted once for this HUD
        // frame. Draw directly from it without allocating a second capture batch.
        if (cleanFrame.image != null) {
            return drawSharedRegions(canvas, context, cleanFrame, regions, tintColor, blurSigma);
        }
        float margin = Math.max(MIN_CAPTURE_MARGIN, blurSigma * 2f);
        List<Region> validRegions = new ArrayList<>(regions.size());
        List<Capture> captures = new ArrayList<>(regions.size());
        float minX = Float.POSITIVE_INFINITY;
        float minY = Float.POSITIVE_INFINITY;
        float maxX = Float.NEGATIVE_INFINITY;
        float maxY = Float.NEGATIVE_INFINITY;
        double individualArea = 0d;
        for (Region region : regions) {
            if (region == null || region.width() <= 0f || region.height() <= 0f) continue;
            validRegions.add(region);
            minX = Math.min(minX, region.x());
            minY = Math.min(minY, region.y());
            maxX = Math.max(maxX, region.x() + region.width());
            maxY = Math.max(maxY, region.y() + region.height());
            individualArea += (region.width() + margin * 2f) * (region.height() + margin * 2f);
        }
        if (validRegions.isEmpty()) return false;

        double mergedArea = (maxX - minX + margin * 2f) * (maxY - minY + margin * 2f);
        boolean mergeCaptures = validRegions.size() >= MIN_MERGED_REGIONS
                && mergedArea <= individualArea * MAX_MERGED_AREA_RATIO;
        Capture mergedCapture = cleanFrame;
        try {
            if (mergedCapture.image == null && mergeCaptures) {
                mergedCapture = captureRegion(context, client, sourceFramebufferId,
                        minX, minY, maxX - minX, maxY - minY, scale, margin,
                        pooledCapture, false);
            }
            if (mergedCapture.image == null) {
                for (int i = 0; i < validRegions.size();) {
                    Region region = validRegions.get(i);
                    Capture capture = captureRegion(context, client, sourceFramebufferId,
                            region.x(), region.y(), region.width(), region.height(), scale, margin,
                            pooledCapture, false);
                    if (capture.image == null) {
                        validRegions.remove(i);
                        continue;
                    }
                    captures.add(capture);
                    i++;
                }
            }
            if (validRegions.isEmpty()) return false;

            // All source copies happen before any blurred panel is drawn. This
            // keeps equal strengths visually equal and needs only one GPU sync.
            if (flushCaptureBatch) glFlush();
            ensureFilters(blurSigma);
            canvas.save();
            blurPaint.setImageFilter(encodeFilter);
            frostPaint.setColor(0x10000000);
            tintPaint.setColor(tintColor);
            try {
                for (int i = 0; i < validRegions.size(); i++) {
                    Region region = validRegions.get(i);
                    Capture capture = mergedCapture.image != null ? mergedCapture : captures.get(i);
                    RRect shape = RRect.makeXYWH(region.x(), region.y(), region.width(), region.height(), region.radius());
                    canvas.save();
                    canvas.clipRRect(shape, true);
                    canvas.drawImageRect(capture.image,
                            Rect.makeXYWH(0f, 0f, capture.width, capture.height),
                            Rect.makeXYWH(capture.dstX, capture.dstY, capture.dstW, capture.dstH),
                            SamplingMode.LINEAR, blurPaint, true);
                    canvas.drawRRect(shape, frostPaint);
                    if ((tintColor >>> 24) != 0) canvas.drawRRect(shape, tintPaint);
                    canvas.restore();
                }
                return true;
            } finally {
                blurPaint.setImageFilter(null);
                canvas.restore();
            }
        } finally {
            if (mergedCapture != cleanFrame) mergedCapture.close();
            for (Capture capture : captures) capture.close();
        }
    }

    private boolean drawSharedRegions(Canvas canvas, DirectContext context, Capture capture, List<Region> regions,
                                      int tintColor, float sigma) {
        int valid = 0;
        for (Region region : regions) {
            if (region != null && region.width() > 0f && region.height() > 0f) {
                valid++;
            }
        }
        if (valid == 0) return false;
        ensureFilters(sigma);
        Image shared = sharedBlur(context, capture, sigma, valid);
        Image image = shared == null ? capture.image : shared;
        Rect source = Rect.makeWH(shared == null ? capture.width : shared.getWidth(), shared == null ? capture.height : shared.getHeight());
        Rect destination = Rect.makeXYWH(capture.dstX, capture.dstY, capture.dstW, capture.dstH);
        canvas.save();
        blurPaint.setImageFilter(shared == null ? encodeFilter : null);
        frostPaint.setColor(0x10000000);
        tintPaint.setColor(tintColor);
        try {
            for (Region region : regions) {
                if (region == null || region.width() <= 0f || region.height() <= 0f) continue;
                RRect shape = RRect.makeXYWH(region.x(), region.y(), region.width(), region.height(), region.radius());
                canvas.save();
                try {
                    canvas.clipRRect(shape, true);
                    canvas.drawImageRect(image, source, destination, SamplingMode.LINEAR, blurPaint, true);
                    canvas.drawRRect(shape, frostPaint);
                    if ((tintColor >>> 24) != 0) canvas.drawRRect(shape, tintPaint);
                } finally {
                    canvas.restore();
                }
            }
            return true;
        } finally {
            blurPaint.setImageFilter(null);
            canvas.restore();
        }
    }

    private Capture cleanHudFrame(DirectContext context, int framebufferId, Minecraft client) {
        if (!captureGeometryMatches(client)) {
            ensureCaptureGeometry(client);
            return Capture.EMPTY;
        }
        return hudFrameSource.image != null && hudFrameSourceContext == context
                && hudFrameSourceFramebufferId == framebufferId ? hudFrameSource : Capture.EMPTY;
    }

    private Capture captureRegion(DirectContext context, Minecraft client, int sourceFramebufferId,
                                  float x, float y, float width, float height, float scale, float margin) {
        return captureRegion(context, client, sourceFramebufferId, x, y, width, height, scale, margin, false);
    }

    private Capture captureRegion(DirectContext context, Minecraft client, int sourceFramebufferId,
                                  float x, float y, float width, float height, float scale, float margin,
                                  boolean pooledCapture) {
        return captureRegion(context, client, sourceFramebufferId, x, y, width, height, scale, margin,
                pooledCapture, true);
    }

    private Capture captureRegion(DirectContext context, Minecraft client, int sourceFramebufferId,
                                  float x, float y, float width, float height, float scale, float margin,
                                  boolean pooledCapture, boolean flushCapture) {
        long started = BlurPerformanceProbe.begin(0);
        try { return captureRegionUnprofiled(context, client, sourceFramebufferId, x, y, width, height, scale, margin, pooledCapture, flushCapture); }
        finally { BlurPerformanceProbe.end(0, started); }
    }

    private Capture captureRegionUnprofiled(DirectContext context, Minecraft client, int sourceFramebufferId,
                                  float x, float y, float width, float height, float scale, float margin,
                                  boolean pooledCapture, boolean flushCapture) {
        return captureRegionUnprofiled(context,client,sourceFramebufferId,x,y,width,height,scale,margin,
                pooledCapture,flushCapture,false);
    }

    private Capture captureRegionUnprofiled(DirectContext context, Minecraft client, int sourceFramebufferId,
                                  float x, float y, float width, float height, float scale, float margin,
                                  boolean pooledCapture, boolean flushCapture, boolean menuCapture) {
        ensureCaptureGeometry(client);
        int framebufferW = client.getWindow().getWidth();
        int framebufferH = client.getWindow().getHeight();
        int left = Math.max(0, (int) Math.floor((x - margin) * scale));
        int top = Math.max(0, (int) Math.floor((y - margin) * scale));
        int right = Math.min(framebufferW, (int) Math.ceil((x + width + margin) * scale));
        int bottom = Math.min(framebufferH, (int) Math.ceil((y + height + margin) * scale));
        int copyW = Math.max(1, right - left);
        int copyH = Math.max(1, bottom - top);
        int targetW = Math.max(1, (copyW + CAPTURE_DOWNSAMPLE - 1) / CAPTURE_DOWNSAMPLE);
        int targetH = Math.max(1, (copyH + CAPTURE_DOWNSAMPLE - 1) / CAPTURE_DOWNSAMPLE);
        int sourceY = Math.max(0, framebufferH - bottom);

        boolean framebufferSrgb = glIsEnabled(GL_FRAMEBUFFER_SRGB);
        boolean scissorEnabled = glIsEnabled(GL_SCISSOR_TEST);
        glGetIntegerv(GL_ACTIVE_TEXTURE, oldActiveTexture);
        glActiveTexture(GL_TEXTURE0);
        glGetIntegerv(GL_TEXTURE_BINDING_2D, oldTexture);
        glGetIntegerv(GL_SAMPLER_BINDING, oldSampler);
        glGetIntegerv(GL_READ_FRAMEBUFFER_BINDING, oldReadFramebuffer);
        glGetIntegerv(GL_DRAW_FRAMEBUFFER_BINDING, oldDrawFramebuffer);
        glGetIntegerv(GL_READ_BUFFER, oldReadBuffer);
        glGetIntegerv(GL_DRAW_BUFFER, oldDrawBuffer);
        glGetIntegerv(GL_VIEWPORT, oldViewport);
        glGetIntegerv(GL_SCISSOR_BOX, oldScissorBox);
        CaptureTarget target = null;
        boolean handedOff = false;
        try {
            target = menuCapture ? acquireMenuCapture(context,targetW,targetH)
                    : pooledCapture ? acquireCaptureTarget(context, targetW, targetH)
                    : createCaptureTarget(context, targetW, targetH);
            if (target == null) return Capture.EMPTY;

            glDisable(GL_FRAMEBUFFER_SRGB);
            glDisable(GL_SCISSOR_TEST);
            glBindTexture(GL_TEXTURE_2D, target.textureId);
            glBindSampler(0, 0);

            glBindFramebuffer(GL_DRAW_FRAMEBUFFER, target.framebufferId);
            glDrawBuffer(GL_COLOR_ATTACHMENT0);
            if (glCheckFramebufferStatus(GL_DRAW_FRAMEBUFFER) != GL_FRAMEBUFFER_COMPLETE) {
                return Capture.EMPTY;
            }

            int readBuffer = prepareReadFramebuffer(sourceFramebufferId);
            if (readBuffer == 0) {
                return Capture.EMPTY;
            }
            glReadBuffer(readBuffer);
            int gpuSample = BlurPerformanceProbe.beginGpu(0);
            try {
                glBlitFramebuffer(
                        left, sourceY, left + copyW, sourceY + copyH,
                        0, 0, targetW, targetH,
                        GL_COLOR_BUFFER_BIT,
                        GL_LINEAR
                );
            } finally {
                BlurPerformanceProbe.endGpu(gpuSample);
            }
            if (flushCapture) glFlush();
            if (!pooledCapture && !menuCapture) glDeleteFramebuffers(target.framebufferId);
            handedOff = true;
            return new Capture(target.image, targetW, targetH,
                    left / scale, top / scale, copyW / scale, copyH / scale, !pooledCapture && !menuCapture);
        } finally {
            if (target != null && !handedOff) {
                if(menuCapture)releaseMenuCapture();
                else if(!pooledCapture)destroyCaptureTarget(target);
            }
            glBindFramebuffer(GL_READ_FRAMEBUFFER, oldReadFramebuffer[0]);
            glBindFramebuffer(GL_DRAW_FRAMEBUFFER, oldDrawFramebuffer[0]);
            restoreReadBuffer(oldReadFramebuffer[0], oldReadBuffer[0]);
            restoreDrawBuffer(oldDrawFramebuffer[0], oldDrawBuffer[0]);
            glViewport(oldViewport[0], oldViewport[1], oldViewport[2], oldViewport[3]);
            glScissor(oldScissorBox[0], oldScissorBox[1], oldScissorBox[2], oldScissorBox[3]);
            if (scissorEnabled) glEnable(GL_SCISSOR_TEST); else glDisable(GL_SCISSOR_TEST);
            glActiveTexture(GL_TEXTURE0);
            glBindTexture(GL_TEXTURE_2D, oldTexture[0]);
            glBindSampler(0, oldSampler[0]);
            glActiveTexture(oldActiveTexture[0]);
            if (framebufferSrgb) {
                glEnable(GL_FRAMEBUFFER_SRGB);
            } else {
                glDisable(GL_FRAMEBUFFER_SRGB);
            }
        }
    }

    private void beginCaptureBatch(DirectContext context) {
        if (capturePoolContext != context) {
            destroyCaptureTargets();
            capturePoolContext = context;
        }
        captureTargetCursor = 0;
    }

    private CaptureTarget acquireCaptureTarget(DirectContext context, int requiredW, int requiredH) {
        int slot = captureTargetCursor++;
        if (slot < captureTargets.size()) {
            CaptureTarget current = captureTargets.get(slot);
            if (current.width >= requiredW && current.height >= requiredH) return current;
            destroyCaptureTarget(current);
            CaptureTarget grown = createCaptureTarget(context,
                    Math.max(current.width, requiredW), Math.max(current.height, requiredH));
            if (grown != null) captureTargets.set(slot, grown);
            else {
                captureTargets.remove(slot);
                captureTargetCursor = slot;
            }
            return grown;
        }
        CaptureTarget created = createCaptureTarget(context, requiredW, requiredH);
        if (created != null) captureTargets.add(created);
        return created;
    }

    private CaptureTarget createCaptureTarget(DirectContext context, int requiredW, int requiredH) {
        int textureId = glGenTextures();
        int framebufferId = glGenFramebuffers();
        Image image = null;
        CaptureTarget created = null;
        try {
            glBindTexture(GL_TEXTURE_2D, textureId);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, requiredW, requiredH, 0, GL_RGBA, GL_UNSIGNED_BYTE, 0L);

            glBindFramebuffer(GL_DRAW_FRAMEBUFFER, framebufferId);
            glFramebufferTexture2D(GL_DRAW_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, textureId, 0);
            glDrawBuffer(GL_COLOR_ATTACHMENT0);
            if (glCheckFramebufferStatus(GL_DRAW_FRAMEBUFFER) != GL_FRAMEBUFFER_COMPLETE) {
                return null;
            }

            image = Image.adoptGLTextureFrom(context, textureId, GL_TEXTURE_2D, requiredW, requiredH,
                    GL_RGBA8, SurfaceOrigin.BOTTOM_LEFT, ColorType.RGB_888X);
            created = new CaptureTarget(textureId, framebufferId, requiredW, requiredH, image);
            return created;
        } finally {
            if (created == null) {
                if (framebufferId != 0) glDeleteFramebuffers(framebufferId);
                if (image != null) {
                    image.close();
                } else if (textureId != 0) {
                    glDeleteTextures(textureId);
                }
            }
        }
    }

    private void destroyCaptureTargets() {
        clearHudFrameSource();
        for (FrameBlur blur : frameBlurs.values()) blur.close();
        frameBlurs.clear();
        for (CaptureTarget target : captureTargets) destroyCaptureTarget(target);
        captureTargets.clear();
        captureTargetCursor = 0;
    }

    private void clearHudFrameSource() {
        for (FrameBlur blur : frameBlurs.values()) blur.reset();
        hudFrameSource = Capture.EMPTY;
        hudFrameSourceContext = null;
        hudFrameSourceFramebufferId = -1;
    }

    private boolean captureGeometryMatches(Minecraft client) {
        if (client == null || client.getWindow() == null) return false;
        return captureFramebufferWidth == client.getWindow().getWidth()
                && captureFramebufferHeight == client.getWindow().getHeight()
                && captureGuiWidth == client.getWindow().getGuiScaledWidth()
                && captureGuiHeight == client.getWindow().getGuiScaledHeight()
                && Double.compare(captureGuiScale, client.getWindow().getGuiScale()) == 0;
    }

    /** Capture textures are pixel-sized; never reuse them across a resize or GUI-scale change. */
    private void ensureCaptureGeometry(Minecraft client) {
        if (captureGeometryMatches(client)) return;
        destroyCaptureTargets();
        sharedFrameActive = false;
        capturePoolContext = null;
        captureFramebufferWidth = client.getWindow().getWidth();
        captureFramebufferHeight = client.getWindow().getHeight();
        captureGuiWidth = client.getWindow().getGuiScaledWidth();
        captureGuiHeight = client.getWindow().getGuiScaledHeight();
        captureGuiScale = client.getWindow().getGuiScale();
    }

    private void destroyCaptureTarget(CaptureTarget target) {
        if (target == null) return;
        if (target.framebufferId != 0) glDeleteFramebuffers(target.framebufferId);
        if (target.image != null) target.image.close();
        else if (target.textureId != 0) glDeleteTextures(target.textureId);
    }

    private void ensureFilters(float sigma) {
        int key = Float.floatToIntBits(sigma);
        if (encodeFilter != null && selectedFilterKey == key) return;
        FilterSet filters = filterCache.get(key);
        if (filters == null) {
            ImageFilter linearize = ImageFilter.makeColorFilter(ColorFilter.getSRGBToLinearGamma(), null);
            ImageFilter blur = ImageFilter.makeBlur(sigma, sigma, FilterTileMode.CLAMP, linearize, (Rect) null);
            filters = new FilterSet(linearize, blur,
                    ImageFilter.makeColorFilter(ColorFilter.getLinearToSRGBGamma(), blur));
            filterCache.put(key, filters);
            if (filterCache.size() > MAX_FILTER_CACHE) {
                var iterator = filterCache.entrySet().iterator();
                FilterSet oldest = iterator.next().getValue();
                iterator.remove();
                oldest.close();
            }
        }
        encodeFilter = filters.encode;
        selectedFilterKey = key;
    }

    private int prepareReadFramebuffer(int framebufferId) {
        glBindFramebuffer(GL_READ_FRAMEBUFFER, framebufferId);
        if (glCheckFramebufferStatus(GL_READ_FRAMEBUFFER) != GL_FRAMEBUFFER_COMPLETE) {
            return 0;
        }
        if (framebufferId == 0) {
            return GL_BACK;
        }
        int attachmentType = glGetFramebufferAttachmentParameteri(
                GL_READ_FRAMEBUFFER,
                GL_COLOR_ATTACHMENT0,
                GL_FRAMEBUFFER_ATTACHMENT_OBJECT_TYPE
        );
        return attachmentType == GL_NONE ? 0 : GL_COLOR_ATTACHMENT0;
    }

    private void restoreReadBuffer(int framebufferId, int readBuffer) {
        if (readBuffer == GL_NONE) {
            glReadBuffer(GL_NONE);
            return;
        }
        if (framebufferId == 0) {
            glReadBuffer(isDefaultFramebufferReadBuffer(readBuffer) ? readBuffer : GL_BACK);
            return;
        }
        glReadBuffer(isColorAttachmentReadBuffer(readBuffer) ? readBuffer : GL_COLOR_ATTACHMENT0);
    }

    private void restoreDrawBuffer(int framebufferId, int drawBuffer) {
        if (drawBuffer == GL_NONE) {
            glDrawBuffer(GL_NONE);
            return;
        }
        if (framebufferId == 0) {
            glDrawBuffer(isDefaultFramebufferReadBuffer(drawBuffer) ? drawBuffer : GL_BACK);
            return;
        }
        glDrawBuffer(isColorAttachmentReadBuffer(drawBuffer) ? drawBuffer : GL_COLOR_ATTACHMENT0);
    }

    private boolean isDefaultFramebufferReadBuffer(int readBuffer) {
        return readBuffer == GL_FRONT
                || readBuffer == GL_BACK
                || readBuffer == GL_LEFT
                || readBuffer == GL_RIGHT
                || readBuffer == GL_FRONT_LEFT
                || readBuffer == GL_FRONT_RIGHT
                || readBuffer == GL_BACK_LEFT
                || readBuffer == GL_BACK_RIGHT;
    }

    private boolean isColorAttachmentReadBuffer(int readBuffer) {
        return readBuffer >= GL_COLOR_ATTACHMENT0 && readBuffer <= GL_COLOR_ATTACHMENT0 + 31;
    }

    /** The actual FBO backing Minecraft's main RenderTarget. */
    public static int mainFramebufferId(Minecraft client) {
        if (client.getMainRenderTarget().getColorTexture() instanceof GlTexture texture
                && RenderSystem.getDevice() instanceof GlDevice device) {
            return texture.getFbo(device.directStateAccess(), client.getMainRenderTarget().getDepthTexture());
        }
        return currentDrawFramebufferId();
    }

    private float blurSigma(float strength) {
        float clamped = Math.max(0f, Math.min(2f, strength));
        return Math.max(0.1f, 3f + clamped * 9f);
    }

    private void ensureNativeLoaded() {
        if (nativeLoaded) return;
        Library.load();
        nativeLoaded = true;
    }

    private static class Capture {
        private static final Capture EMPTY = new Capture(null, 0, 0, 0f, 0f, 0f, 0f, false);

        private final Image image;
        private final int width;
        private final int height;
        private final float dstX;
        private final float dstY;
        private final float dstW;
        private final float dstH;
        private final boolean closeImage;

        private Capture(Image image, int width, int height, float dstX, float dstY, float dstW, float dstH,
                        boolean closeImage) {
            this.image = image;
            this.width = width;
            this.height = height;
            this.dstX = dstX;
            this.dstY = dstY;
            this.dstW = dstW;
            this.dstH = dstH;
            this.closeImage = closeImage;
        }

        private void close() {
            if (closeImage && image != null) image.close();
        }
    }

    public record Region(float x, float y, float width, float height, float radius) {}

    private record CaptureTarget(int textureId, int framebufferId, int width, int height, Image image) {}

    private record FilterSet(ImageFilter linearize, ImageFilter blur, ImageFilter encode) {
        private void close() {
            encode.close();
            blur.close();
            linearize.close();
        }
    }
}
