package com.linclient.client.render.skia;

import io.github.humbleui.skija.Canvas;
import io.github.humbleui.skija.Data;
import io.github.humbleui.skija.FilterTileMode;
import io.github.humbleui.skija.Image;
import io.github.humbleui.skija.Matrix33;
import io.github.humbleui.skija.Paint;
import io.github.humbleui.skija.RuntimeEffect;
import io.github.humbleui.skija.RuntimeEffectChild;
import io.github.humbleui.skija.SamplingMode;
import io.github.humbleui.skija.Shader;
import io.github.humbleui.types.RRect;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/** Edge optics adapted from DayDreamInAReverie's MIT-licensed Lens renderer.
 * https://github.com/ruiqichenbiec/design-systems (lens/lab/design-system/internal/renderer.js).
 * Samples the same captured game image as the blur; no clock, idle animation or extra capture. */
public final class LensOptics {
    private static RuntimeEffect effect;
    private static boolean unavailable;
    private static final java.util.Map<String, Integer> UNIFORM_OFFSETS = new java.util.HashMap<>();
    private static final String SOURCE = """
            uniform shader scene;
            uniform float4 panel;
            uniform float4 capture;
            uniform float2 imageSize;
            uniform float radius;
            uniform float unit;
            uniform float refraction;
            uniform float dispersion;

            float distanceToLens(float2 position) {
                float2 point = position - panel.xy - panel.zw * .5;
                float2 q = abs(point) - panel.zw * .5 + radius;
                return min(max(q.x, q.y), 0.) + length(max(q, float2(0.))) - radius;
            }
            float3 sampleScene(float2 position) {
                float2 pixel = (position - capture.xy) * imageSize / capture.zw;
                return float3(scene.eval(clamp(pixel, float2(.5), imageSize - .5)).rgb);
            }
            half4 main(float2 position) {
                float d = distanceToLens(position);
                float bevel = max(.25, min(12. * unit, min(panel.z, panel.w) * .18));
                if (d > 0. || d < -bevel) return half4(0.);
                float edge = clamp(1. + d / bevel, 0., 1.);
                float aa = 1. - smoothstep(-1.2 * unit, 0., d);
                float e = max(.05, .7 * unit);
                float2 normal2 = normalize(float2(
                    distanceToLens(position + float2(e, 0.)) - distanceToLens(position - float2(e, 0.)),
                    distanceToLens(position + float2(0., e)) - distanceToLens(position - float2(0., e))) + .00001);
                float slope = pow(edge, 1.85) * .62;
                float3 normal = float3(normal2 * slope, sqrt(max(1. - slope * slope, .001)));
                // Air -> glass-like medium; subtle edge refraction without smearing the border.
                float3 ray = refract(float3(0., 0., -1.), normal, 1. / 1.32);
                float2 offset = ray.xy / max(-ray.z, .08) * (4. + refraction * 6.) * unit * refraction;
                offset = clamp(offset, float2(-5. * unit), float2(5. * unit));
                float2 at = position + offset;
                float2 split = normal2 * pow(edge, 3.2) * dispersion * .55 * unit;
                float3 color = sampleScene(at);
                color.r = mix(color.r, sampleScene(at + split).r, .45);
                color.b = mix(color.b, sampleScene(at - split).b, .45);

                float2 light = normalize(float2(-.55, -.84));
                float leading = pow(max(dot(normal2, light), 0.), 7.);
                float trailing = pow(max(dot(normal2, -light), 0.), 7.) * .36;
                float outline = 1. - smoothstep(.15 * unit, 1.15 * unit, abs(d + .7 * unit));
                float fresnel = .04 + .96 * pow(1. - normal.z, 5.);
                float3 environment = sampleScene(position + normal2 * 18. * unit);
                color = mix(color, environment, fresnel * .05);
                float specular = (leading + trailing) * (outline * .24 + pow(edge, 4.) * .035);
                color += mix(float3(1.), environment, .18) * specular;
                // Broad reflection is weak and uses the actual environment's color.
                color = mix(color, min(environment + .04, float3(1.)), pow(edge, 1.8) * .025);
                color -= pow(edge, 8.) * max(dot(normal2, normalize(float2(.45, .89))), 0.) * .025;
                float alpha = pow(edge, 1.8) * .38 * aa;
                return half4(half3(clamp(color, 0., 1.) * alpha), half(alpha));
            }
            """;

    public static boolean draw(Canvas canvas, Image image, float captureX, float captureY,
                               float captureWidth, float captureHeight,
                               float x, float y, float width, float height, float radius,
                               float scale, float refraction, float dispersion) {
        if (unavailable || image == null || width <= 0 || height <= 0
                || captureWidth <= 0 || captureHeight <= 0) return false;
        try {
            if (effect == null) {
                effect = RuntimeEffect.makeForShader(SOURCE);
                for (var uniform : effect.getUniforms()) UNIFORM_OFFSETS.put(uniform.getName(), uniform.getOffset());
            }
            ByteBuffer uniforms = ByteBuffer.allocate(effect.getUniformSize()).order(ByteOrder.nativeOrder());
            put(uniforms, "panel", x, y, width, height);
            put(uniforms, "capture", captureX, captureY, captureWidth, captureHeight);
            put(uniforms, "imageSize", image.getWidth(), image.getHeight());
            float safeRadius = Math.max(0, Math.min(radius, Math.min(width, height) * .5f));
            put(uniforms, "radius", safeRadius);
            put(uniforms, "unit", Math.max(.01f, scale));
            put(uniforms, "refraction", Math.max(0, Math.min(1.5f, refraction)));
            put(uniforms, "dispersion", Math.max(0, Math.min(1.5f, dispersion)));
            try (Data data = Data.makeFromBytes(uniforms.array());
                 Shader scene = image.makeShader(FilterTileMode.CLAMP, FilterTileMode.CLAMP,
                         SamplingMode.LINEAR, Matrix33.IDENTITY);
                 Shader lens = effect.makeShader(data, new RuntimeEffectChild[]{scene});
                 Paint paint = new Paint().setAntiAlias(true).setShader(lens)) {
                canvas.drawRRect(RRect.makeXYWH(x, y, width, height, safeRadius), paint);
            }
            return true;
        } catch (RuntimeException failure) {
            unavailable = true;
            System.err.println("[Lin Lens] Optical shader unavailable; retaining the shared blur: " + failure.getMessage());
            return false;
        }
    }

    private static void put(ByteBuffer target, String name, float... values) {
        // Query Skia's native uniform layout, including any vector alignment padding.
        target.position(UNIFORM_OFFSETS.get(name));
        for (float value : values) target.putFloat(value);
    }

    private LensOptics() {}
}
