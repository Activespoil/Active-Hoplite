/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  io.github.humbleui.skija.Canvas
 *  io.github.humbleui.skija.Data
 *  io.github.humbleui.skija.Font
 *  io.github.humbleui.skija.FontEdging
 *  io.github.humbleui.skija.FontHinting
 *  io.github.humbleui.skija.FontMetrics
 *  io.github.humbleui.skija.FontMgr
 *  io.github.humbleui.skija.Paint
 *  io.github.humbleui.skija.Typeface
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 */
package com.linclient.client.render.font;

import com.linclient.client.render.skia.SkiaRenderer;
import io.github.humbleui.skija.Canvas;
import io.github.humbleui.skija.Data;
import io.github.humbleui.skija.Font;
import io.github.humbleui.skija.FontEdging;
import io.github.humbleui.skija.FontHinting;
import io.github.humbleui.skija.FontMetrics;
import io.github.humbleui.skija.FontMgr;
import io.github.humbleui.skija.Paint;
import io.github.humbleui.skija.Typeface;
import io.github.humbleui.skija.TextBlob;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.ArrayList;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public class FontRenderer {
    public static final String DEFAULT = "harmony";
    public static final String ICON = "icon";
    public static final String MATERIAL_SYMBOLS = "material_symbols";
    public static final String SCRIPT = "script";
    public static final String LIN_HUD_FONT = "lin_hud_font";
    public static final String LIN_BOLD = "lin_bold";
    public static final String SYMBOL_FALLBACK = "symbol_fallback";
    private static final Map<String, Typeface> typefaces = new HashMap<String, Typeface>();
    private static final FontMgr fontMgr = FontMgr.getDefault();
    private static long layoutVersion;
    public static long layoutVersion() { return layoutVersion; }
    private static final int MAX_FONT_CACHE = 192;
    private static final int MAX_WIDTH_CACHE = 8192;
    private static final Map<FontKey, FontMetrics> metricsCache = new LinkedHashMap<>(64, .75f, true) {
        @Override protected boolean removeEldestEntry(Map.Entry<FontKey, FontMetrics> entry) {
            return size() > MAX_FONT_CACHE;
        }
    };
    private static final Map<WidthKey, List<FallbackRun>> fallbackCache = new LinkedHashMap<>(256, .75f, true) {
        @Override protected boolean removeEldestEntry(Map.Entry<WidthKey, List<FallbackRun>> entry) {
            return size() > 1024;
        }
    };
    private static final Map<FontKey, Font> fonts = new LinkedHashMap<FontKey, Font>(64, 0.75f, true){

        @Override
        protected boolean removeEldestEntry(Map.Entry<FontKey, Font> eldest) {
            if (this.size() <= 192) return false;
            eldest.getValue().close();
            return true;
        }
    };
    private static final Map<WidthKey, Float> widthCache = new LinkedHashMap<WidthKey, Float>(1024, 0.75f, true){

        @Override
        protected boolean removeEldestEntry(Map.Entry<WidthKey, Float> eldest) {
            return this.size() > 8192;
        }
    };
    private static final Paint textPaint = new Paint().setAntiAlias(true);
    private static final Map<WidthKey, TextBlob> textBlobs = new LinkedHashMap<>(256, .75f, true) {
        @Override protected boolean removeEldestEntry(Map.Entry<WidthKey, TextBlob> entry) {
            if (size() <= 1024) return false;
            entry.getValue().close();
            return true;
        }
    };

    private record PositionedKey(String text, List<Float> positions) {}
    private static final Map<PositionedKey, List<TextBlob>> positionedBlobs = new LinkedHashMap<>(128, .75f, true) {
        @Override protected boolean removeEldestEntry(Map.Entry<PositionedKey, List<TextBlob>> entry) {
            if (size() <= 1024) return false;
            entry.getValue().forEach(TextBlob::close);
            return true;
        }
    };

    /** Fixed-size name glyphs retain their original per-codepoint advances, including symbol fallback. */
    public static void drawPositionedName(Canvas canvas, String text, List<Float> positions, int argb) {
        PositionedKey key = new PositionedKey(text, positions);
        List<TextBlob> blobs = positionedBlobs.get(key);
        if (blobs == null) {
            blobs = new ArrayList<>();
            Font primary = makeFont(LIN_BOLD, 9f);
            Font fallback = typefaces.containsKey(SYMBOL_FALLBACK) ? makeFont(SYMBOL_FALLBACK, 9f) : null;
            List<Short> ids = new ArrayList<>();
            List<Float> offsets = new ArrayList<>();
            Font active = null;
            int slot = 0;
            for (int at = 0; at < text.length();) {
                int cp = text.codePointAt(at);
                String letter = new String(Character.toChars(cp));
                at += Character.charCount(cp);
                float cursor = positions.get(slot++);
                List<FallbackRun> runs = fallback == null ? List.of(new FallbackRun(letter, false, 0))
                        : fallbackRuns(letter, 9f, primary, fallback);
                for (FallbackRun run : runs) {
                    Font selected = run.fallback() ? fallback : primary;
                    if (active != null && active != selected) {
                        appendPositionedBlob(blobs, ids, offsets, active);
                        ids.clear(); offsets.clear();
                    }
                    active = selected;
                    short[] glyphs = selected.getStringGlyphs(run.text());
                    float[] xs = selected.getXPositions(glyphs);
                    for (int i = 0; i < glyphs.length; i++) {
                        ids.add(glyphs[i]); offsets.add(cursor + xs[i]);
                    }
                    cursor += run.width();
                }
            }
            if (active != null) appendPositionedBlob(blobs, ids, offsets, active);
            positionedBlobs.put(new PositionedKey(text, List.copyOf(positions)), blobs);
        }
        textPaint.setColor(argb);
        for (TextBlob blob : blobs) canvas.drawTextBlob(blob, 0, 8f, textPaint);
        SkiaRenderer.feedRegionContent(text, 0, 8f, 9f, argb, LIN_BOLD);
    }

    private static void appendPositionedBlob(List<TextBlob> blobs, List<Short> ids, List<Float> offsets, Font font) {
        if (ids.isEmpty()) return;
        short[] glyphs = new short[ids.size()]; float[] xs = new float[ids.size()];
        for (int i = 0; i < glyphs.length; i++) { glyphs[i] = ids.get(i); xs[i] = offsets.get(i); }
        TextBlob blob = TextBlob.makeFromPosH(glyphs, xs, 0f, font);
        if (blob == null) throw new IllegalStateException("Cannot create positioned name glyphs");
        blobs.add(blob);
    }

    private static void drawCachedText(Canvas canvas, String text, float x, float y,
                                       Font font, float size, String fontName, Paint paint) {
        if (text.isEmpty()) return;
        if (text.length() > 256) {
            canvas.drawString(text, x, y, font, paint);
            return;
        }
        WidthKey key = new WidthKey(fontName, Float.floatToIntBits(size), text);
        TextBlob blob = textBlobs.get(key);
        if (blob == null) {
            short[] glyphs = font.getStringGlyphs(text);
            blob = TextBlob.makeFromPosH(glyphs, font.getXPositions(glyphs), 0f, font);
            if (blob == null) {
                canvas.drawString(text, x, y, font, paint);
                return;
            }
            textBlobs.put(key, blob);
        }
        canvas.drawTextBlob(blob, x, y, paint);
    }

    public static void registerFromResources(String name, String resourcePath) {
        try (InputStream is = FontRenderer.class.getResourceAsStream(resourcePath);){
            if (is == null) {
                throw new IOException("Font not found: " + resourcePath);
            }
            byte[] data = is.readAllBytes();
            try (Data nativeData = Data.makeFromBytes(data)) {
                replaceTypeface(name, fontMgr.makeFromData(nativeData));
            }
        }
        catch (IOException e) {
            throw new RuntimeException("Failed to load font: " + resourcePath, e);
        }
    }

    public static void registerFromFile(String name, Path path) {
        replaceTypeface(name, fontMgr.makeFromFile(path.toAbsolutePath().toString()));
    }

    /** Called on the render thread, like the font caches themselves. */
    private static void replaceTypeface(String name, Typeface replacement) {
        if (replacement == null) throw new IllegalArgumentException("Cannot load font: " + name);
        Typeface previous = typefaces.put(name, replacement);
        try { clearCaches(name); }
        finally { if (previous != null && previous != replacement) previous.close(); }
    }
    private static Font makeFont(String fontName, float size) {
        FontKey key = new FontKey(fontName, Float.floatToIntBits(size));
        Font font = fonts.get(key);
        if (font != null) {
            return font;
        }
        Typeface typeface = typefaces.getOrDefault(fontName, typefaces.get(DEFAULT));
        font = new Font(typeface, size);
        font.setSubpixel(true);
        font.setHinting(FontHinting.SLIGHT);
        font.setEdging(FontEdging.SUBPIXEL_ANTI_ALIAS);
        fonts.put(key, font);
        return font;
    }

    public static void drawText(Canvas canvas, String text, float x, float y, float size, int argb) {
        FontRenderer.drawText(canvas, text, x, y, size, argb, DEFAULT);
    }

    public static void drawText(Canvas canvas, String text, float x, float y, float size, int argb, String fontName) {
        Font font = FontRenderer.makeFont(fontName, size);
        if (LIN_BOLD.equals(fontName) && typefaces.containsKey(SYMBOL_FALLBACK)) {
            FontRenderer.drawWithSymbolFallback(canvas, text, x, y, size, argb, font);
            return;
        }
        textPaint.setColor(argb);
        drawCachedText(canvas, text, x, y, font, size, fontName, textPaint);
        SkiaRenderer.feedRegionContent(text, x, y, size, argb, fontName);
    }

    public static void drawSegmented(Canvas canvas, Segment[] segments, float x, float y) {
        float cursor = x;
        for (Segment seg : segments) {
            FontRenderer.drawText(canvas, seg.text, cursor, y, seg.size, seg.argb, seg.fontName);
            cursor += FontRenderer.measureTextWidth(seg.text, seg.size, seg.fontName) + seg.gap;
        }
    }

    public static float measureTextWidth(String text, float size) {
        return FontRenderer.measureTextWidth(text, size, DEFAULT);
    }

    public static float measureTextWidth(String text, float size, String fontName) {
        if (text.length() <= 256) {
            WidthKey key = new WidthKey(fontName, Float.floatToIntBits(size), text);
            Float cached = widthCache.get(key);
            if (cached != null) {
                return cached.floatValue();
            }
            float width = LIN_BOLD.equals(fontName) && typefaces.containsKey(SYMBOL_FALLBACK) ? FontRenderer.measureWithSymbolFallback(text, size) : FontRenderer.makeFont(fontName, size).measureTextWidth(text);
            widthCache.put(key, Float.valueOf(width));
            return width;
        }
        if (LIN_BOLD.equals(fontName) && typefaces.containsKey(SYMBOL_FALLBACK)) {
            return FontRenderer.measureWithSymbolFallback(text, size);
        }
        return FontRenderer.makeFont(fontName, size).measureTextWidth(text);
    }

    private static void drawWithSymbolFallback(Canvas canvas, String text, float x, float y, float size, int argb, Font primary) {
        if (text == null || text.isEmpty()) {
            return;
        }
        Font fallback = FontRenderer.makeFont(SYMBOL_FALLBACK, size);
        float cursor = x;
        for (FallbackRun run : fallbackRuns(text, size, primary, fallback)) {
            Font selected = run.fallback() ? fallback : primary;
            textPaint.setColor(argb);
            drawCachedText(canvas, run.text(), cursor, y, selected, size,
                    run.fallback() ? SYMBOL_FALLBACK : LIN_BOLD, textPaint);
            SkiaRenderer.feedRegionContent(run.text(), cursor, y, size, argb,
                    run.fallback() ? SYMBOL_FALLBACK : LIN_BOLD);
            cursor += run.width();
        }
    }

    private static List<FallbackRun> fallbackRuns(String text, float size, Font primary, Font fallback) {
        WidthKey key = new WidthKey(LIN_BOLD, Float.floatToIntBits(size), text);
        List<FallbackRun> cached = fallbackCache.get(key);
        if (cached != null) return cached;
        List<FallbackRun> result = new ArrayList<>();
        StringBuilder run = new StringBuilder();
        boolean fallbackRun = false;
        int codePoint;
        for (int offset = 0; offset < text.length(); offset += Character.charCount(codePoint)) {
            boolean useFallback;
            codePoint = text.codePointAt(offset);
            boolean bl = useFallback = primary.getUTF32Glyph(codePoint) == 0 && fallback.getUTF32Glyph(codePoint) != 0;
            if (!run.isEmpty() && useFallback != fallbackRun) {
                String value = run.toString();
                Font selected = fallbackRun ? fallback : primary;
                result.add(new FallbackRun(value, fallbackRun, selected.measureTextWidth(value)));
                run.setLength(0);
            }
            fallbackRun = useFallback;
            run.appendCodePoint(codePoint);
        }
        if (!run.isEmpty()) {
            String value = run.toString();
            Font selected = fallbackRun ? fallback : primary;
            result.add(new FallbackRun(value, fallbackRun, selected.measureTextWidth(value)));
        }
        if (text.length() <= 256) fallbackCache.put(key, result);
        return result;
    }

    private record GlyphWidthKey(int codePoint, int sizeBits) {}
    // Shared by changing HUD strings; preserve the original per-codepoint measurement.
    private static final Map<GlyphWidthKey, Float> glyphWidths = new LinkedHashMap<>(256, .75f, true) {
        @Override protected boolean removeEldestEntry(Map.Entry<GlyphWidthKey, Float> entry) {
            return size() > 4096;
        }
    };

    private static float symbolGlyphWidth(int codePoint, float size, Font primary, Font fallback) {
        GlyphWidthKey key = new GlyphWidthKey(codePoint, Float.floatToIntBits(size));
        Float cached = glyphWidths.get(key);
        if (cached != null) return cached;
        Font selected = primary.getUTF32Glyph(codePoint) == 0 && fallback.getUTF32Glyph(codePoint) != 0
                ? fallback : primary;
        float width = selected.measureTextWidth(new String(Character.toChars(codePoint)));
        glyphWidths.put(key, width);
        return width;
    }
    private static float measureWithSymbolFallback(String text, float size) {
        int codePoint;
        Font primary = FontRenderer.makeFont(LIN_BOLD, size);
        Font fallback = FontRenderer.makeFont(SYMBOL_FALLBACK, size);
        float width = 0.0f;
        for (int offset = 0; offset < text.length(); offset += Character.charCount(codePoint)) {
            codePoint = text.codePointAt(offset);
            width += symbolGlyphWidth(codePoint, size, primary, fallback);
        }
        return width;
    }

    public static float getLineHeight(float size) {
        return FontRenderer.getLineHeight(size, DEFAULT);
    }

    public static float getLineHeight(float size, String fontName) {
        FontMetrics m = metrics(size, fontName);
        return -m.getAscent() + m.getDescent();
    }

    public static float getAscent(float size, String fontName) {
        return -metrics(size, fontName).getAscent();
    }

    public static float getCapHeight(float size, String fontName) {
        return metrics(size, fontName).getCapHeight();
    }

    private static FontMetrics metrics(float size, String fontName) {
        FontKey key = new FontKey(fontName, Float.floatToIntBits(size));
        FontMetrics cached = metricsCache.get(key);
        if (cached == null) {
            cached = makeFont(fontName, size).getMetrics();
            metricsCache.put(key, cached);
        }
        return cached;
    }

    private record FallbackRun(String text, boolean fallback, float width) {}

    private static void clearCaches(String fontName) {
        layoutVersion++;
        glyphWidths.clear();
        // Default font aliases and symbol fallback can affect any cached text.
        for (TextBlob blob : textBlobs.values()) blob.close();
        textBlobs.clear();
        positionedBlobs.values().forEach(blobs -> blobs.forEach(TextBlob::close));
        positionedBlobs.clear();
        fonts.entrySet().removeIf(entry -> {
            if (!DEFAULT.equals(fontName) && !entry.getKey().fontName.equals(fontName)) return false;
            entry.getValue().close();
            return true;
        });
        widthCache.keySet().removeIf(key -> key.fontName.equals(fontName));
        metricsCache.keySet().removeIf(key -> DEFAULT.equals(fontName) || key.fontName.equals(fontName));
        fallbackCache.clear();
        // LIN_BOLD measurements depend on the registered symbol fallback too.
        if (SYMBOL_FALLBACK.equals(fontName) || DEFAULT.equals(fontName)) widthCache.clear();
    }

    static {
        FontRenderer.registerFromResources(DEFAULT, "/assets/lin_client/font/harmony.ttf");
        FontRenderer.registerFromResources(ICON, "/fonts/icon.ttf");
        FontRenderer.registerFromResources(MATERIAL_SYMBOLS, "/fonts/MaterialSymbolsRounded.ttf");
        FontRenderer.registerFromResources(SCRIPT, "/fonts/segoe_script.ttf");
        FontRenderer.registerFromResources(LIN_BOLD, "/assets/lin/font/alibaba-bold.ttf");
        Path windowsSymbols = Path.of("C:/Windows/Fonts/seguisym.ttf", new String[0]);
        if (Files.isRegularFile(windowsSymbols, new LinkOption[0])) {
            FontRenderer.registerFromFile(SYMBOL_FALLBACK, windowsSymbols);
        }
    }

    @Environment(value=EnvType.CLIENT)
    private record FontKey(String fontName, int sizeBits) {
    }

    @Environment(value=EnvType.CLIENT)
    public static class Segment {
        public final String text;
        public final float size;
        public final int argb;
        public final String fontName;
        public final float gap;

        public Segment(String text, float size, int argb) {
            this(text, size, argb, FontRenderer.DEFAULT, 0.0f);
        }

        public Segment(String text, float size, int argb, String fontName) {
            this(text, size, argb, fontName, 0.0f);
        }

        public Segment(String text, float size, int argb, String fontName, float gap) {
            this.text = text;
            this.size = size;
            this.argb = argb;
            this.fontName = fontName;
            this.gap = gap;
        }
    }

    @Environment(value=EnvType.CLIENT)
    private record WidthKey(String fontName, int sizeBits, String text) {
    }
}


