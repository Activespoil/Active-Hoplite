/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.platform.Window
 *  io.github.humbleui.skija.BackendRenderTarget
 *  io.github.humbleui.skija.Canvas
 *  io.github.humbleui.skija.ColorSpace
 *  io.github.humbleui.skija.ColorType
 *  io.github.humbleui.skija.DirectContext
 *  io.github.humbleui.skija.Surface
 *  io.github.humbleui.skija.SurfaceOrigin
 *  net.fabricmc.api.EnvType
 *  net.fabricmc.api.Environment
 *  net.minecraft.client.Minecraft
 *  org.lwjgl.opengl.GL11
 *  org.lwjgl.opengl.GL30
 */
package com.linclient.client.render.skia;

import com.linclient.client.render.skia.SkiaGlState;
import com.mojang.blaze3d.platform.Window;
import io.github.humbleui.skija.BackendRenderTarget;
import io.github.humbleui.skija.Canvas;
import io.github.humbleui.skija.ColorSpace;
import io.github.humbleui.skija.ColorType;
import io.github.humbleui.skija.DirectContext;
import io.github.humbleui.skija.Surface;
import io.github.humbleui.skija.SurfaceOrigin;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.Minecraft;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL30;

@Environment(value=EnvType.CLIENT)
public final class SkiaGlBackend {
    private DirectContext context;
    private BackendRenderTarget renderTarget;
    private Surface surface;
    private Canvas canvas;
    private SkiaGlState state;
    private int width = -1;
    private int height = -1;
    private int framebufferId = -1;
    private boolean drawing = false;

    public Canvas begin() {
        return this.begin(0);
    }

    public Canvas begin(int targetFramebufferId) {
        if (this.drawing) {
            return this.canvas;
        }
        Window window = Minecraft.getInstance().getWindow();
        int targetW = Math.max(1, window.getWidth());
        int targetH = Math.max(1, window.getHeight());
        this.ensureState();
        long saveStarted = BlurPerformanceProbe.begin(4);
        try { this.state.push(); }
        finally { BlurPerformanceProbe.end(4, saveStarted); }
        try {
            long surfaceStarted = BlurPerformanceProbe.begin(5);
            try { this.ensureSurface(targetW, targetH, targetFramebufferId); }
            finally { BlurPerformanceProbe.end(5, surfaceStarted); }
            if (this.surface == null || this.canvas == null) {
                restoreGlState();
                return null;
            }
            long resetStarted = BlurPerformanceProbe.begin(6);
            try { this.context.resetGLAll(); }
            finally { BlurPerformanceProbe.end(6, resetStarted); }
            GL11.glDisable((int)2884);
            GL11.glDisable((int)2929);
            GL11.glDisable((int)3089);
            GL11.glDisable((int)2960);
            GL11.glDepthMask((boolean)false);
            GL11.glColorMask((boolean)true, (boolean)true, (boolean)true, (boolean)true);
            GL11.glViewport((int)0, (int)0, (int)targetW, (int)targetH);
            GL11.glClearColor((float)0.0f, (float)0.0f, (float)0.0f, (float)0.0f);
            this.canvas.restoreToCount(1);
            this.canvas.resetMatrix();
            this.canvas.save();
            this.canvas.scale((float)window.getGuiScale(), (float)window.getGuiScale());
            this.drawing = true;
            return this.canvas;
        }
        catch (RuntimeException e) {
            restoreGlState();
            throw e;
        }
    }

    public void end() {
        if (!this.drawing || this.surface == null) {
            return;
        }
        try {
            this.canvas.restore();
            flushPending();
        }
        finally {
            this.drawing = false;
            restoreGlState();
        }
    }

    /** Submit in order without closing the canvas or restoring the outer game state. */
    public void flushPending() {
        if (!this.drawing || this.surface == null) return;
        long started = BlurPerformanceProbe.begin(3);
        int gpuSample = BlurPerformanceProbe.beginGpu(1);
        try { this.context.flushAndSubmit(this.surface); }
        finally { BlurPerformanceProbe.endGpu(gpuSample); BlurPerformanceProbe.end(3, started); }
    }

    /** NativeGlass restores its touched GL state; invalidate Skija's driver-state cache. */
    public void resumeAfterGlass() {
        if (!this.drawing || this.context == null) return;
        long started = BlurPerformanceProbe.begin(6);
        try { this.context.resetGLAll(); }
        finally { BlurPerformanceProbe.end(6, started); }
    }

    private void restoreGlState() {
        long started = BlurPerformanceProbe.begin(7);
        try { this.state.pop(); }
        finally { BlurPerformanceProbe.end(7, started); }
    }

    public boolean isDrawing() {
        return this.drawing;
    }

    public boolean hasSurface() {
        return this.surface != null;
    }

    /** Capture needs the context, but no destination canvas or empty HUD submission. */
    public DirectContext contextForCapture() {
        if (this.context != null) return this.context;
        this.ensureState();
        this.state.push();
        try {
            this.ensureContext();
            return this.context;
        } finally {
            restoreGlState();
        }
    }

    public DirectContext getContext() {
        return this.context;
    }

    public void resetCanvasState() {
        this.drawing = false;
        if (this.canvas != null) {
            this.canvas.restoreToCount(1);
            this.canvas.resetMatrix();
        }
    }

    public void runWithSavedState(Runnable action) {
        this.ensureState();
        this.state.push();
        try {
            action.run();
        }
        finally {
            restoreGlState();
        }
    }

    public void destroy() {
        SkiaGlState savedState;
        if (this.drawing) {
            this.end();
        }
        if ((savedState = this.state) != null) {
            savedState.push();
        }
        try {
            this.resetCanvasState();
            if (this.surface != null) {
                this.surface.close();
                this.surface = null;
            }
            if (this.renderTarget != null) {
                this.renderTarget.close();
                this.renderTarget = null;
            }
            if (this.context != null) {
                this.context.close();
                this.context = null;
            }
            this.canvas = null;
            this.width = -1;
            this.height = -1;
            this.framebufferId = -1;
        }
        finally {
            if (savedState != null) {
                savedState.pop();
            }
            this.state = null;
        }
    }

    private void ensureSurface(int targetW, int targetH, int targetFramebufferId) {
        this.ensureContext();
        if (this.surface != null && targetW == this.width && targetH == this.height && targetFramebufferId == this.framebufferId) {
            return;
        }
        if (this.surface != null) {
            this.surface.close();
            this.surface = null;
        }
        if (this.renderTarget != null) {
            this.renderTarget.close();
            this.renderTarget = null;
        }
        this.renderTarget = BackendRenderTarget.makeGL((int)targetW, (int)targetH, (int)0, (int)8, (int)targetFramebufferId, (int)32856);
        this.surface = Surface.wrapBackendRenderTarget((DirectContext)this.context, (BackendRenderTarget)this.renderTarget, (SurfaceOrigin)SurfaceOrigin.BOTTOM_LEFT, (ColorType)ColorType.RGBA_8888, (ColorSpace)ColorSpace.getSRGB());
        this.canvas = this.surface.getCanvas();
        this.width = targetW;
        this.height = targetH;
        this.framebufferId = targetFramebufferId;
    }

    private void ensureContext() {
        if (this.context != null) {
            return;
        }
        this.context = DirectContext.makeGL();
    }

    private void ensureState() {
        if (this.state != null) {
            return;
        }
        this.state = new SkiaGlState(SkiaGlBackend.readGlVersion());
    }

    private static int readGlVersion() {
        int[] major = new int[1];
        int[] minor = new int[1];
        GL30.glGetIntegerv((int)33307, (int[])major);
        GL30.glGetIntegerv((int)33308, (int[])minor);
        return major[0] * 100 + minor[0] * 10;
    }
}


