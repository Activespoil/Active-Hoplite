package com.linclient.client.gui.clickgui;

import com.linclient.client.render.font.FontRenderer;
import dev.lin.client.cosmetics.font.SharedMenuText;
import io.github.humbleui.skija.Canvas;
import io.github.humbleui.skija.ClipMode;
import io.github.humbleui.types.Rect;
import io.github.humbleui.types.RRect;

/** Direct main-surface text, identical to SettingModule; no intermediate glyph image. */
public final class SharedMenuTextPainter {
    public static void paint(Canvas canvas,SharedMenuText.Frame frame){
        if(frame.lines().isEmpty())return;
        var shell=frame.shell();
        for(int i=0;i<frame.lines().size();i++){
            var line=frame.lines().get(i);
            canvas.save();
            try{
                var clip=line.clip();
                if(clip!=null)canvas.clipRect(Rect.makeLTRB(clip.left(),clip.top(),clip.right(),clip.bottom()));
                for(var cover:frame.covers())if(cover.beforeLine()>i)
                    canvas.clipRRect(RRect.makeXYWH(cover.x(),cover.y(),cover.width(),cover.height(),cover.radius()),ClipMode.DIFFERENCE,true);
                canvas.translate(shell.x(),shell.y());
                canvas.scale(shell.scale(),shell.scale());
                FontRenderer.drawText(canvas,line.text(),line.x(),line.baseline(),line.size(),line.color());
            }finally{canvas.restore();}
        }
    }
    private SharedMenuTextPainter() {}
}
