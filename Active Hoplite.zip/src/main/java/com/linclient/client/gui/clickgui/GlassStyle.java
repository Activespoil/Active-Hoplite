package com.linclient.client.gui.clickgui;

import java.util.Properties;
/** Shared source of truth: workspace shared-ui/assets/lin_client/ui/glass.properties. */
public final class GlassStyle {
 private static final Properties P = new Properties();
 static { try(var in=GlassStyle.class.getResourceAsStream("/assets/lin_client/ui/glass.properties")) { if(in!=null)P.load(in); } catch(java.io.IOException e) { throw new ExceptionInInitializerError(e); } }
 private static int hex(String k,String d){return (int)Long.parseLong(P.getProperty(k,d),16);}
 private static final java.lang.reflect.Method HOST_NUMBER = hostNumber();
 private static final java.lang.reflect.Method HOST_SET = hostSet();
 private static java.lang.reflect.Method hostNumber(){try{return Class.forName("dev.lin.client.cosmetics.ui.GlassStyle").getMethod("number",String.class,float.class);}catch(ReflectiveOperationException e){return null;}}
 private static java.lang.reflect.Method hostSet(){try{return Class.forName("dev.lin.client.cosmetics.ui.GlassStyle").getMethod("set",String.class,float.class);}catch(ReflectiveOperationException e){return null;}}
 public static float number(String k,float d){if(HOST_NUMBER!=null)try{return ((Number)HOST_NUMBER.invoke(null,k,d)).floatValue();}catch(ReflectiveOperationException e){throw new IllegalStateException(e);}return Float.parseFloat(P.getProperty(k,Float.toString(d)));}
 public static void set(String k,float v){if(HOST_SET!=null)try{HOST_SET.invoke(null,k,v);return;}catch(ReflectiveOperationException e){throw new IllegalStateException(e);}P.setProperty(k,Float.toString(v));}
 public static int panel(){return ((int)number("panel.alpha",122)<<24)|hex("panel.rgb","807E78");}
 public static int control(){return hex("control.argb","207F7D77");}
 public static int hover(){return hex("hover.argb","30FFFFFF");}
 public static int selected(){return hex("selected.argb","50FFFFFF");}
 public static int border(){int base=hex("border.argb","30FFFFFF");return ((int)number("border.alpha",base>>>24)<<24)|(base&0xFFFFFF);}
 public static float borderWidth(){return number("border.width",1f);}
 public static int blur(){return (int)number("blur.radius",10);}
 public static float scale(float w,float h){return Math.max(.01f,Math.min(w*number("width.fraction",.88f)/1000f,h*number("height.fraction",.80f)/620f));}
 private GlassStyle(){}
}
