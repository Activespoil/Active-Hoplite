package com.linclient.client.gui.clickgui;
import com.linclient.client.render.skia.SkiaBlurRenderer;
import com.linclient.client.render.skia.SkiaGlBackend;
import com.linclient.client.render.skia.SkiaRenderer;
import com.mojang.blaze3d.opengl.GlTexture;
import com.mojang.blaze3d.opengl.GlDevice;
import com.mojang.blaze3d.systems.RenderSystem;
import io.github.humbleui.skija.Canvas;
import io.github.humbleui.skija.DirectContext;
import net.minecraft.client.Minecraft;
import dev.lin.client.cosmetics.ui.ClientShell;
/** One effects implementation, captured after HUD and before screen content. */
public final class SharedScreenEffects {
 private static final SkiaGlBackend BACKEND=new SkiaGlBackend();
 private static float clamp01(float v){return Math.max(0,Math.min(1,v));}
 private static boolean menuActive(){
  var screen=dev.lin.client.cosmetics.ui.SystemNavigation.activeScreen();
  return screen instanceof dev.lin.client.cosmetics.ui.CosmeticLockerScreen;
 }
 public static boolean renderNative(){
  Minecraft minecraft=Minecraft.getInstance();
  if(!menuActive())return false;
  if(SkiaRenderer.isMobileArm64())return false;
  if(!(minecraft.getMainRenderTarget().getColorTexture() instanceof GlTexture texture)
      || !(RenderSystem.getDevice() instanceof GlDevice device))return false;
  int fbo=texture.getFbo(device.directStateAccess(),minecraft.getMainRenderTarget().getDepthTexture());
  Canvas canvas=BACKEND.begin(fbo);if(canvas==null)return false;
  try{
   int w=minecraft.getWindow().getGuiScaledWidth(),h=minecraft.getWindow().getGuiScaledHeight();
   var l=ClientShell.layout(w,h);
   float vis=1f;
   var screen=dev.lin.client.cosmetics.ui.SystemNavigation.activeScreen();
   if(screen instanceof dev.lin.client.cosmetics.ui.CosmeticLockerScreen locker)vis=locker.openProgress();
   float tScale=0.96f+0.04f*vis;
   float liftY=(1f-vis)*12f*l.scale();
   float pw=ClientShell.totalWidth()*l.scale()*tScale;
   float ph=ClientShell.HEIGHT*l.scale()*tScale;
   float px=(w-pw)*0.5f;
   float py=(h-ph)*0.5f+liftY;
   draw(canvas,BACKEND.getContext(),minecraft,fbo,w,h,px,py,pw,ph,l.scale()*tScale);
  }finally{BACKEND.end();}
  return true;
 }
 /** Menu glyphs use the same main framebuffer and direct FontRenderer path as function cards. */
 public static void renderMenuText(){
  var frame=dev.lin.client.cosmetics.font.SharedMenuText.takeFrame();
  if(!menuActive())return;
  var active=dev.lin.client.cosmetics.ui.SystemNavigation.activeScreen();
  var locker=active instanceof dev.lin.client.cosmetics.ui.CosmeticLockerScreen l?l:null;
  boolean intro=locker!=null && locker.isIntroActive();
  if(frame.lines().isEmpty() && !intro)return;
  Minecraft minecraft=Minecraft.getInstance();
  if(!(minecraft.getMainRenderTarget().getColorTexture() instanceof GlTexture texture)
      || !(RenderSystem.getDevice() instanceof GlDevice device))return;
  int fbo=texture.getFbo(device.directStateAccess(),minecraft.getMainRenderTarget().getDepthTexture());
  Canvas canvas=BACKEND.begin(fbo);if(canvas==null)return;
  try{
   if(!frame.lines().isEmpty())SharedMenuTextPainter.paint(canvas,frame);
   if(intro){
    int w=minecraft.getWindow().getGuiScaledWidth(),h=minecraft.getWindow().getGuiScaledHeight();
    ActiveOpenAnimation.paint(canvas,locker,w,h);
   }
  }finally{BACKEND.end();}
 }
 /** Draw the same FontRenderer as settings into 1:1 pixel GPU textures before GUI submission. */
 public static void prepareText(){
  var blur=SkiaBlurRenderer.getInstance();
  if(!menuActive() && blur.hasMenuCapture()) BACKEND.runWithSavedState(blur::releaseMenuCapture);
  var jobs=dev.lin.client.cosmetics.font.SharedScreenText.takePending();
  if(jobs.isEmpty())return;
  if(!(RenderSystem.getDevice() instanceof GlDevice device))throw new IllegalStateException("Shared glyphs require OpenGL");
  DirectContext context=BACKEND.contextForCapture();
  BACKEND.runWithSavedState(()->{
   context.resetGLAll();
   try{
    for(var job:jobs){
     if(job.texture().getTexture().isClosed())continue;
     GlTexture texture=(GlTexture)job.texture().getTexture();
     int w=texture.getWidth(0),h=texture.getHeight(0);
     int fbo=texture.getFbo(device.directStateAccess(),null);
     SharedGlyphPainter.paint(context,fbo,w,h,job.text(),job.size(),job.color(),job.density(),job.font());
    }
   }finally{context.resetGLAll();}
  });
 }
 public static void draw(Canvas canvas,DirectContext context,Minecraft minecraft,int framebufferId,
                         int width,int height,float panelX,float panelY,float panelWidth,float panelHeight,float scale){
        float outsideOpacity=clamp01(GlassStyle.number("backdrop.alpha",0f));
        float outsideStrength=Math.max(0f,Math.min(2f,
                GlassStyle.number("backdrop.blur.radius",GlassStyle.blur())/10f));
        float panelStrength=Math.max(0f,Math.min(2f,
                GlassStyle.number("panel.blur.radius",GlassStyle.blur())/10f));
        SkiaBlurRenderer.getInstance().renderMenu(canvas,context,minecraft,framebufferId,width,height,
                new SkiaBlurRenderer.Region(panelX,panelY,panelWidth,panelHeight,20*scale),
                Math.round(outsideOpacity*255f)<<24,outsideStrength,panelStrength,scale,
                GlassStyle.number("lens.refraction",.9f),GlassStyle.number("lens.dispersion",.65f));

    }

}
