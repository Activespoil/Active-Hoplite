package com.linclient.client.gui.clickgui;

import com.linclient.client.render.font.FontRenderer;
import io.github.humbleui.skija.*;

/** The settings font renderer, cached without PNG conversion or fixed-resolution resampling. */
public final class SharedGlyphPainter {
    public static void paint(DirectContext context,int fbo,int width,int height,
                             String text,float size,int color,float density) {
        paint(context,fbo,width,height,text,size,color,density,FontRenderer.DEFAULT);
    }
    public static void paint(DirectContext context,int fbo,int width,int height,
                             String text,float size,int color,float density,String font) {
        // Native GUI UV (0,0) samples the first uploaded row. TOP_LEFT puts that row
        // at the same texture origin, unlike the main-window BOTTOM_LEFT surface.
        try(var target=BackendRenderTarget.makeGL(width,height,0,0,fbo,0x8058);
            var surface=Surface.wrapBackendRenderTarget(context,target,SurfaceOrigin.TOP_LEFT,
                    ColorType.RGBA_8888,ColorSpace.getSRGB())) {
            Canvas canvas=surface.getCanvas();
            canvas.clear(0);canvas.scale(density,density);
            float padding=Math.max(size*.5f,3/density);
            FontRenderer.drawText(canvas,text,padding,padding+size,size,color,font);
            context.flushAndSubmit(surface);
        }
    }
    private SharedGlyphPainter() {}
}
