package com.linclient.client.gui.clickgui;

import com.linclient.client.render.font.FontRenderer;
import dev.lin.client.cosmetics.ui.ClientShell;
import dev.lin.client.cosmetics.ui.CosmeticLockerScreen;
import io.github.humbleui.skija.Canvas;
import io.github.humbleui.skija.Image;
import io.github.humbleui.skija.Paint;
import io.github.humbleui.skija.PaintMode;
import io.github.humbleui.skija.PaintStrokeCap;
import io.github.humbleui.skija.SamplingMode;
import io.github.humbleui.skija.Shader;
import io.github.humbleui.types.RRect;
import io.github.humbleui.types.Rect;

import java.io.InputStream;

/**
 * High-FPS 1.35s Scheme A ("Orbital Glide") opening animation for Active.
 * Reuses static native Skija Paint objects and uses hardware bilinear sampling
 * to keep per-frame overhead sub-millisecond.
 */
public final class ActiveOpenAnimation {
    public static final float DURATION_SECONDS = 1.35F;
    public static final float SKIP_TARGET_SECONDS = 0.80F;
    public static final float OPAQUE_CURTAIN_END_SECONDS = 0.78F;
    private static final String LOGO_RESOURCE = "/assets/lin_client/textures/ui/brand_logo.png";

    private static final Paint VEIL_PAINT = new Paint().setAntiAlias(true);
    private static final Paint HALO_PAINT = new Paint().setAntiAlias(true);
    private static final Paint GLINT_PAINT = new Paint().setAntiAlias(true);
    private static final Paint ARC_PAINT = new Paint().setAntiAlias(true)
            .setMode(PaintMode.STROKE).setStrokeCap(PaintStrokeCap.ROUND).setStrokeWidth(2.1F);
    private static final Paint FINE_ARC_PAINT = new Paint().setAntiAlias(true)
            .setMode(PaintMode.STROKE).setStrokeCap(PaintStrokeCap.ROUND).setStrokeWidth(1.05F);
    private static final Paint DOT_GLOW_PAINT = new Paint().setAntiAlias(true);
    private static final Paint DOT_CORE_PAINT = new Paint().setAntiAlias(true);
    private static final Paint SEP_PAINT = new Paint().setAntiAlias(true);
    private static final Paint TRACK_PAINT = new Paint().setAntiAlias(true);
    private static final Paint FILL_PAINT = new Paint().setAntiAlias(true);
    private static final Paint TIP_GLOW_PAINT = new Paint().setAntiAlias(true);
    private static final Paint IMG_PAINT = new Paint().setAntiAlias(true);
    private static final Paint RIM_PAINT = new Paint().setAntiAlias(true)
            .setMode(PaintMode.STROKE).setStrokeWidth(1.6F);

    private static Image cachedLogo;
    private static boolean logoAttempted;
    private static float cachedTitleW = -1.0F;
    private static float cachedLeftW = -1.0F;
    private static float cachedRightW = -1.0F;

    private ActiveOpenAnimation() {}

    private static Image logo() {
        if (!logoAttempted) {
            logoAttempted = true;
            try (InputStream in = ActiveOpenAnimation.class.getResourceAsStream(LOGO_RESOURCE)) {
                if (in != null) {
                    byte[] bytes = in.readAllBytes();
                    if (bytes.length > 0) {
                        cachedLogo = Image.makeDeferredFromEncodedBytes(bytes);
                    }
                }
            } catch (Exception ignored) {
                cachedLogo = null;
            }
        }
        return cachedLogo;
    }

    public static void paint(Canvas canvas, CosmeticLockerScreen locker, int guiW, int guiH) {
        if (canvas == null || locker == null || !locker.isIntroActive()) return;
        float t = locker.introElapsedSeconds();
        if (t < 0.0F || t >= DURATION_SECONDS) return;

        var layout = ClientShell.layout(guiW, guiH);
        float vis = locker.openProgress();
        float tScale = 0.96F + 0.04F * vis;
        float liftY = (1.0F - vis) * 12.0F * layout.scale();
        float ps = layout.scale() * tScale;
        float totalW = ClientShell.totalWidth();
        float totalH = ClientShell.HEIGHT;
        float pw = totalW * ps;
        float ph = totalH * ps;
        float px = (guiW - pw) * 0.5F;
        float py = (guiH - ph) * 0.5F + liftY;

        float curtainFadeOut = smoothstep(0.84F, 1.30F, t);
        float curtainAlpha = (1.0F - curtainFadeOut) * smoothstep(0.0F, 0.14F, t);

        float cx = totalW * 0.5F;
        float cy = totalH * 0.45F;

        // Exact header logo target center & size in shell virtual space: ClientShell draws at (17, 22, 26x26).
        float targetCx = 30.0F;
        float targetCy = 35.0F;
        float startSize = 78.0F;
        float endSize = 26.0F;

        canvas.save();
        try {
            RRect panelClip = RRect.makeXYWH(px, py, pw, ph, 20.0F * ps);
            canvas.clipRRect(panelClip, true);
            canvas.translate(px, py);
            canvas.scale(ps, ps);

            // 1. Dark obsidian veil + ambient emerald halo + specular glint
            if (curtainAlpha > 0.004F) {
                VEIL_PAINT.setColor(argb(0.985F * curtainAlpha, 0x0D1311));
                canvas.drawRect(Rect.makeWH(totalW, totalH), VEIL_PAINT);

                float haloIn = easeOutCubic(range(t, 0.04F, 0.50F));
                float haloOut = 1.0F - smoothstep(0.76F, 1.12F, t);
                float haloAlpha = haloIn * haloOut * 0.28F;
                if (haloAlpha > 0.004F) {
                    float haloRadius = 165.0F + 38.0F * haloIn;
                    try (Shader glow = Shader.makeRadialGradient(
                            cx, cy, haloRadius,
                            new int[]{argb(haloAlpha, 0x76E02A), argb(haloAlpha * 0.35F, 0x2F781B), 0x00000000},
                            new float[]{0.0F, 0.48F, 1.0F})) {
                        HALO_PAINT.setShader(glow);
                        canvas.drawCircle(cx, cy, haloRadius, HALO_PAINT);
                        HALO_PAINT.setShader(null);
                    }
                }

                float glintP = range(t, 0.38F, 0.92F);
                if (glintP > 0.0F && glintP < 1.0F) {
                    float glintEnv = (float) Math.sin(glintP * Math.PI) * curtainAlpha;
                    float gx = -260.0F + (totalW + 520.0F) * easeInOutCubic(glintP);
                    try (Shader sweep = Shader.makeLinearGradient(
                            gx - 140.0F, 0.0F, gx + 140.0F, totalH * 0.55F,
                            new int[]{0x00FFFFFF, argb(0.070F * glintEnv, 0xC8FFAA), 0x00FFFFFF},
                            new float[]{0.0F, 0.5F, 1.0F})) {
                        GLINT_PAINT.setShader(sweep);
                        canvas.drawRect(Rect.makeWH(totalW, totalH), GLINT_PAINT);
                        GLINT_PAINT.setShader(null);
                    }
                }
            }

            // 2. Twin precision orbital rings + glowing leading orbital particle
            float ringIn = easeOutCubic(range(t, 0.04F, 0.52F));
            float ringOut = 1.0F - smoothstep(0.76F, 1.05F, t);
            float ringAlpha = ringIn * ringOut;
            if (ringAlpha > 0.005F) {
                float expand = 1.0F + 0.24F * smoothstep(0.76F, 1.06F, t);
                float outerR = 54.0F * (0.86F + 0.14F * ringIn) * expand;
                float innerR = 66.0F * (0.90F + 0.10F * ringIn) * expand;

                float outerStart = -110.0F + t * 185.0F;
                float outerSweep = 290.0F * easeOutCubic(range(t, 0.04F, 0.62F));
                ARC_PAINT.setColor(argb(0.92F * ringAlpha, 0x76E02A));
                canvas.drawArc(cx - outerR, cy - outerR, cx + outerR, cy + outerR,
                        outerStart, outerSweep, false, ARC_PAINT);

                if (outerSweep > 12.0F) {
                    double tipRad = Math.toRadians(outerStart + outerSweep);
                    float dotX = cx + (float) Math.cos(tipRad) * outerR;
                    float dotY = cy + (float) Math.sin(tipRad) * outerR;
                    DOT_GLOW_PAINT.setColor(argb(0.38F * ringAlpha, 0x76E02A));
                    DOT_CORE_PAINT.setColor(argb(0.98F * ringAlpha, 0xEEFFE0));
                    canvas.drawCircle(dotX, dotY, 5.4F, DOT_GLOW_PAINT);
                    canvas.drawCircle(dotX, dotY, 2.2F, DOT_CORE_PAINT);
                }

                float innerStart = 60.0F - t * 120.0F;
                float innerSweep = 210.0F * easeOutCubic(range(t, 0.10F, 0.68F));
                FINE_ARC_PAINT.setColor(argb(0.24F * ringAlpha, 0xFFFFFF));
                canvas.drawArc(cx - innerR, cy - innerR, cx + innerR, cy + innerR,
                        innerStart, innerSweep, false, FINE_ARC_PAINT);
            }

            // 3. Wordmark "ACTIVE" + subtitle + emerald shimmer progress bar
            float textIn = easeOutCubic(range(t, 0.16F, 0.50F));
            float textOut = 1.0F - smoothstep(0.76F, 1.02F, t);
            float textAlpha = textIn * textOut;
            if (textAlpha > 0.005F) {
                float textSlideY = (1.0F - textIn) * 12.0F + smoothstep(0.76F, 1.02F, t) * 8.0F;
                if (cachedTitleW < 0.0F) {
                    cachedTitleW = FontRenderer.measureTextWidth("ACTIVE", 23.0F, FontRenderer.LIN_BOLD);
                    cachedLeftW = FontRenderer.measureTextWidth("HOPLITE", 10.5F, FontRenderer.DEFAULT);
                    cachedRightW = FontRenderer.measureTextWidth("COSMETICS", 10.5F, FontRenderer.DEFAULT);
                }
                FontRenderer.drawText(canvas, "ACTIVE", cx - cachedTitleW * 0.5F, cy + 92.0F + textSlideY,
                        23.0F, argb(textAlpha, 0xF4F7F6), FontRenderer.LIN_BOLD);

                float subIn = easeOutCubic(range(t, 0.24F, 0.54F));
                float subAlpha = subIn * textOut;
                if (subAlpha > 0.005F) {
                    float dotGap = 14.0F;
                    float subX = cx - (cachedLeftW + dotGap + cachedRightW) * 0.5F;
                    float subY = cy + 112.0F + textSlideY;
                    FontRenderer.drawText(canvas, "HOPLITE", subX, subY, 10.5F, argb(subAlpha, 0x8F9C97));
                    FontRenderer.drawText(canvas, "COSMETICS", subX + cachedLeftW + dotGap, subY, 10.5F, argb(subAlpha, 0xC6D3CE));
                    SEP_PAINT.setColor(argb(subAlpha, 0x76E02A));
                    canvas.drawCircle(subX + cachedLeftW + dotGap * 0.5F, subY - 3.6F, 2.0F, SEP_PAINT);
                }

                float barW = 144.0F;
                float barH = 2.6F;
                float barX = cx - barW * 0.5F;
                float barY = cy + 126.0F + textSlideY;
                float fillP = easeInOutCubic(range(t, 0.20F, 0.84F));
                TRACK_PAINT.setColor(argb(0.75F * textAlpha, 0x1E2925));
                canvas.drawRRect(RRect.makeXYWH(barX, barY, barW, barH, barH * 0.5F), TRACK_PAINT);
                float filled = Math.max(barH, barW * fillP);
                FILL_PAINT.setColor(argb(textAlpha, 0x76E02A));
                canvas.drawRRect(RRect.makeXYWH(barX, barY, filled, barH, barH * 0.5F), FILL_PAINT);
                if (fillP > 0.02F && fillP < 0.99F) {
                    TIP_GLOW_PAINT.setColor(argb(0.55F * textAlpha, 0xD8FFAD));
                    canvas.drawCircle(barX + filled, barY + barH * 0.5F, 3.8F, TIP_GLOW_PAINT);
                }
            }

            // 4. Active A star-orbit logo: springs in at center, then glides to exact top-left header slot
            Image logoImg = logo();
            if (logoImg != null) {
                float logoIn = easeOutBack(range(t, 0.05F, 0.44F));
                float logoAlphaIn = smoothstep(0.05F, 0.24F, t);
                float flyP = easeInOutCubic(range(t, 0.80F, 1.25F));
                float handoffOut = 1.0F - smoothstep(1.25F, 1.34F, t);
                float logoAlpha = logoAlphaIn * handoffOut;

                if (logoAlpha > 0.005F) {
                    float breath = 1.0F + 0.018F * (float) Math.sin(range(t, 0.44F, 0.80F) * Math.PI);
                    float size = lerp(startSize * (0.68F + 0.32F * logoIn) * breath, endSize, flyP);
                    float drawCx = lerp(cx, targetCx, flyP);
                    float drawCy = lerp(cy, targetCy, flyP);

                    Rect src = Rect.makeWH(logoImg.getWidth(), logoImg.getHeight());
                    Rect dst = Rect.makeXYWH(drawCx - size * 0.5F, drawCy - size * 0.5F, size, size);
                    IMG_PAINT.setAlphaf(logoAlpha);
                    canvas.drawImageRect(logoImg, src, dst, SamplingMode.LINEAR, IMG_PAINT, true);
                }
            }

            // 5. Crisp emerald rim highlight pulse as curtain lifts
            float rimP = range(t, 0.82F, 1.34F);
            if (rimP > 0.0F && rimP < 1.0F) {
                RIM_PAINT.setColor(argb((float) Math.sin(rimP * Math.PI) * 0.48F, 0x76E02A));
                canvas.drawRRect(RRect.makeXYWH(0.8F, 0.8F, totalW - 1.6F, totalH - 1.6F, 19.2F), RIM_PAINT);
            }
        } finally {
            canvas.restore();
        }
    }

    private static float clamp01(float v) { return Math.max(0.0F, Math.min(1.0F, v)); }
    private static float range(float t, float start, float end) { return clamp01((t - start) / Math.max(0.0001F, end - start)); }
    private static float smoothstep(float start, float end, float t) { float x = range(t, start, end); return x * x * (3.0F - 2.0F * x); }
    private static float easeOutCubic(float x) { float inv = 1.0F - clamp01(x); return 1.0F - inv * inv * inv; }
    private static float easeInOutCubic(float x) { x = clamp01(x); return x < 0.5F ? 4.0F * x * x * x : 1.0F - (float) Math.pow(-2.0F * x + 2.0F, 3.0) * 0.5F; }
    private static float easeOutBack(float x) { x = clamp01(x); float c1 = 1.35F; float u = x - 1.0F; return 1.0F + (c1 + 1.0F) * u * u * u + c1 * u * u; }
    private static float lerp(float a, float b, float t) { return a + (b - a) * t; }
    private static int argb(float alpha, int rgb) { return (Math.max(0, Math.min(255, Math.round(clamp01(alpha) * 255.0F))) << 24) | (rgb & 0x00FFFFFF); }
}
