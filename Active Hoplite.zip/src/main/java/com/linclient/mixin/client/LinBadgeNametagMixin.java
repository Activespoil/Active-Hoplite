package com.linclient.mixin.client;

import com.linclient.client.presence.LinBadge;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.state.EntityRenderState;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** A final render-state decoration retains vanilla visibility, teams and entity identity. */
@Mixin(value = EntityRenderer.class, priority = 900)
public abstract class LinBadgeNametagMixin {
    @Inject(method = "extractRenderState", at = @At("TAIL"))
    private void lin$peer(Entity entity, EntityRenderState state, float delta, CallbackInfo callback) {
        if (entity instanceof Player player && state.nameTag != null) {
            state.nameTag = LinBadge.nametag(
                    dev.lin.client.cosmetics.vip.VipIcons.decorate(state.nameTag, player.getUUID()),
                    player.getUUID());
        }
    }
}
