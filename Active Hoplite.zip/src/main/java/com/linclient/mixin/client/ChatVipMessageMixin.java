package com.linclient.mixin.client;

import dev.lin.client.cosmetics.vip.VipIcons;
import net.minecraft.client.gui.components.ChatComponent;
import net.minecraft.network.chat.Component;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

/** Decorate messages before Minecraft splits them into visible chat lines. */
@Mixin(ChatComponent.class)
public abstract class ChatVipMessageMixin {
    @ModifyVariable(method = "addMessage(Lnet/minecraft/network/chat/Component;Lnet/minecraft/network/chat/MessageSignature;Lnet/minecraft/client/GuiMessageTag;)V",
            at = @At("HEAD"), argsOnly = true, ordinal = 0)
    private Component lin$decorateVipSender(Component message) {
        return VipIcons.detectedChat(com.linclient.client.presence.LinBadgeChat.detected(message));
    }
}
