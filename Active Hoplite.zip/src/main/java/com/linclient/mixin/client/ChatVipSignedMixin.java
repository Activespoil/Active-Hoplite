package com.linclient.mixin.client;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.mojang.authlib.GameProfile;
import dev.lin.client.cosmetics.vip.VipIcons;
import net.minecraft.client.GuiMessageTag;
import net.minecraft.client.gui.components.ChatComponent;
import net.minecraft.client.multiplayer.chat.ChatListener;
import net.minecraft.network.chat.ChatType;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MessageSignature;
import net.minecraft.network.chat.PlayerChatMessage;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import java.time.Instant;

/** Signed player chat has a sender UUID, so VIP works on every server format. */
@Mixin(ChatListener.class)
public abstract class ChatVipSignedMixin {
    @WrapOperation(method = "method_44943", at = @At(value = "INVOKE",
            target = "Lnet/minecraft/class_338;method_44811(Lnet/minecraft/class_2561;Lnet/minecraft/class_7469;Lnet/minecraft/class_7591;)V", remap = false), remap = false)
    private void lin$decorateSignedChat(ChatComponent chat, Component displayed,
                                       MessageSignature signature, GuiMessageTag tag,
                                       Operation<Void> original, ChatType.Bound bound,
                                       PlayerChatMessage signed, Component source,
                                       GameProfile profile, boolean secure, Instant received) {
        Component decorated = com.linclient.client.presence.LinBadgeChat.signed(displayed, bound.name(), profile.id());
        original.call(chat, VipIcons.decorateChat(decorated, profile.id()), signature, tag);
    }
}
