package com.linclient.mixin.client;

import dev.lin.client.cosmetics.config.CosmeticConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.world.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Shows the local player's own nametag in third-person perspective when enabled. */
@Mixin(LivingEntityRenderer.class)
public abstract class ThirdPersonNametagMixin {
    @Inject(method = "shouldShowName(Lnet/minecraft/world/entity/LivingEntity;D)Z", at = @At("HEAD"), cancellable = true)
    private void lin$thirdPersonOwnNametag(LivingEntity entity, double distanceToCameraSq, CallbackInfoReturnable<Boolean> cir) {
        if (cir.isCancelled() || !CosmeticConfig.thirdPersonNametag()) return;
        Minecraft client = Minecraft.getInstance();
        if (client.player != null && entity == client.player
                && !client.options.getCameraType().isFirstPerson()
                && !client.player.isInvisible()) {
            cir.setReturnValue(Minecraft.renderNames());
        }
    }
}
