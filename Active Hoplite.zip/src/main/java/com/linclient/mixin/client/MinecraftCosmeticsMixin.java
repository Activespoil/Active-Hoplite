package com.linclient.mixin.client;

import com.linclient.client.gui.clickgui.SharedScreenEffects;
import dev.lin.client.cosmetics.font.SharedMenuText;
import dev.lin.client.cosmetics.ui.ClientFeaturePolicy;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Minimal Minecraft lifecycle hooks for Skia text and runtime menu policy. */
@Mixin(Minecraft.class)
public class MinecraftCosmeticsMixin {
    @Inject(method = "setScreen", at = @At("HEAD"), cancellable = true)
    private void linclient$worldFeatureBoundary(Screen next, CallbackInfo ci) {
        if (!ClientFeaturePolicy.permits(next)) ci.cancel();
    }

    @Inject(method = "runTick", at = @At("HEAD"))
    private void linclient$beginFrame(boolean advanceGameTime, CallbackInfo ci) {
        SharedMenuText.beginFrame();
        ClientFeaturePolicy.tick((Minecraft) (Object) this);
    }

    @Inject(
            method = "runTick",
            at = @At(
                    value = "INVOKE",
                    target = "Lcom/mojang/blaze3d/pipeline/RenderTarget;blitToScreen()V"
            )
    )
    private void linclient$renderCustomScreens(boolean advanceGameTime, CallbackInfo ci) {
        Minecraft client = (Minecraft) (Object) this;
        if (!ClientFeaturePolicy.permits(client.screen)) return;
        SharedScreenEffects.renderMenuText();
    }
}
