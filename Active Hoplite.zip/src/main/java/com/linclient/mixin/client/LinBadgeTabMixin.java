package com.linclient.mixin.client;

import com.linclient.client.presence.LinBadge;
import com.linclient.client.presence.LinPresence;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.PlayerTabOverlay;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;
import net.minecraft.resources.Identifier;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.List;
import java.util.Optional;

/** Only verified Lin rows gain a badge; other players retain their vanilla head/name positions. */
@Mixin(value = PlayerTabOverlay.class, priority = 900)
public abstract class LinBadgeTabMixin {
    @Shadow @Final private Minecraft minecraft;
    @Unique private boolean lin$heads;
    @Unique private int lin$advance;

    @Inject(method = "getPlayerInfos", at = @At("RETURN"))
    private void lin$column(CallbackInfoReturnable<List<PlayerInfo>> callback) {
        lin$advance = minecraft.font.width(LinBadge.prefix());
        lin$heads = minecraft.isLocalServer() || (minecraft.getConnection() != null
                && minecraft.getConnection().getConnection().isEncrypted());
    }

    @Inject(method = "getNameForDisplay", at = @At("RETURN"), cancellable = true)
    private void lin$name(PlayerInfo player, CallbackInfoReturnable<Component> callback) {
        Component name = dev.lin.client.cosmetics.vip.VipIcons.decorate(
                callback.getReturnValue(), player.getProfile().id());
        callback.setReturnValue(LinBadge.tab(name, player.getProfile().id()));
    }

    @WrapOperation(method = "render", at = @At(value = "INVOKE",
            target = "Lnet/minecraft/client/gui/components/PlayerFaceRenderer;draw(Lnet/minecraft/client/gui/GuiGraphics;Lnet/minecraft/resources/Identifier;IIIZZI)V"))
    private void lin$head(GuiGraphics graphics, Identifier skin, int x, int y, int size, boolean hat,
                          boolean upsideDown, int color, Operation<Void> original, @Local PlayerInfo player) {
        original.call(graphics, skin, x + (dev.lin.client.cosmetics.config.CosmeticConfig.showTabBadge()
                && LinPresence.visible(player.getProfile().id()) ? lin$advance : 0),
                y, size, hat, upsideDown, color);
    }

    @WrapOperation(method = "render", at = @At(value = "INVOKE",
            target = "Lnet/minecraft/client/gui/GuiGraphics;drawString(Lnet/minecraft/client/gui/Font;Lnet/minecraft/network/chat/Component;III)V"))
    private void lin$beforeHead(GuiGraphics graphics, Font font, Component text, int x, int y, int color, Operation<Void> original) {
        if (!lin$heads) { original.call(graphics, font, text, x, y, color); return; }
        boolean marked = text.visit((style, value) -> LinBadge.isBadge(style) && value.indexOf('\uFFFC') >= 0
                ? Optional.of(true) : Optional.<Boolean>empty(), Style.EMPTY).orElse(false);
        if (!marked) { original.call(graphics, font, text, x, y, color); return; }
        graphics.drawString(font, LinBadge.icon(), x - 9, y, color, false);
        original.call(graphics, font, LinBadge.strip(text), x + lin$advance, y, color);
    }
}
