package com.linclient.mixin.client;
import com.linclient.client.render.skia.BlurPerformanceProbe;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/** Optional diagnostics: observe existing draw stages without adding flushes or changing rendering. */
@Mixin(net.minecraft.client.gui.render.GuiRenderer.class)
public abstract class GuiRenderPerformanceMixin {
    // This boundary is after the HUD has been submitted, before the native screen.
    // It uses the same Skia effects as the settings page instead of vanilla blur.
    @org.spongepowered.asm.mixin.injection.Redirect(method="draw",at=@At(value="INVOKE",
            target="Lnet/minecraft/client/renderer/GameRenderer;processBlurEffect()V"),require=1)
    private void lin$sharedScreenEffects(net.minecraft.client.renderer.GameRenderer renderer) {
        if (!com.linclient.client.gui.clickgui.SharedScreenEffects.renderNative()) renderer.processBlurEffect();
    }
    @Unique private long lin$GuiCpu;
    @Unique private int lin$GuiGpu;
    @Inject(method="render",at=@At("HEAD"),require=1)
    private void lin$beginGui(CallbackInfo ci) {
        com.linclient.client.gui.clickgui.SharedScreenEffects.prepareText();
        lin$GuiCpu=BlurPerformanceProbe.begin(10);
        lin$GuiGpu=BlurPerformanceProbe.beginGpu(3);
    }
    @Inject(method="render",at=@At("RETURN"),require=0)
    private void lin$endGui(CallbackInfo ci) {
        BlurPerformanceProbe.endGpu(lin$GuiGpu);
        BlurPerformanceProbe.end(10,lin$GuiCpu);
    }
    @Unique private long lin$ItemsCpu;
    @Unique private int lin$ItemsGpu;
    @Inject(method="prepareItemElements",at=@At("HEAD"),require=0)
    private void lin$beginItems(CallbackInfo ci) {
        lin$ItemsCpu=BlurPerformanceProbe.begin(11);
        lin$ItemsGpu=BlurPerformanceProbe.beginGpu(4);
    }
    @Inject(method="prepareItemElements",at=@At("RETURN"),require=0)
    private void lin$endItems(CallbackInfo ci) {
        BlurPerformanceProbe.endGpu(lin$ItemsGpu);
        BlurPerformanceProbe.end(11,lin$ItemsCpu);
    }
    @Unique private long lin$AtlasCpu;
    @Inject(method="renderItemToAtlas",at=@At("HEAD"),require=0)
    private void lin$beginAtlas(CallbackInfo ci) {
        lin$AtlasCpu=BlurPerformanceProbe.begin(12);
    }
    @Inject(method="renderItemToAtlas",at=@At("RETURN"),require=0)
    private void lin$endAtlas(CallbackInfo ci) {
        BlurPerformanceProbe.end(12,lin$AtlasCpu);
    }
    @Unique private long lin$PipCpu;
    @Unique private int lin$PipGpu;
    @Inject(method="preparePictureInPicture",at=@At("HEAD"),require=0)
    private void lin$beginPip(CallbackInfo ci) {
        lin$PipCpu=BlurPerformanceProbe.begin(13);
        lin$PipGpu=BlurPerformanceProbe.beginGpu(5);
    }
    @Inject(method="preparePictureInPicture",at=@At("RETURN"),require=0)
    private void lin$endPip(CallbackInfo ci) {
        BlurPerformanceProbe.endGpu(lin$PipGpu);
        BlurPerformanceProbe.end(13,lin$PipCpu);
    }
}
